package dev.anilbeesetti.nextplayer.core.model

import java.io.Serializable
import java.util.Date

data class Video(
    val id: Long,
    val path: String,
    val parentPath: String = "",
    val duration: Long,
    val uriString: String,
    val nameWithExtension: String,
    val width: Int,
    val height: Int,
    val size: Long,
    val playbackPosition: Long? = null,
    val dateModified: Long = 0,
    val dateAdded: Long = 0,
    val formattedDuration: String = "",
    val formattedFileSize: String = "",
    val format: String? = null,
    val lastPlayedAt: Date? = null,
    val videoStream: VideoStreamInfo? = null,
    val audioStreams: List<AudioStreamInfo> = emptyList(),
    val subtitleStreams: List<SubtitleStreamInfo> = emptyList(),
) : Serializable {

    val displayName: String = nameWithExtension.substringBeforeLast(".")
    val playedPercentage: Float? = playbackPosition?.let { playbackPosition ->
        when {
            duration <= 0 -> null
            playbackPosition < 0 -> 1f
            else -> playbackPosition.toFloat() / duration.toFloat()
        }
    }

    companion object {
        val sample = Video(
            id = 8,
            path = "/storage/emulated/0/Download/Avengers Endgame (2019) BluRay x264.mp4",
            parentPath = "/storage/emulated/0/Download",
            uriString = "",
            nameWithExtension = "Avengers Endgame (2019) BluRay x264.mp4",
            duration = 1000,
            width = 1920,
            height = 1080,
            size = 1000,
            formattedDuration = "29.36",
            formattedFileSize = "320KB",
            playbackPosition = 200,
        )
    }
}

fun List<Video>.recentPlayed(): Video? =
    filter { it.lastPlayedAt != null }.sortedByDescending { it.lastPlayedAt?.time }.firstOrNull()

fun Video.isNew(nowMillis: Long = System.currentTimeMillis(), thresholdDays: Int = 7): Boolean {
    if (lastPlayedAt != null || thresholdDays <= 0) return false
    val addedAtMillis = dateAdded * 1000L
    return nowMillis - addedAtMillis in 0..(thresholdDays * 24L * 60L * 60L * 1000L)
}
