package kotlinx.android.synthetic.main.dialog_select_alarm_sound
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_select_alarm_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_select_alarm_scrollview)
val Dialog.dialog_select_alarm_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_select_alarm_scrollview)
val Fragment.dialog_select_alarm_scrollview: android.widget.ScrollView get() = requireView().findViewById<android.widget.ScrollView>(R.id.dialog_select_alarm_scrollview)
val View.dialog_select_alarm_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_select_alarm_scrollview)
val Activity.dialog_select_alarm_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_select_alarm_holder)
val Dialog.dialog_select_alarm_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_select_alarm_holder)
val Fragment.dialog_select_alarm_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.dialog_select_alarm_holder)
val View.dialog_select_alarm_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_select_alarm_holder)
val Activity.dialog_select_alarm_your_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_your_label)
val Dialog.dialog_select_alarm_your_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_your_label)
val Fragment.dialog_select_alarm_your_label: android.widget.TextView get() = requireView().findViewById<android.widget.TextView>(R.id.dialog_select_alarm_your_label)
val View.dialog_select_alarm_your_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_your_label)
val Activity.dialog_select_alarm_your_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_your_radio)
val Dialog.dialog_select_alarm_your_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_your_radio)
val Fragment.dialog_select_alarm_your_radio: android.widget.RadioGroup get() = requireView().findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_your_radio)
val View.dialog_select_alarm_your_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_your_radio)
val Activity.dialog_select_alarm_system_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_system_label)
val Dialog.dialog_select_alarm_system_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_system_label)
val Fragment.dialog_select_alarm_system_label: android.widget.TextView get() = requireView().findViewById<android.widget.TextView>(R.id.dialog_select_alarm_system_label)
val View.dialog_select_alarm_system_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_system_label)
val Activity.dialog_select_alarm_system_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_system_radio)
val Dialog.dialog_select_alarm_system_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_system_radio)
val Fragment.dialog_select_alarm_system_radio: android.widget.RadioGroup get() = requireView().findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_system_radio)
val View.dialog_select_alarm_system_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_system_radio)
