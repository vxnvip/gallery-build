package kotlinx.android.synthetic.main.item_property
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.property_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.property_holder)
val Dialog.property_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.property_holder)
val Fragment.property_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.property_holder)
val View.property_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.property_holder)
val Activity.property_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_label)
val Dialog.property_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_label)
val Fragment.property_label: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_label)
val View.property_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_label)
val Activity.property_value: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_value)
val Dialog.property_value: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_value)
val Fragment.property_value: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_value)
val View.property_value: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_value)
