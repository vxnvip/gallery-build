package kotlinx.android.synthetic.main.dialog_add_blocked_number
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Dialog.dialog_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Fragment.dialog_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val View.dialog_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Activity.add_blocked_number_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.add_blocked_number_hint)
val Dialog.add_blocked_number_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.add_blocked_number_hint)
val Fragment.add_blocked_number_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.add_blocked_number_hint)
val View.add_blocked_number_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.add_blocked_number_hint)
val Activity.add_blocked_number_edittext get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.add_blocked_number_edittext)
val Dialog.add_blocked_number_edittext get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.add_blocked_number_edittext)
val Fragment.add_blocked_number_edittext get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.add_blocked_number_edittext)
val View.add_blocked_number_edittext get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.add_blocked_number_edittext)
