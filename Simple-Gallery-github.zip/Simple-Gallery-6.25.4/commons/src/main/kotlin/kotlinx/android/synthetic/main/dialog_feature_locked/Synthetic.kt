package kotlinx.android.synthetic.main.dialog_feature_locked
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.feature_locked_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.feature_locked_holder)
val Dialog.feature_locked_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.feature_locked_holder)
val Fragment.feature_locked_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.feature_locked_holder)
val View.feature_locked_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.feature_locked_holder)
val Activity.feature_locked_image: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.feature_locked_image)
val Dialog.feature_locked_image: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.feature_locked_image)
val Fragment.feature_locked_image: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.feature_locked_image)
val View.feature_locked_image: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.feature_locked_image)
val Activity.feature_locked_description: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.feature_locked_description)
val Dialog.feature_locked_description: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.feature_locked_description)
val Fragment.feature_locked_description: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.feature_locked_description)
val View.feature_locked_description: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.feature_locked_description)
