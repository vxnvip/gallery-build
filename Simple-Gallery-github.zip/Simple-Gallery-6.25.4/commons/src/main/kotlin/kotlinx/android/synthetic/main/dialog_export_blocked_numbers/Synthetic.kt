package kotlinx.android.synthetic.main.dialog_export_blocked_numbers
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.export_blocked_numbers_wrapper get() = findViewById<android.widget.ScrollView>(R.id.export_blocked_numbers_wrapper)
val Dialog.export_blocked_numbers_wrapper get() = findViewById<android.widget.ScrollView>(R.id.export_blocked_numbers_wrapper)
val Fragment.export_blocked_numbers_wrapper get() = requireView().findViewById<android.widget.ScrollView>(R.id.export_blocked_numbers_wrapper)
val View.export_blocked_numbers_wrapper get() = findViewById<android.widget.ScrollView>(R.id.export_blocked_numbers_wrapper)
val Activity.export_blocked_numbers_holder get() = findViewById<android.widget.LinearLayout>(R.id.export_blocked_numbers_holder)
val Dialog.export_blocked_numbers_holder get() = findViewById<android.widget.LinearLayout>(R.id.export_blocked_numbers_holder)
val Fragment.export_blocked_numbers_holder get() = requireView().findViewById<android.widget.LinearLayout>(R.id.export_blocked_numbers_holder)
val View.export_blocked_numbers_holder get() = findViewById<android.widget.LinearLayout>(R.id.export_blocked_numbers_holder)
val Activity.export_blocked_numbers_folder_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder_label)
val Dialog.export_blocked_numbers_folder_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder_label)
val Fragment.export_blocked_numbers_folder_label get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder_label)
val View.export_blocked_numbers_folder_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder_label)
val Activity.export_blocked_numbers_folder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder)
val Dialog.export_blocked_numbers_folder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder)
val Fragment.export_blocked_numbers_folder get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder)
val View.export_blocked_numbers_folder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder)
val Activity.export_blocked_numbers_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.export_blocked_numbers_hint)
val Dialog.export_blocked_numbers_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.export_blocked_numbers_hint)
val Fragment.export_blocked_numbers_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.export_blocked_numbers_hint)
val View.export_blocked_numbers_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.export_blocked_numbers_hint)
val Activity.export_blocked_numbers_filename get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.export_blocked_numbers_filename)
val Dialog.export_blocked_numbers_filename get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.export_blocked_numbers_filename)
val Fragment.export_blocked_numbers_filename get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.export_blocked_numbers_filename)
val View.export_blocked_numbers_filename get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.export_blocked_numbers_filename)
