package kotlinx.android.synthetic.main.dialog_select_alarm_sound.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_select_alarm_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_select_alarm_scrollview)
val View.dialog_select_alarm_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_select_alarm_holder)
val View.dialog_select_alarm_your_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_your_label)
val View.dialog_select_alarm_your_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_your_radio)
val View.dialog_select_alarm_system_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dialog_select_alarm_system_label)
val View.dialog_select_alarm_system_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_select_alarm_system_radio)
