package kotlinx.android.synthetic.main.item_contact_with_number
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.item_contact_frame get() = findViewById<android.widget.FrameLayout>(R.id.item_contact_frame)
val Dialog.item_contact_frame get() = findViewById<android.widget.FrameLayout>(R.id.item_contact_frame)
val Fragment.item_contact_frame get() = requireView().findViewById<android.widget.FrameLayout>(R.id.item_contact_frame)
val View.item_contact_frame get() = findViewById<android.widget.FrameLayout>(R.id.item_contact_frame)
val Activity.item_contact_holder get() = findViewById<android.widget.RelativeLayout>(R.id.item_contact_holder)
val Dialog.item_contact_holder get() = findViewById<android.widget.RelativeLayout>(R.id.item_contact_holder)
val Fragment.item_contact_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.item_contact_holder)
val View.item_contact_holder get() = findViewById<android.widget.RelativeLayout>(R.id.item_contact_holder)
val Activity.item_contact_image get() = findViewById<android.widget.ImageView>(R.id.item_contact_image)
val Dialog.item_contact_image get() = findViewById<android.widget.ImageView>(R.id.item_contact_image)
val Fragment.item_contact_image get() = requireView().findViewById<android.widget.ImageView>(R.id.item_contact_image)
val View.item_contact_image get() = findViewById<android.widget.ImageView>(R.id.item_contact_image)
val Activity.item_contact_name get() = findViewById<android.widget.TextView>(R.id.item_contact_name)
val Dialog.item_contact_name get() = findViewById<android.widget.TextView>(R.id.item_contact_name)
val Fragment.item_contact_name get() = requireView().findViewById<android.widget.TextView>(R.id.item_contact_name)
val View.item_contact_name get() = findViewById<android.widget.TextView>(R.id.item_contact_name)
val Activity.item_contact_number get() = findViewById<android.widget.TextView>(R.id.item_contact_number)
val Dialog.item_contact_number get() = findViewById<android.widget.TextView>(R.id.item_contact_number)
val Fragment.item_contact_number get() = requireView().findViewById<android.widget.TextView>(R.id.item_contact_number)
val View.item_contact_number get() = findViewById<android.widget.TextView>(R.id.item_contact_number)
val Activity.drag_handle_icon get() = findViewById<android.widget.ImageView>(R.id.drag_handle_icon)
val Dialog.drag_handle_icon get() = findViewById<android.widget.ImageView>(R.id.drag_handle_icon)
val Fragment.drag_handle_icon get() = requireView().findViewById<android.widget.ImageView>(R.id.drag_handle_icon)
val View.drag_handle_icon get() = findViewById<android.widget.ImageView>(R.id.drag_handle_icon)
