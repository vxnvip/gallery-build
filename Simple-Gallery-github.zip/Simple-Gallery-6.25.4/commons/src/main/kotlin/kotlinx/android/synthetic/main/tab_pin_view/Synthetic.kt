package kotlinx.android.synthetic.main.tab_pin.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.pin_lock_holder get() = findViewById<com.simplemobiletools.commons.views.PinTab>(R.id.pin_lock_holder)
val View.pin_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_lock_title)
val View.pin_lock_current_pin get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_lock_current_pin)
val View.pin_1 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_1)
val View.pin_2 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_2)
val View.pin_3 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_3)
val View.pin_4 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_4)
val View.pin_5 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_5)
val View.pin_6 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_6)
val View.pin_7 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_7)
val View.pin_8 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_8)
val View.pin_9 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_9)
val View.pin_c get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_c)
val View.pin_0 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pin_0)
val View.pin_ok get() = findViewById<android.widget.ImageView>(R.id.pin_ok)
