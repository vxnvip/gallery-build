package kotlinx.android.synthetic.main.item_license.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.license_layout get() = findViewById<android.widget.LinearLayout>(R.id.license_layout)
val View.license_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val View.license_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
