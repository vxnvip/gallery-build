package kotlinx.android.synthetic.main.tab_rename_simple.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.rename_simple_holder: com.simplemobiletools.commons.views.RenameSimpleTab get() = findViewById<com.simplemobiletools.commons.views.RenameSimpleTab>(R.id.rename_simple_holder)
val View.rename_simple_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_simple_hint)
val View.rename_simple_value: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_simple_value)
val View.rename_simple_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.rename_simple_radio_group)
val View.rename_simple_radio_append: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_append)
val View.rename_simple_radio_prepend: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_prepend)
