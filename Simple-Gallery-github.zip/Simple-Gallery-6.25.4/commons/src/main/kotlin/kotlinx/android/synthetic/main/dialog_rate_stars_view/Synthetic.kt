package kotlinx.android.synthetic.main.dialog_rate_stars.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val View.rate_stars_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rate_stars_text)
val View.rate_stars_holder get() = findViewById<android.widget.LinearLayout>(R.id.rate_stars_holder)
val View.rate_star_1 get() = findViewById<android.widget.ImageView>(R.id.rate_star_1)
val View.rate_star_2 get() = findViewById<android.widget.ImageView>(R.id.rate_star_2)
val View.rate_star_3 get() = findViewById<android.widget.ImageView>(R.id.rate_star_3)
val View.rate_star_4 get() = findViewById<android.widget.ImageView>(R.id.rate_star_4)
val View.rate_star_5 get() = findViewById<android.widget.ImageView>(R.id.rate_star_5)
