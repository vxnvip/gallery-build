package kotlinx.android.synthetic.main.dialog_upgrade_to_pro
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.upgrade_to_pro get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.upgrade_to_pro)
val Dialog.upgrade_to_pro get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.upgrade_to_pro)
val Fragment.upgrade_to_pro get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.upgrade_to_pro)
val View.upgrade_to_pro get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.upgrade_to_pro)
