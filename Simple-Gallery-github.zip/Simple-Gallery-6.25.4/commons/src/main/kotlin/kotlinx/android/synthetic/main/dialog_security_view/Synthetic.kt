package kotlinx.android.synthetic.main.dialog_security.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_scrollview: com.simplemobiletools.commons.views.MyScrollView get() = findViewById<com.simplemobiletools.commons.views.MyScrollView>(R.id.dialog_scrollview)
val View.dialog_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val View.dialog_tab_layout: com.google.android.material.tabs.TabLayout get() = findViewById<com.google.android.material.tabs.TabLayout>(R.id.dialog_tab_layout)
val View.dialog_tab_pattern: com.google.android.material.tabs.TabItem get() = findViewById<com.google.android.material.tabs.TabItem>(R.id.dialog_tab_pattern)
val View.dialog_tab_pin: com.google.android.material.tabs.TabItem get() = findViewById<com.google.android.material.tabs.TabItem>(R.id.dialog_tab_pin)
val View.dialog_tab_view_pager: com.simplemobiletools.commons.views.MyDialogViewPager get() = findViewById<com.simplemobiletools.commons.views.MyDialogViewPager>(R.id.dialog_tab_view_pager)
