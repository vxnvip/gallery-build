package kotlinx.android.synthetic.main.item_property.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.property_holder get() = findViewById<android.widget.LinearLayout>(R.id.property_holder)
val View.property_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_label)
val View.property_value get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_value)
