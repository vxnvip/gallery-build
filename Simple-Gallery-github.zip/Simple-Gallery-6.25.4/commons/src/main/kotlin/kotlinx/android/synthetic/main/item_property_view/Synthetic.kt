package kotlinx.android.synthetic.main.item_property.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.property_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.property_holder)
val View.property_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_label)
val View.property_value: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.property_value)
