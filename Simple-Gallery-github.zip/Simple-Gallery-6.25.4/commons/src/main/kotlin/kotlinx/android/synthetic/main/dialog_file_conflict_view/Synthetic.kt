package kotlinx.android.synthetic.main.dialog_file_conflict.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.conflict_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.conflict_dialog_holder)
val View.conflict_dialog_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.conflict_dialog_title)
val View.conflict_dialog_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.conflict_dialog_radio_group)
val View.conflict_dialog_radio_skip get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.conflict_dialog_radio_skip)
val View.conflict_dialog_radio_overwrite get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.conflict_dialog_radio_overwrite)
val View.conflict_dialog_radio_merge get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.conflict_dialog_radio_merge)
val View.conflict_dialog_radio_keep_both get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.conflict_dialog_radio_keep_both)
val View.conflict_dialog_divider get() = findViewById<android.widget.ImageView>(R.id.conflict_dialog_divider)
val View.conflict_dialog_apply_to_all get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.conflict_dialog_apply_to_all)
