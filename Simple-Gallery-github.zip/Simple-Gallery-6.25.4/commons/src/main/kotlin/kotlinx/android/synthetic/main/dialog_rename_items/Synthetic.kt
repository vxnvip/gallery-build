package kotlinx.android.synthetic.main.dialog_rename_items
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.rename_items_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.rename_items_holder)
val Dialog.rename_items_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.rename_items_holder)
val Fragment.rename_items_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.rename_items_holder)
val View.rename_items_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.rename_items_holder)
val Activity.rename_items_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val Dialog.rename_items_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val Fragment.rename_items_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val View.rename_items_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val Activity.rename_items_value: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val Dialog.rename_items_value: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val Fragment.rename_items_value: com.google.android.material.textfield.TextInputEditText get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val View.rename_items_value: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val Activity.rename_items_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.rename_items_radio_group)
val Dialog.rename_items_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.rename_items_radio_group)
val Fragment.rename_items_radio_group: android.widget.RadioGroup get() = requireView().findViewById<android.widget.RadioGroup>(R.id.rename_items_radio_group)
val View.rename_items_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.rename_items_radio_group)
val Activity.rename_items_radio_append: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_append)
val Dialog.rename_items_radio_append: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_append)
val Fragment.rename_items_radio_append: com.simplemobiletools.commons.views.MyCompatRadioButton get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_append)
val View.rename_items_radio_append: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_append)
val Activity.rename_items_radio_prepend: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_prepend)
val Dialog.rename_items_radio_prepend: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_prepend)
val Fragment.rename_items_radio_prepend: com.simplemobiletools.commons.views.MyCompatRadioButton get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_prepend)
val View.rename_items_radio_prepend: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_prepend)
