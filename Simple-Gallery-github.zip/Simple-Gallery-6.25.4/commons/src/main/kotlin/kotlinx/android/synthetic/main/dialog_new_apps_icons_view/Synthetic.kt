package kotlinx.android.synthetic.main.dialog_new_apps_icons.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val View.new_apps_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.new_apps_text)
val View.new_apps_dialer get() = findViewById<android.widget.ImageView>(R.id.new_apps_dialer)
val View.new_apps_sms_messenger get() = findViewById<android.widget.ImageView>(R.id.new_apps_sms_messenger)
val View.new_apps_voice_recorder get() = findViewById<android.widget.ImageView>(R.id.new_apps_voice_recorder)
