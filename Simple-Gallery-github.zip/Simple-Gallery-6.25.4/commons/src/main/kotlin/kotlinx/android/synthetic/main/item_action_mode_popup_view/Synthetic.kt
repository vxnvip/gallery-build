package kotlinx.android.synthetic.main.item_action_mode_popup.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.cab_item get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.cab_item)
