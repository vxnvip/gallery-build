package kotlinx.android.synthetic.main.tab_rename_simple
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.rename_simple_holder get() = findViewById<com.simplemobiletools.commons.views.RenameSimpleTab>(R.id.rename_simple_holder)
val Dialog.rename_simple_holder get() = findViewById<com.simplemobiletools.commons.views.RenameSimpleTab>(R.id.rename_simple_holder)
val Fragment.rename_simple_holder get() = requireView().findViewById<com.simplemobiletools.commons.views.RenameSimpleTab>(R.id.rename_simple_holder)
val View.rename_simple_holder get() = findViewById<com.simplemobiletools.commons.views.RenameSimpleTab>(R.id.rename_simple_holder)
val Activity.rename_simple_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_simple_hint)
val Dialog.rename_simple_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_simple_hint)
val Fragment.rename_simple_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_simple_hint)
val View.rename_simple_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_simple_hint)
val Activity.rename_simple_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_simple_value)
val Dialog.rename_simple_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_simple_value)
val Fragment.rename_simple_value get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_simple_value)
val View.rename_simple_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_simple_value)
val Activity.rename_simple_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.rename_simple_radio_group)
val Dialog.rename_simple_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.rename_simple_radio_group)
val Fragment.rename_simple_radio_group get() = requireView().findViewById<android.widget.RadioGroup>(R.id.rename_simple_radio_group)
val View.rename_simple_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.rename_simple_radio_group)
val Activity.rename_simple_radio_append get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_append)
val Dialog.rename_simple_radio_append get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_append)
val Fragment.rename_simple_radio_append get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_append)
val View.rename_simple_radio_append get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_append)
val Activity.rename_simple_radio_prepend get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_prepend)
val Dialog.rename_simple_radio_prepend get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_prepend)
val Fragment.rename_simple_radio_prepend get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_prepend)
val View.rename_simple_radio_prepend get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_simple_radio_prepend)
