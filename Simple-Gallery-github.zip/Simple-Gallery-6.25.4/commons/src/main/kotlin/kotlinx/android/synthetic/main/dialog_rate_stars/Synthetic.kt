package kotlinx.android.synthetic.main.dialog_rate_stars
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val Dialog.dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val Fragment.dialog_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val View.dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val Activity.rate_stars_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rate_stars_text)
val Dialog.rate_stars_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rate_stars_text)
val Fragment.rate_stars_text: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rate_stars_text)
val View.rate_stars_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rate_stars_text)
val Activity.rate_stars_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.rate_stars_holder)
val Dialog.rate_stars_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.rate_stars_holder)
val Fragment.rate_stars_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.rate_stars_holder)
val View.rate_stars_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.rate_stars_holder)
val Activity.rate_star_1: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_1)
val Dialog.rate_star_1: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_1)
val Fragment.rate_star_1: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.rate_star_1)
val View.rate_star_1: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_1)
val Activity.rate_star_2: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_2)
val Dialog.rate_star_2: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_2)
val Fragment.rate_star_2: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.rate_star_2)
val View.rate_star_2: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_2)
val Activity.rate_star_3: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_3)
val Dialog.rate_star_3: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_3)
val Fragment.rate_star_3: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.rate_star_3)
val View.rate_star_3: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_3)
val Activity.rate_star_4: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_4)
val Dialog.rate_star_4: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_4)
val Fragment.rate_star_4: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.rate_star_4)
val View.rate_star_4: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_4)
val Activity.rate_star_5: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_5)
val Dialog.rate_star_5: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_5)
val Fragment.rate_star_5: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.rate_star_5)
val View.rate_star_5: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.rate_star_5)
