package kotlinx.android.synthetic.main.dialog_radio_group.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_radio_holder get() = findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val View.dialog_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
