package kotlinx.android.synthetic.main.activity_faq.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.faq_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.faq_coordinator)
val View.faq_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.faq_app_bar_layout)
val View.faq_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.faq_toolbar)
val View.faq_nested_scrollview get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.faq_nested_scrollview)
val View.faq_holder get() = findViewById<android.widget.LinearLayout>(R.id.faq_holder)
