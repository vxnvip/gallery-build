package kotlinx.android.synthetic.main.tab_rename_pattern.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.rename_items_holder: com.simplemobiletools.commons.views.RenamePatternTab get() = findViewById<com.simplemobiletools.commons.views.RenamePatternTab>(R.id.rename_items_holder)
val View.rename_items_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val View.rename_items_value: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val View.rename_items_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rename_items_label)
