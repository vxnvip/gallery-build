package kotlinx.android.synthetic.main.tab_fingerprint.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.fingerprint_lock_holder: com.simplemobiletools.commons.views.FingerprintTab get() = findViewById<com.simplemobiletools.commons.views.FingerprintTab>(R.id.fingerprint_lock_holder)
val View.fingerprint_lock_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_lock_title)
val View.fingerprint_image: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.fingerprint_image)
val View.fingerprint_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_label)
val View.fingerprint_settings: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_settings)
