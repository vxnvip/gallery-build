package kotlinx.android.synthetic.main.tab_fingerprint.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.fingerprint_lock_holder get() = findViewById<com.simplemobiletools.commons.views.FingerprintTab>(R.id.fingerprint_lock_holder)
val View.fingerprint_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_lock_title)
val View.fingerprint_image get() = findViewById<android.widget.ImageView>(R.id.fingerprint_image)
val View.fingerprint_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_label)
val View.fingerprint_settings get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_settings)
