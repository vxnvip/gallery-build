package kotlinx.android.synthetic.main.dialog_message
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.message get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val Dialog.message get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val Fragment.message get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val View.message get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
