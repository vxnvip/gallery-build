package kotlinx.android.synthetic.main.bottom_tablayout_item
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.tab_item_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.tab_item_holder)
val Dialog.tab_item_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.tab_item_holder)
val Fragment.tab_item_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.tab_item_holder)
val View.tab_item_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.tab_item_holder)
val Activity.tab_item_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.tab_item_icon)
val Dialog.tab_item_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.tab_item_icon)
val Fragment.tab_item_icon: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.tab_item_icon)
val View.tab_item_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.tab_item_icon)
val Activity.tab_item_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.tab_item_label)
val Dialog.tab_item_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.tab_item_label)
val Fragment.tab_item_label: android.widget.TextView get() = requireView().findViewById<android.widget.TextView>(R.id.tab_item_label)
val View.tab_item_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.tab_item_label)
