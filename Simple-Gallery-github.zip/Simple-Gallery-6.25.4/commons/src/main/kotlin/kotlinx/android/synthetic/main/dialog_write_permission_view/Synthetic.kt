package kotlinx.android.synthetic.main.dialog_write_permission.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.write_permissions_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.write_permissions_dialog_holder)
val View.write_permissions_dialog_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text)
val View.write_permissions_dialog_image get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image)
val View.write_permissions_dialog_text_sd get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text_sd)
val View.write_permissions_dialog_image_sd get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image_sd)
