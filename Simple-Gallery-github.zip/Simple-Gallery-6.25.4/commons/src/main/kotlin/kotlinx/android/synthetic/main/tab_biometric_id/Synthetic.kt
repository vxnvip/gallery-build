package kotlinx.android.synthetic.main.tab_biometric_id
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.biometric_lock_holder get() = findViewById<com.simplemobiletools.commons.views.BiometricIdTab>(R.id.biometric_lock_holder)
val Dialog.biometric_lock_holder get() = findViewById<com.simplemobiletools.commons.views.BiometricIdTab>(R.id.biometric_lock_holder)
val Fragment.biometric_lock_holder get() = requireView().findViewById<com.simplemobiletools.commons.views.BiometricIdTab>(R.id.biometric_lock_holder)
val View.biometric_lock_holder get() = findViewById<com.simplemobiletools.commons.views.BiometricIdTab>(R.id.biometric_lock_holder)
val Activity.open_biometric_dialog get() = findViewById<com.simplemobiletools.commons.views.MyButton>(R.id.open_biometric_dialog)
val Dialog.open_biometric_dialog get() = findViewById<com.simplemobiletools.commons.views.MyButton>(R.id.open_biometric_dialog)
val Fragment.open_biometric_dialog get() = requireView().findViewById<com.simplemobiletools.commons.views.MyButton>(R.id.open_biometric_dialog)
val View.open_biometric_dialog get() = findViewById<com.simplemobiletools.commons.views.MyButton>(R.id.open_biometric_dialog)
