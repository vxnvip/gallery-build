package kotlinx.android.synthetic.main.dialog_call_confirmation
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Dialog.dialog_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Fragment.dialog_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val View.dialog_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Activity.call_confirm_phone: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.call_confirm_phone)
val Dialog.call_confirm_phone: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.call_confirm_phone)
val Fragment.call_confirm_phone: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.call_confirm_phone)
val View.call_confirm_phone: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.call_confirm_phone)
