package kotlinx.android.synthetic.main.empty_image_view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.empty_image_view: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.empty_image_view)
val Dialog.empty_image_view: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.empty_image_view)
val Fragment.empty_image_view: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.empty_image_view)
val View.empty_image_view: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.empty_image_view)
