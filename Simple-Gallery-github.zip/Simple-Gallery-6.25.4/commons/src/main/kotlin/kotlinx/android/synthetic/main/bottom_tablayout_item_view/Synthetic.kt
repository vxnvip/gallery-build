package kotlinx.android.synthetic.main.bottom_tablayout_item.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.tab_item_holder get() = findViewById<android.widget.LinearLayout>(R.id.tab_item_holder)
val View.tab_item_icon get() = findViewById<android.widget.ImageView>(R.id.tab_item_icon)
val View.tab_item_label get() = findViewById<android.widget.TextView>(R.id.tab_item_label)
