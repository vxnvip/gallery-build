package kotlinx.android.synthetic.main.bottom_tablayout_item.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.tab_item_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.tab_item_holder)
val View.tab_item_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.tab_item_icon)
val View.tab_item_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.tab_item_label)
