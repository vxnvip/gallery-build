package kotlinx.android.synthetic.main.radio_button
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_radio_button get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_button)
val Dialog.dialog_radio_button get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_button)
val Fragment.dialog_radio_button get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_button)
val View.dialog_radio_button get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_button)
