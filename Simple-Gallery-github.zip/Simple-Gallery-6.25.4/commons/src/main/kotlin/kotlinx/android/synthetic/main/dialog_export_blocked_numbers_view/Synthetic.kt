package kotlinx.android.synthetic.main.dialog_export_blocked_numbers.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.export_blocked_numbers_wrapper: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.export_blocked_numbers_wrapper)
val View.export_blocked_numbers_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.export_blocked_numbers_holder)
val View.export_blocked_numbers_folder_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder_label)
val View.export_blocked_numbers_folder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_blocked_numbers_folder)
val View.export_blocked_numbers_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.export_blocked_numbers_hint)
val View.export_blocked_numbers_filename: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.export_blocked_numbers_filename)
