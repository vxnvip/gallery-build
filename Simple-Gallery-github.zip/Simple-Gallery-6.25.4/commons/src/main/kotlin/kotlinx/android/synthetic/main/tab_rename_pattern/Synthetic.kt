package kotlinx.android.synthetic.main.tab_rename_pattern
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.rename_items_holder get() = findViewById<com.simplemobiletools.commons.views.RenamePatternTab>(R.id.rename_items_holder)
val Dialog.rename_items_holder get() = findViewById<com.simplemobiletools.commons.views.RenamePatternTab>(R.id.rename_items_holder)
val Fragment.rename_items_holder get() = requireView().findViewById<com.simplemobiletools.commons.views.RenamePatternTab>(R.id.rename_items_holder)
val View.rename_items_holder get() = findViewById<com.simplemobiletools.commons.views.RenamePatternTab>(R.id.rename_items_holder)
val Activity.rename_items_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val Dialog.rename_items_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val Fragment.rename_items_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val View.rename_items_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val Activity.rename_items_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val Dialog.rename_items_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val Fragment.rename_items_value get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val View.rename_items_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val Activity.rename_items_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rename_items_label)
val Dialog.rename_items_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rename_items_label)
val Fragment.rename_items_label get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rename_items_label)
val View.rename_items_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.rename_items_label)
