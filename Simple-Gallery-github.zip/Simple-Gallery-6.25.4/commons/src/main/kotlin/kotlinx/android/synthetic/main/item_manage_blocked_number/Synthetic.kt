package kotlinx.android.synthetic.main.item_manage_blocked_number
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.manage_blocked_number_holder get() = findViewById<android.widget.RelativeLayout>(R.id.manage_blocked_number_holder)
val Dialog.manage_blocked_number_holder get() = findViewById<android.widget.RelativeLayout>(R.id.manage_blocked_number_holder)
val Fragment.manage_blocked_number_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.manage_blocked_number_holder)
val View.manage_blocked_number_holder get() = findViewById<android.widget.RelativeLayout>(R.id.manage_blocked_number_holder)
val Activity.manage_blocked_number_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_blocked_number_title)
val Dialog.manage_blocked_number_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_blocked_number_title)
val Fragment.manage_blocked_number_title get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_blocked_number_title)
val View.manage_blocked_number_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_blocked_number_title)
val Activity.overflow_menu_icon get() = findViewById<android.widget.ImageView>(R.id.overflow_menu_icon)
val Dialog.overflow_menu_icon get() = findViewById<android.widget.ImageView>(R.id.overflow_menu_icon)
val Fragment.overflow_menu_icon get() = requireView().findViewById<android.widget.ImageView>(R.id.overflow_menu_icon)
val View.overflow_menu_icon get() = findViewById<android.widget.ImageView>(R.id.overflow_menu_icon)
val Activity.overflow_menu_anchor get() = findViewById<android.view.View>(R.id.overflow_menu_anchor)
val Dialog.overflow_menu_anchor get() = findViewById<android.view.View>(R.id.overflow_menu_anchor)
val Fragment.overflow_menu_anchor get() = requireView().findViewById<android.view.View>(R.id.overflow_menu_anchor)
val View.overflow_menu_anchor get() = findViewById<android.view.View>(R.id.overflow_menu_anchor)
