package kotlinx.android.synthetic.main.dialog_change_date_time_format.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.change_date_time_dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.change_date_time_dialog_scrollview)
val View.change_date_time_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.change_date_time_dialog_holder)
val View.change_date_time_dialog_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.change_date_time_dialog_radio_group)
val View.change_date_time_dialog_radio_one get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_one)
val View.change_date_time_dialog_radio_two get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_two)
val View.change_date_time_dialog_radio_three get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_three)
val View.change_date_time_dialog_radio_eight get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_eight)
val View.change_date_time_dialog_radio_seven get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_seven)
val View.change_date_time_dialog_radio_four get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_four)
val View.change_date_time_dialog_radio_five get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_five)
val View.change_date_time_dialog_radio_six get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_six)
val View.sorting_dialog_order_divider get() = findViewById<android.widget.ImageView>(R.id.sorting_dialog_order_divider)
val View.change_date_time_dialog_24_hour get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_date_time_dialog_24_hour)
