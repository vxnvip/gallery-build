package kotlinx.android.synthetic.main.dialog_change_date_time_format.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.change_date_time_dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.change_date_time_dialog_scrollview)
val View.change_date_time_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.change_date_time_dialog_holder)
val View.change_date_time_dialog_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.change_date_time_dialog_radio_group)
val View.change_date_time_dialog_radio_one: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_one)
val View.change_date_time_dialog_radio_two: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_two)
val View.change_date_time_dialog_radio_three: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_three)
val View.change_date_time_dialog_radio_eight: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_eight)
val View.change_date_time_dialog_radio_seven: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_seven)
val View.change_date_time_dialog_radio_four: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_four)
val View.change_date_time_dialog_radio_five: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_five)
val View.change_date_time_dialog_radio_six: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_date_time_dialog_radio_six)
val View.sorting_dialog_order_divider: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.sorting_dialog_order_divider)
val View.change_date_time_dialog_24_hour: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_date_time_dialog_24_hour)
