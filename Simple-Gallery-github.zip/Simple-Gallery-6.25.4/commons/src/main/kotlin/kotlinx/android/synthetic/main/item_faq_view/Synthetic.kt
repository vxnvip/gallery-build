package kotlinx.android.synthetic.main.item_faq.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.faq_layout get() = findViewById<android.widget.LinearLayout>(R.id.faq_layout)
val View.faq_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_title)
val View.faq_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_text)
