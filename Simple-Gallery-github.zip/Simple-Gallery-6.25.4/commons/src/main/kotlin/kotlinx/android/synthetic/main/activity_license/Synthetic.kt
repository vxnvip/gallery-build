package kotlinx.android.synthetic.main.activity_license
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.license_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.license_coordinator)
val Dialog.license_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.license_coordinator)
val Fragment.license_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.license_coordinator)
val View.license_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.license_coordinator)
val Activity.license_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.license_app_bar_layout)
val Dialog.license_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.license_app_bar_layout)
val Fragment.license_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.license_app_bar_layout)
val View.license_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.license_app_bar_layout)
val Activity.license_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.license_toolbar)
val Dialog.license_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.license_toolbar)
val Fragment.license_toolbar: com.google.android.material.appbar.MaterialToolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.license_toolbar)
val View.license_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.license_toolbar)
val Activity.license_nested_scrollview: androidx.core.widget.NestedScrollView get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.license_nested_scrollview)
val Dialog.license_nested_scrollview: androidx.core.widget.NestedScrollView get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.license_nested_scrollview)
val Fragment.license_nested_scrollview: androidx.core.widget.NestedScrollView get() = requireView().findViewById<androidx.core.widget.NestedScrollView>(R.id.license_nested_scrollview)
val View.license_nested_scrollview: androidx.core.widget.NestedScrollView get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.license_nested_scrollview)
val Activity.licenses_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.licenses_holder)
val Dialog.licenses_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.licenses_holder)
val Fragment.licenses_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.licenses_holder)
val View.licenses_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.licenses_holder)
