package kotlinx.android.synthetic.main.tab_fingerprint
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.fingerprint_lock_holder get() = findViewById<com.simplemobiletools.commons.views.FingerprintTab>(R.id.fingerprint_lock_holder)
val Dialog.fingerprint_lock_holder get() = findViewById<com.simplemobiletools.commons.views.FingerprintTab>(R.id.fingerprint_lock_holder)
val Fragment.fingerprint_lock_holder get() = requireView().findViewById<com.simplemobiletools.commons.views.FingerprintTab>(R.id.fingerprint_lock_holder)
val View.fingerprint_lock_holder get() = findViewById<com.simplemobiletools.commons.views.FingerprintTab>(R.id.fingerprint_lock_holder)
val Activity.fingerprint_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_lock_title)
val Dialog.fingerprint_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_lock_title)
val Fragment.fingerprint_lock_title get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_lock_title)
val View.fingerprint_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_lock_title)
val Activity.fingerprint_image get() = findViewById<android.widget.ImageView>(R.id.fingerprint_image)
val Dialog.fingerprint_image get() = findViewById<android.widget.ImageView>(R.id.fingerprint_image)
val Fragment.fingerprint_image get() = requireView().findViewById<android.widget.ImageView>(R.id.fingerprint_image)
val View.fingerprint_image get() = findViewById<android.widget.ImageView>(R.id.fingerprint_image)
val Activity.fingerprint_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_label)
val Dialog.fingerprint_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_label)
val Fragment.fingerprint_label get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_label)
val View.fingerprint_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_label)
val Activity.fingerprint_settings get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_settings)
val Dialog.fingerprint_settings get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_settings)
val Fragment.fingerprint_settings get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_settings)
val View.fingerprint_settings get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.fingerprint_settings)
