package kotlinx.android.synthetic.main.item_contact_without_number.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.item_contact_frame get() = findViewById<android.widget.FrameLayout>(R.id.item_contact_frame)
val View.item_contact_holder get() = findViewById<android.widget.RelativeLayout>(R.id.item_contact_holder)
val View.item_contact_image get() = findViewById<android.widget.ImageView>(R.id.item_contact_image)
val View.item_contact_name get() = findViewById<android.widget.TextView>(R.id.item_contact_name)
val View.drag_handle_icon get() = findViewById<android.widget.ImageView>(R.id.drag_handle_icon)
