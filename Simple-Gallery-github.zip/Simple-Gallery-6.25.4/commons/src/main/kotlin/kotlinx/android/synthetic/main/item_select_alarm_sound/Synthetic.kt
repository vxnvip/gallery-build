package kotlinx.android.synthetic.main.item_select_alarm_sound
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.item_select_alarm_sound: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.item_select_alarm_sound)
val Dialog.item_select_alarm_sound: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.item_select_alarm_sound)
val Fragment.item_select_alarm_sound: com.simplemobiletools.commons.views.MyCompatRadioButton get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.item_select_alarm_sound)
val View.item_select_alarm_sound: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.item_select_alarm_sound)
