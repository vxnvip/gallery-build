package kotlinx.android.synthetic.main.dialog_write_permission_otg.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.write_permissions_dialog_otg_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.write_permissions_dialog_otg_holder)
val View.write_permissions_dialog_otg_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_otg_text)
val View.write_permissions_dialog_otg_image: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_otg_image)
