package kotlinx.android.synthetic.main.dialog_write_permission
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.write_permissions_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.write_permissions_dialog_holder)
val Dialog.write_permissions_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.write_permissions_dialog_holder)
val Fragment.write_permissions_dialog_holder get() = requireView().findViewById<android.widget.LinearLayout>(R.id.write_permissions_dialog_holder)
val View.write_permissions_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.write_permissions_dialog_holder)
val Activity.write_permissions_dialog_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text)
val Dialog.write_permissions_dialog_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text)
val Fragment.write_permissions_dialog_text get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text)
val View.write_permissions_dialog_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text)
val Activity.write_permissions_dialog_image get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image)
val Dialog.write_permissions_dialog_image get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image)
val Fragment.write_permissions_dialog_image get() = requireView().findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image)
val View.write_permissions_dialog_image get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image)
val Activity.write_permissions_dialog_text_sd get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text_sd)
val Dialog.write_permissions_dialog_text_sd get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text_sd)
val Fragment.write_permissions_dialog_text_sd get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text_sd)
val View.write_permissions_dialog_text_sd get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.write_permissions_dialog_text_sd)
val Activity.write_permissions_dialog_image_sd get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image_sd)
val Dialog.write_permissions_dialog_image_sd get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image_sd)
val Fragment.write_permissions_dialog_image_sd get() = requireView().findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image_sd)
val View.write_permissions_dialog_image_sd get() = findViewById<android.widget.ImageView>(R.id.write_permissions_dialog_image_sd)
