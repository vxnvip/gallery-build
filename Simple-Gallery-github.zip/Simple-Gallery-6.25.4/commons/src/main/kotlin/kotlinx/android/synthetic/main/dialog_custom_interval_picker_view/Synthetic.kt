package kotlinx.android.synthetic.main.dialog_custom_interval_picker.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_custom_interval_scrollview get() = findViewById<android.widget.ScrollView>(R.id.dialog_custom_interval_scrollview)
val View.dialog_custom_interval_holder get() = findViewById<android.widget.LinearLayout>(R.id.dialog_custom_interval_holder)
val View.dialog_custom_interval_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.dialog_custom_interval_hint)
val View.dialog_custom_interval_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.dialog_custom_interval_value)
val View.dialog_radio_view get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_view)
val View.dialog_radio_seconds get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_seconds)
val View.dialog_radio_minutes get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_minutes)
val View.dialog_radio_hours get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_hours)
val View.dialog_radio_days get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_days)
