package kotlinx.android.synthetic.main.dialog_title
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_title_textview get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.dialog_title_textview)
val Dialog.dialog_title_textview get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.dialog_title_textview)
val Fragment.dialog_title_textview get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.dialog_title_textview)
val View.dialog_title_textview get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.dialog_title_textview)
