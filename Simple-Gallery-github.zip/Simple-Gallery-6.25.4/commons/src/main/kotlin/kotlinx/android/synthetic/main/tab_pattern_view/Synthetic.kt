package kotlinx.android.synthetic.main.tab_pattern.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.pattern_lock_holder: com.simplemobiletools.commons.views.PatternTab get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val View.pattern_lock_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val View.pattern_lock_view: com.andrognito.patternlockview.PatternLockView get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
