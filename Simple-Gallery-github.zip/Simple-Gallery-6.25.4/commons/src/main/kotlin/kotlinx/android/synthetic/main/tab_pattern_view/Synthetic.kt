package kotlinx.android.synthetic.main.tab_pattern.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.pattern_lock_holder get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val View.pattern_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val View.pattern_lock_view get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
