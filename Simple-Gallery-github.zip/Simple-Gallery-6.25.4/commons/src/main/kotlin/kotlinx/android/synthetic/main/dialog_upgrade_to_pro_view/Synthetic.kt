package kotlinx.android.synthetic.main.dialog_upgrade_to_pro.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.upgrade_to_pro get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.upgrade_to_pro)
