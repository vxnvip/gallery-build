package kotlinx.android.synthetic.main.search_bar
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.search_root get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val Dialog.search_root get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val Fragment.search_root get() = requireView().findViewById<android.widget.FrameLayout>(R.id.search_root)
val View.search_root get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val Activity.search_layout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val Dialog.search_layout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val Fragment.search_layout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.search_layout)
val View.search_layout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val Activity.search_query get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val Dialog.search_query get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val Fragment.search_query get() = requireView().findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val View.search_query get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val Activity.search_previous get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val Dialog.search_previous get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val Fragment.search_previous get() = requireView().findViewById<android.widget.ImageView>(R.id.search_previous)
val View.search_previous get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val Activity.search_next get() = findViewById<android.widget.ImageView>(R.id.search_next)
val Dialog.search_next get() = findViewById<android.widget.ImageView>(R.id.search_next)
val Fragment.search_next get() = requireView().findViewById<android.widget.ImageView>(R.id.search_next)
val View.search_next get() = findViewById<android.widget.ImageView>(R.id.search_next)
val Activity.search_clear get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val Dialog.search_clear get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val Fragment.search_clear get() = requireView().findViewById<android.widget.ImageView>(R.id.search_clear)
val View.search_clear get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val Activity.search_divider get() = findViewById<android.view.View>(R.id.search_divider)
val Dialog.search_divider get() = findViewById<android.view.View>(R.id.search_divider)
val Fragment.search_divider get() = requireView().findViewById<android.view.View>(R.id.search_divider)
val View.search_divider get() = findViewById<android.view.View>(R.id.search_divider)
