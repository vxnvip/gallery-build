package kotlinx.android.synthetic.main.search_bar
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.search_root: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val Dialog.search_root: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val Fragment.search_root: android.widget.FrameLayout get() = requireView().findViewById<android.widget.FrameLayout>(R.id.search_root)
val View.search_root: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val Activity.search_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val Dialog.search_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val Fragment.search_layout: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.search_layout)
val View.search_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val Activity.search_query: com.simplemobiletools.commons.views.MyEditText get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val Dialog.search_query: com.simplemobiletools.commons.views.MyEditText get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val Fragment.search_query: com.simplemobiletools.commons.views.MyEditText get() = requireView().findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val View.search_query: com.simplemobiletools.commons.views.MyEditText get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val Activity.search_previous: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val Dialog.search_previous: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val Fragment.search_previous: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.search_previous)
val View.search_previous: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val Activity.search_next: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_next)
val Dialog.search_next: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_next)
val Fragment.search_next: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.search_next)
val View.search_next: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_next)
val Activity.search_clear: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val Dialog.search_clear: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val Fragment.search_clear: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.search_clear)
val View.search_clear: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val Activity.search_divider: android.view.View get() = findViewById<android.view.View>(R.id.search_divider)
val Dialog.search_divider: android.view.View get() = findViewById<android.view.View>(R.id.search_divider)
val Fragment.search_divider: android.view.View get() = requireView().findViewById<android.view.View>(R.id.search_divider)
val View.search_divider: android.view.View get() = findViewById<android.view.View>(R.id.search_divider)
