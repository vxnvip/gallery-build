package kotlinx.android.synthetic.main.item_filepicker_list
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.list_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.list_item_holder)
val Dialog.list_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.list_item_holder)
val Fragment.list_item_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.list_item_holder)
val View.list_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.list_item_holder)
val Activity.list_item_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.list_item_icon)
val Dialog.list_item_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.list_item_icon)
val Fragment.list_item_icon: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.list_item_icon)
val View.list_item_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.list_item_icon)
val Activity.list_item_text_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.list_item_text_holder)
val Dialog.list_item_text_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.list_item_text_holder)
val Fragment.list_item_text_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.list_item_text_holder)
val View.list_item_text_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.list_item_text_holder)
val Activity.list_item_name: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_name)
val Dialog.list_item_name: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_name)
val Fragment.list_item_name: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_name)
val View.list_item_name: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_name)
val Activity.list_item_details: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_details)
val Dialog.list_item_details: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_details)
val Fragment.list_item_details: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_details)
val View.list_item_details: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.list_item_details)
