package kotlinx.android.synthetic.main.activity_manage_blocked_numbers.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.block_numbers_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.block_numbers_coordinator)
val View.block_numbers_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.block_numbers_app_bar_layout)
val View.block_numbers_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.block_numbers_toolbar)
val View.block_numbers_nested_scrollview: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.block_numbers_nested_scrollview)
val View.manage_blocked_numbers_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.manage_blocked_numbers_wrapper)
val View.block_unknown_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.block_unknown_holder)
val View.block_unknown: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.block_unknown)
val View.block_numbers_divider: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.block_numbers_divider)
val View.manage_blocked_numbers_list: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.manage_blocked_numbers_list)
val View.manage_blocked_numbers_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_blocked_numbers_placeholder)
val View.manage_blocked_numbers_placeholder_2: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_blocked_numbers_placeholder_2)
