package kotlinx.android.synthetic.main.dialog_rename_items.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.rename_items_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.rename_items_holder)
val View.rename_items_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_items_hint)
val View.rename_items_value: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_items_value)
val View.rename_items_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.rename_items_radio_group)
val View.rename_items_radio_append: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_append)
val View.rename_items_radio_prepend: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.rename_items_radio_prepend)
