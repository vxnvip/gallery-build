package kotlinx.android.synthetic.main.dialog_line_color_picker
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.line_color_picker_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.line_color_picker_holder)
val Dialog.line_color_picker_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.line_color_picker_holder)
val Fragment.line_color_picker_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.line_color_picker_holder)
val View.line_color_picker_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.line_color_picker_holder)
val Activity.line_color_picker_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.line_color_picker_icon)
val Dialog.line_color_picker_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.line_color_picker_icon)
val Fragment.line_color_picker_icon: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.line_color_picker_icon)
val View.line_color_picker_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.line_color_picker_icon)
val Activity.primary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.primary_line_color_picker)
val Dialog.primary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.primary_line_color_picker)
val Fragment.primary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = requireView().findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.primary_line_color_picker)
val View.primary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.primary_line_color_picker)
val Activity.secondary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.secondary_line_color_picker)
val Dialog.secondary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.secondary_line_color_picker)
val Fragment.secondary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = requireView().findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.secondary_line_color_picker)
val View.secondary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.secondary_line_color_picker)
val Activity.hex_code: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.hex_code)
val Dialog.hex_code: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.hex_code)
val Fragment.hex_code: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.hex_code)
val View.hex_code: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.hex_code)
