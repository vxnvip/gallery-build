package kotlinx.android.synthetic.main.dialog_filepicker.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.filepicker_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.filepicker_coordinator)
val View.filepicker_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.filepicker_holder)
val View.filepicker_files_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.filepicker_files_holder)
val View.filepicker_breadcrumbs: com.simplemobiletools.commons.views.Breadcrumbs get() = findViewById<com.simplemobiletools.commons.views.Breadcrumbs>(R.id.filepicker_breadcrumbs)
val View.filepicker_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.filepicker_placeholder)
val View.filepicker_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.filepicker_fastscroller)
val View.filepicker_list: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.filepicker_list)
val View.filepicker_favorites_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.filepicker_favorites_holder)
val View.filepicker_favorites_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.filepicker_favorites_label)
val View.filepicker_favorites_list: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.filepicker_favorites_list)
val View.filepicker_fabs_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.filepicker_fabs_holder)
val View.filepicker_fab_show_favorites: com.simplemobiletools.commons.views.MyFloatingActionButton get() = findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.filepicker_fab_show_favorites)
val View.filepicker_fab_show_hidden: com.simplemobiletools.commons.views.MyFloatingActionButton get() = findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.filepicker_fab_show_hidden)
val View.filepicker_fab: com.simplemobiletools.commons.views.MyFloatingActionButton get() = findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.filepicker_fab)
