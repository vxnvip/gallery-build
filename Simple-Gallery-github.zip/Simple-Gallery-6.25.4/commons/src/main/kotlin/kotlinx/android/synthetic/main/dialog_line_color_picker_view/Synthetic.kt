package kotlinx.android.synthetic.main.dialog_line_color_picker.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.line_color_picker_holder get() = findViewById<android.widget.RelativeLayout>(R.id.line_color_picker_holder)
val View.line_color_picker_icon get() = findViewById<android.widget.ImageView>(R.id.line_color_picker_icon)
val View.primary_line_color_picker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.primary_line_color_picker)
val View.secondary_line_color_picker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.secondary_line_color_picker)
val View.hex_code get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.hex_code)
