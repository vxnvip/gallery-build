package kotlinx.android.synthetic.main.dialog_line_color_picker.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.line_color_picker_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.line_color_picker_holder)
val View.line_color_picker_icon: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.line_color_picker_icon)
val View.primary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.primary_line_color_picker)
val View.secondary_line_color_picker: com.simplemobiletools.commons.views.LineColorPicker get() = findViewById<com.simplemobiletools.commons.views.LineColorPicker>(R.id.secondary_line_color_picker)
val View.hex_code: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.hex_code)
