package kotlinx.android.synthetic.main.dialog_textview.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.text_view get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.text_view)
