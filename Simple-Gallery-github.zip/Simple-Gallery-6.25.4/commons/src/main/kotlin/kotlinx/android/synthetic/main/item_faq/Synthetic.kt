package kotlinx.android.synthetic.main.item_faq
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.faq_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.faq_layout)
val Dialog.faq_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.faq_layout)
val Fragment.faq_layout: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.faq_layout)
val View.faq_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.faq_layout)
val Activity.faq_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_title)
val Dialog.faq_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_title)
val Fragment.faq_title: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_title)
val View.faq_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_title)
val Activity.faq_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_text)
val Dialog.faq_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_text)
val Fragment.faq_text: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_text)
val View.faq_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.faq_text)
