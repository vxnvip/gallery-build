package kotlinx.android.synthetic.main.empty_image_view.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.empty_image_view: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.empty_image_view)
