package kotlinx.android.synthetic.main.dialog_properties.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.properties_scrollview get() = findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val View.properties_holder get() = findViewById<android.widget.LinearLayout>(R.id.properties_holder)
