package kotlinx.android.synthetic.main.dialog_whats_new
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.whats_new_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.whats_new_scrollview)
val Dialog.whats_new_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.whats_new_scrollview)
val Fragment.whats_new_scrollview: android.widget.ScrollView get() = requireView().findViewById<android.widget.ScrollView>(R.id.whats_new_scrollview)
val View.whats_new_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.whats_new_scrollview)
val Activity.whats_new_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.whats_new_holder)
val Dialog.whats_new_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.whats_new_holder)
val Fragment.whats_new_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.whats_new_holder)
val View.whats_new_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.whats_new_holder)
val Activity.whats_new_content: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_content)
val Dialog.whats_new_content: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_content)
val Fragment.whats_new_content: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_content)
val View.whats_new_content: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_content)
val Activity.whats_new_disclaimer: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_disclaimer)
val Dialog.whats_new_disclaimer: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_disclaimer)
val Fragment.whats_new_disclaimer: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_disclaimer)
val View.whats_new_disclaimer: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.whats_new_disclaimer)
