package kotlinx.android.synthetic.main.dialog_textview
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.text_view get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.text_view)
val Dialog.text_view get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.text_view)
val Fragment.text_view get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.text_view)
val View.text_view get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.text_view)
