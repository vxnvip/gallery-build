package kotlinx.android.synthetic.main.dialog_rename_item
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.rename_item_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.rename_item_holder)
val Dialog.rename_item_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.rename_item_holder)
val Fragment.rename_item_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.rename_item_holder)
val View.rename_item_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.rename_item_holder)
val Activity.rename_item_title_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_title_hint)
val Dialog.rename_item_title_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_title_hint)
val Fragment.rename_item_title_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_title_hint)
val View.rename_item_title_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_title_hint)
val Activity.rename_item_name: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_name)
val Dialog.rename_item_name: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_name)
val Fragment.rename_item_name: com.google.android.material.textfield.TextInputEditText get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_name)
val View.rename_item_name: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_name)
val Activity.rename_item_extension_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_extension_hint)
val Dialog.rename_item_extension_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_extension_hint)
val Fragment.rename_item_extension_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_extension_hint)
val View.rename_item_extension_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.rename_item_extension_hint)
val Activity.rename_item_extension: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_extension)
val Dialog.rename_item_extension: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_extension)
val Fragment.rename_item_extension: com.google.android.material.textfield.TextInputEditText get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_extension)
val View.rename_item_extension: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.rename_item_extension)
