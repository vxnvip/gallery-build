package kotlinx.android.synthetic.main.dialog_new_apps_icons
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Dialog.dialog_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Fragment.dialog_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val View.dialog_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val Activity.new_apps_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.new_apps_text)
val Dialog.new_apps_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.new_apps_text)
val Fragment.new_apps_text get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.new_apps_text)
val View.new_apps_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.new_apps_text)
val Activity.new_apps_dialer get() = findViewById<android.widget.ImageView>(R.id.new_apps_dialer)
val Dialog.new_apps_dialer get() = findViewById<android.widget.ImageView>(R.id.new_apps_dialer)
val Fragment.new_apps_dialer get() = requireView().findViewById<android.widget.ImageView>(R.id.new_apps_dialer)
val View.new_apps_dialer get() = findViewById<android.widget.ImageView>(R.id.new_apps_dialer)
val Activity.new_apps_sms_messenger get() = findViewById<android.widget.ImageView>(R.id.new_apps_sms_messenger)
val Dialog.new_apps_sms_messenger get() = findViewById<android.widget.ImageView>(R.id.new_apps_sms_messenger)
val Fragment.new_apps_sms_messenger get() = requireView().findViewById<android.widget.ImageView>(R.id.new_apps_sms_messenger)
val View.new_apps_sms_messenger get() = findViewById<android.widget.ImageView>(R.id.new_apps_sms_messenger)
val Activity.new_apps_voice_recorder get() = findViewById<android.widget.ImageView>(R.id.new_apps_voice_recorder)
val Dialog.new_apps_voice_recorder get() = findViewById<android.widget.ImageView>(R.id.new_apps_voice_recorder)
val Fragment.new_apps_voice_recorder get() = requireView().findViewById<android.widget.ImageView>(R.id.new_apps_voice_recorder)
val View.new_apps_voice_recorder get() = findViewById<android.widget.ImageView>(R.id.new_apps_voice_recorder)
