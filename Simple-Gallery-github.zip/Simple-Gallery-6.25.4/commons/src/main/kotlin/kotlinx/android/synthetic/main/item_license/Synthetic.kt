package kotlinx.android.synthetic.main.item_license
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.license_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.license_layout)
val Dialog.license_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.license_layout)
val Fragment.license_layout: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.license_layout)
val View.license_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.license_layout)
val Activity.license_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val Dialog.license_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val Fragment.license_title: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val View.license_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val Activity.license_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
val Dialog.license_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
val Fragment.license_text: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
val View.license_text: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
