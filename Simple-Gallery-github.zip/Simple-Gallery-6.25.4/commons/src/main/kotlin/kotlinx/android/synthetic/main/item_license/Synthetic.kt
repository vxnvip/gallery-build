package kotlinx.android.synthetic.main.item_license
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.license_layout get() = findViewById<android.widget.LinearLayout>(R.id.license_layout)
val Dialog.license_layout get() = findViewById<android.widget.LinearLayout>(R.id.license_layout)
val Fragment.license_layout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.license_layout)
val View.license_layout get() = findViewById<android.widget.LinearLayout>(R.id.license_layout)
val Activity.license_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val Dialog.license_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val Fragment.license_title get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val View.license_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_title)
val Activity.license_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
val Dialog.license_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
val Fragment.license_text get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
val View.license_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.license_text)
