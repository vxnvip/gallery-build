package kotlinx.android.synthetic.main.search_bar.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.search_root: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val View.search_layout: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val View.search_query: com.simplemobiletools.commons.views.MyEditText get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val View.search_previous: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val View.search_next: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_next)
val View.search_clear: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val View.search_divider: android.view.View get() = findViewById<android.view.View>(R.id.search_divider)
