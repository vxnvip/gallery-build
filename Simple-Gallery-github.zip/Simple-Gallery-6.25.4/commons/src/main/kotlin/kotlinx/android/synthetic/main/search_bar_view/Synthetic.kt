package kotlinx.android.synthetic.main.search_bar.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.search_root get() = findViewById<android.widget.FrameLayout>(R.id.search_root)
val View.search_layout get() = findViewById<android.widget.LinearLayout>(R.id.search_layout)
val View.search_query get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.search_query)
val View.search_previous get() = findViewById<android.widget.ImageView>(R.id.search_previous)
val View.search_next get() = findViewById<android.widget.ImageView>(R.id.search_next)
val View.search_clear get() = findViewById<android.widget.ImageView>(R.id.search_clear)
val View.search_divider get() = findViewById<android.view.View>(R.id.search_divider)
