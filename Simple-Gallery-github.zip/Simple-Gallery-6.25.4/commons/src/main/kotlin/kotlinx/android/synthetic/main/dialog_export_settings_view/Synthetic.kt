package kotlinx.android.synthetic.main.dialog_export_settings.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.export_settings_wrapper get() = findViewById<android.widget.ScrollView>(R.id.export_settings_wrapper)
val View.export_settings_holder get() = findViewById<android.widget.LinearLayout>(R.id.export_settings_holder)
val View.export_settings_path_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_settings_path_label)
val View.export_settings_path get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.export_settings_path)
val View.export_settings_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.export_settings_hint)
val View.export_settings_filename get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.export_settings_filename)
