package kotlinx.android.synthetic.main.item_select_alarm_sound.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.item_select_alarm_sound get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.item_select_alarm_sound)
