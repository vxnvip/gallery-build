package kotlinx.android.synthetic.main.dialog_properties
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.properties_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val Dialog.properties_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val Fragment.properties_scrollview: android.widget.ScrollView get() = requireView().findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val View.properties_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val Activity.properties_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.properties_holder)
val Dialog.properties_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.properties_holder)
val Fragment.properties_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.properties_holder)
val View.properties_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.properties_holder)
