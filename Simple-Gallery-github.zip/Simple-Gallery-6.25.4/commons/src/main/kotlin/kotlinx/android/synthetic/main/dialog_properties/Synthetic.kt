package kotlinx.android.synthetic.main.dialog_properties
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.properties_scrollview get() = findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val Dialog.properties_scrollview get() = findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val Fragment.properties_scrollview get() = requireView().findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val View.properties_scrollview get() = findViewById<android.widget.ScrollView>(R.id.properties_scrollview)
val Activity.properties_holder get() = findViewById<android.widget.LinearLayout>(R.id.properties_holder)
val Dialog.properties_holder get() = findViewById<android.widget.LinearLayout>(R.id.properties_holder)
val Fragment.properties_holder get() = requireView().findViewById<android.widget.LinearLayout>(R.id.properties_holder)
val View.properties_holder get() = findViewById<android.widget.LinearLayout>(R.id.properties_holder)
