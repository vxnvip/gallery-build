package kotlinx.android.synthetic.main.dialog_call_confirmation.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_holder)
val View.call_confirm_phone: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.call_confirm_phone)
