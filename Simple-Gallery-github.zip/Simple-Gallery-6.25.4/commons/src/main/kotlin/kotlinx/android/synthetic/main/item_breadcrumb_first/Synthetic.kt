package kotlinx.android.synthetic.main.item_breadcrumb_first
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.breadcrumb_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.breadcrumb_text)
val Dialog.breadcrumb_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.breadcrumb_text)
val Fragment.breadcrumb_text get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.breadcrumb_text)
val View.breadcrumb_text get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.breadcrumb_text)
