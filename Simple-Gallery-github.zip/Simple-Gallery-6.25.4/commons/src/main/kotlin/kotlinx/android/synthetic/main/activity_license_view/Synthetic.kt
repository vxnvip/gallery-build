package kotlinx.android.synthetic.main.activity_license.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.license_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.license_coordinator)
val View.license_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.license_app_bar_layout)
val View.license_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.license_toolbar)
val View.license_nested_scrollview: androidx.core.widget.NestedScrollView get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.license_nested_scrollview)
val View.licenses_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.licenses_holder)
