package kotlinx.android.synthetic.main.activity_license.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.license_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.license_coordinator)
val View.license_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.license_app_bar_layout)
val View.license_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.license_toolbar)
val View.license_nested_scrollview get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.license_nested_scrollview)
val View.licenses_holder get() = findViewById<android.widget.LinearLayout>(R.id.licenses_holder)
