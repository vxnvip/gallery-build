package kotlinx.android.synthetic.main.dialog_create_new_folder.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val View.folder_path_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_path_hint)
val View.folder_path get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_path)
val View.folder_name_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_name_hint)
val View.folder_name get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_name)
