package kotlinx.android.synthetic.main.dialog_create_new_folder.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val View.folder_path_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_path_hint)
val View.folder_path: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_path)
val View.folder_name_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_name_hint)
val View.folder_name: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_name)
