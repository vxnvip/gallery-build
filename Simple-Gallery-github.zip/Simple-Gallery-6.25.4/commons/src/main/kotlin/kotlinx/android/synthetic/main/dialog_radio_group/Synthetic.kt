package kotlinx.android.synthetic.main.dialog_radio_group
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_radio_holder get() = findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val Dialog.dialog_radio_holder get() = findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val Fragment.dialog_radio_holder get() = requireView().findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val View.dialog_radio_holder get() = findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val Activity.dialog_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
val Dialog.dialog_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
val Fragment.dialog_radio_group get() = requireView().findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
val View.dialog_radio_group get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
