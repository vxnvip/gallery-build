package kotlinx.android.synthetic.main.dialog_radio_group
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_radio_holder: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val Dialog.dialog_radio_holder: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val Fragment.dialog_radio_holder: android.widget.ScrollView get() = requireView().findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val View.dialog_radio_holder: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_radio_holder)
val Activity.dialog_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
val Dialog.dialog_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
val Fragment.dialog_radio_group: android.widget.RadioGroup get() = requireView().findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
val View.dialog_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_group)
