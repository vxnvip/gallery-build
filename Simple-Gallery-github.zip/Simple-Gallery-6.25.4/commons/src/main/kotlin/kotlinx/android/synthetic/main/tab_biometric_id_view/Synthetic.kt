package kotlinx.android.synthetic.main.tab_biometric_id.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.biometric_lock_holder: com.simplemobiletools.commons.views.BiometricIdTab get() = findViewById<com.simplemobiletools.commons.views.BiometricIdTab>(R.id.biometric_lock_holder)
val View.open_biometric_dialog: com.simplemobiletools.commons.views.MyButton get() = findViewById<com.simplemobiletools.commons.views.MyButton>(R.id.open_biometric_dialog)
