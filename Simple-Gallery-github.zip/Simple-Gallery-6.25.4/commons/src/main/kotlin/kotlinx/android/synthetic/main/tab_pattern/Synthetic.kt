package kotlinx.android.synthetic.main.tab_pattern
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.pattern_lock_holder get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val Dialog.pattern_lock_holder get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val Fragment.pattern_lock_holder get() = requireView().findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val View.pattern_lock_holder get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val Activity.pattern_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val Dialog.pattern_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val Fragment.pattern_lock_title get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val View.pattern_lock_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val Activity.pattern_lock_view get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
val Dialog.pattern_lock_view get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
val Fragment.pattern_lock_view get() = requireView().findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
val View.pattern_lock_view get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
