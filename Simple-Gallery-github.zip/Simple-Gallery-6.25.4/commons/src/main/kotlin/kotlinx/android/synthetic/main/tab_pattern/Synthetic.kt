package kotlinx.android.synthetic.main.tab_pattern
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.pattern_lock_holder: com.simplemobiletools.commons.views.PatternTab get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val Dialog.pattern_lock_holder: com.simplemobiletools.commons.views.PatternTab get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val Fragment.pattern_lock_holder: com.simplemobiletools.commons.views.PatternTab get() = requireView().findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val View.pattern_lock_holder: com.simplemobiletools.commons.views.PatternTab get() = findViewById<com.simplemobiletools.commons.views.PatternTab>(R.id.pattern_lock_holder)
val Activity.pattern_lock_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val Dialog.pattern_lock_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val Fragment.pattern_lock_title: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val View.pattern_lock_title: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.pattern_lock_title)
val Activity.pattern_lock_view: com.andrognito.patternlockview.PatternLockView get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
val Dialog.pattern_lock_view: com.andrognito.patternlockview.PatternLockView get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
val Fragment.pattern_lock_view: com.andrognito.patternlockview.PatternLockView get() = requireView().findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
val View.pattern_lock_view: com.andrognito.patternlockview.PatternLockView get() = findViewById<com.andrognito.patternlockview.PatternLockView>(R.id.pattern_lock_view)
