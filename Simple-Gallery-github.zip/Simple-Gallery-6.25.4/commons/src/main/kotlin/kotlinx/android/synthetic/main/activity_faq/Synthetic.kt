package kotlinx.android.synthetic.main.activity_faq
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.faq_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.faq_coordinator)
val Dialog.faq_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.faq_coordinator)
val Fragment.faq_coordinator get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.faq_coordinator)
val View.faq_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.faq_coordinator)
val Activity.faq_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.faq_app_bar_layout)
val Dialog.faq_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.faq_app_bar_layout)
val Fragment.faq_app_bar_layout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.faq_app_bar_layout)
val View.faq_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.faq_app_bar_layout)
val Activity.faq_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.faq_toolbar)
val Dialog.faq_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.faq_toolbar)
val Fragment.faq_toolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.faq_toolbar)
val View.faq_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.faq_toolbar)
val Activity.faq_nested_scrollview get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.faq_nested_scrollview)
val Dialog.faq_nested_scrollview get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.faq_nested_scrollview)
val Fragment.faq_nested_scrollview get() = requireView().findViewById<androidx.core.widget.NestedScrollView>(R.id.faq_nested_scrollview)
val View.faq_nested_scrollview get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.faq_nested_scrollview)
val Activity.faq_holder get() = findViewById<android.widget.LinearLayout>(R.id.faq_holder)
val Dialog.faq_holder get() = findViewById<android.widget.LinearLayout>(R.id.faq_holder)
val Fragment.faq_holder get() = requireView().findViewById<android.widget.LinearLayout>(R.id.faq_holder)
val View.faq_holder get() = findViewById<android.widget.LinearLayout>(R.id.faq_holder)
