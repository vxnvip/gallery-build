package kotlinx.android.synthetic.main.actionbar_title.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.actionbar_title get() = findViewById<android.widget.TextView>(R.id.actionbar_title)
