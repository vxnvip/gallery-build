package kotlinx.android.synthetic.main.dialog_color_picker.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.color_picker_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.color_picker_scrollview)
val View.color_picker_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_holder)
val View.recent_colors: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.recent_colors)
val View.recent_colors_flow: androidx.constraintlayout.helper.widget.Flow get() = findViewById<androidx.constraintlayout.helper.widget.Flow>(R.id.recent_colors_flow)
val View.color_picker_top_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_top_holder)
val View.color_picker_square: com.simplemobiletools.commons.views.ColorPickerSquare get() = findViewById<com.simplemobiletools.commons.views.ColorPickerSquare>(R.id.color_picker_square)
val View.color_picker_hue: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.color_picker_hue)
val View.color_picker_hue_cursor: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.color_picker_hue_cursor)
val View.color_picker_cursor: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.color_picker_cursor)
val View.color_picker_hex_codes_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_hex_codes_holder)
val View.color_picker_old_hex: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.color_picker_old_hex)
val View.color_picker_hex_arrow: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.color_picker_hex_arrow)
val View.color_picker_new_hex_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.color_picker_new_hex_label)
val View.color_picker_new_hex: com.simplemobiletools.commons.views.MyEditText get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.color_picker_new_hex)
val View.color_picker_bottom_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_bottom_holder)
val View.color_picker_old_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.color_picker_old_color)
val View.color_picker_arrow: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.color_picker_arrow)
val View.color_picker_new_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.color_picker_new_color)
