package kotlinx.android.synthetic.main.dialog_color_picker.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.color_picker_scrollview get() = findViewById<android.widget.ScrollView>(R.id.color_picker_scrollview)
val View.color_picker_holder get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_holder)
val View.recent_colors get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.recent_colors)
val View.recent_colors_flow get() = findViewById<androidx.constraintlayout.helper.widget.Flow>(R.id.recent_colors_flow)
val View.color_picker_top_holder get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_top_holder)
val View.color_picker_square get() = findViewById<com.simplemobiletools.commons.views.ColorPickerSquare>(R.id.color_picker_square)
val View.color_picker_hue get() = findViewById<android.widget.ImageView>(R.id.color_picker_hue)
val View.color_picker_hue_cursor get() = findViewById<android.widget.ImageView>(R.id.color_picker_hue_cursor)
val View.color_picker_cursor get() = findViewById<android.widget.ImageView>(R.id.color_picker_cursor)
val View.color_picker_hex_codes_holder get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_hex_codes_holder)
val View.color_picker_old_hex get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.color_picker_old_hex)
val View.color_picker_hex_arrow get() = findViewById<android.widget.ImageView>(R.id.color_picker_hex_arrow)
val View.color_picker_new_hex_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.color_picker_new_hex_label)
val View.color_picker_new_hex get() = findViewById<com.simplemobiletools.commons.views.MyEditText>(R.id.color_picker_new_hex)
val View.color_picker_bottom_holder get() = findViewById<android.widget.RelativeLayout>(R.id.color_picker_bottom_holder)
val View.color_picker_old_color get() = findViewById<android.widget.ImageView>(R.id.color_picker_old_color)
val View.color_picker_arrow get() = findViewById<android.widget.ImageView>(R.id.color_picker_arrow)
val View.color_picker_new_color get() = findViewById<android.widget.ImageView>(R.id.color_picker_new_color)
