package kotlinx.android.synthetic.main.dialog_create_new_folder
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val Dialog.dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val Fragment.dialog_holder get() = requireView().findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val View.dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val Activity.folder_path_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_path_hint)
val Dialog.folder_path_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_path_hint)
val Fragment.folder_path_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_path_hint)
val View.folder_path_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_path_hint)
val Activity.folder_path get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_path)
val Dialog.folder_path get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_path)
val Fragment.folder_path get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_path)
val View.folder_path get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_path)
val Activity.folder_name_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_name_hint)
val Dialog.folder_name_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_name_hint)
val Fragment.folder_name_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_name_hint)
val View.folder_name_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_name_hint)
val Activity.folder_name get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_name)
val Dialog.folder_name get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_name)
val Fragment.folder_name get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_name)
val View.folder_name get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_name)
