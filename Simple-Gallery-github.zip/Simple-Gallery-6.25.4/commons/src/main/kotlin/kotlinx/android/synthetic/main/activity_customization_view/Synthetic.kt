package kotlinx.android.synthetic.main.activity_customization.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.customization_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.customization_coordinator)
val View.customization_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.customization_app_bar_layout)
val View.customization_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.customization_toolbar)
val View.customization_nested_scrollview: androidx.core.widget.NestedScrollView get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.customization_nested_scrollview)
val View.customization_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_holder)
val View.customization_theme_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_theme_holder)
val View.customization_theme_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_theme_label)
val View.customization_theme: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_theme)
val View.customization_text_color_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_text_color_holder)
val View.customization_text_color_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_text_color_label)
val View.customization_text_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.customization_text_color)
val View.customization_background_color_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_background_color_holder)
val View.customization_background_color_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_background_color_label)
val View.customization_background_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.customization_background_color)
val View.customization_primary_color_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_primary_color_holder)
val View.customization_primary_color_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_primary_color_label)
val View.customization_primary_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.customization_primary_color)
val View.customization_accent_color_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_accent_color_holder)
val View.customization_accent_color_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_accent_color_label)
val View.customization_accent_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.customization_accent_color)
val View.customization_app_icon_color_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_app_icon_color_holder)
val View.customization_app_icon_color_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_app_icon_color_label)
val View.customization_app_icon_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.customization_app_icon_color)
val View.customization_navigation_bar_color_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.customization_navigation_bar_color_holder)
val View.customization_navigation_bar_color_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_navigation_bar_color_label)
val View.customization_navigation_bar_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.customization_navigation_bar_color)
val View.apply_to_all_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.apply_to_all_holder)
val View.apply_to_all: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.apply_to_all)
