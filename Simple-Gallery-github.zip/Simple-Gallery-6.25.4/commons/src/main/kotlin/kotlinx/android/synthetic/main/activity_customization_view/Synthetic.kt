package kotlinx.android.synthetic.main.activity_customization.view
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val View.customization_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.customization_coordinator)
val View.customization_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.customization_app_bar_layout)
val View.customization_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.customization_toolbar)
val View.customization_nested_scrollview get() = findViewById<androidx.core.widget.NestedScrollView>(R.id.customization_nested_scrollview)
val View.customization_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_holder)
val View.customization_theme_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_theme_holder)
val View.customization_theme_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_theme_label)
val View.customization_theme get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_theme)
val View.customization_text_color_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_text_color_holder)
val View.customization_text_color_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_text_color_label)
val View.customization_text_color get() = findViewById<android.widget.ImageView>(R.id.customization_text_color)
val View.customization_background_color_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_background_color_holder)
val View.customization_background_color_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_background_color_label)
val View.customization_background_color get() = findViewById<android.widget.ImageView>(R.id.customization_background_color)
val View.customization_primary_color_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_primary_color_holder)
val View.customization_primary_color_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_primary_color_label)
val View.customization_primary_color get() = findViewById<android.widget.ImageView>(R.id.customization_primary_color)
val View.customization_accent_color_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_accent_color_holder)
val View.customization_accent_color_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_accent_color_label)
val View.customization_accent_color get() = findViewById<android.widget.ImageView>(R.id.customization_accent_color)
val View.customization_app_icon_color_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_app_icon_color_holder)
val View.customization_app_icon_color_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_app_icon_color_label)
val View.customization_app_icon_color get() = findViewById<android.widget.ImageView>(R.id.customization_app_icon_color)
val View.customization_navigation_bar_color_holder get() = findViewById<android.widget.RelativeLayout>(R.id.customization_navigation_bar_color_holder)
val View.customization_navigation_bar_color_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.customization_navigation_bar_color_label)
val View.customization_navigation_bar_color get() = findViewById<android.widget.ImageView>(R.id.customization_navigation_bar_color)
val View.apply_to_all_holder get() = findViewById<android.widget.RelativeLayout>(R.id.apply_to_all_holder)
val View.apply_to_all get() = findViewById<android.widget.TextView>(R.id.apply_to_all)
