package kotlinx.android.synthetic.main.actionbar_title
import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.commons.R

val Activity.actionbar_title get() = findViewById<android.widget.TextView>(R.id.actionbar_title)
val Dialog.actionbar_title get() = findViewById<android.widget.TextView>(R.id.actionbar_title)
val Fragment.actionbar_title get() = requireView().findViewById<android.widget.TextView>(R.id.actionbar_title)
val View.actionbar_title get() = findViewById<android.widget.TextView>(R.id.actionbar_title)
