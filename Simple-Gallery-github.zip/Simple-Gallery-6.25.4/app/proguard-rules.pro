# v-lean: không giữ nguyên cả Simple Commons nữa (để R8 cắt code thừa); chỉ giữ model dùng Gson/Room
-keep class com.simplemobiletools.gallery.pro.models.** { *; }
-keep class com.simplemobiletools.gallery.pro.helpers.** { *; }
-keep class com.simplemobiletools.commons.models.** { *; }
-keep class com.simplemobiletools.commons.helpers.** { *; }
-keepattributes Signature, *Annotation*, EnclosingMethod, InnerClasses
-allowaccessmodification
-repackageclasses ''
-dontwarn android.graphics.Canvas
-dontwarn com.simplemobiletools.**
-dontwarn org.apache.**

# Picasso
-dontwarn javax.annotation.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase
-dontwarn org.codehaus.mojo.animal_sniffer.*
-dontwarn okhttp3.internal.platform.ConscryptPlatform

-keepclassmembers class * implements android.os.Parcelable {
    static ** CREATOR;
}

# RenderScript
-keepclasseswithmembernames class * {
native <methods>;
}
-keep class androidx.renderscript.** { *; }

# Reprint
-keep class com.github.ajalt.reprint.module.** { *; }

# NetPlayer (trình phát video)
-keep class com.duy.netplayer.** { *; }
-dontwarn androidx.media3.**
