package kotlinx.android.synthetic.main.dialog_exclude_folder.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.exclude_folder_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.exclude_folder_scrollview)
val View.exclude_folder_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.exclude_folder_holder)
val View.exclude_folder_description: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_description)
val View.exclude_folder_parent: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_parent)
val View.exclude_folder_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.exclude_folder_radio_group)
