package kotlinx.android.synthetic.main.bottom_video_time_holder.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.video_time_holder get() = findViewById<android.widget.RelativeLayout>(R.id.video_time_holder)
val View.video_prev_file get() = findViewById<android.widget.ImageView>(R.id.video_prev_file)
val View.video_toggle_play_pause get() = findViewById<android.widget.ImageView>(R.id.video_toggle_play_pause)
val View.video_next_file get() = findViewById<android.widget.ImageView>(R.id.video_next_file)
val View.video_curr_time get() = findViewById<android.widget.TextView>(R.id.video_curr_time)
val View.video_seekbar get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.video_seekbar)
val View.video_duration get() = findViewById<android.widget.TextView>(R.id.video_duration)
