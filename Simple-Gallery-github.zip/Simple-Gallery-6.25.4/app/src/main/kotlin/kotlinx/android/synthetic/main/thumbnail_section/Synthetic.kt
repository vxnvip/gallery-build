package kotlinx.android.synthetic.main.thumbnail_section

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.thumbnail_section get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.thumbnail_section)
val Dialog.thumbnail_section get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.thumbnail_section)
val Fragment.thumbnail_section get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.thumbnail_section)
val View.thumbnail_section get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.thumbnail_section)
