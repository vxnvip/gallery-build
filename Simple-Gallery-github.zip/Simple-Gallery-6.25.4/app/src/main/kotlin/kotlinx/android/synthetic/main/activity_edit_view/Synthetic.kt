package kotlinx.android.synthetic.main.activity_edit.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.editor_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.editor_coordinator)
val View.editor_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.editor_app_bar_layout)
val View.editor_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.editor_toolbar)
val View.activity_edit_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.activity_edit_holder)
val View.default_image_view: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.default_image_view)
val View.crop_image_view: com.theartofdev.edmodo.cropper.CropImageView get() = findViewById<com.theartofdev.edmodo.cropper.CropImageView>(R.id.crop_image_view)
val View.editor_draw_canvas: com.simplemobiletools.gallery.pro.views.EditorDrawCanvas get() = findViewById<com.simplemobiletools.gallery.pro.views.EditorDrawCanvas>(R.id.editor_draw_canvas)
val View.bottom_editor_actions_background: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.bottom_editor_actions_background)
val View.bottom_editor_primary_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_primary_actions)
val View.bottom_aspect_ratios: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_aspect_ratios)
val View.bottom_editor_filter_actions: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.bottom_editor_filter_actions)
val View.bottom_editor_crop_rotate_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_crop_rotate_actions)
val View.bottom_editor_draw_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_draw_actions)
