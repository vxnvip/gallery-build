package kotlinx.android.synthetic.main.bottom_set_wallpaper_actions.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.bottom_set_wallpaper_actions_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_set_wallpaper_actions_wrapper)
val View.bottom_set_wallpaper_aspect_ratio: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_set_wallpaper_aspect_ratio)
val View.bottom_set_wallpaper_rotate: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_set_wallpaper_rotate)
