package kotlinx.android.synthetic.main.activity_set_wallpaper.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.set_wallpaper_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.set_wallpaper_coordinator)
val View.set_wallpaper_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.set_wallpaper_app_bar_layout)
val View.set_wallpaper_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.set_wallpaper_toolbar)
val View.activity_set_wallpaper_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.activity_set_wallpaper_holder)
val View.crop_image_view: com.theartofdev.edmodo.cropper.CropImageView get() = findViewById<com.theartofdev.edmodo.cropper.CropImageView>(R.id.crop_image_view)
val View.bottom_set_wallpaper_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_set_wallpaper_actions)
