package kotlinx.android.synthetic.main.fragment_holder

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.fragment_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val Dialog.fragment_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val Fragment.fragment_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val View.fragment_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val Activity.fragment_placeholder: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.fragment_placeholder)
val Dialog.fragment_placeholder: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.fragment_placeholder)
val Fragment.fragment_placeholder: android.widget.FrameLayout get() = requireView().findViewById<android.widget.FrameLayout>(R.id.fragment_placeholder)
val View.fragment_placeholder: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.fragment_placeholder)
val Activity.top_shadow: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val Dialog.top_shadow: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val Fragment.top_shadow: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.top_shadow)
val View.top_shadow: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val Activity.bottom_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val Dialog.bottom_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val Fragment.bottom_actions: androidx.constraintlayout.widget.ConstraintLayout get() = requireView().findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val View.bottom_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val Activity.fragment_viewer_appbar: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.fragment_viewer_appbar)
val Dialog.fragment_viewer_appbar: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.fragment_viewer_appbar)
val Fragment.fragment_viewer_appbar: com.google.android.material.appbar.AppBarLayout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.fragment_viewer_appbar)
val View.fragment_viewer_appbar: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.fragment_viewer_appbar)
val Activity.fragment_viewer_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.fragment_viewer_toolbar)
val Dialog.fragment_viewer_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.fragment_viewer_toolbar)
val Fragment.fragment_viewer_toolbar: com.google.android.material.appbar.MaterialToolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.fragment_viewer_toolbar)
val View.fragment_viewer_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.fragment_viewer_toolbar)
