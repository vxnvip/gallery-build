package kotlinx.android.synthetic.main.dialog_directory_picker.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.directories_holder: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.directories_holder)
val View.directories_grid_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.directories_grid_holder)
val View.directories_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.directories_fastscroller)
val View.directories_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.directories_grid)
val View.directories_show_hidden: com.simplemobiletools.commons.views.MyFloatingActionButton get() = findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.directories_show_hidden)
