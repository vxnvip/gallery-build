package kotlinx.android.synthetic.main.bottom_actions_aspect_ratio.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.bottom_aspect_ratios_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_aspect_ratios_wrapper)
val View.bottom_aspect_ratio_free: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.bottom_aspect_ratio_free)
val View.bottom_aspect_ratio_one_one: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.bottom_aspect_ratio_one_one)
val View.bottom_aspect_ratio_four_three: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.bottom_aspect_ratio_four_three)
val View.bottom_aspect_ratio_sixteen_nine: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.bottom_aspect_ratio_sixteen_nine)
val View.bottom_aspect_ratio_other: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.bottom_aspect_ratio_other)
