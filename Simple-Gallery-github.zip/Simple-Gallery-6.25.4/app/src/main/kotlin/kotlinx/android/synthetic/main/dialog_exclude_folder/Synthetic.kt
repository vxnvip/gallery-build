package kotlinx.android.synthetic.main.dialog_exclude_folder

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.exclude_folder_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.exclude_folder_scrollview)
val Dialog.exclude_folder_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.exclude_folder_scrollview)
val Fragment.exclude_folder_scrollview: android.widget.ScrollView get() = requireView().findViewById<android.widget.ScrollView>(R.id.exclude_folder_scrollview)
val View.exclude_folder_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.exclude_folder_scrollview)
val Activity.exclude_folder_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.exclude_folder_holder)
val Dialog.exclude_folder_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.exclude_folder_holder)
val Fragment.exclude_folder_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.exclude_folder_holder)
val View.exclude_folder_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.exclude_folder_holder)
val Activity.exclude_folder_description: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_description)
val Dialog.exclude_folder_description: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_description)
val Fragment.exclude_folder_description: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_description)
val View.exclude_folder_description: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_description)
val Activity.exclude_folder_parent: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_parent)
val Dialog.exclude_folder_parent: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_parent)
val Fragment.exclude_folder_parent: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_parent)
val View.exclude_folder_parent: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.exclude_folder_parent)
val Activity.exclude_folder_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.exclude_folder_radio_group)
val Dialog.exclude_folder_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.exclude_folder_radio_group)
val Fragment.exclude_folder_radio_group: android.widget.RadioGroup get() = requireView().findViewById<android.widget.RadioGroup>(R.id.exclude_folder_radio_group)
val View.exclude_folder_radio_group: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.exclude_folder_radio_group)
