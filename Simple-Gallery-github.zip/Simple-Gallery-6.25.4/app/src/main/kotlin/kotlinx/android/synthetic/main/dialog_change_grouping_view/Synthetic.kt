package kotlinx.android.synthetic.main.dialog_change_grouping.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.grouping_dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.grouping_dialog_scrollview)
val View.grouping_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.grouping_dialog_holder)
val View.grouping_dialog_radio_grouping: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.grouping_dialog_radio_grouping)
val View.grouping_dialog_radio_none: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_none)
val View.grouping_dialog_radio_last_modified_daily: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_last_modified_daily)
val View.grouping_dialog_radio_last_modified_monthly: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_last_modified_monthly)
val View.grouping_dialog_radio_date_taken_daily: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_date_taken_daily)
val View.grouping_dialog_radio_date_taken_monthly: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_date_taken_monthly)
val View.grouping_dialog_radio_file_type: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_file_type)
val View.grouping_dialog_radio_extension: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_extension)
val View.grouping_dialog_radio_folder: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_folder)
val View.grouping_dialog_radio_order: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.grouping_dialog_radio_order)
val View.grouping_dialog_radio_ascending: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_ascending)
val View.grouping_dialog_radio_descending: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.grouping_dialog_radio_descending)
val View.use_for_this_folder_divider: android.view.View get() = findViewById<android.view.View>(R.id.use_for_this_folder_divider)
val View.grouping_dialog_show_file_count: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.grouping_dialog_show_file_count)
val View.grouping_dialog_use_for_this_folder: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.grouping_dialog_use_for_this_folder)
val View.grouping_dialog_bottom_note: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.grouping_dialog_bottom_note)
