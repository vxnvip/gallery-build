package kotlinx.android.synthetic.main.dialog_manage_bottom_actions.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.manage_bottom_actions_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.manage_bottom_actions_scrollview)
val View.manage_bottom_actions_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.manage_bottom_actions_holder)
val View.manage_bottom_actions_toggle_favorite: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_toggle_favorite)
val View.manage_bottom_actions_edit: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_edit)
val View.manage_bottom_actions_share: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_share)
val View.manage_bottom_actions_delete: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_delete)
val View.manage_bottom_actions_rotate: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_rotate)
val View.manage_bottom_actions_properties: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_properties)
val View.manage_bottom_actions_change_orientation: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_change_orientation)
val View.manage_bottom_actions_slideshow: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_slideshow)
val View.manage_bottom_actions_show_on_map: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_show_on_map)
val View.manage_bottom_actions_toggle_visibility: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_toggle_visibility)
val View.manage_bottom_actions_rename: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_rename)
val View.manage_bottom_actions_set_as: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_set_as)
val View.manage_bottom_actions_copy: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_copy)
val View.manage_bottom_actions_move: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_move)
val View.manage_bottom_actions_resize: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_bottom_actions_resize)
