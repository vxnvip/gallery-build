package kotlinx.android.synthetic.main.activity_medium.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.fragment_holder get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val View.view_pager get() = findViewById<com.simplemobiletools.commons.views.MyViewPager>(R.id.view_pager)
val View.bottom_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val View.top_shadow get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val View.medium_viewer_appbar get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.medium_viewer_appbar)
val View.medium_viewer_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.medium_viewer_toolbar)
