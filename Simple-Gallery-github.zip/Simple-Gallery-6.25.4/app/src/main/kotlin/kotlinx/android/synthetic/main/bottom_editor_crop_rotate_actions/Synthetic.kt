package kotlinx.android.synthetic.main.bottom_editor_crop_rotate_actions

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.bottom_editor_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val Dialog.bottom_editor_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val Fragment.bottom_editor_actions_wrapper get() = requireView().findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val View.bottom_editor_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val Activity.bottom_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val Dialog.bottom_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val Fragment.bottom_rotate get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val View.bottom_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val Activity.bottom_resize get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
val Dialog.bottom_resize get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
val Fragment.bottom_resize get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_resize)
val View.bottom_resize get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
val Activity.bottom_aspect_ratio get() = findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val Dialog.bottom_aspect_ratio get() = findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val Fragment.bottom_aspect_ratio get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val View.bottom_aspect_ratio get() = findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val Activity.bottom_flip_horizontally get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val Dialog.bottom_flip_horizontally get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val Fragment.bottom_flip_horizontally get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val View.bottom_flip_horizontally get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val Activity.bottom_flip_vertically get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
val Dialog.bottom_flip_vertically get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
val Fragment.bottom_flip_vertically get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
val View.bottom_flip_vertically get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
