package kotlinx.android.synthetic.main.bottom_editor_crop_rotate_actions

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.bottom_editor_actions_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val Dialog.bottom_editor_actions_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val Fragment.bottom_editor_actions_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = requireView().findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val View.bottom_editor_actions_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val Activity.bottom_rotate: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val Dialog.bottom_rotate: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val Fragment.bottom_rotate: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val View.bottom_rotate: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val Activity.bottom_resize: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
val Dialog.bottom_resize: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
val Fragment.bottom_resize: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_resize)
val View.bottom_resize: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
val Activity.bottom_aspect_ratio: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val Dialog.bottom_aspect_ratio: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val Fragment.bottom_aspect_ratio: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val View.bottom_aspect_ratio: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val Activity.bottom_flip_horizontally: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val Dialog.bottom_flip_horizontally: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val Fragment.bottom_flip_horizontally: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val View.bottom_flip_horizontally: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val Activity.bottom_flip_vertically: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
val Dialog.bottom_flip_vertically: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
val Fragment.bottom_flip_vertically: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
val View.bottom_flip_vertically: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
