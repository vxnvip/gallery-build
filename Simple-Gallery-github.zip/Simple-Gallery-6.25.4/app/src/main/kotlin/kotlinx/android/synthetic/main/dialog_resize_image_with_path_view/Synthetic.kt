package kotlinx.android.synthetic.main.dialog_resize_image_with_path.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.resize_image_with_path_holder get() = findViewById<android.widget.RelativeLayout>(R.id.resize_image_with_path_holder)
val View.resize_image_width_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.resize_image_width_hint)
val View.resize_image_width get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.resize_image_width)
val View.resize_image_colon get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.resize_image_colon)
val View.resize_image_height_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.resize_image_height_hint)
val View.resize_image_height get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.resize_image_height)
val View.folder_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_hint)
val View.folder get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder)
val View.filename_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.filename_hint)
val View.filename_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.filename_value)
val View.extension_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.extension_hint)
val View.extension_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.extension_value)
