package kotlinx.android.synthetic.main.dialog_delete_with_remember

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.delete_remember_holder get() = findViewById<android.widget.RelativeLayout>(R.id.delete_remember_holder)
val Dialog.delete_remember_holder get() = findViewById<android.widget.RelativeLayout>(R.id.delete_remember_holder)
val Fragment.delete_remember_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.delete_remember_holder)
val View.delete_remember_holder get() = findViewById<android.widget.RelativeLayout>(R.id.delete_remember_holder)
val Activity.delete_remember_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.delete_remember_title)
val Dialog.delete_remember_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.delete_remember_title)
val Fragment.delete_remember_title get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.delete_remember_title)
val View.delete_remember_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.delete_remember_title)
val Activity.delete_remember_checkbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.delete_remember_checkbox)
val Dialog.delete_remember_checkbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.delete_remember_checkbox)
val Fragment.delete_remember_checkbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.delete_remember_checkbox)
val View.delete_remember_checkbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.delete_remember_checkbox)
