package kotlinx.android.synthetic.main.pager_video_item.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.video_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.video_holder)
val View.video_preview: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.video_preview)
val View.video_surface_frame: com.alexvasilkov.gestures.GestureFrameLayout get() = findViewById<com.alexvasilkov.gestures.GestureFrameLayout>(R.id.video_surface_frame)
val View.video_surface: android.view.TextureView get() = findViewById<android.view.TextureView>(R.id.video_surface)
val View.video_volume_controller: com.simplemobiletools.gallery.pro.views.MediaSideScroll get() = findViewById<com.simplemobiletools.gallery.pro.views.MediaSideScroll>(R.id.video_volume_controller)
val View.video_brightness_controller: com.simplemobiletools.gallery.pro.views.MediaSideScroll get() = findViewById<com.simplemobiletools.gallery.pro.views.MediaSideScroll>(R.id.video_brightness_controller)
val View.video_play_outline: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.video_play_outline)
val View.panorama_outline: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.panorama_outline)
val View.video_details: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.video_details)
val View.slide_info: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.slide_info)
