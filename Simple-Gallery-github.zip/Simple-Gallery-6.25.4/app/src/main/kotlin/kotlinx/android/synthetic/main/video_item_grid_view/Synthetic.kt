package kotlinx.android.synthetic.main.video_item_grid.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.media_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val View.medium_thumbnail get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val View.play_portrait_outline get() = findViewById<android.widget.ImageView>(R.id.play_portrait_outline)
val View.favorite get() = findViewById<android.widget.ImageView>(R.id.favorite)
val View.video_duration get() = findViewById<android.widget.TextView>(R.id.video_duration)
val View.medium_check get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val View.medium_name get() = findViewById<android.widget.TextView>(R.id.medium_name)
