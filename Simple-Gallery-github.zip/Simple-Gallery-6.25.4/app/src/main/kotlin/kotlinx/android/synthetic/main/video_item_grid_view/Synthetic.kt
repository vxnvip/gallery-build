package kotlinx.android.synthetic.main.video_item_grid.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.media_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val View.medium_thumbnail: com.simplemobiletools.commons.views.MySquareImageView get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val View.play_portrait_outline: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.play_portrait_outline)
val View.favorite: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.favorite)
val View.video_duration: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.video_duration)
val View.medium_check: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val View.medium_name: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.medium_name)
