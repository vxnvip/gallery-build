package kotlinx.android.synthetic.main.dialog_filter_media.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.filter_media_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.filter_media_dialog_holder)
val View.filter_media_images get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_images)
val View.filter_media_videos get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_videos)
val View.filter_media_gifs get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_gifs)
val View.filter_media_raws get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_raws)
val View.filter_media_svgs get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_svgs)
val View.filter_media_portraits get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_portraits)
