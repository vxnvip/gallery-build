package kotlinx.android.synthetic.main.bottom_editor_primary_actions

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.bottom_editor_primary_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_primary_actions_wrapper)
val Dialog.bottom_editor_primary_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_primary_actions_wrapper)
val Fragment.bottom_editor_primary_actions_wrapper get() = requireView().findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_primary_actions_wrapper)
val View.bottom_editor_primary_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_primary_actions_wrapper)
val Activity.bottom_primary_filter get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_filter)
val Dialog.bottom_primary_filter get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_filter)
val Fragment.bottom_primary_filter get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_primary_filter)
val View.bottom_primary_filter get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_filter)
val Activity.bottom_primary_crop_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_crop_rotate)
val Dialog.bottom_primary_crop_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_crop_rotate)
val Fragment.bottom_primary_crop_rotate get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_primary_crop_rotate)
val View.bottom_primary_crop_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_crop_rotate)
val Activity.bottom_primary_draw get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_draw)
val Dialog.bottom_primary_draw get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_draw)
val Fragment.bottom_primary_draw get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_primary_draw)
val View.bottom_primary_draw get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_draw)
