package kotlinx.android.synthetic.main.photo_item_grid

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.media_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val Dialog.media_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val Fragment.media_item_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val View.media_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val Activity.medium_thumbnail: com.simplemobiletools.commons.views.MySquareImageView get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val Dialog.medium_thumbnail: com.simplemobiletools.commons.views.MySquareImageView get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val Fragment.medium_thumbnail: com.simplemobiletools.commons.views.MySquareImageView get() = requireView().findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val View.medium_thumbnail: com.simplemobiletools.commons.views.MySquareImageView get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val Activity.file_type: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.file_type)
val Dialog.file_type: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.file_type)
val Fragment.file_type: android.widget.TextView get() = requireView().findViewById<android.widget.TextView>(R.id.file_type)
val View.file_type: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.file_type)
val Activity.favorite: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.favorite)
val Dialog.favorite: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.favorite)
val Fragment.favorite: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.favorite)
val View.favorite: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.favorite)
val Activity.medium_check: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val Dialog.medium_check: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val Fragment.medium_check: android.widget.ImageView get() = requireView().findViewById<android.widget.ImageView>(R.id.medium_check)
val View.medium_check: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val Activity.medium_name: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.medium_name)
val Dialog.medium_name: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.medium_name)
val Fragment.medium_name: android.widget.TextView get() = requireView().findViewById<android.widget.TextView>(R.id.medium_name)
val View.medium_name: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.medium_name)
