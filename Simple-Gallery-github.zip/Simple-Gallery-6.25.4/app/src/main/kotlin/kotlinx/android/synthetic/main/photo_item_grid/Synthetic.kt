package kotlinx.android.synthetic.main.photo_item_grid

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.media_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val Dialog.media_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val Fragment.media_item_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val View.media_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_item_holder)
val Activity.medium_thumbnail get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val Dialog.medium_thumbnail get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val Fragment.medium_thumbnail get() = requireView().findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val View.medium_thumbnail get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.medium_thumbnail)
val Activity.file_type get() = findViewById<android.widget.TextView>(R.id.file_type)
val Dialog.file_type get() = findViewById<android.widget.TextView>(R.id.file_type)
val Fragment.file_type get() = requireView().findViewById<android.widget.TextView>(R.id.file_type)
val View.file_type get() = findViewById<android.widget.TextView>(R.id.file_type)
val Activity.favorite get() = findViewById<android.widget.ImageView>(R.id.favorite)
val Dialog.favorite get() = findViewById<android.widget.ImageView>(R.id.favorite)
val Fragment.favorite get() = requireView().findViewById<android.widget.ImageView>(R.id.favorite)
val View.favorite get() = findViewById<android.widget.ImageView>(R.id.favorite)
val Activity.medium_check get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val Dialog.medium_check get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val Fragment.medium_check get() = requireView().findViewById<android.widget.ImageView>(R.id.medium_check)
val View.medium_check get() = findViewById<android.widget.ImageView>(R.id.medium_check)
val Activity.medium_name get() = findViewById<android.widget.TextView>(R.id.medium_name)
val Dialog.medium_name get() = findViewById<android.widget.TextView>(R.id.medium_name)
val Fragment.medium_name get() = requireView().findViewById<android.widget.TextView>(R.id.medium_name)
val View.medium_name get() = findViewById<android.widget.TextView>(R.id.medium_name)
