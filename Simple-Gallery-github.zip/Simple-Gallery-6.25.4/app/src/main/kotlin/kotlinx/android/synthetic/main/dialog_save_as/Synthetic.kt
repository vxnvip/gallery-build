package kotlinx.android.synthetic.main.dialog_save_as

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.save_as_holder get() = findViewById<android.widget.LinearLayout>(R.id.save_as_holder)
val Dialog.save_as_holder get() = findViewById<android.widget.LinearLayout>(R.id.save_as_holder)
val Fragment.save_as_holder get() = requireView().findViewById<android.widget.LinearLayout>(R.id.save_as_holder)
val View.save_as_holder get() = findViewById<android.widget.LinearLayout>(R.id.save_as_holder)
val Activity.folder_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_hint)
val Dialog.folder_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_hint)
val Fragment.folder_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_hint)
val View.folder_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.folder_hint)
val Activity.folder_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_value)
val Dialog.folder_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_value)
val Fragment.folder_value get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_value)
val View.folder_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.folder_value)
val Activity.filename_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.filename_hint)
val Dialog.filename_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.filename_hint)
val Fragment.filename_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.filename_hint)
val View.filename_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.filename_hint)
val Activity.filename_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.filename_value)
val Dialog.filename_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.filename_value)
val Fragment.filename_value get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.filename_value)
val View.filename_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.filename_value)
val Activity.extension_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.extension_hint)
val Dialog.extension_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.extension_hint)
val Fragment.extension_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.extension_hint)
val View.extension_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.extension_hint)
val Activity.extension_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.extension_value)
val Dialog.extension_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.extension_value)
val Fragment.extension_value get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.extension_value)
val View.extension_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.extension_value)
