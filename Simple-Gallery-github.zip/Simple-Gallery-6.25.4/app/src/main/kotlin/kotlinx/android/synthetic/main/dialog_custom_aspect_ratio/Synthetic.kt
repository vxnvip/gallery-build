package kotlinx.android.synthetic.main.dialog_custom_aspect_ratio

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.aspect_ratio_holder get() = findViewById<android.widget.RelativeLayout>(R.id.aspect_ratio_holder)
val Dialog.aspect_ratio_holder get() = findViewById<android.widget.RelativeLayout>(R.id.aspect_ratio_holder)
val Fragment.aspect_ratio_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.aspect_ratio_holder)
val View.aspect_ratio_holder get() = findViewById<android.widget.RelativeLayout>(R.id.aspect_ratio_holder)
val Activity.aspect_ratio_width_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_width_hint)
val Dialog.aspect_ratio_width_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_width_hint)
val Fragment.aspect_ratio_width_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_width_hint)
val View.aspect_ratio_width_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_width_hint)
val Activity.aspect_ratio_width get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_width)
val Dialog.aspect_ratio_width get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_width)
val Fragment.aspect_ratio_width get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_width)
val View.aspect_ratio_width get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_width)
val Activity.aspect_ratio_colon get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.aspect_ratio_colon)
val Dialog.aspect_ratio_colon get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.aspect_ratio_colon)
val Fragment.aspect_ratio_colon get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.aspect_ratio_colon)
val View.aspect_ratio_colon get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.aspect_ratio_colon)
val Activity.aspect_ratio_height_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_height_hint)
val Dialog.aspect_ratio_height_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_height_hint)
val Fragment.aspect_ratio_height_hint get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_height_hint)
val View.aspect_ratio_height_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_height_hint)
val Activity.aspect_ratio_height get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_height)
val Dialog.aspect_ratio_height get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_height)
val Fragment.aspect_ratio_height get() = requireView().findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_height)
val View.aspect_ratio_height get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_height)
