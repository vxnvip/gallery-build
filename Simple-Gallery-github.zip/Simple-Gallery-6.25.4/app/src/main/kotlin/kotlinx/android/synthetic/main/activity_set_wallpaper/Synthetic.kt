package kotlinx.android.synthetic.main.activity_set_wallpaper

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.set_wallpaper_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.set_wallpaper_coordinator)
val Dialog.set_wallpaper_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.set_wallpaper_coordinator)
val Fragment.set_wallpaper_coordinator get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.set_wallpaper_coordinator)
val View.set_wallpaper_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.set_wallpaper_coordinator)
val Activity.set_wallpaper_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.set_wallpaper_app_bar_layout)
val Dialog.set_wallpaper_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.set_wallpaper_app_bar_layout)
val Fragment.set_wallpaper_app_bar_layout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.set_wallpaper_app_bar_layout)
val View.set_wallpaper_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.set_wallpaper_app_bar_layout)
val Activity.set_wallpaper_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.set_wallpaper_toolbar)
val Dialog.set_wallpaper_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.set_wallpaper_toolbar)
val Fragment.set_wallpaper_toolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.set_wallpaper_toolbar)
val View.set_wallpaper_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.set_wallpaper_toolbar)
val Activity.activity_set_wallpaper_holder get() = findViewById<android.widget.RelativeLayout>(R.id.activity_set_wallpaper_holder)
val Dialog.activity_set_wallpaper_holder get() = findViewById<android.widget.RelativeLayout>(R.id.activity_set_wallpaper_holder)
val Fragment.activity_set_wallpaper_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.activity_set_wallpaper_holder)
val View.activity_set_wallpaper_holder get() = findViewById<android.widget.RelativeLayout>(R.id.activity_set_wallpaper_holder)
val Activity.crop_image_view get() = findViewById<com.theartofdev.edmodo.cropper.CropImageView>(R.id.crop_image_view)
val Dialog.crop_image_view get() = findViewById<com.theartofdev.edmodo.cropper.CropImageView>(R.id.crop_image_view)
val Fragment.crop_image_view get() = requireView().findViewById<com.theartofdev.edmodo.cropper.CropImageView>(R.id.crop_image_view)
val View.crop_image_view get() = findViewById<com.theartofdev.edmodo.cropper.CropImageView>(R.id.crop_image_view)
val Activity.bottom_set_wallpaper_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_set_wallpaper_actions)
val Dialog.bottom_set_wallpaper_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_set_wallpaper_actions)
val Fragment.bottom_set_wallpaper_actions get() = requireView().findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_set_wallpaper_actions)
val View.bottom_set_wallpaper_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_set_wallpaper_actions)
