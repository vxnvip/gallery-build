package kotlinx.android.synthetic.main.editor_filter_item.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.editor_filter_item_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.editor_filter_item_holder)
val View.editor_filter_item_thumbnail: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.editor_filter_item_thumbnail)
val View.editor_filter_item_label: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.editor_filter_item_label)
