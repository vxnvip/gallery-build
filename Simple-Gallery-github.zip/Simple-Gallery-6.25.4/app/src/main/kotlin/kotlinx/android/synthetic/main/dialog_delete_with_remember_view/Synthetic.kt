package kotlinx.android.synthetic.main.dialog_delete_with_remember.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.delete_remember_holder get() = findViewById<android.widget.RelativeLayout>(R.id.delete_remember_holder)
val View.delete_remember_title get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.delete_remember_title)
val View.delete_remember_checkbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.delete_remember_checkbox)
