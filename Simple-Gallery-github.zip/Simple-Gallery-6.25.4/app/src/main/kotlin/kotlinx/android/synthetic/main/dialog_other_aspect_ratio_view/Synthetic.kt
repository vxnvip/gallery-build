package kotlinx.android.synthetic.main.dialog_other_aspect_ratio.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.other_aspect_ratio_dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.other_aspect_ratio_dialog_scrollview)
val View.other_aspect_ratio_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.other_aspect_ratio_dialog_holder)
val View.other_aspect_ratio_dialog_radio_1 get() = findViewById<android.widget.RadioGroup>(R.id.other_aspect_ratio_dialog_radio_1)
val View.other_aspect_ratio_2_1 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_2_1)
val View.other_aspect_ratio_3_2 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_3_2)
val View.other_aspect_ratio_4_3 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_4_3)
val View.other_aspect_ratio_5_3 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_5_3)
val View.other_aspect_ratio_16_9 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_16_9)
val View.other_aspect_ratio_19_9 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_19_9)
val View.other_aspect_ratio_custom get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_custom)
val View.other_aspect_ratio_dialog_radio_2 get() = findViewById<android.widget.RadioGroup>(R.id.other_aspect_ratio_dialog_radio_2)
val View.other_aspect_ratio_1_2 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_1_2)
val View.other_aspect_ratio_2_3 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_2_3)
val View.other_aspect_ratio_3_4 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_3_4)
val View.other_aspect_ratio_3_5 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_3_5)
val View.other_aspect_ratio_9_16 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_9_16)
val View.other_aspect_ratio_9_19 get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.other_aspect_ratio_9_19)
