package kotlinx.android.synthetic.main.portrait_photo_item.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.portrait_photo_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.portrait_photo_item_holder)
val View.portrait_photo_item_thumbnail get() = findViewById<android.widget.ImageView>(R.id.portrait_photo_item_thumbnail)
