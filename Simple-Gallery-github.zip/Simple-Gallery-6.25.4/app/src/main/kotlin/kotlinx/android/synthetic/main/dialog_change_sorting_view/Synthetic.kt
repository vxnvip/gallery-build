package kotlinx.android.synthetic.main.dialog_change_sorting.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.sorting_dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.sorting_dialog_scrollview)
val View.sorting_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.sorting_dialog_holder)
val View.sorting_dialog_radio_sorting: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.sorting_dialog_radio_sorting)
val View.sorting_dialog_radio_name: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_name)
val View.sorting_dialog_radio_path: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_path)
val View.sorting_dialog_radio_size: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_size)
val View.sorting_dialog_radio_last_modified: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_last_modified)
val View.sorting_dialog_radio_date_taken: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_date_taken)
val View.sorting_dialog_radio_random: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_random)
val View.sorting_dialog_radio_custom: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_custom)
val View.sorting_dialog_order_divider: android.view.View get() = findViewById<android.view.View>(R.id.sorting_dialog_order_divider)
val View.sorting_dialog_radio_order: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.sorting_dialog_radio_order)
val View.sorting_dialog_radio_ascending: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_ascending)
val View.sorting_dialog_radio_descending: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_descending)
val View.use_for_this_folder_divider: android.view.View get() = findViewById<android.view.View>(R.id.use_for_this_folder_divider)
val View.sorting_dialog_numeric_sorting: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.sorting_dialog_numeric_sorting)
val View.sorting_dialog_use_for_this_folder: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.sorting_dialog_use_for_this_folder)
val View.sorting_dialog_bottom_note: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.sorting_dialog_bottom_note)
