package kotlinx.android.synthetic.main.dialog_change_sorting.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.sorting_dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.sorting_dialog_scrollview)
val View.sorting_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.sorting_dialog_holder)
val View.sorting_dialog_radio_sorting get() = findViewById<android.widget.RadioGroup>(R.id.sorting_dialog_radio_sorting)
val View.sorting_dialog_radio_name get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_name)
val View.sorting_dialog_radio_path get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_path)
val View.sorting_dialog_radio_size get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_size)
val View.sorting_dialog_radio_last_modified get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_last_modified)
val View.sorting_dialog_radio_date_taken get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_date_taken)
val View.sorting_dialog_radio_random get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_random)
val View.sorting_dialog_radio_custom get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_custom)
val View.sorting_dialog_order_divider get() = findViewById<android.view.View>(R.id.sorting_dialog_order_divider)
val View.sorting_dialog_radio_order get() = findViewById<android.widget.RadioGroup>(R.id.sorting_dialog_radio_order)
val View.sorting_dialog_radio_ascending get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_ascending)
val View.sorting_dialog_radio_descending get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.sorting_dialog_radio_descending)
val View.use_for_this_folder_divider get() = findViewById<android.view.View>(R.id.use_for_this_folder_divider)
val View.sorting_dialog_numeric_sorting get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.sorting_dialog_numeric_sorting)
val View.sorting_dialog_use_for_this_folder get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.sorting_dialog_use_for_this_folder)
val View.sorting_dialog_bottom_note get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.sorting_dialog_bottom_note)
