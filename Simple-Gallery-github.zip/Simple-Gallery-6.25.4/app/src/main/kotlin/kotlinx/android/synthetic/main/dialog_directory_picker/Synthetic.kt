package kotlinx.android.synthetic.main.dialog_directory_picker

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.directories_holder get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.directories_holder)
val Dialog.directories_holder get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.directories_holder)
val Fragment.directories_holder get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.directories_holder)
val View.directories_holder get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.directories_holder)
val Activity.directories_grid_holder get() = findViewById<android.widget.RelativeLayout>(R.id.directories_grid_holder)
val Dialog.directories_grid_holder get() = findViewById<android.widget.RelativeLayout>(R.id.directories_grid_holder)
val Fragment.directories_grid_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.directories_grid_holder)
val View.directories_grid_holder get() = findViewById<android.widget.RelativeLayout>(R.id.directories_grid_holder)
val Activity.directories_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.directories_fastscroller)
val Dialog.directories_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.directories_fastscroller)
val Fragment.directories_fastscroller get() = requireView().findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.directories_fastscroller)
val View.directories_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.directories_fastscroller)
val Activity.directories_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.directories_grid)
val Dialog.directories_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.directories_grid)
val Fragment.directories_grid get() = requireView().findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.directories_grid)
val View.directories_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.directories_grid)
val Activity.directories_show_hidden get() = findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.directories_show_hidden)
val Dialog.directories_show_hidden get() = findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.directories_show_hidden)
val Fragment.directories_show_hidden get() = requireView().findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.directories_show_hidden)
val View.directories_show_hidden get() = findViewById<com.simplemobiletools.commons.views.MyFloatingActionButton>(R.id.directories_show_hidden)
