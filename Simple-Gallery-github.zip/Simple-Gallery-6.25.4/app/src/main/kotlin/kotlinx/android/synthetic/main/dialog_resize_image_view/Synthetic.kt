package kotlinx.android.synthetic.main.dialog_resize_image.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.resize_image_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.resize_image_holder)
val View.resize_image_width_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.resize_image_width_hint)
val View.resize_image_width: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.resize_image_width)
val View.resize_image_colon: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.resize_image_colon)
val View.resize_image_height_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.resize_image_height_hint)
val View.resize_image_height: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.resize_image_height)
val View.keep_aspect_ratio: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.keep_aspect_ratio)
