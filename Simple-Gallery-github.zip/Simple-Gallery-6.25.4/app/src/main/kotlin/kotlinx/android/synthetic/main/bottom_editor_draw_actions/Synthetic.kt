package kotlinx.android.synthetic.main.bottom_editor_draw_actions

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.bottom_editor_draw_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_draw_actions_wrapper)
val Dialog.bottom_editor_draw_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_draw_actions_wrapper)
val Fragment.bottom_editor_draw_actions_wrapper get() = requireView().findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_draw_actions_wrapper)
val View.bottom_editor_draw_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_draw_actions_wrapper)
val Activity.bottom_draw_width get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.bottom_draw_width)
val Dialog.bottom_draw_width get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.bottom_draw_width)
val Fragment.bottom_draw_width get() = requireView().findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.bottom_draw_width)
val View.bottom_draw_width get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.bottom_draw_width)
val Activity.bottom_draw_color_clickable get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color_clickable)
val Dialog.bottom_draw_color_clickable get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color_clickable)
val Fragment.bottom_draw_color_clickable get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_draw_color_clickable)
val View.bottom_draw_color_clickable get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color_clickable)
val Activity.bottom_draw_color get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color)
val Dialog.bottom_draw_color get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color)
val Fragment.bottom_draw_color get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_draw_color)
val View.bottom_draw_color get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color)
val Activity.bottom_draw_undo get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_undo)
val Dialog.bottom_draw_undo get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_undo)
val Fragment.bottom_draw_undo get() = requireView().findViewById<android.widget.ImageView>(R.id.bottom_draw_undo)
val View.bottom_draw_undo get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_undo)
