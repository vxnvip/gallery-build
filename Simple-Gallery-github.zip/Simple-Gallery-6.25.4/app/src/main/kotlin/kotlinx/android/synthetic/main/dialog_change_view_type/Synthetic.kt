package kotlinx.android.synthetic.main.dialog_change_view_type

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.change_view_type_dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val Dialog.change_view_type_dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val Fragment.change_view_type_dialog_scrollview get() = requireView().findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val View.change_view_type_dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val Activity.change_view_type_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val Dialog.change_view_type_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val Fragment.change_view_type_dialog_holder get() = requireView().findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val View.change_view_type_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val Activity.change_view_type_dialog_radio get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val Dialog.change_view_type_dialog_radio get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val Fragment.change_view_type_dialog_radio get() = requireView().findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val View.change_view_type_dialog_radio get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val Activity.change_view_type_dialog_radio_grid get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val Dialog.change_view_type_dialog_radio_grid get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val Fragment.change_view_type_dialog_radio_grid get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val View.change_view_type_dialog_radio_grid get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val Activity.change_view_type_dialog_radio_list get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val Dialog.change_view_type_dialog_radio_list get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val Fragment.change_view_type_dialog_radio_list get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val View.change_view_type_dialog_radio_list get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val Activity.group_direct_subfolders_divider get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val Dialog.group_direct_subfolders_divider get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val Fragment.group_direct_subfolders_divider get() = requireView().findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val View.group_direct_subfolders_divider get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val Activity.change_view_type_dialog_group_direct_subfolders get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val Dialog.change_view_type_dialog_group_direct_subfolders get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val Fragment.change_view_type_dialog_group_direct_subfolders get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val View.change_view_type_dialog_group_direct_subfolders get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val Activity.change_view_type_dialog_use_for_this_folder get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
val Dialog.change_view_type_dialog_use_for_this_folder get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
val Fragment.change_view_type_dialog_use_for_this_folder get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
val View.change_view_type_dialog_use_for_this_folder get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
