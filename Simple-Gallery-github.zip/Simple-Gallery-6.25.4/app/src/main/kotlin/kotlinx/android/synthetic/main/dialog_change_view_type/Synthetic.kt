package kotlinx.android.synthetic.main.dialog_change_view_type

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.change_view_type_dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val Dialog.change_view_type_dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val Fragment.change_view_type_dialog_scrollview: android.widget.ScrollView get() = requireView().findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val View.change_view_type_dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val Activity.change_view_type_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val Dialog.change_view_type_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val Fragment.change_view_type_dialog_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val View.change_view_type_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val Activity.change_view_type_dialog_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val Dialog.change_view_type_dialog_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val Fragment.change_view_type_dialog_radio: android.widget.RadioGroup get() = requireView().findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val View.change_view_type_dialog_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val Activity.change_view_type_dialog_radio_grid: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val Dialog.change_view_type_dialog_radio_grid: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val Fragment.change_view_type_dialog_radio_grid: com.simplemobiletools.commons.views.MyCompatRadioButton get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val View.change_view_type_dialog_radio_grid: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val Activity.change_view_type_dialog_radio_list: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val Dialog.change_view_type_dialog_radio_list: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val Fragment.change_view_type_dialog_radio_list: com.simplemobiletools.commons.views.MyCompatRadioButton get() = requireView().findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val View.change_view_type_dialog_radio_list: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val Activity.group_direct_subfolders_divider: android.view.View get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val Dialog.group_direct_subfolders_divider: android.view.View get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val Fragment.group_direct_subfolders_divider: android.view.View get() = requireView().findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val View.group_direct_subfolders_divider: android.view.View get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val Activity.change_view_type_dialog_group_direct_subfolders: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val Dialog.change_view_type_dialog_group_direct_subfolders: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val Fragment.change_view_type_dialog_group_direct_subfolders: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val View.change_view_type_dialog_group_direct_subfolders: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val Activity.change_view_type_dialog_use_for_this_folder: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
val Dialog.change_view_type_dialog_use_for_this_folder: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
val Fragment.change_view_type_dialog_use_for_this_folder: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
val View.change_view_type_dialog_use_for_this_folder: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
