package kotlinx.android.synthetic.main.directory_item_grid_square.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.dir_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dir_holder)
val View.dir_thumbnail: com.simplemobiletools.commons.views.MySquareImageView get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.dir_thumbnail)
val View.dir_lock: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.dir_lock)
val View.dir_check: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.dir_check)
val View.dir_pin: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.dir_pin)
val View.dir_drag_handle_wrapper: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dir_drag_handle_wrapper)
val View.dir_drag_handle: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.dir_drag_handle)
val View.dir_shadow_holder: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.dir_shadow_holder)
val View.dir_bottom_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dir_bottom_holder)
val View.dir_name: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.dir_name)
val View.photo_cnt: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.photo_cnt)
val View.dir_location: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.dir_location)
