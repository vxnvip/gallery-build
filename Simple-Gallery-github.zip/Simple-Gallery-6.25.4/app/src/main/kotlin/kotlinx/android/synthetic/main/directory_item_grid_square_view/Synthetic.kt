package kotlinx.android.synthetic.main.directory_item_grid_square.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.dir_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dir_holder)
val View.dir_thumbnail get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.dir_thumbnail)
val View.dir_lock get() = findViewById<android.widget.ImageView>(R.id.dir_lock)
val View.dir_check get() = findViewById<android.widget.ImageView>(R.id.dir_check)
val View.dir_pin get() = findViewById<android.widget.ImageView>(R.id.dir_pin)
val View.dir_drag_handle_wrapper get() = findViewById<android.widget.RelativeLayout>(R.id.dir_drag_handle_wrapper)
val View.dir_drag_handle get() = findViewById<android.widget.ImageView>(R.id.dir_drag_handle)
val View.dir_shadow_holder get() = findViewById<android.widget.ImageView>(R.id.dir_shadow_holder)
val View.dir_bottom_holder get() = findViewById<android.widget.LinearLayout>(R.id.dir_bottom_holder)
val View.dir_name get() = findViewById<android.widget.TextView>(R.id.dir_name)
val View.photo_cnt get() = findViewById<android.widget.TextView>(R.id.photo_cnt)
val View.dir_location get() = findViewById<android.widget.ImageView>(R.id.dir_location)
