package kotlinx.android.synthetic.main.dialog_change_file_thumbnail_style.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.dialog_scrollview)
val View.dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val View.dialog_file_style_spacing_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_file_style_spacing_holder)
val View.dialog_file_style_spacing_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.dialog_file_style_spacing_label)
val View.dialog_file_style_spacing get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.dialog_file_style_spacing)
val View.dialog_file_style_rounded_corners_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_file_style_rounded_corners_holder)
val View.dialog_file_style_rounded_corners get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.dialog_file_style_rounded_corners)
val View.dialog_file_style_animate_gifs_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_file_style_animate_gifs_holder)
val View.dialog_file_style_animate_gifs get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.dialog_file_style_animate_gifs)
val View.dialog_file_style_show_thumbnail_video_duration_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_file_style_show_thumbnail_video_duration_holder)
val View.dialog_file_style_show_thumbnail_video_duration get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.dialog_file_style_show_thumbnail_video_duration)
val View.dialog_file_style_show_thumbnail_file_types_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_file_style_show_thumbnail_file_types_holder)
val View.dialog_file_style_show_thumbnail_file_types get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.dialog_file_style_show_thumbnail_file_types)
val View.dialog_file_style_mark_favorite_items_holder get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_file_style_mark_favorite_items_holder)
val View.dialog_file_style_mark_favorite_items get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.dialog_file_style_mark_favorite_items)
