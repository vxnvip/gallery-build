package kotlinx.android.synthetic.main.dialog_manage_extended_details.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.manage_extended_details_scrollview get() = findViewById<android.widget.ScrollView>(R.id.manage_extended_details_scrollview)
val View.manage_extended_details_holder get() = findViewById<android.widget.LinearLayout>(R.id.manage_extended_details_holder)
val View.manage_extended_details_name get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_name)
val View.manage_extended_details_path get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_path)
val View.manage_extended_details_size get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_size)
val View.manage_extended_details_resolution get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_resolution)
val View.manage_extended_details_last_modified get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_last_modified)
val View.manage_extended_details_date_taken get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_date_taken)
val View.manage_extended_details_camera get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_camera)
val View.manage_extended_details_exif get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_exif)
val View.manage_extended_details_gps_coordinates get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_gps_coordinates)
