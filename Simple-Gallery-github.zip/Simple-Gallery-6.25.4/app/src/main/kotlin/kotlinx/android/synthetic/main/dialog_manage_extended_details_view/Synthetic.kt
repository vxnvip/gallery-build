package kotlinx.android.synthetic.main.dialog_manage_extended_details.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.manage_extended_details_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.manage_extended_details_scrollview)
val View.manage_extended_details_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.manage_extended_details_holder)
val View.manage_extended_details_name: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_name)
val View.manage_extended_details_path: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_path)
val View.manage_extended_details_size: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_size)
val View.manage_extended_details_resolution: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_resolution)
val View.manage_extended_details_last_modified: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_last_modified)
val View.manage_extended_details_date_taken: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_date_taken)
val View.manage_extended_details_camera: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_camera)
val View.manage_extended_details_exif: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_exif)
val View.manage_extended_details_gps_coordinates: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.manage_extended_details_gps_coordinates)
