package kotlinx.android.synthetic.main.dialog_slideshow.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.slideshow_scrollview get() = findViewById<android.widget.ScrollView>(R.id.slideshow_scrollview)
val View.slideshow_holder get() = findViewById<android.widget.RelativeLayout>(R.id.slideshow_holder)
val View.interval_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.interval_label)
val View.interval_hint get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.interval_hint)
val View.interval_value get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.interval_value)
val View.animation_holder get() = findViewById<android.widget.RelativeLayout>(R.id.animation_holder)
val View.animation_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.animation_label)
val View.animation_value get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.animation_value)
val View.include_videos_holder get() = findViewById<android.widget.RelativeLayout>(R.id.include_videos_holder)
val View.include_videos get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.include_videos)
val View.include_gifs_holder get() = findViewById<android.widget.RelativeLayout>(R.id.include_gifs_holder)
val View.include_gifs get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.include_gifs)
val View.random_order_holder get() = findViewById<android.widget.RelativeLayout>(R.id.random_order_holder)
val View.random_order get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.random_order)
val View.move_backwards_holder get() = findViewById<android.widget.RelativeLayout>(R.id.move_backwards_holder)
val View.move_backwards get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.move_backwards)
val View.loop_slideshow_holder get() = findViewById<android.widget.RelativeLayout>(R.id.loop_slideshow_holder)
val View.loop_slideshow get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.loop_slideshow)
