package kotlinx.android.synthetic.main.activity_media

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.media_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val Dialog.media_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val Fragment.media_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val View.media_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val Activity.media_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val Dialog.media_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val Fragment.media_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val View.media_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val Activity.media_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val Dialog.media_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val Fragment.media_toolbar: com.google.android.material.appbar.MaterialToolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val View.media_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val Activity.media_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val Dialog.media_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val Fragment.media_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val View.media_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val Activity.media_empty_text_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val Dialog.media_empty_text_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val Fragment.media_empty_text_placeholder: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val View.media_empty_text_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val Activity.media_empty_text_placeholder_2: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val Dialog.media_empty_text_placeholder_2: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val Fragment.media_empty_text_placeholder_2: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val View.media_empty_text_placeholder_2: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val Activity.media_refresh_layout: androidx.swiperefreshlayout.widget.SwipeRefreshLayout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val Dialog.media_refresh_layout: androidx.swiperefreshlayout.widget.SwipeRefreshLayout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val Fragment.media_refresh_layout: androidx.swiperefreshlayout.widget.SwipeRefreshLayout get() = requireView().findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val View.media_refresh_layout: androidx.swiperefreshlayout.widget.SwipeRefreshLayout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val Activity.media_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Dialog.media_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Fragment.media_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = requireView().findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val View.media_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Activity.media_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val Dialog.media_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val Fragment.media_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val View.media_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
