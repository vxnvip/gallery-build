package kotlinx.android.synthetic.main.activity_media

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.media_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val Dialog.media_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val Fragment.media_coordinator get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val View.media_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val Activity.media_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val Dialog.media_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val Fragment.media_app_bar_layout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val View.media_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val Activity.media_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val Dialog.media_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val Fragment.media_toolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val View.media_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val Activity.media_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val Dialog.media_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val Fragment.media_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val View.media_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val Activity.media_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val Dialog.media_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val Fragment.media_empty_text_placeholder get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val View.media_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val Activity.media_empty_text_placeholder_2 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val Dialog.media_empty_text_placeholder_2 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val Fragment.media_empty_text_placeholder_2 get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val View.media_empty_text_placeholder_2 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val Activity.media_refresh_layout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val Dialog.media_refresh_layout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val Fragment.media_refresh_layout get() = requireView().findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val View.media_refresh_layout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val Activity.media_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Dialog.media_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Fragment.media_fastscroller get() = requireView().findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val View.media_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Activity.media_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val Dialog.media_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val Fragment.media_grid get() = requireView().findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val View.media_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
