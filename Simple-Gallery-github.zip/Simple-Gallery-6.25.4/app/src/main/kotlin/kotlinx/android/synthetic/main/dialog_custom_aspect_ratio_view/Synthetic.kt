package kotlinx.android.synthetic.main.dialog_custom_aspect_ratio.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.aspect_ratio_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.aspect_ratio_holder)
val View.aspect_ratio_width_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_width_hint)
val View.aspect_ratio_width: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_width)
val View.aspect_ratio_colon: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.aspect_ratio_colon)
val View.aspect_ratio_height_hint: com.simplemobiletools.commons.views.MyTextInputLayout get() = findViewById<com.simplemobiletools.commons.views.MyTextInputLayout>(R.id.aspect_ratio_height_hint)
val View.aspect_ratio_height: com.google.android.material.textfield.TextInputEditText get() = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.aspect_ratio_height)
