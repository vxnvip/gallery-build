package kotlinx.android.synthetic.main.activity_main.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.directories_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.directories_coordinator)
val View.directories_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.directories_app_bar_layout)
val View.directories_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.directories_toolbar)
val View.directories_holder get() = findViewById<android.widget.RelativeLayout>(R.id.directories_holder)
val View.directories_switch_searching get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.directories_switch_searching)
val View.directories_empty_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.directories_empty_placeholder)
val View.directories_empty_placeholder_2 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.directories_empty_placeholder_2)
val View.directories_refresh_layout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.directories_refresh_layout)
val View.directories_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.directories_fastscroller)
val View.directories_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.directories_grid)
