package kotlinx.android.synthetic.main.activity_main.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.directories_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.directories_coordinator)
val View.directories_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.directories_app_bar_layout)
val View.directories_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.directories_toolbar)
val View.directories_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.directories_holder)
val View.directories_switch_searching: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.directories_switch_searching)
val View.directories_empty_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.directories_empty_placeholder)
val View.directories_empty_placeholder_2: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.directories_empty_placeholder_2)
val View.directories_refresh_layout: androidx.swiperefreshlayout.widget.SwipeRefreshLayout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.directories_refresh_layout)
val View.directories_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.directories_fastscroller)
val View.directories_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.directories_grid)
