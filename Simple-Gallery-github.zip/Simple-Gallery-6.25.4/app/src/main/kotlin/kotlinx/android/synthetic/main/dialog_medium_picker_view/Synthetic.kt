package kotlinx.android.synthetic.main.dialog_medium_picker.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.media_grid_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_grid_holder)
val View.media_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val View.media_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
