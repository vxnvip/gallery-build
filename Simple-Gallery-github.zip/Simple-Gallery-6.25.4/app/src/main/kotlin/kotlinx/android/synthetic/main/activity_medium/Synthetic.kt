package kotlinx.android.synthetic.main.activity_medium

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.fragment_holder get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val Dialog.fragment_holder get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val Fragment.fragment_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val View.fragment_holder get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val Activity.view_pager get() = findViewById<com.simplemobiletools.commons.views.MyViewPager>(R.id.view_pager)
val Dialog.view_pager get() = findViewById<com.simplemobiletools.commons.views.MyViewPager>(R.id.view_pager)
val Fragment.view_pager get() = requireView().findViewById<com.simplemobiletools.commons.views.MyViewPager>(R.id.view_pager)
val View.view_pager get() = findViewById<com.simplemobiletools.commons.views.MyViewPager>(R.id.view_pager)
val Activity.bottom_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val Dialog.bottom_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val Fragment.bottom_actions get() = requireView().findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val View.bottom_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val Activity.top_shadow get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val Dialog.top_shadow get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val Fragment.top_shadow get() = requireView().findViewById<android.widget.ImageView>(R.id.top_shadow)
val View.top_shadow get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val Activity.medium_viewer_appbar get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.medium_viewer_appbar)
val Dialog.medium_viewer_appbar get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.medium_viewer_appbar)
val Fragment.medium_viewer_appbar get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.medium_viewer_appbar)
val View.medium_viewer_appbar get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.medium_viewer_appbar)
val Activity.medium_viewer_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.medium_viewer_toolbar)
val Dialog.medium_viewer_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.medium_viewer_toolbar)
val Fragment.medium_viewer_toolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.medium_viewer_toolbar)
val View.medium_viewer_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.medium_viewer_toolbar)
