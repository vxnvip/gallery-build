package kotlinx.android.synthetic.main.dialog_change_folder_thumbnail_style.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.dialog_scrollview)
val View.dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.dialog_holder)
val View.dialog_folder_sample_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_folder_sample_holder)
val View.dialog_radio_folder_style: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_folder_style)
val View.dialog_radio_folder_square: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_folder_square)
val View.dialog_radio_folder_rounded_corners: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_folder_rounded_corners)
val View.dialog_radio_folder_count_holder: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.dialog_radio_folder_count_holder)
val View.dialog_radio_folder_count_line: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_folder_count_line)
val View.dialog_radio_folder_count_brackets: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_folder_count_brackets)
val View.dialog_radio_folder_count_none: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.dialog_radio_folder_count_none)
val View.dialog_folder_limit_title: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.dialog_folder_limit_title)
