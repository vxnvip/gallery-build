package kotlinx.android.synthetic.main.dialog_confirm_delete_folder

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.dialog_confirm_delete_folder_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_confirm_delete_folder_holder)
val Dialog.dialog_confirm_delete_folder_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_confirm_delete_folder_holder)
val Fragment.dialog_confirm_delete_folder_holder: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.dialog_confirm_delete_folder_holder)
val View.dialog_confirm_delete_folder_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_confirm_delete_folder_holder)
val Activity.message: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val Dialog.message: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val Fragment.message: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val View.message: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val Activity.message_warning: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.message_warning)
val Dialog.message_warning: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.message_warning)
val Fragment.message_warning: android.widget.TextView get() = requireView().findViewById<android.widget.TextView>(R.id.message_warning)
val View.message_warning: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.message_warning)
