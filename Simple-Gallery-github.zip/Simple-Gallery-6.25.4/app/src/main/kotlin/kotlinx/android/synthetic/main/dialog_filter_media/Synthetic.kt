package kotlinx.android.synthetic.main.dialog_filter_media

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.filter_media_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.filter_media_dialog_holder)
val Dialog.filter_media_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.filter_media_dialog_holder)
val Fragment.filter_media_dialog_holder: android.widget.LinearLayout get() = requireView().findViewById<android.widget.LinearLayout>(R.id.filter_media_dialog_holder)
val View.filter_media_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.filter_media_dialog_holder)
val Activity.filter_media_images: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_images)
val Dialog.filter_media_images: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_images)
val Fragment.filter_media_images: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_images)
val View.filter_media_images: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_images)
val Activity.filter_media_videos: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_videos)
val Dialog.filter_media_videos: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_videos)
val Fragment.filter_media_videos: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_videos)
val View.filter_media_videos: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_videos)
val Activity.filter_media_gifs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_gifs)
val Dialog.filter_media_gifs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_gifs)
val Fragment.filter_media_gifs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_gifs)
val View.filter_media_gifs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_gifs)
val Activity.filter_media_raws: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_raws)
val Dialog.filter_media_raws: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_raws)
val Fragment.filter_media_raws: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_raws)
val View.filter_media_raws: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_raws)
val Activity.filter_media_svgs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_svgs)
val Dialog.filter_media_svgs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_svgs)
val Fragment.filter_media_svgs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_svgs)
val View.filter_media_svgs: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_svgs)
val Activity.filter_media_portraits: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_portraits)
val Dialog.filter_media_portraits: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_portraits)
val Fragment.filter_media_portraits: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = requireView().findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_portraits)
val View.filter_media_portraits: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.filter_media_portraits)
