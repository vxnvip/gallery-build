package kotlinx.android.synthetic.main.bottom_editor_draw_actions.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.bottom_editor_draw_actions_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_draw_actions_wrapper)
val View.bottom_draw_width: com.simplemobiletools.commons.views.MySeekBar get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.bottom_draw_width)
val View.bottom_draw_color_clickable: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color_clickable)
val View.bottom_draw_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_color)
val View.bottom_draw_undo: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_draw_undo)
