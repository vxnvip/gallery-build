package kotlinx.android.synthetic.main.dialog_change_view_type.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.change_view_type_dialog_scrollview: android.widget.ScrollView get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val View.change_view_type_dialog_holder: android.widget.LinearLayout get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val View.change_view_type_dialog_radio: android.widget.RadioGroup get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val View.change_view_type_dialog_radio_grid: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val View.change_view_type_dialog_radio_list: com.simplemobiletools.commons.views.MyCompatRadioButton get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val View.group_direct_subfolders_divider: android.view.View get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val View.change_view_type_dialog_group_direct_subfolders: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val View.change_view_type_dialog_use_for_this_folder: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
