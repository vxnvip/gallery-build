package kotlinx.android.synthetic.main.dialog_change_view_type.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.change_view_type_dialog_scrollview get() = findViewById<android.widget.ScrollView>(R.id.change_view_type_dialog_scrollview)
val View.change_view_type_dialog_holder get() = findViewById<android.widget.LinearLayout>(R.id.change_view_type_dialog_holder)
val View.change_view_type_dialog_radio get() = findViewById<android.widget.RadioGroup>(R.id.change_view_type_dialog_radio)
val View.change_view_type_dialog_radio_grid get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_grid)
val View.change_view_type_dialog_radio_list get() = findViewById<com.simplemobiletools.commons.views.MyCompatRadioButton>(R.id.change_view_type_dialog_radio_list)
val View.group_direct_subfolders_divider get() = findViewById<android.view.View>(R.id.group_direct_subfolders_divider)
val View.change_view_type_dialog_group_direct_subfolders get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_group_direct_subfolders)
val View.change_view_type_dialog_use_for_this_folder get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.change_view_type_dialog_use_for_this_folder)
