package kotlinx.android.synthetic.main.bottom_actions.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.bottom_actions_wrapper: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions_wrapper)
val View.bottom_favorite: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_favorite)
val View.bottom_edit: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_edit)
val View.bottom_share: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_share)
val View.bottom_delete: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_delete)
val View.bottom_rotate: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val View.bottom_properties: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_properties)
val View.bottom_change_orientation: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_change_orientation)
val View.bottom_slideshow: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_slideshow)
val View.bottom_show_on_map: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_show_on_map)
val View.bottom_toggle_file_visibility: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_toggle_file_visibility)
val View.bottom_rename: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_rename)
val View.bottom_set_as: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_set_as)
val View.bottom_copy: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_copy)
val View.bottom_move: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_move)
val View.bottom_resize: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
