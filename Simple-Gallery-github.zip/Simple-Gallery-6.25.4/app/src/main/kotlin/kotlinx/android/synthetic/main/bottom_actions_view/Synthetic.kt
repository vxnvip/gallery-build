package kotlinx.android.synthetic.main.bottom_actions.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.bottom_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions_wrapper)
val View.bottom_favorite get() = findViewById<android.widget.ImageView>(R.id.bottom_favorite)
val View.bottom_edit get() = findViewById<android.widget.ImageView>(R.id.bottom_edit)
val View.bottom_share get() = findViewById<android.widget.ImageView>(R.id.bottom_share)
val View.bottom_delete get() = findViewById<android.widget.ImageView>(R.id.bottom_delete)
val View.bottom_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val View.bottom_properties get() = findViewById<android.widget.ImageView>(R.id.bottom_properties)
val View.bottom_change_orientation get() = findViewById<android.widget.ImageView>(R.id.bottom_change_orientation)
val View.bottom_slideshow get() = findViewById<android.widget.ImageView>(R.id.bottom_slideshow)
val View.bottom_show_on_map get() = findViewById<android.widget.ImageView>(R.id.bottom_show_on_map)
val View.bottom_toggle_file_visibility get() = findViewById<android.widget.ImageView>(R.id.bottom_toggle_file_visibility)
val View.bottom_rename get() = findViewById<android.widget.ImageView>(R.id.bottom_rename)
val View.bottom_set_as get() = findViewById<android.widget.ImageView>(R.id.bottom_set_as)
val View.bottom_copy get() = findViewById<android.widget.ImageView>(R.id.bottom_copy)
val View.bottom_move get() = findViewById<android.widget.ImageView>(R.id.bottom_move)
val View.bottom_resize get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
