package kotlinx.android.synthetic.main.bottom_editor_crop_rotate_actions.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.bottom_editor_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_actions_wrapper)
val View.bottom_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_rotate)
val View.bottom_resize get() = findViewById<android.widget.ImageView>(R.id.bottom_resize)
val View.bottom_aspect_ratio get() = findViewById<android.widget.ImageView>(R.id.bottom_aspect_ratio)
val View.bottom_flip_horizontally get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_horizontally)
val View.bottom_flip_vertically get() = findViewById<android.widget.ImageView>(R.id.bottom_flip_vertically)
