package kotlinx.android.synthetic.main.fragment_holder.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.fragment_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val View.fragment_placeholder: android.widget.FrameLayout get() = findViewById<android.widget.FrameLayout>(R.id.fragment_placeholder)
val View.top_shadow: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val View.bottom_actions: androidx.constraintlayout.widget.ConstraintLayout get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val View.fragment_viewer_appbar: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.fragment_viewer_appbar)
val View.fragment_viewer_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.fragment_viewer_toolbar)
