package kotlinx.android.synthetic.main.fragment_holder.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.fragment_holder get() = findViewById<android.widget.RelativeLayout>(R.id.fragment_holder)
val View.fragment_placeholder get() = findViewById<android.widget.FrameLayout>(R.id.fragment_placeholder)
val View.top_shadow get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val View.bottom_actions get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_actions)
val View.fragment_viewer_appbar get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.fragment_viewer_appbar)
val View.fragment_viewer_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.fragment_viewer_toolbar)
