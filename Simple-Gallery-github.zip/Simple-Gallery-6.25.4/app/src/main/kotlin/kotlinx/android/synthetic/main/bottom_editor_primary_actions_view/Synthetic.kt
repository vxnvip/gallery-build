package kotlinx.android.synthetic.main.bottom_editor_primary_actions.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.bottom_editor_primary_actions_wrapper get() = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.bottom_editor_primary_actions_wrapper)
val View.bottom_primary_filter get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_filter)
val View.bottom_primary_crop_rotate get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_crop_rotate)
val View.bottom_primary_draw get() = findViewById<android.widget.ImageView>(R.id.bottom_primary_draw)
