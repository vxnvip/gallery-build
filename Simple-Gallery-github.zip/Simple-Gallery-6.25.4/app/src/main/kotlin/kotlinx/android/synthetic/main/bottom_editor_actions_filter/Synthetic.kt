package kotlinx.android.synthetic.main.bottom_editor_actions_filter

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.bottom_actions_filter_wrapper get() = findViewById<android.widget.RelativeLayout>(R.id.bottom_actions_filter_wrapper)
val Dialog.bottom_actions_filter_wrapper get() = findViewById<android.widget.RelativeLayout>(R.id.bottom_actions_filter_wrapper)
val Fragment.bottom_actions_filter_wrapper get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.bottom_actions_filter_wrapper)
val View.bottom_actions_filter_wrapper get() = findViewById<android.widget.RelativeLayout>(R.id.bottom_actions_filter_wrapper)
val Activity.bottom_actions_filter_list get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.bottom_actions_filter_list)
val Dialog.bottom_actions_filter_list get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.bottom_actions_filter_list)
val Fragment.bottom_actions_filter_list get() = requireView().findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.bottom_actions_filter_list)
val View.bottom_actions_filter_list get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.bottom_actions_filter_list)
