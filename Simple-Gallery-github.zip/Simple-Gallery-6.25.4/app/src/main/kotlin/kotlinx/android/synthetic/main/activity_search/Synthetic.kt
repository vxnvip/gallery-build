package kotlinx.android.synthetic.main.activity_search

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.search_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.search_coordinator)
val Dialog.search_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.search_coordinator)
val Fragment.search_coordinator get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.search_coordinator)
val View.search_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.search_coordinator)
val Activity.search_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.search_app_bar_layout)
val Dialog.search_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.search_app_bar_layout)
val Fragment.search_app_bar_layout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.search_app_bar_layout)
val View.search_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.search_app_bar_layout)
val Activity.search_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.search_toolbar)
val Dialog.search_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.search_toolbar)
val Fragment.search_toolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.search_toolbar)
val View.search_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.search_toolbar)
val Activity.search_holder get() = findViewById<android.widget.RelativeLayout>(R.id.search_holder)
val Dialog.search_holder get() = findViewById<android.widget.RelativeLayout>(R.id.search_holder)
val Fragment.search_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.search_holder)
val View.search_holder get() = findViewById<android.widget.RelativeLayout>(R.id.search_holder)
val Activity.search_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.search_empty_text_placeholder)
val Dialog.search_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.search_empty_text_placeholder)
val Fragment.search_empty_text_placeholder get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.search_empty_text_placeholder)
val View.search_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.search_empty_text_placeholder)
val Activity.search_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.search_fastscroller)
val Dialog.search_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.search_fastscroller)
val Fragment.search_fastscroller get() = requireView().findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.search_fastscroller)
val View.search_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.search_fastscroller)
val Activity.search_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.search_grid)
val Dialog.search_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.search_grid)
val Fragment.search_grid get() = requireView().findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.search_grid)
val View.search_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.search_grid)
