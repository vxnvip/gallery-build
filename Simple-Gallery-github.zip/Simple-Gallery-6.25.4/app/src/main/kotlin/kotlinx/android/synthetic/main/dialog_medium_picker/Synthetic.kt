package kotlinx.android.synthetic.main.dialog_medium_picker

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.media_grid_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_grid_holder)
val Dialog.media_grid_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_grid_holder)
val Fragment.media_grid_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.media_grid_holder)
val View.media_grid_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_grid_holder)
val Activity.media_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Dialog.media_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Fragment.media_fastscroller get() = requireView().findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val View.media_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val Activity.media_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val Dialog.media_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val Fragment.media_grid get() = requireView().findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
val View.media_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
