package kotlinx.android.synthetic.main.activity_media.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.media_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val View.media_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val View.media_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val View.media_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val View.media_empty_text_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val View.media_empty_text_placeholder_2: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val View.media_refresh_layout: androidx.swiperefreshlayout.widget.SwipeRefreshLayout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val View.media_fastscroller: com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val View.media_grid: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
