package kotlinx.android.synthetic.main.activity_media.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.media_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.media_coordinator)
val View.media_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.media_app_bar_layout)
val View.media_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.media_toolbar)
val View.media_holder get() = findViewById<android.widget.RelativeLayout>(R.id.media_holder)
val View.media_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder)
val View.media_empty_text_placeholder_2 get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.media_empty_text_placeholder_2)
val View.media_refresh_layout get() = findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.media_refresh_layout)
val View.media_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.media_fastscroller)
val View.media_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.media_grid)
