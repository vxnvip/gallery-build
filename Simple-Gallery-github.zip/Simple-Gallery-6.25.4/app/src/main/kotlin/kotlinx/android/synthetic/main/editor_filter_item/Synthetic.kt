package kotlinx.android.synthetic.main.editor_filter_item

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.editor_filter_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.editor_filter_item_holder)
val Dialog.editor_filter_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.editor_filter_item_holder)
val Fragment.editor_filter_item_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.editor_filter_item_holder)
val View.editor_filter_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.editor_filter_item_holder)
val Activity.editor_filter_item_thumbnail get() = findViewById<android.widget.ImageView>(R.id.editor_filter_item_thumbnail)
val Dialog.editor_filter_item_thumbnail get() = findViewById<android.widget.ImageView>(R.id.editor_filter_item_thumbnail)
val Fragment.editor_filter_item_thumbnail get() = requireView().findViewById<android.widget.ImageView>(R.id.editor_filter_item_thumbnail)
val View.editor_filter_item_thumbnail get() = findViewById<android.widget.ImageView>(R.id.editor_filter_item_thumbnail)
val Activity.editor_filter_item_label get() = findViewById<android.widget.TextView>(R.id.editor_filter_item_label)
val Dialog.editor_filter_item_label get() = findViewById<android.widget.TextView>(R.id.editor_filter_item_label)
val Fragment.editor_filter_item_label get() = requireView().findViewById<android.widget.TextView>(R.id.editor_filter_item_label)
val View.editor_filter_item_label get() = findViewById<android.widget.TextView>(R.id.editor_filter_item_label)
