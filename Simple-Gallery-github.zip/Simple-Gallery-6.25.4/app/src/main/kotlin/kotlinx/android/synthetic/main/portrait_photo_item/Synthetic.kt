package kotlinx.android.synthetic.main.portrait_photo_item

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.portrait_photo_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.portrait_photo_item_holder)
val Dialog.portrait_photo_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.portrait_photo_item_holder)
val Fragment.portrait_photo_item_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.portrait_photo_item_holder)
val View.portrait_photo_item_holder get() = findViewById<android.widget.RelativeLayout>(R.id.portrait_photo_item_holder)
val Activity.portrait_photo_item_thumbnail get() = findViewById<android.widget.ImageView>(R.id.portrait_photo_item_thumbnail)
val Dialog.portrait_photo_item_thumbnail get() = findViewById<android.widget.ImageView>(R.id.portrait_photo_item_thumbnail)
val Fragment.portrait_photo_item_thumbnail get() = requireView().findViewById<android.widget.ImageView>(R.id.portrait_photo_item_thumbnail)
val View.portrait_photo_item_thumbnail get() = findViewById<android.widget.ImageView>(R.id.portrait_photo_item_thumbnail)
