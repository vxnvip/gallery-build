package kotlinx.android.synthetic.main.dialog_confirm_delete_folder.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.dialog_confirm_delete_folder_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.dialog_confirm_delete_folder_holder)
val View.message: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.message)
val View.message_warning: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.message_warning)
