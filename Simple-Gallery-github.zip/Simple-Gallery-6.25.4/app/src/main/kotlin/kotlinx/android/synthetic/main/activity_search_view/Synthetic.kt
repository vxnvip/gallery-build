package kotlinx.android.synthetic.main.activity_search.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.search_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.search_coordinator)
val View.search_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.search_app_bar_layout)
val View.search_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.search_toolbar)
val View.search_holder get() = findViewById<android.widget.RelativeLayout>(R.id.search_holder)
val View.search_empty_text_placeholder get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.search_empty_text_placeholder)
val View.search_fastscroller get() = findViewById<com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller>(R.id.search_fastscroller)
val View.search_grid get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.search_grid)
