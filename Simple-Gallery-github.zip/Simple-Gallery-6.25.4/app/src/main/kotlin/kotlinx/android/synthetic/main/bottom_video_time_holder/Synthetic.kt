package kotlinx.android.synthetic.main.bottom_video_time_holder

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.video_time_holder get() = findViewById<android.widget.RelativeLayout>(R.id.video_time_holder)
val Dialog.video_time_holder get() = findViewById<android.widget.RelativeLayout>(R.id.video_time_holder)
val Fragment.video_time_holder get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.video_time_holder)
val View.video_time_holder get() = findViewById<android.widget.RelativeLayout>(R.id.video_time_holder)
val Activity.video_prev_file get() = findViewById<android.widget.ImageView>(R.id.video_prev_file)
val Dialog.video_prev_file get() = findViewById<android.widget.ImageView>(R.id.video_prev_file)
val Fragment.video_prev_file get() = requireView().findViewById<android.widget.ImageView>(R.id.video_prev_file)
val View.video_prev_file get() = findViewById<android.widget.ImageView>(R.id.video_prev_file)
val Activity.video_toggle_play_pause get() = findViewById<android.widget.ImageView>(R.id.video_toggle_play_pause)
val Dialog.video_toggle_play_pause get() = findViewById<android.widget.ImageView>(R.id.video_toggle_play_pause)
val Fragment.video_toggle_play_pause get() = requireView().findViewById<android.widget.ImageView>(R.id.video_toggle_play_pause)
val View.video_toggle_play_pause get() = findViewById<android.widget.ImageView>(R.id.video_toggle_play_pause)
val Activity.video_next_file get() = findViewById<android.widget.ImageView>(R.id.video_next_file)
val Dialog.video_next_file get() = findViewById<android.widget.ImageView>(R.id.video_next_file)
val Fragment.video_next_file get() = requireView().findViewById<android.widget.ImageView>(R.id.video_next_file)
val View.video_next_file get() = findViewById<android.widget.ImageView>(R.id.video_next_file)
val Activity.video_curr_time get() = findViewById<android.widget.TextView>(R.id.video_curr_time)
val Dialog.video_curr_time get() = findViewById<android.widget.TextView>(R.id.video_curr_time)
val Fragment.video_curr_time get() = requireView().findViewById<android.widget.TextView>(R.id.video_curr_time)
val View.video_curr_time get() = findViewById<android.widget.TextView>(R.id.video_curr_time)
val Activity.video_seekbar get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.video_seekbar)
val Dialog.video_seekbar get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.video_seekbar)
val Fragment.video_seekbar get() = requireView().findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.video_seekbar)
val View.video_seekbar get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.video_seekbar)
val Activity.video_duration get() = findViewById<android.widget.TextView>(R.id.video_duration)
val Dialog.video_duration get() = findViewById<android.widget.TextView>(R.id.video_duration)
val Fragment.video_duration get() = requireView().findViewById<android.widget.TextView>(R.id.video_duration)
val View.video_duration get() = findViewById<android.widget.TextView>(R.id.video_duration)
