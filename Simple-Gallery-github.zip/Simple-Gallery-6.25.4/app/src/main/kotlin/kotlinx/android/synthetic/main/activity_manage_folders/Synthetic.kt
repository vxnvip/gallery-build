package kotlinx.android.synthetic.main.activity_manage_folders

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val Activity.manage_folders_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.manage_folders_coordinator)
val Dialog.manage_folders_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.manage_folders_coordinator)
val Fragment.manage_folders_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = requireView().findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.manage_folders_coordinator)
val View.manage_folders_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.manage_folders_coordinator)
val Activity.manage_folders_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.manage_folders_app_bar_layout)
val Dialog.manage_folders_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.manage_folders_app_bar_layout)
val Fragment.manage_folders_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = requireView().findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.manage_folders_app_bar_layout)
val View.manage_folders_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.manage_folders_app_bar_layout)
val Activity.manage_folders_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.manage_folders_toolbar)
val Dialog.manage_folders_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.manage_folders_toolbar)
val Fragment.manage_folders_toolbar: com.google.android.material.appbar.MaterialToolbar get() = requireView().findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.manage_folders_toolbar)
val View.manage_folders_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.manage_folders_toolbar)
val Activity.manage_folders_wrapper: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.manage_folders_wrapper)
val Dialog.manage_folders_wrapper: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.manage_folders_wrapper)
val Fragment.manage_folders_wrapper: android.widget.RelativeLayout get() = requireView().findViewById<android.widget.RelativeLayout>(R.id.manage_folders_wrapper)
val View.manage_folders_wrapper: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.manage_folders_wrapper)
val Activity.manage_folders_list: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.manage_folders_list)
val Dialog.manage_folders_list: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.manage_folders_list)
val Fragment.manage_folders_list: com.simplemobiletools.commons.views.MyRecyclerView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.manage_folders_list)
val View.manage_folders_list: com.simplemobiletools.commons.views.MyRecyclerView get() = findViewById<com.simplemobiletools.commons.views.MyRecyclerView>(R.id.manage_folders_list)
val Activity.manage_folders_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_folders_placeholder)
val Dialog.manage_folders_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_folders_placeholder)
val Fragment.manage_folders_placeholder: com.simplemobiletools.commons.views.MyTextView get() = requireView().findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_folders_placeholder)
val View.manage_folders_placeholder: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.manage_folders_placeholder)
