package kotlinx.android.synthetic.main.activity_widget_config.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.config_coordinator: androidx.coordinatorlayout.widget.CoordinatorLayout get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.config_coordinator)
val View.config_app_bar_layout: com.google.android.material.appbar.AppBarLayout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.config_app_bar_layout)
val View.config_toolbar: com.google.android.material.appbar.MaterialToolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.config_toolbar)
val View.config_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.config_holder)
val View.folder_picker_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.folder_picker_holder)
val View.folder_picker_show_folder_name_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.folder_picker_show_folder_name_holder)
val View.folder_picker_show_folder_name: com.simplemobiletools.commons.views.MyAppCompatCheckbox get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.folder_picker_show_folder_name)
val View.folder_picker_label: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.folder_picker_label)
val View.folder_picker_value: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.folder_picker_value)
val View.config_image_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.config_image_holder)
val View.config_image: com.simplemobiletools.commons.views.MySquareImageView get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.config_image)
val View.config_folder_name: com.simplemobiletools.commons.views.MyTextView get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.config_folder_name)
val View.config_bg_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.config_bg_color)
val View.config_bg_seekbar_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.config_bg_seekbar_holder)
val View.config_bg_seekbar: com.simplemobiletools.commons.views.MySeekBar get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.config_bg_seekbar)
val View.config_text_color: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.config_text_color)
val View.config_save: android.widget.Button get() = findViewById<android.widget.Button>(R.id.config_save)
