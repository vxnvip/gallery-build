package kotlinx.android.synthetic.main.activity_widget_config.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.config_coordinator get() = findViewById<androidx.coordinatorlayout.widget.CoordinatorLayout>(R.id.config_coordinator)
val View.config_app_bar_layout get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.config_app_bar_layout)
val View.config_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.config_toolbar)
val View.config_holder get() = findViewById<android.widget.RelativeLayout>(R.id.config_holder)
val View.folder_picker_holder get() = findViewById<android.widget.RelativeLayout>(R.id.folder_picker_holder)
val View.folder_picker_show_folder_name_holder get() = findViewById<android.widget.RelativeLayout>(R.id.folder_picker_show_folder_name_holder)
val View.folder_picker_show_folder_name get() = findViewById<com.simplemobiletools.commons.views.MyAppCompatCheckbox>(R.id.folder_picker_show_folder_name)
val View.folder_picker_label get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.folder_picker_label)
val View.folder_picker_value get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.folder_picker_value)
val View.config_image_holder get() = findViewById<android.widget.RelativeLayout>(R.id.config_image_holder)
val View.config_image get() = findViewById<com.simplemobiletools.commons.views.MySquareImageView>(R.id.config_image)
val View.config_folder_name get() = findViewById<com.simplemobiletools.commons.views.MyTextView>(R.id.config_folder_name)
val View.config_bg_color get() = findViewById<android.widget.ImageView>(R.id.config_bg_color)
val View.config_bg_seekbar_holder get() = findViewById<android.widget.RelativeLayout>(R.id.config_bg_seekbar_holder)
val View.config_bg_seekbar get() = findViewById<com.simplemobiletools.commons.views.MySeekBar>(R.id.config_bg_seekbar)
val View.config_text_color get() = findViewById<android.widget.ImageView>(R.id.config_text_color)
val View.config_save get() = findViewById<android.widget.Button>(R.id.config_save)
