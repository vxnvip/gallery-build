package kotlinx.android.synthetic.main.pager_photo_item.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.photo_holder: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.photo_holder)
val View.gestures_view: com.alexvasilkov.gestures.GestureImageView get() = findViewById<com.alexvasilkov.gestures.GestureImageView>(R.id.gestures_view)
val View.gif_view_frame: com.alexvasilkov.gestures.GestureFrameLayout get() = findViewById<com.alexvasilkov.gestures.GestureFrameLayout>(R.id.gif_view_frame)
val View.gif_view: pl.droidsonroids.gif.GifTextureView get() = findViewById<pl.droidsonroids.gif.GifTextureView>(R.id.gif_view)
val View.subsampling_view: com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView get() = findViewById<com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView>(R.id.subsampling_view)
val View.panorama_outline: android.widget.ImageView get() = findViewById<android.widget.ImageView>(R.id.panorama_outline)
val View.photo_details: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.photo_details)
val View.photo_brightness_controller: com.simplemobiletools.gallery.pro.views.MediaSideScroll get() = findViewById<com.simplemobiletools.gallery.pro.views.MediaSideScroll>(R.id.photo_brightness_controller)
val View.slide_info: android.widget.TextView get() = findViewById<android.widget.TextView>(R.id.slide_info)
val View.photo_portrait_stripe_wrapper: android.widget.RelativeLayout get() = findViewById<android.widget.RelativeLayout>(R.id.photo_portrait_stripe_wrapper)
val View.photo_portrait_stripe: androidx.recyclerview.widget.RecyclerView get() = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.photo_portrait_stripe)
val View.instant_prev_item: com.simplemobiletools.gallery.pro.views.InstantItemSwitch get() = findViewById<com.simplemobiletools.gallery.pro.views.InstantItemSwitch>(R.id.instant_prev_item)
val View.instant_next_item: com.simplemobiletools.gallery.pro.views.InstantItemSwitch get() = findViewById<com.simplemobiletools.gallery.pro.views.InstantItemSwitch>(R.id.instant_next_item)
