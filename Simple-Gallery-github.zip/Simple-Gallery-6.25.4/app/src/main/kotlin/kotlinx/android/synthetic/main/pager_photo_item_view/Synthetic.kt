package kotlinx.android.synthetic.main.pager_photo_item.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.photo_holder get() = findViewById<android.widget.RelativeLayout>(R.id.photo_holder)
val View.gestures_view get() = findViewById<com.alexvasilkov.gestures.GestureImageView>(R.id.gestures_view)
val View.gif_view_frame get() = findViewById<com.alexvasilkov.gestures.GestureFrameLayout>(R.id.gif_view_frame)
val View.gif_view get() = findViewById<pl.droidsonroids.gif.GifTextureView>(R.id.gif_view)
val View.subsampling_view get() = findViewById<com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView>(R.id.subsampling_view)
val View.panorama_outline get() = findViewById<android.widget.ImageView>(R.id.panorama_outline)
val View.photo_details get() = findViewById<android.widget.TextView>(R.id.photo_details)
val View.photo_brightness_controller get() = findViewById<com.simplemobiletools.gallery.pro.views.MediaSideScroll>(R.id.photo_brightness_controller)
val View.slide_info get() = findViewById<android.widget.TextView>(R.id.slide_info)
val View.photo_portrait_stripe_wrapper get() = findViewById<android.widget.RelativeLayout>(R.id.photo_portrait_stripe_wrapper)
val View.photo_portrait_stripe get() = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.photo_portrait_stripe)
val View.instant_prev_item get() = findViewById<com.simplemobiletools.gallery.pro.views.InstantItemSwitch>(R.id.instant_prev_item)
val View.instant_next_item get() = findViewById<com.simplemobiletools.gallery.pro.views.InstantItemSwitch>(R.id.instant_next_item)
