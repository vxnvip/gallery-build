package com.simplemobiletools.gallery.pro.interfaces

import com.simplemobiletools.commons.models.FileDirItem
import com.simplemobiletools.gallery.pro.models.ThumbnailItem

interface MediaOperationsListener {
    fun refreshItems()

    fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>)

    fun selectedPaths(paths: ArrayList<String>)

    fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>)

    fun mediaReordered(media: ArrayList<ThumbnailItem>) {}

    // đặt ảnh được chọn làm ảnh bìa của album đang mở
    fun canSetAlbumCover(): Boolean = false

    fun setAlbumCover(path: String) {}
}
