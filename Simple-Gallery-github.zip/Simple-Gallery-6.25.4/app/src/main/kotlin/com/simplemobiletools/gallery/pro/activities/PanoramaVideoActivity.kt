package com.simplemobiletools.gallery.pro.activities

import android.os.Bundle

/** Bản rỗng: đã bỏ Google VR SDK để APK nhỏ. Chạm vào nút panorama chỉ quay lại. */
open class PanoramaVideoActivity : SimpleActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        finish()
    }
}
