package com.zomato.photofilters

import android.content.Context
import android.graphics.ColorMatrix
import com.zomato.photofilters.imageprocessors.Filter

object FilterPack {
    @JvmStatic
    fun getFilterPack(context: Context): List<Filter> {
        fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }
        fun scale(r: Float, g: Float, b: Float) = ColorMatrix(floatArrayOf(
            r, 0f, 0f, 0f, 0f,
            0f, g, 0f, 0f, 0f,
            0f, 0f, b, 0f, 0f,
            0f, 0f, 0f, 1f, 0f))
        fun contrast(c: Float, brightness: Float = 0f): ColorMatrix {
            val t = (-0.5f * c + 0.5f) * 255f + brightness
            return ColorMatrix(floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f))
        }
        val sepia = ColorMatrix().apply { setSaturation(0f); postConcat(scale(1.07f, 0.74f, 0.43f)) }
        val vivid = ColorMatrix().apply { setSaturation(1.5f); postConcat(contrast(1.1f)) }
        val fade = ColorMatrix().apply { setSaturation(0.7f); postConcat(contrast(0.85f, 20f)) }
        return listOf(
            Filter("Mono", sat(0f)),
            Filter("Sepia", sepia),
            Filter("Warm", scale(1.12f, 1.0f, 0.88f)),
            Filter("Cool", scale(0.9f, 1.0f, 1.12f)),
            Filter("Vivid", vivid),
            Filter("Fade", fade),
            Filter("Contrast", contrast(1.3f))
        )
    }
}
