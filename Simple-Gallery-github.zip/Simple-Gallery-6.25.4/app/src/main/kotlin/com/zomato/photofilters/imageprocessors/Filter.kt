package com.zomato.photofilters.imageprocessors

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode

/** Bo loc anh don gian (thay thu vien com.zomato.photofilters). processFilter sua truc tiep bitmap neu co the. */
open class Filter(var name: String = "", private val matrix: ColorMatrix? = null) {
    open fun processFilter(input: Bitmap): Bitmap {
        val m = matrix ?: return input
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(m)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC)
        }
        return if (input.isMutable) {
            val copy = input.copy(Bitmap.Config.ARGB_8888, false)
            Canvas(input).drawBitmap(copy, 0f, 0f, paint)
            copy.recycle()
            input
        } else {
            val out = input.copy(Bitmap.Config.ARGB_8888, true)
            Canvas(out).drawBitmap(input, 0f, 0f, paint)
            out
        }
    }
}
