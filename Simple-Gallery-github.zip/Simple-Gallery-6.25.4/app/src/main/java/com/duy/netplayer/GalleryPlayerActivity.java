package com.duy.netplayer;

/**
 * Bản PlayerActivity dành cho đường mở từ Gallery: dùng theme nền đen (không trong suốt)
 * nên list bên dưới không bị dịch lên/xuống khi thanh trạng thái ẩn/hiện.
 * Toàn bộ logic nằm ở PlayerActivity.
 */
public class GalleryPlayerActivity extends PlayerActivity {
}
