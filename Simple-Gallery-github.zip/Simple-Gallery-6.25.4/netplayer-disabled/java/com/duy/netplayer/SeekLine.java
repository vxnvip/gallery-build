package com.duy.netplayer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** Thanh tiến trình chỉ để hiển thị (không nhận chạm) dùng cho lúc vuốt tua khi thanh chức năng ẩn. */
public final class SeekLine extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private long progress, max = 1;

    public SeekLine(Context c, AttributeSet a) {
        super(c, a);
        dp = c.getResources().getDisplayMetrics().density;
        track.setColor(0xFF888888);
        track.setStrokeWidth(4 * dp);
        track.setStrokeCap(Paint.Cap.ROUND);
        fill.setColor(0xFF4CAF50);
        fill.setStrokeWidth(4 * dp);
        fill.setStrokeCap(Paint.Cap.ROUND);
        ring.setColor(0x66FFFFFF);
        dot.setColor(0xFF4CAF50);
    }

    void set(long p, long m) {
        max = Math.max(1, m);
        progress = Math.max(0, Math.min(max, p));
        invalidate();
    }

    private float pad() {
        return 16 * dp;
    }

    /** Vị trí ngang của núm, tính từ mép trái của view. */
    float thumbX() {
        return pad() + progress / (float) max * Math.max(1, getWidth() - 2 * pad());
    }

    @Override
    protected void onDraw(Canvas cv) {
        float cy = getHeight() / 2f, x0 = pad(), x1 = getWidth() - pad(), tx = thumbX();
        cv.drawLine(x0, cy, x1, cy, track);
        cv.drawLine(x0, cy, tx, cy, fill);
        cv.drawCircle(tx, cy, 15 * dp, ring);
        cv.drawCircle(tx, cy, 8 * dp, dot);
    }
}
