package com.duy.netplayer;

import com.simplemobiletools.gallery.pro.R;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/**
 * Phát nền: PlayerActivity giao nguyên MpEngine (MediaPlayer) đang chạy cho service này (không tạo lại,
 * không buffer lại), service giữ nó sống bằng foreground service + thông báo có nút phát/tạm dừng/đóng.
 * Bấm thông báo -> mở lại PlayerActivity và nhận lại đúng player đó, xem tiếp cả hình.
 */
public class BackgroundPlayService extends Service {
    static final String ACTION_TOGGLE = "com.duy.netplayer.TOGGLE";
    static final String ACTION_STOP = "com.duy.netplayer.STOP";
    private static final String CHANNEL = "bg_play";
    private static final int NOTI_ID = 7;

    // player + trạng thái đi kèm (để Activity nhận lại được)
    private static MpEngine player;
    private static Uri uri;
    private static String title, referer;
    private static BackgroundPlayService instance;

    private MpEngine.Listener listener;
    private final Handler mainH = new Handler(Looper.getMainLooper());
    private boolean closed;
    private SpectrumOverlay spectrum;
    private View overlay; // cửa sổ 1px trong suốt: Android 15 chỉ cho app có quyền 'hiển thị trên ứng dụng khác' mở Activity từ nền khi có overlay đang hiện
    private MediaSession session; // cho thanh tua trên thông báo (Android 13+), khóa màn hình, nút tai nghe

    /** Giao player cho service và bắt đầu phát nền. Activity phải tự gỡ listener + view khỏi player trước. */
    static void start(Context c, MpEngine p, Uri u, String t, String ref) {
        if (player != null && player != p) discard(c); // đang có player nền khác thì bỏ
        player = p;
        uri = u;
        title = t;
        referer = ref;
        c.startForegroundService(new Intent(c, BackgroundPlayService.class));
    }

    // zoom / vị trí hình lúc chuyển sang phát nền: giữ tới khi mở lại, reset khi thoát hẳn
    private static String viewKey;
    private static float vZoom = 1f, vPanX, vPanY;
    private static int vAspect;

    static void saveView(String k, float z, float px, float py, int aspect) {
        viewKey = k;
        vZoom = z;
        vPanX = px;
        vPanY = py;
        vAspect = aspect;
    }

    /** Lấy {zoom, panX, panY, aspect} đã lưu cho video này (nếu có), rồi xóa. */
    static float[] takeView(String k) {
        if (viewKey == null || !viewKey.equals(k)) return null;
        viewKey = null;
        return new float[]{vZoom, vPanX, vPanY, vAspect};
    }

    static Uri currentUri() { return player != null ? uri : null; }

    static boolean has(Uri u) {
        return player != null && uri != null && uri.equals(u);
    }

    /** Activity nhận lại player để xem tiếp cả hình. Service tự dừng nhưng KHÔNG release player. */
    static MpEngine take(Context c) {
        MpEngine p = player;
        BackgroundPlayService s = instance;
        if (s != null) s.detach();
        player = null;
        if (s != null) {
            s.stopForeground(STOP_FOREGROUND_REMOVE);
            s.stopSelf();
        }
        return p;
    }

    static String takeReferer() { return referer; }

    /** Thời gian tối đa giữa 2 lần bấm thân thông báo (lần 1 thu bảng thông báo nên cần kéo xuống lại). */
    static final long TAP_WINDOW_MS = 4000;
    static long lastTap;

    /** Intent mở lại player đúng video đang phát nền; null nếu không còn phát nền. */
    static Intent openIntent(Context c) {
        if (player == null || uri == null) return null;
        Intent open = new Intent(c, PlayerActivity.class).setData(uri);
        if (referer != null) open.putExtra("referer", referer);
        if (title != null) open.putExtra("title", title);
        open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        return open;
    }

    /** Dừng hẳn và giải phóng player nền (nếu có). */
    static void discard(Context c) {
        if (instance != null) {
            instance.shutdown(); // đồng bộ, để không lỡ tay dừng nhầm player mới
        } else if (player != null) {
            player.release();
            player = null;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Phát nền", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);

        session = new MediaSession(this, "NetPlayer");
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                if (player == null) return;
                if (player.getState() == MpEngine.ENDED) player.seekTo(0);
                player.play();
                refresh();
            }

            @Override
            public void onPause() {
                if (player == null) return;
                player.pause();
                refresh();
            }

            @Override
            public void onSeekTo(long pos) {
                if (player == null) return;
                // kẹp trong [0, hết-1s]: kéo thanh tới sát cuối mà để hết video thì service tự đóng ngay
                long dur = player.getDuration();
                long t = Math.max(0, pos);
                if (dur > 1000) t = Math.min(t, dur - 1000);
                player.seekTo(t); // listener onSeekDone sẽ tự cập nhật thông báo
            }

            @Override
            public void onStop() {
                mainH.post(BackgroundPlayService.this::shutdown);
            }

            @Override
            public void onCustomAction(String action, Bundle extras) {
                android.util.Log.i("NPBG", "onCustomAction action=" + action + " overlay=" + (overlay != null)
                        + " canDraw=" + Settings.canDrawOverlays(BackgroundPlayService.this));
                if ("open".equals(action)) { // nút "Mở" trên thẻ media: mở 1 chạm
                    addOverlay(); // đảm bảo có overlay (nếu chưa/đã mất), đợi nó hiện rồi mới mở
                    mainH.postDelayed(() -> {
                        try {
                            startActivity(buildOpenIntent());
                            collapseShade(); // mở từ service nên hệ thống không tự thu bảng thông báo
                        } catch (Throwable e) {
                            App.saveLog(BackgroundPlayService.this, "Không mở được từ nút Mở", e);
                        }
                    }, overlay != null ? 150 : 0);
                }
            }
        });
        session.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(act)) {
            shutdown();
            return START_NOT_STICKY;
        }
        if (player == null) { // bị hệ thống khởi động lại mà không còn player
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_TOGGLE.equals(act)) {
            if (player.isPlaying() || player.getPlayWhenReady()) player.pause();
            else {
                if (player.getState() == MpEngine.ENDED) player.seekTo(0);
                player.play();
            }
            refresh();
            return START_NOT_STICKY;
        }
        // lần đầu: vào foreground ngay
        closed = false;
        updateSession();
        Notification n = build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTI_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTI_ID, n);
        }
        addOverlay();
        updateSpectrum();
        scheduleSpectrumRetry();
        if (listener == null) {
            listener = new MpEngine.Listener() {
                @Override
                void onPlaying(boolean playing) {
                    refresh();
                }

                @Override
                void onState(int st) {
                    if (st == MpEngine.ENDED) mainH.post(BackgroundPlayService.this::shutdown); // không release player ngay trong callback của chính nó
                    else refresh(); // READY: đã biết thời lượng -> cập nhật thanh tua
                }

                @Override
                void onSeekDone() {
                    refresh(); // vừa tua
                }

                @Override
                void onError(int what, int extra) {
                    App.saveLog(BackgroundPlayService.this, "Lỗi phát nền what=" + what + " extra=" + extra, null);
                    mainH.post(BackgroundPlayService.this::shutdown);
                }
            };
            player.setListener(listener);
        }
        return START_NOT_STICKY;
    }

    private void detach() {
        if (player != null && listener != null) player.removeListener(listener);
        listener = null;
    }

    private void refresh() {
        updateSession();
        notifyNow();
        updateSpectrum();
    }

    /** Đang phát -> bật dải cột nhạc trên thanh trạng thái; tạm dừng / dừng -> tắt. */
    private void updateSpectrum() {
        if (spectrum == null) spectrum = new SpectrumOverlay(this);
        if (player != null && !closed && (player.isPlaying() || player.getPlayWhenReady())) {
            spectrum.start(player.audioSession());
        } else {
            spectrum.stop();
        }
    }

    private final Runnable spectrumRetry = this::updateSpectrum;

    /** Player có thể chưa kịp báo trạng thái ngay sau khi vào foreground: thử lại vài lần, không chờ event. */
    private void scheduleSpectrumRetry() {
        mainH.removeCallbacks(spectrumRetry);
        mainH.postDelayed(spectrumRetry, 400);
        mainH.postDelayed(spectrumRetry, 1500);
    }

    /** Đẩy vị trí / thời lượng / trạng thái vào MediaSession: hệ thống dùng để vẽ thanh tua và tự chạy thanh khi đang phát. */
    private void updateSession() {
        if (player == null || session == null) return;
        long dur = player.getDuration();
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title == null ? "NetPlayer" : title)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur > 0 ? dur : -1)
                .build());
        boolean playing = player.getPlayWhenReady() && player.getState() == MpEngine.READY;
        int st;
        if (player.getState() == MpEngine.BUFFERING && player.getPlayWhenReady()) {
            st = PlaybackState.STATE_BUFFERING;
        } else if (playing) {
            st = PlaybackState.STATE_PLAYING;
        } else {
            st = PlaybackState.STATE_PAUSED;
        }
        float spd = playing ? player.getSpeed() : 0f;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                        | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SEEK_TO
                        | PlaybackState.ACTION_STOP)
                // 3 nút đệm trong suốt (không làm gì): 2 bên nút phát/tạm dừng mỗi bên 2 ô -> nút phát ở chính giữa, "Mở" ở ô ngoài cùng bên phải
                .addCustomAction(new PlaybackState.CustomAction.Builder("pad1", " ", R.drawable.ic_blank).build())
                .addCustomAction(new PlaybackState.CustomAction.Builder("pad2", " ", R.drawable.ic_blank).build())
                .addCustomAction(new PlaybackState.CustomAction.Builder("pad3", " ", R.drawable.ic_blank).build())
                .addCustomAction(new PlaybackState.CustomAction.Builder(
                        "open", "Mở", R.drawable.ic_open).build())
                .setState(st, player.getCurrentPosition(), spd)
                .build());
    }

    private void notifyNow() {
        if (player == null || session == null) return;
        getSystemService(NotificationManager.class).notify(NOTI_ID, build());
    }

    /** Lưu vị trí, giải phóng player, gỡ thông báo, dừng service. */
    private void shutdown() {
        if (closed) return;
        closed = true;
        mainH.removeCallbacks(spectrumRetry);
        if (spectrum != null) spectrum.stop();
        removeOverlay();
        detach();
        viewKey = null; // thoát hẳn: reset zoom
        if (player != null) {
            if (uri != null) {
                getSharedPreferences("pos", 0).edit().putLong(uri.toString(),
                        player.getState() == MpEngine.ENDED ? 0 : player.getCurrentPosition()).apply();
            }
            player.release();
            player = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private Notification build() {
        boolean playing = player != null && player.getPlayWhenReady()
                && player.getState() != MpEngine.ENDED;

        // contentIntent chỉ để Samsung hiện chip tai nghe + tên (bỏ nó là mất chip). Broadcast NOOP không có receiver nên không làm gì.
        PendingIntent content = PendingIntent.getBroadcast(this, 3,
                new Intent("com.duy.netplayer.NOOP").setPackage(getPackageName()),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Action toggle = new Notification.Action.Builder(
                Icon.createWithResource(this, playing ? R.drawable.ic_pause : R.drawable.ic_play),
                playing ? "Tạm dừng" : "Phát", actionIntent(1, ACTION_TOGGLE)).build();
        Notification.Action close = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_close),
                "Đóng", actionIntent(2, ACTION_STOP)).build();

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_headphones)
                .setContentTitle(title == null || title.isEmpty() ? "NetPlayer" : title)
                .setContentText(playing ? "Đang phát nền" : "Đã tạm dừng")
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(toggle)
                .addAction(close)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .build();
    }

    private Intent buildOpenIntent() {
        // Không setData / không xin grant URI: service không có quyền với content:// đó (SecurityException).
        // PlayerActivity tự lấy lại URI từ player nền qua extra from_bg.
        Intent open = new Intent(this, PlayerActivity.class).putExtra("from_bg", true);
        if (referer != null) open.putExtra("referer", referer);
        if (title != null) open.putExtra("title", title);
        // MULTIPLE_TASK: luôn mở player trong task RIÊNG (không chồng lên task cũ có trang chủ app bên dưới),
        // để thoát ra là về app / màn hình trước đó chứ không rơi vào trang chủ NetPlayer.
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        return open;
    }

    /** Thu bảng thông báo (cần quyền EXPAND_STATUS_BAR; gọi hàm ẩn của StatusBarManager qua reflection). */
    private void collapseShade() {
        try {
            Object sb = getSystemService("statusbar");
            Class.forName("android.app.StatusBarManager").getMethod("collapsePanels").invoke(sb);
        } catch (Throwable e) {
            android.util.Log.w("NPBG", "collapsePanels lỗi", e);
        }
    }

    private void addOverlay() {
        if (overlay != null) return;
        if (!Settings.canDrawOverlays(this)) {
            android.util.Log.w("NPBG", "Chưa có quyền 'Hiển thị trên các ứng dụng khác' -> không tạo overlay");
            return;
        }
        try {
            View v = new View(this);
            v.setBackgroundColor(0x02000000);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            getSystemService(WindowManager.class).addView(v, lp);
            overlay = v;
        } catch (Exception e) {
            android.util.Log.e("NPBG", "addView overlay lỗi", e);
            App.saveLog(this, "Không tạo được overlay", e);
        }
    }

    private void removeOverlay() {
        if (overlay == null) return;
        try { getSystemService(WindowManager.class).removeView(overlay); } catch (Exception ignored) {}
        overlay = null;
    }

    private PendingIntent actionIntent(int code, String action) {
        return PendingIntent.getService(this, code,
                new Intent(this, BackgroundPlayService.class).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // vuốt app khỏi recents: vẫn phát nền (đóng bằng nút Đóng trên thông báo)
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        mainH.removeCallbacksAndMessages(null);
        if (spectrum != null) spectrum.stop();
        removeOverlay();
        detach();
        if (session != null) {
            session.setActive(false);
            session.release();
            session = null;
        }
        if (instance == this) viewKey = null;
        if (player != null && instance == this) { // bị hủy bất thường: đừng để player mồ côi
            player.release();
            player = null;
        }
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
