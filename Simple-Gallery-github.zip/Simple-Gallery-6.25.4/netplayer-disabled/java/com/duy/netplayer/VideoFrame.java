package com.duy.netplayer;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.TextureView;
import android.widget.FrameLayout;

/**
 * Khung hiển thị video (thay PlayerView của media3): một TextureView đặt theo tỉ lệ video,
 * 3 kiểu Vừa / FULL / Kéo. TextureView để zoom / dời / cắt hình bằng scale + translation cho ổn định.
 */
public class VideoFrame extends FrameLayout {
    static final int FIT = 0, ZOOM = 1, FILL = 2;

    private final TextureView tv;
    private int vw, vh, mode = FIT;
    private Surface surface;
    private MpEngine engine;
    private SurfaceTexture ext; // SurfaceTexture mượn của MpEngine (MediaPlayer): TextureView không được huỷ nó

    public VideoFrame(Context c) {
        this(c, null);
    }

    public VideoFrame(Context c, AttributeSet a) {
        super(c, a);
        tv = new TextureView(c);
        addView(tv, new LayoutParams(-1, -1));
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                if (st == ext) return;
                surface = new Surface(st);
                if (engine != null && !engine.constSurface()) engine.setSurface(surface);
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                if (st == ext) { // của engine: giữ lại, hút khung thay cho màn hình
                    if (engine != null) engine.startDrain();
                    return false;
                }
                if (engine != null && !engine.constSurface()) engine.setSurface(null);
                if (surface != null) {
                    surface.release();
                    surface = null;
                }
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture st) {
            }
        });
    }

    /** Gắn engine: hình phát lên khung này. */
    void bind(MpEngine e) {
        engine = e;
        if (e == null) return;
        if (e.constSurface()) {
            // MediaPlayer: mượn SurfaceTexture cố định của engine, không đổi mặt hiển thị của MediaPlayer
            SurfaceTexture t = e.videoTexture();
            if (t == null) return;
            e.stopDrain();
            try {
                if (tv.getSurfaceTexture() != t) tv.setSurfaceTexture(t);
                ext = t;
                if (surface != null) {
                    surface.release();
                    surface = null;
                }
            } catch (Exception x) {
                App.saveLog(getContext(), "TextureView mượn SurfaceTexture lỗi", x);
            }
            return;
        }
        if (surface != null) e.setSurface(surface);
    }

    /** Gỡ engine (đồng thời gỡ mặt hiển thị khỏi MediaPlayer -> chỉ còn tiếng). */
    void unbind() {
        if (engine != null) {
            if (engine.constSurface()) engine.startDrain();
            else engine.setSurface(null);
        }
        engine = null;
    }

    void setVideoSize(int w, int h) {
        if (w == vw && h == vh) return;
        vw = w;
        vh = h;
        requestLayout();
    }

    void setResizeMode(int m) {
        mode = m;
        requestLayout();
    }

    /**
     * Video ngang trên màn dọc: mức zoom mà chiều ngang video vừa chạm 2 mép (fit / cắt).
     * Trường hợp khác hoặc chưa biết kích thước: 0.
     */
    float cropMinZoom() {
        int w = getWidth(), h = getHeight();
        if (vw <= 0 || vh <= 0 || w <= 0 || h <= 0 || h <= w || vw < vh) return 0f;
        float a = (float) w / vw, b = (float) h / vh;
        return Math.min(a, b) / Math.max(a, b);
    }

    TextureView getVideoSurfaceView() {
        return tv;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec), h = MeasureSpec.getSize(hSpec);
        setMeasuredDimension(w, h);
        int[] s = childSize(w, h);
        tv.measure(MeasureSpec.makeMeasureSpec(s[0], MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(s[1], MeasureSpec.EXACTLY));
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l, h = b - t;
        int[] s = childSize(w, h);
        int x = (w - s[0]) / 2, y = (h - s[1]) / 2;
        tv.layout(x, y, x + s[0], y + s[1]);
        // pivot luôn theo kích thước mới, tránh scale quanh tâm cũ sau khi xoay màn hình
        tv.setPivotX(s[0] / 2f);
        tv.setPivotY(s[1] / 2f);
    }

    /** Chưa biết kích thước video thì phủ đầy khung để TextureView sớm có mặt hiển thị. */
    private int[] childSize(int w, int h) {
        if (vw <= 0 || vh <= 0 || w <= 0 || h <= 0 || mode == FILL) return new int[]{w, h};
        float sc = mode == ZOOM ? Math.max((float) w / vw, (float) h / vh)
                : Math.min((float) w / vw, (float) h / vh);
        return new int[]{Math.max(1, Math.round(vw * sc)), Math.max(1, Math.round(vh * sc))};
    }
}
