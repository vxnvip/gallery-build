package com.duy.netplayer;

import android.app.Application;
import android.content.Context;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

/**
 * Bắt crash (kể cả trong service phát nền), lưu lại để MainActivity hiện ra lần mở sau.
 * Trong Simple Gallery lớp này không còn là Application: App của Simple gọi {@link #install(Application)}.
 */
public class App {
    /** Ghi thêm 1 dòng nhật ký (hiện ở hộp thoại lần mở app sau). */
    static void saveLog(Context c, String tag, Throwable e) {
        try {
            StringWriter sw = new StringWriter();
            if (e != null) e.printStackTrace(new PrintWriter(sw));
            android.content.SharedPreferences sp = c.getSharedPreferences("crash", 0);
            sp.edit().putString("log", sp.getString("log", "") + new Date() + " [" + tag + "]\n" + sw + "\n")
                    .commit();
        } catch (Throwable ignored) {
        }
    }

    /** Gọi 1 lần từ Application.onCreate(). */
    public static void install(final Application app) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                app.getSharedPreferences("crash", 0).edit()
                        .putString("log", new Date() + " [" + t.getName() + "]\n" + sw)
                        .commit(); // commit (đồng bộ) vì process sắp chết
            } catch (Throwable ignored) {
            }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }
}
