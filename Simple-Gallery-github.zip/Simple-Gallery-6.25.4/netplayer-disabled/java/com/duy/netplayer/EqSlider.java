package com.duy.netplayer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/** Thanh trượt mảnh, núm tròn viền xanh. Dọc: xanh từ đáy lên núm. Ngang: xanh từ trái sang núm. */
final class EqSlider extends View {
    interface Listener {
        void onChanged(float value);
    }

    private static final int GREEN = 0xFF5CC97C, TRACK = 0xFF4A4A4A, KNOB = 0xFF1F2A37;
    private final boolean vertical;
    private final float min, max;
    private float value;
    private boolean dragging, decided;
    private float downX, downY;
    private final int slop;
    private final float dp;
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    Listener listener;
    Runnable onStop;

    EqSlider(Context c, boolean vertical, float min, float max) {
        super(c);
        this.vertical = vertical;
        this.min = min;
        this.max = max;
        this.value = min;
        dp = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        track.setColor(TRACK);
        track.setStrokeWidth(4 * dp);
        track.setStrokeCap(Paint.Cap.ROUND);
        fill.setColor(GREEN);
        fill.setStrokeWidth(4 * dp);
        fill.setStrokeCap(Paint.Cap.ROUND);
        knob.setColor(KNOB);
        ring.setColor(GREEN);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(3 * dp);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(13 * dp);
        text.setTextAlign(Paint.Align.CENTER);
    }

    void setValue(float v) {
        value = Math.max(min, Math.min(max, v));
        invalidate();
    }

    private float pad() {
        return 13 * dp;
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), p = pad();
        float t = (value - min) / (max - min);
        if (vertical) {
            float cx = w / 2, y0 = p, y1 = h - p, ty = y1 - t * (y1 - y0);
            cv.drawLine(cx, y0, cx, y1, track);
            cv.drawLine(cx, ty, cx, y1, fill);
            cv.drawCircle(cx, ty, 11 * dp, knob);
            cv.drawCircle(cx, ty, 11 * dp, ring);
            if (dragging) {
                cv.drawText(String.format(java.util.Locale.US, "%+.1f", value), cx, ty - 18 * dp, text);
            }
        } else {
            float cy = h / 2, x0 = p, x1 = w - p, tx = x0 + t * (x1 - x0);
            cv.drawLine(x0, cy, x1, cy, track);
            if (t > 0.001f) cv.drawLine(x0, cy, tx, cy, fill);
            cv.drawCircle(tx, cy, 11 * dp, knob);
            cv.drawCircle(tx, cy, 11 * dp, ring);
        }
    }

    private void update(MotionEvent e) {
        float p = pad(), t;
        if (vertical) t = 1f - (e.getY() - p) / Math.max(1f, getHeight() - 2 * p);
        else t = (e.getX() - p) / Math.max(1f, getWidth() - 2 * p);
        t = Math.max(0f, Math.min(1f, t));
        float v = min + t * (max - min);
        if (vertical) v = Math.round(v * 2f) / 2f; // bước 0.5 dB
        setValue(v);
        if (listener != null) listener.onChanged(value);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                dragging = false;
                decided = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!decided) {
                    float dx = Math.abs(e.getX() - downX), dy = Math.abs(e.getY() - downY);
                    if (Math.max(dx, dy) < slop) return true;
                    decided = true;
                    boolean mine = vertical ? dy >= dx : dx >= dy;
                    if (!mine) return false; // để cha (cuộn/trang) xử lý
                    dragging = true;
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (dragging) update(e);
                return true;
            case MotionEvent.ACTION_UP:
                if (!decided) update(e); // chạm nhanh = nhảy tới vị trí đó
                finish();
                return true;
            case MotionEvent.ACTION_CANCEL:
                finish();
                return true;
        }
        return true;
    }

    private void finish() {
        dragging = false;
        invalidate();
        if (onStop != null) onStop.run();
    }
}
