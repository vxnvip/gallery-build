package com.duy.netplayer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.media.audiofx.Visualizer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/**
 * Dải cột nhảy theo âm thanh, vẽ trong 1 cửa sổ overlay đúng bằng chiều cao thanh trạng thái.
 * Overlay nằm DƯỚI cửa sổ thanh trạng thái nên đồng hồ / pin / sóng vẫn nằm đè lên trên, nhìn rõ.
 * Chỉ nghe âm thanh của chính NetPlayer (Visualizer gắn vào audio session của player).
 * Cần quyền RECORD_AUDIO (Visualizer bắt buộc) và quyền "Hiển thị trên các ứng dụng khác".
 */
final class SpectrumOverlay {
    private static final int BARS = 28;
    private static final int COLOR = 0x9940C4FF; // xanh nhạt trong suốt; đổi ở đây nếu muốn màu khác

    private final Context ctx;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final float[] level = new float[BARS];
    private final float[] target = new float[BARS];
    private BarsView view;
    private Visualizer viz;
    private int session = -1;
    private boolean running;

    SpectrumOverlay(Context c) {
        ctx = c.getApplicationContext();
    }

    boolean isRunningFor(int sessionId) {
        return running && session == sessionId;
    }

    void start(int sessionId) {
        if (sessionId <= 0) return;
        if (isRunningFor(sessionId)) return;
        stop();
        if (!Settings.canDrawOverlays(ctx)) {
            android.util.Log.w("NPBG", "Spectrum: chưa có quyền hiển thị trên ứng dụng khác");
            return;
        }
        if (ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            android.util.Log.w("NPBG", "Spectrum: chưa có quyền RECORD_AUDIO");
            return;
        }
        try {
            viz = new Visualizer(sessionId);
            viz.setCaptureSize(Visualizer.getCaptureSizeRange()[1] >= 512 ? 512 : Visualizer.getCaptureSizeRange()[1]);
            viz.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer v, byte[] wave, int rate) {
                }

                @Override
                public void onFftDataCapture(Visualizer v, byte[] fft, int rate) {
                    computeTargets(fft);
                }
            }, Math.min(Visualizer.getMaxCaptureRate(), 20000), false, true);
            viz.setEnabled(true);

            int sbh = statusBarHeight();
            view = new BarsView(ctx, sbh);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, sbh,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            ctx.getSystemService(WindowManager.class).addView(view, lp);
            session = sessionId;
            running = true;
            h.post(tick);
        } catch (Throwable e) {
            android.util.Log.e("NPBG", "Spectrum lỗi", e);
            App.saveLog(ctx, "Hiệu ứng cột nhạc lỗi", e);
            stop();
        }
    }

    void stop() {
        running = false;
        session = -1;
        h.removeCallbacks(tick);
        if (viz != null) {
            try { viz.setEnabled(false); } catch (Throwable ignored) {}
            try { viz.release(); } catch (Throwable ignored) {}
            viz = null;
        }
        if (view != null) {
            try { ctx.getSystemService(WindowManager.class).removeView(view); } catch (Throwable ignored) {}
            view = null;
        }
        java.util.Arrays.fill(level, 0f);
        java.util.Arrays.fill(target, 0f);
    }

    private int statusBarHeight() {
        int id = ctx.getResources().getIdentifier("status_bar_height", "dimen", "android");
        int px = id > 0 ? ctx.getResources().getDimensionPixelSize(id) : 0;
        return px > 0 ? px : (int) (28 * ctx.getResources().getDisplayMetrics().density);
    }

    /** FFT -> BARS cột, chia theo thang log để bass không lấn hết. */
    private void computeTargets(byte[] fft) {
        int n = fft.length / 2; // số bin (cặp re/im)
        if (n < 4) return;
        int lo = 1;
        for (int b = 0; b < BARS; b++) {
            int hi = (int) Math.round(Math.pow((double) n, (b + 1) / (double) BARS));
            if (hi <= lo) hi = lo + 1;
            if (hi > n) hi = n;
            float peak = 0;
            for (int k = lo; k < hi; k++) {
                float re = fft[2 * k], im = fft[2 * k + 1];
                float m = (float) Math.sqrt(re * re + im * im);
                if (m > peak) peak = m;
            }
            float v = (float) Math.sqrt(Math.min(1f, peak / 90f));
            target[b] = v;
            lo = Math.max(hi - 1, lo + 1);
            if (lo >= n) lo = n - 1;
        }
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running || view == null) return;
            for (int i = 0; i < BARS; i++) {
                float t = target[i];
                level[i] = t > level[i] ? level[i] + (t - level[i]) * 0.6f : level[i] * 0.86f; // lên nhanh, xuống chậm
            }
            view.invalidate();
            h.postDelayed(this, 33);
        }
    };

    private final class BarsView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float block, gap;

        BarsView(Context c, int height) {
            super(c);
            float d = c.getResources().getDisplayMetrics().density;
            block = 3 * d;
            gap = 1.2f * d;
            p.setColor(COLOR);
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), hgt = getHeight();
            if (w <= 0) return;
            float slot = w / (float) BARS;
            float barW = slot * 0.72f;
            float step = block + gap;
            int maxBlocks = Math.max(1, (int) (hgt / step));
            for (int i = 0; i < BARS; i++) {
                int nb = Math.round(level[i] * maxBlocks);
                float x = i * slot + (slot - barW) / 2f;
                for (int b = 0; b < nb; b++) {
                    float bottom = hgt - b * step;
                    c.drawRect(x, bottom - block, x + barW, bottom, p);
                }
            }
        }
    }
}
