package com.duy.netplayer;

import com.simplemobiletools.gallery.pro.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Trang cài đặt: nhớ độ sáng, nhớ tỉ lệ khung hình, thời gian tua. */
public class SettingsActivity extends Activity {
    static final String PREFS = "settings";
    static final String K_BRIGHT = "remember_brightness";
    static final String K_ASPECT = "remember_aspect";
    static final String K_SEEK = "seek_sec";
    static final String K_RESUME = "resume_mode";
    static final String K_LOOP = "loop_all"; // chế độ lặp lại: áp dụng cho mọi video, nhớ giữa các lần mở
    /** Tiếp tục phát video: 0 bật (phát tiếp vị trí cũ), 1 tắt (từ đầu), 2 từ đầu + thông báo "tiếp tục", 3 vị trí cũ + thông báo "bắt đầu lại". */
    static final int RESUME_ON = 0, RESUME_OFF = 1, RESUME_OFFER = 2, RESUME_ASK_RESTART = 3;
    static final String[] RESUME_LABELS = {
            "Bật",
            "Tắt",
            "Bắt đầu, hỏi tiếp tục",
            "Tiếp tục, hỏi bắt đầu lại"};
    static final String[] RESUME_SHORT = {"Bật", "Tắt", "Từ đầu", "Hỏi lại"};
    static final String K_BRIGHT_VAL = "brightness";
    static final String K_ASPECT_VAL = "aspect_idx";
    /** Các tỉ lệ khung hình, theo thứ tự vuốt / bấm icon. */
    static final String[] ASPECT_NAMES = {"Vừa", "FULL", "Kéo"};
    private static final String K_ASPECT_ON = "aspect_on_"; // + chỉ số: tỉ lệ đó có nằm trong vòng đổi không
    static final int[] PRESETS = {5, 10, 15, 20, 30, 60};
    static final int MAX_SEC = 600;

    private static final int GREEN = 0xFF5BC27A, TEXT = 0xFFFFFFFF, SUB = 0xFF9E9E9E;
    private SharedPreferences sp;
    private TextView seekValue, resumeValue;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, 0);
    }

    /** Tỉ lệ thứ i đang bật (hiện)? Mặc định bật hết. */
    static boolean aspectEnabled(Context c, int i) {
        return prefs(c).getBoolean(K_ASPECT_ON + i, true);
    }

    static void setAspectEnabled(Context c, int i, boolean on) {
        prefs(c).edit().putBoolean(K_ASPECT_ON + i, on).apply();
    }

    static int aspectEnabledCount(Context c) {
        int n = 0;
        for (int i = 0; i < ASPECT_NAMES.length; i++) if (aspectEnabled(c, i)) n++;
        return n;
    }

    /** Tỉ lệ kế tiếp đang bật sau cur (bỏ qua cái đã ẩn). Không còn cái nào bật thì coi như bật hết. */
    static int nextAspect(Context c, int cur) {
        int n = ASPECT_NAMES.length;
        for (int k = 1; k <= n; k++) {
            int i = (cur + k) % n;
            if (aspectEnabled(c, i)) return i;
        }
        return (cur + 1) % n;
    }

    /** cur còn bật thì giữ, đã ẩn thì lấy tỉ lệ bật đầu tiên. */
    static int validAspect(Context c, int cur) {
        if (cur >= 0 && cur < ASPECT_NAMES.length && aspectEnabled(c, cur)) return cur;
        return nextAspect(c, ASPECT_NAMES.length - 1);
    }

    static int resumeMode(Context c) {
        int m = prefs(c).getInt(K_RESUME, RESUME_ON);
        return m >= 0 && m < RESUME_LABELS.length ? m : RESUME_ON;
    }

    static int seekSec(Context c) {
        return Math.max(1, prefs(c).getInt(K_SEEK, 10));
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        sp = prefs(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121212);

        // thanh tiêu đề: mũi tên quay lại + "Cài đặt"
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(16), dp(8));
        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setPadding(dp(12), dp(12), dp(12), dp(12));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView title = new TextView(this);
        title.setText("Cài đặt");
        title.setTextSize(22);
        title.setTextColor(TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = dp(12);
        bar.addView(title, tp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView sec = new TextView(this);
        sec.setText("Điều khiển phát lại");
        sec.setTextColor(GREEN);
        sec.setTextSize(15);
        sec.setTypeface(Typeface.DEFAULT_BOLD);
        sec.setPadding(dp(20), dp(16), dp(20), dp(4));
        list.addView(sec);

        list.addView(toggleRow("Nhớ độ sáng", "Video sau vào lại dùng độ sáng đã chỉnh lần trước", K_BRIGHT));
        list.addView(toggleRow("Nhớ tỉ lệ khung hình", "Giữ kiểu Vừa / FULL / Kéo đã chọn", K_ASPECT));
        list.addView(aspectRow());
        list.addView(seekRow());
        list.addView(resumeRow());

        setContentView(root);
    }

    private LinearLayout texts(String title, String sub) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        TextView a = new TextView(this);
        a.setText(title);
        a.setTextColor(TEXT);
        a.setTextSize(17);
        t.addView(a);
        if (sub != null) {
            TextView b = new TextView(this);
            b.setText(sub);
            b.setTextColor(SUB);
            b.setTextSize(14);
            b.setPadding(0, dp(2), 0, 0);
            t.addView(b);
        }
        return t;
    }

    private View toggleRow(String title, String sub, final String key) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(16), dp(20), dp(16));
        final Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, true));
        sw.setOnCheckedChangeListener((b, on) -> sp.edit().putBoolean(key, on).apply());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.rightMargin = dp(12);
        row.addView(texts(title, sub), lp);
        row.addView(sw);
        row.setOnClickListener(v -> sw.toggle());
        return row;
    }

    /** Mục "Tỉ lệ": mở trang bật / ẩn từng tỉ lệ khung hình. */
    private View aspectRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(16), dp(20), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.rightMargin = dp(12);
        row.addView(texts("Tỉ lệ", "Chọn tỉ lệ khung hình dùng khi vuốt / bấm đổi"), lp);
        TextView chev = new TextView(this);
        chev.setText("  ›");
        chev.setTextColor(SUB);
        chev.setTextSize(22);
        row.addView(chev);
        row.setOnClickListener(v -> startActivity(new android.content.Intent(this, AspectSettingsActivity.class)));
        return row;
    }

    private View seekRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(16), dp(20), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.rightMargin = dp(12);
        row.addView(texts("Thời gian tua nhanh và tua lại", "Chạm đôi trái / phải và nút tua"), lp);
        seekValue = new TextView(this);
        seekValue.setTextColor(SUB);
        seekValue.setTextSize(16);
        row.addView(seekValue);
        TextView chev = new TextView(this);
        chev.setText("  ›");
        chev.setTextColor(SUB);
        chev.setTextSize(22);
        row.addView(chev);
        row.setOnClickListener(v -> showSeekDialog());
        refreshSeek();
        return row;
    }

    private View resumeRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(16), dp(20), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.rightMargin = dp(12);
        row.addView(texts("Tiếp tục phát video", "Cách xử lý khi mở lại video đang xem dở"), lp);
        resumeValue = new TextView(this);
        resumeValue.setTextColor(SUB);
        resumeValue.setTextSize(16);
        row.addView(resumeValue);
        TextView chev = new TextView(this);
        chev.setText("  ›");
        chev.setTextColor(SUB);
        chev.setTextSize(22);
        row.addView(chev);
        row.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Tiếp tục phát video")
                .setSingleChoiceItems(RESUME_LABELS, resumeMode(this), (d, which) -> {
                    sp.edit().putInt(K_RESUME, which).apply();
                    refreshResume();
                    d.dismiss();
                })
                .show());
        refreshResume();
        return row;
    }

    private void refreshResume() {
        resumeValue.setText(RESUME_SHORT[resumeMode(this)]);
    }

    private void refreshSeek() {
        seekValue.setText(seekSec(this) + "s");
    }

    private void setSeek(int sec) {
        sp.edit().putInt(K_SEEK, sec).apply();
        refreshSeek();
    }

    private void showSeekDialog() {
        int cur = seekSec(this);
        int checked = PRESETS.length; // mặc định: Tùy chỉnh
        String[] items = new String[PRESETS.length + 1];
        for (int i = 0; i < PRESETS.length; i++) {
            items[i] = PRESETS[i] + "s";
            if (PRESETS[i] == cur) checked = i;
        }
        items[PRESETS.length] = checked == PRESETS.length ? "Tùy chỉnh (" + cur + "s)" : "Tùy chỉnh";
        new AlertDialog.Builder(this)
                .setSingleChoiceItems(items, checked, (d, which) -> {
                    d.dismiss();
                    if (which < PRESETS.length) setSeek(PRESETS[which]);
                    else showCustomDialog();
                })
                .show();
    }

    private void showCustomDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("Số giây (1 - " + MAX_SEC + ")");
        et.setSingleLine(true);
        et.setText(String.valueOf(seekSec(this)));
        et.selectAll();
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        box.addView(et, new FrameLayout.LayoutParams(-1, -2));

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Tùy chỉnh thời gian tua")
                .setView(box)
                .setPositiveButton("Lưu", null) // gắn sau để nhập sai thì hộp thoại không đóng
                .setNegativeButton("Hủy", null)
                .create();
        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            int sec;
            try {
                sec = Integer.parseInt(et.getText().toString().trim());
            } catch (NumberFormatException e) {
                sec = 0;
            }
            if (sec < 1 || sec > MAX_SEC) {
                Toast.makeText(this, "Nhập số giây từ 1 đến " + MAX_SEC, Toast.LENGTH_SHORT).show();
                return;
            }
            setSeek(sec);
            dlg.dismiss();
        });
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
