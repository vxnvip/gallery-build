package com.duy.netplayer;

import android.util.Base64;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * Local HTTP proxy: MediaPlayer đọc http://127.0.0.1:PORT/TOKEN (ping < 1ms, không bắt tay HTTPS lại khi tua),
 * còn mạng thật do HttpMediaSource lo (redirect, UA/Referer, Range, cache RAM, pre-buffer đuôi file chứa moov).
 *
 * - Chỉ nghe trên loopback, cổng tự chọn (không đụng cổng cố định), mỗi video một token ngẫu nhiên.
 * - Hiểu Range (bytes=a-b, a-, -n) -> trả 206 + Content-Range đúng, HEAD, 416.
 * - Server gốc không hỗ trợ Range: HttpMediaSource tải tuần tự xuống file tạm, proxy vẫn trả Range cho MediaPlayer.
 * - Không biết tổng dung lượng (chunked): trả 200 không Content-Length, đọc một mạch.
 */
final class LocalProxyServer {
    private static LocalProxyServer inst;

    static synchronized LocalProxyServer get() {
        if (inst == null) inst = new LocalProxyServer();
        return inst;
    }

    private final ConcurrentHashMap<String, HttpMediaSource> sessions = new ConcurrentHashMap<>();
    private final SecureRandom rnd = new SecureRandom();
    private final ExecutorService pool = Executors.newCachedThreadPool(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "np-proxy");
            t.setDaemon(true);
            return t;
        }
    });
    private final ConcurrentHashMap<String, Map<String, String>> hlsSessions = new ConcurrentHashMap<>();
    private final AtomicLong hlsBytes = new AtomicLong();
    volatile String lastHlsError;
    private ServerSocket ss;
    private volatile boolean running;

    private LocalProxyServer() {
    }

    /** Khởi động (nếu chưa chạy). Trả về false nếu không mở được cổng -> MpEngine dùng MediaDataSource trực tiếp. */
    synchronized boolean start() {
        if (running) return true;
        System.setProperty("http.keepAlive", "true");
        System.setProperty("http.maxConnections", "12");
        try {
            ss = new ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"));
        } catch (IOException e) {
            return false;
        }
        running = true;
        final ServerSocket server = ss;
        Thread t = new Thread(() -> {
            while (running) {
                try {
                    final Socket c = server.accept();
                    pool.execute(() -> handle(c));
                } catch (IOException e) {
                    if (!running) break;
                } catch (Exception ignored) {
                }
            }
        }, "np-proxy-accept");
        t.setDaemon(true);
        t.start();
        return true;
    }

    /** Đăng ký nguồn, trả URL localhost cho MediaPlayer; null nếu proxy không chạy được. */
    String register(HttpMediaSource s) {
        if (!start()) return null;
        byte[] b = new byte[12];
        rnd.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(Locale.ROOT, "%02x", x));
        String token = sb.toString();
        sessions.put(token, s);
        return "http://127.0.0.1:" + ss.getLocalPort() + "/" + token;
    }

    /** Đăng ký link HLS: playlist + đoạn + key đều đi qua proxy (gắn UA/Referer, theo redirect). */
    String registerHls(String url, Map<String, String> headers) {
        if (!start()) return null;
        byte[] b = new byte[12];
        rnd.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(Locale.ROOT, "%02x", x));
        String token = sb.toString();
        final Map<String, String> hd = headers == null ? new java.util.HashMap<String, String>() : headers;
        hlsSessions.put(token, hd);
        final String tk = token, u = url;
        // Tải playlist ngay (song song với việc MediaPlayer khởi tạo); request đầu của MediaPlayer sẽ nhập chung.
        prefetchPool.execute(() -> {
            try {
                getPlaylist(u, hd, tk, false);
            } catch (Exception ignored) {
            }
        });
        return "http://127.0.0.1:" + ss.getLocalPort() + "/h/" + token + "/" + enc(url) + ".m3u8";
    }

    long hlsReceived() {
        return hlsBytes.get();
    }

    void unregister(String url) {
        if (url == null) return;
        int h = url.indexOf("/h/");
        if (h >= 0) {
            int e = url.indexOf('/', h + 3);
            if (e > 0) hlsSessions.remove(url.substring(h + 3, e));
            if (hlsSessions.isEmpty()) clearHlsCache();
            return;
        }
        int i = url.lastIndexOf('/');
        if (i >= 0) sessions.remove(url.substring(i + 1));
    }

    // ---------------- xử lý 1 kết nối ----------------

    private void handle(Socket c) {
        try {
            c.setTcpNoDelay(true);
            c.setSoTimeout(30000); // chỉ áp cho lúc đọc request
            InputStream in = new BufferedInputStream(c.getInputStream(), 2048);
            OutputStream out = c.getOutputStream();

            String reqLine = readLine(in);
            if (reqLine == null) return;
            String[] rl = reqLine.split(" ");
            if (rl.length < 2) return;
            String method = rl[0];
            String path = rl[1];
            String range = null;
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                if (line.toLowerCase(Locale.ROOT).startsWith("range:")) range = line.substring(6).trim();
            }
            c.setSoTimeout(0);

            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            if (path.startsWith("/h/")) {
                handleHls(out, method, path, range);
                return;
            }
            String token = path.startsWith("/") ? path.substring(1) : path;
            HttpMediaSource src = sessions.get(token);
            if (src == null) {
                out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes("ISO-8859-1"));
                out.flush();
                return;
            }
            boolean head = "HEAD".equals(method);
            long total = src.getSize();
            String type = src.contentType();

            if (total <= 0) { // không biết dung lượng: đọc một mạch từ đầu
                String h = "HTTP/1.1 200 OK\r\nContent-Type: " + type + "\r\nAccept-Ranges: none\r\nConnection: close\r\n\r\n";
                out.write(h.getBytes("ISO-8859-1"));
                if (!head) pipe(src, out, 0, Long.MAX_VALUE);
                out.flush();
                return;
            }

            long start = 0, end = total - 1;
            boolean partial = false;
            if (range != null && range.toLowerCase(Locale.ROOT).startsWith("bytes=")) {
                long[] r = parseRange(range.substring(6).trim(), total);
                if (r == null) {
                    String h = "HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + total
                            + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
                    out.write(h.getBytes("ISO-8859-1"));
                    out.flush();
                    return;
                }
                start = r[0];
                end = r[1];
                partial = true;
            }
            StringBuilder h = new StringBuilder();
            h.append(partial ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
            h.append("Content-Type: ").append(type).append("\r\n");
            h.append("Accept-Ranges: bytes\r\n");
            h.append("Content-Length: ").append(end - start + 1).append("\r\n");
            if (partial) h.append("Content-Range: bytes ").append(start).append('-').append(end).append('/').append(total).append("\r\n");
            h.append("Connection: close\r\n\r\n");
            out.write(h.toString().getBytes("ISO-8859-1"));
            if (!head) pipe(src, out, start, end);
            out.flush();
        } catch (Exception ignored) {
            // MediaPlayer ngắt kết nối giữa chừng khi tua = bình thường
        } finally {
            try {
                c.close();
            } catch (Exception ignored) {
            }
        }
    }

    /** Đọc từ nguồn (đã có cache/prefetch) ghi thẳng vào socket; socket đầy thì tự chờ (backpressure). */
    private static void pipe(HttpMediaSource src, OutputStream out, long start, long end) throws IOException {
        byte[] buf = new byte[64 * 1024];
        long pos = start;
        while (pos <= end) {
            int want = (int) Math.min(buf.length, end - pos + 1);
            int n = src.readAt(pos, buf, 0, want);
            if (n < 0) break;
            out.write(buf, 0, n);
            pos += n;
        }
    }

    /** "a-b", "a-", "-n" -> {start,end} đã kẹp theo dung lượng; null nếu không hợp lệ. */
    private static long[] parseRange(String spec, long total) {
        try {
            int comma = spec.indexOf(',');
            if (comma >= 0) spec = spec.substring(0, comma); // nhiều dải: chỉ lấy dải đầu
            int dash = spec.indexOf('-');
            if (dash < 0) return null;
            String a = spec.substring(0, dash).trim(), b = spec.substring(dash + 1).trim();
            long s, e;
            if (a.isEmpty()) {
                long n = Long.parseLong(b);
                if (n <= 0) return null;
                s = Math.max(0, total - n);
                e = total - 1;
            } else {
                s = Long.parseLong(a);
                e = b.isEmpty() ? total - 1 : Math.min(Long.parseLong(b), total - 1);
            }
            if (s < 0 || s >= total || e < s) return null;
            return new long[]{s, e};
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    // ---------------- HLS qua proxy ----------------

    private static final Pattern URI_ATTR = Pattern.compile("URI=\"([^\"]*)\"");

    private static String enc(String u) {
        return Base64.encodeToString(u.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    private static String dec(String e) {
        return new String(Base64.decode(e, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING),
                java.nio.charset.StandardCharsets.UTF_8);
    }

    private static void sendSimple(OutputStream out, String status) throws IOException {
        out.write(("HTTP/1.1 " + status + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes("ISO-8859-1"));
        out.flush();
    }

    /** Mở kết nối tới server gốc, tự theo redirect (kể cả https <-> http). Trả về kết nối đã có getResponseCode(). */
    private static HttpURLConnection openUpstream(String url, Map<String, String> hd, String range) throws IOException {
        String u = url;
        for (int i = 0; i < 10; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(10000);
            c.setReadTimeout(20000);
            c.setUseCaches(false);
            for (Map.Entry<String, String> e : hd.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            c.setRequestProperty("Accept", "*/*");
            c.setRequestProperty("Accept-Encoding", "identity");
            if (range != null) c.setRequestProperty("Range", range);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && code != 304) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null || loc.isEmpty()) throw new IOException("HTTP " + code + " không có Location");
                u = new URL(new URL(u), loc).toString();
                continue;
            }
            finalUrls.put(c, u);
            return c;
        }
        throw new IOException("Quá nhiều chuyển hướng");
    }

    private static final java.util.Map<HttpURLConnection, String> finalUrls =
            java.util.Collections.synchronizedMap(new java.util.WeakHashMap<HttpURLConnection, String>());

    // ---- cache + prefetch HLS ----
    private static final long CACHE_LIMIT = 64L << 20, BIG_SEG = 32L << 20;
    private static final int PREFETCH_AHEAD = 4, WARM_SEGS = 3;

    static final class UpstreamHttp extends IOException {
        final int code;

        UpstreamHttp(int code, String url) {
            super("HTTP " + code + " " + url);
            this.code = code;
        }
    }

    /** Một đoạn (.ts/.key) đang tải hoặc đã tải trong RAM; nhiều request cùng dùng chung, đọc dần khi đang tải. */
    private static final class Seg {
        volatile byte[] buf = new byte[256 * 1024];
        volatile int len, off, code = 200;
        volatile long total = -1;
        volatile boolean done, bypass;
        volatile String type;
        volatile IOException err;
        final AtomicBoolean started = new AtomicBoolean();
    }

    private static final class Pl {
        byte[] data;
        String type = "application/vnd.apple.mpegurl";
        boolean vod, warmed;
        long time = System.currentTimeMillis();
        String firstVariant;
        String[] firstSegs = new String[0];

        boolean stale() {
            return !vod && System.currentTimeMillis() - time > 2000;
        }
    }

    private final ExecutorService prefetchPool = Executors.newFixedThreadPool(3, new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "np-prefetch");
            t.setDaemon(true);
            return t;
        }
    });
    private final Object cacheLock = new Object();
    private final LinkedHashMap<String, Seg> segCache = new LinkedHashMap<>(32, 0.75f, true);
    private long cacheBytes;
    private final ConcurrentHashMap<String, Pl> plCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Object> plLocks = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String[]> segNext = new ConcurrentHashMap<>();

    private void clearHlsCache() {
        synchronized (cacheLock) {
            segCache.clear();
            cacheBytes = 0;
        }
        plCache.clear();
        plLocks.clear();
        segNext.clear();
        lastHlsError = null;
    }

    private void evictLocked() {
        Iterator<Map.Entry<String, Seg>> it = segCache.entrySet().iterator();
        while (cacheBytes > CACHE_LIMIT && it.hasNext()) {
            Map.Entry<String, Seg> e = it.next();
            if (e.getValue().done) {
                cacheBytes -= e.getValue().len;
                it.remove();
            }
        }
    }

    private Seg getSeg(final String url, final Map<String, String> hd, boolean urgent) {
        final Seg s;
        boolean created = false;
        synchronized (cacheLock) {
            Seg x = segCache.get(url);
            if (x == null || (x.done && x.err != null)) {
                x = new Seg();
                segCache.put(url, x);
                created = true;
            }
            s = x;
        }
        Runnable r = () -> download(s, url, hd);
        try {
            if (created && !urgent) prefetchPool.execute(r);
            else if (urgent && !s.started.get()) pool.execute(r); // request của player không phải xếp hàng sau prefetch
        } catch (Exception ignored) {
        }
        return s;
    }

    private void download(Seg s, String url, Map<String, String> hd) {
        if (!s.started.compareAndSet(false, true)) return;
        HttpURLConnection c = null;
        boolean ok = false;
        InputStream in = null;
        try {
            try {
                c = openUpstream(url, hd, null);
            } catch (IOException first) {
                lastHlsError = url + " -> " + first;
                Thread.sleep(300);
                c = openUpstream(url, hd, null);
            }
            int code = c.getResponseCode();
            if (code >= 400) throw new UpstreamHttp(code, url);
            s.code = code;
            s.type = c.getContentType();
            long cl = c.getContentLengthLong();
            if (cl > BIG_SEG) {
                s.bypass = true;
                return;
            }
            if (cl > 0) {
                s.total = cl;
                s.buf = new byte[(int) cl + 1];
            }
            in = c.getInputStream();
            while (true) {
                byte[] b = s.buf;
                if (s.len == b.length) {
                    if (s.len > 64 << 20) throw new IOException("Đoạn quá lớn");
                    synchronized (s) {
                        s.buf = Arrays.copyOf(b, b.length * 2);
                    }
                    b = s.buf;
                }
                int r = in.read(b, s.len, b.length - s.len);
                if (r < 0) break;
                hlsBytes.addAndGet(r);
                synchronized (s) {
                    s.len += r;
                    s.notifyAll();
                }
            }
            if (s.len >= 32 && looksLikeFakeImage(s.buf, 32)) {
                s.off = findTsStart(Arrays.copyOf(s.buf, s.len));
            }
            ok = true;
        } catch (Exception e) {
            s.err = e instanceof IOException ? (IOException) e : new IOException(e.toString());
            lastHlsError = url + " -> " + e;
        } finally {
            synchronized (s) {
                s.done = true;
                s.notifyAll();
            }
            synchronized (cacheLock) {
                if (segCache.get(url) == s) {
                    if (s.err != null || s.bypass) segCache.remove(url);
                    else {
                        cacheBytes += s.len;
                        evictLocked();
                    }
                }
            }
            if (c != null) {
                try {
                    if (ok && in != null) in.close(); // đọc hết + close = giữ keep-alive cho request sau
                    else c.disconnect();
                } catch (Exception ignored) {
                }
                finalUrls.remove(c);
            }
        }
    }

    private Pl getPlaylist(String url, Map<String, String> hd, String token, boolean fromPlayer) throws IOException {
        Pl p = plCache.get(url);
        if (p == null || p.stale()) {
            Object lock = plLocks.computeIfAbsent(url, k -> new Object());
            synchronized (lock) {
                p = plCache.get(url);
                if (p == null || p.stale()) {
                    p = fetchPlaylist(url, hd, token);
                    plCache.put(url, p);
                }
            }
        }
        if (fromPlayer) {
            boolean w;
            synchronized (p) {
                w = !p.warmed;
                p.warmed = true;
            }
            if (w) warm(p, hd, token);
        }
        return p;
    }

    /** Player mới lấy playlist này lần đầu: tải sẵn vài đoạn đầu (hoặc playlist con đầu tiên nếu là master). */
    private void warm(Pl p, final Map<String, String> hd, final String token) {
        if (p.firstVariant != null) {
            final String fv = p.firstVariant;
            prefetchPool.execute(() -> {
                try {
                    getPlaylist(fv, hd, token, false);
                } catch (Exception ignored) {
                }
            });
        }
        for (String u : p.firstSegs) getSeg(u, hd, false);
    }

    private Pl fetchPlaylist(String url, Map<String, String> hd, String token) throws IOException {
        HttpURLConnection c = null;
        try {
            try {
                c = openUpstream(url, hd, null);
            } catch (IOException first) {
                lastHlsError = url + " -> " + first;
                try {
                    Thread.sleep(300);
                } catch (InterruptedException ignored) {
                }
                c = openUpstream(url, hd, null);
            }
            int code = c.getResponseCode();
            if (code >= 400) throw new UpstreamHttp(code, url);
            String base = finalUrls.get(c);
            if (base == null) base = url;
            InputStream in = c.getInputStream();
            byte[] body = readAll(in, 4 << 20);
            in.close();
            hlsBytes.addAndGet(body.length);
            Pl p = new Pl();
            if (!HttpMediaSource.startsWithExtM3u(body, Math.min(32, body.length))) {
                p.data = body; // không phải playlist: trả nguyên
                p.type = c.getContentType() == null ? "application/octet-stream" : c.getContentType();
                p.vod = true;
                return p;
            }
            String txt = new String(body, "UTF-8");
            p.vod = txt.contains("#EXT-X-ENDLIST") || txt.contains("#EXT-X-STREAM-INF");
            p.data = rewritePlaylist(txt, base, token, p).getBytes("UTF-8");
            return p;
        } catch (IOException e) {
            lastHlsError = url + " -> " + e;
            if (c != null) c.disconnect();
            throw e;
        } finally {
            if (c != null) finalUrls.remove(c);
        }
    }

    private void handleHls(OutputStream out, String method, String path, String range) throws IOException {
        // /h/<token>/<base64url(url)>.<ext>
        String[] p = path.split("/");
        if (p.length < 4) {
            sendSimple(out, "404 Not Found");
            return;
        }
        Map<String, String> hd = hlsSessions.get(p[2]);
        if (hd == null) {
            sendSimple(out, "404 Not Found");
            return;
        }
        String e = p[3];
        boolean playlist = e.endsWith(".m3u8");
        int dot = e.lastIndexOf('.');
        if (dot > 0) e = e.substring(0, dot);
        String url;
        try {
            url = dec(e);
        } catch (Exception ex) {
            sendSimple(out, "400 Bad Request");
            return;
        }
        try {
            if (playlist) servePlaylist(out, method, url, hd, p[2]);
            else if (range != null) passThrough(out, method, url, hd, range);
            else serveSeg(out, method, url, hd);
        } catch (UpstreamHttp ex) {
            lastHlsError = ex.getMessage();
            sendSimple(out, ex.code + " Upstream");
        } catch (IOException ex) {
            lastHlsError = url + " -> " + ex;
            sendSimple(out, "502 Bad Gateway");
        }
    }

    private void servePlaylist(OutputStream out, String method, String url, Map<String, String> hd, String token) throws IOException {
        Pl p = getPlaylist(url, hd, token, true);
        String h = "HTTP/1.1 200 OK\r\nContent-Type: " + p.type + "\r\nContent-Length: " + p.data.length
                + "\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes("ISO-8859-1"));
        if (!"HEAD".equals(method)) out.write(p.data);
        out.flush();
    }

    private void serveSeg(OutputStream out, String method, String url, Map<String, String> hd) throws IOException {
        Seg s = getSeg(url, hd, true);
        String[] nx = segNext.get(url);
        if (nx != null) for (String u : nx) getSeg(u, hd, false); // tải trước các đoạn kế tiếp
        try {
            synchronized (s) {
                while (s.len < 32 && !s.done) s.wait(200);
            }
            boolean fake = s.len >= 32 && looksLikeFakeImage(s.buf, 32);
            if (fake) {
                synchronized (s) {
                    while (!s.done) s.wait(200);
                }
            }
            if (s.bypass) {
                passThrough(out, method, url, hd, null);
                return;
            }
            if (s.err != null && s.len == 0) {
                if (s.err instanceof UpstreamHttp) throw (UpstreamHttp) s.err;
                throw s.err;
            }
            int pos = fake ? s.off : 0;
            long clen = fake ? s.len - s.off : (s.total >= 0 ? s.total : (s.done ? s.len : -1));
            String ct = fake || s.type == null ? "video/mp2t" : s.type;
            String h = "HTTP/1.1 200 OK\r\nContent-Type: " + ct + (clen >= 0 ? "\r\nContent-Length: " + clen : "")
                    + "\r\nConnection: close\r\n\r\n";
            out.write(h.getBytes("ISO-8859-1"));
            if ("HEAD".equals(method)) {
                out.flush();
                return;
            }
            while (true) {
                byte[] b;
                int l;
                synchronized (s) {
                    while (s.len <= pos && !s.done) s.wait(200);
                    b = s.buf;
                    l = s.len;
                }
                if (l <= pos) break;
                out.write(b, pos, l - pos);
                pos = l;
            }
            out.flush();
        } catch (InterruptedException ie) {
            throw new IOException("interrupted");
        }
    }

    /** Không cache: dùng khi player xin Range (byte-range HLS) hoặc đoạn quá lớn. */
    private void passThrough(OutputStream out, String method, String url, Map<String, String> hd, String range) throws IOException {
        HttpURLConnection c = null;
        boolean clean = false;
        try {
            c = openUpstream(url, hd, range);
            int code = c.getResponseCode();
            if (code >= 400) throw new UpstreamHttp(code, url);
            StringBuilder h = new StringBuilder(code == 206 ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
            String ct = c.getContentType();
            h.append("Content-Type: ").append(ct == null ? "video/mp2t" : ct).append("\r\n");
            long cl = c.getContentLengthLong();
            if (cl >= 0) h.append("Content-Length: ").append(cl).append("\r\n");
            String cr = c.getHeaderField("Content-Range");
            if (cr != null) h.append("Content-Range: ").append(cr).append("\r\n");
            h.append("Connection: close\r\n\r\n");
            out.write(h.toString().getBytes("ISO-8859-1"));
            if (!"HEAD".equals(method)) {
                InputStream in = c.getInputStream();
                byte[] buf = new byte[32 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) {
                    out.write(buf, 0, r);
                    hlsBytes.addAndGet(r);
                }
                in.close();
                clean = true;
            }
            out.flush();
        } finally {
            if (c != null) {
                finalUrls.remove(c);
                if (!clean) c.disconnect();
            }
        }
    }

    private static byte[] readAll(InputStream in, int max) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024];
        int r;
        while ((r = in.read(buf)) > 0) {
            bo.write(buf, 0, r);
            if (bo.size() > max) throw new IOException("Dữ liệu quá lớn");
        }
        return bo.toByteArray();
    }

    private static boolean looksLikeFakeImage(byte[] b, int n) {
        if (n < 4) return false;
        int b0 = b[0] & 0xff, b1 = b[1] & 0xff, b2 = b[2] & 0xff, b3 = b[3] & 0xff;
        return (b0 == 0x89 && b1 == 'P' && b2 == 'N' && b3 == 'G')
                || (b0 == 0xff && b1 == 0xd8 && b2 == 0xff)
                || (b0 == 'G' && b1 == 'I' && b2 == 'F' && b3 == '8')
                || (b0 == 'R' && b1 == 'I' && b2 == 'F' && b3 == 'F');
    }

    /** Vị trí đầu tiên mà cứ 188 byte lại có 0x47 (sync byte của MPEG-TS), 3 lần liên tiếp. */
    private static int findTsStart(byte[] b) {
        for (int i = 0; i + 376 < b.length; i++) {
            if (b[i] == 0x47 && b[i + 188] == 0x47 && b[i + 376] == 0x47) return i;
        }
        return 0;
    }

    /** Viết lại playlist: mọi URL (đoạn, key, playlist con, URI="...") thành URL localhost cùng phiên. Ghi danh sách đoạn vào p. */
    private String rewritePlaylist(String text, String base, String token, Pl p) {
        StringBuilder sb = new StringBuilder(text.length() + 256);
        String[] lines = text.split("\r?\n");
        List<String> segs = new ArrayList<>();
        boolean nextIsVariant = false;
        for (String line : lines) {
            String t = line.trim();
            if (t.isEmpty()) {
                sb.append('\n');
                continue;
            }
            if (t.startsWith("#")) {
                if (t.startsWith("#EXT-X-STREAM-INF")) nextIsVariant = true;
                final boolean isKey = t.startsWith("#EXT-X-KEY") || t.startsWith("#EXT-X-SESSION-KEY");
                final boolean isMedia = t.startsWith("#EXT-X-MEDIA") || t.startsWith("#EXT-X-I-FRAME-STREAM-INF");
                Matcher m = URI_ATTR.matcher(t);
                StringBuffer o = new StringBuffer();
                while (m.find()) {
                    String ext = isKey ? ".key" : (isMedia ? ".m3u8" : ".mp4");
                    m.appendReplacement(o, Matcher.quoteReplacement("URI=\"" + proxied(base, m.group(1), token, ext) + "\""));
                }
                m.appendTail(o);
                sb.append(o).append('\n');
            } else {
                boolean variant = nextIsVariant || t.toLowerCase(Locale.ROOT).contains(".m3u8");
                nextIsVariant = false;
                String abs = absUrl(base, t);
                if (abs != null) {
                    if (variant) {
                        if (p.firstVariant == null) p.firstVariant = abs;
                    } else {
                        segs.add(abs);
                    }
                }
                sb.append(proxied(base, t, token, variant ? ".m3u8" : ".ts")).append('\n');
            }
        }
        // đoạn i -> danh sách đoạn kế tiếp cần tải trước
        for (int i = 0; i < segs.size(); i++) {
            int n = Math.min(PREFETCH_AHEAD, segs.size() - 1 - i);
            if (n > 0) segNext.put(segs.get(i), segs.subList(i + 1, i + 1 + n).toArray(new String[0]));
        }
        p.firstSegs = segs.subList(0, Math.min(WARM_SEGS, segs.size())).toArray(new String[0]);
        return sb.toString();
    }

    private static String absUrl(String base, String ref) {
        try {
            return new URL(new URL(base), ref).toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String proxied(String base, String ref, String token, String ext) {
        String abs = absUrl(base, ref);
        if (abs == null) return ref;
        return "http://127.0.0.1:" + ss.getLocalPort() + "/h/" + token + "/" + enc(abs) + ext;
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int ch;
        while ((ch = in.read()) != -1) {
            if (ch == '\n') break;
            if (ch != '\r') sb.append((char) ch);
            if (sb.length() > 8192) throw new IOException("header too long");
        }
        if (ch == -1 && sb.length() == 0) return null;
        return sb.toString();
    }
}
