package com.duy.netplayer;

import android.content.Context;
import android.media.MediaDataSource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Nguồn dữ liệu HTTP tự viết cho android.media.MediaPlayer (thay cho việc để MediaPlayer tự đọc URL).
 * - Tự đi theo redirect (cả https <-> http), gửi đúng User-Agent / Referer, tắt gzip (Accept-Encoding: identity).
 * - Server hỗ trợ Range (206): đọc từng khối 512KB theo yêu cầu, cache LRU trong RAM, đọc trước 2 khối.
 *   Tua và mp4 có moov ở cuối file đều chạy nhanh.
 * - Server KHÔNG hỗ trợ Range (200): tải tuần tự xuống file tạm trong cache của app, readAt() đợi tới khi có đủ dữ liệu.
 * open() chặn mạng: phải gọi trên luồng nền, TRƯỚC khi setDataSource().
 */
final class HttpMediaSource extends MediaDataSource {
    static final class HttpStatusException extends IOException {
        final int code;

        HttpStatusException(int code) {
            super("HTTP " + code);
            this.code = code;
        }
    }

    private static final int CHUNK = 512 * 1024;
    private static final int MAX_CHUNKS = 32; // ~16MB RAM
    private static final int STAGE_BYTES = 4096; // đủ để đọc ftyp + header mdat, biết moov ở đâu
    private static final int MAX_TAIL_CHUNKS = 12; // moov lớn: ghim tối đa ~6MB cuối file
    private static final int CONNECT_MS = 10000, READ_MS = 15000;
    private static final long LINEAR_STALL_MS = 30000;

    private final Context app;
    private final String origUrl;
    private final Map<String, String> headers;

    private volatile String finalUrl;
    private volatile long size = -1;
    private volatile boolean rangeOk;
    private volatile String contentType = "";
    private volatile boolean closed;
    private volatile boolean sniffedHls;
    volatile String lastError;
    private final AtomicLong received = new AtomicLong();

    // chế độ Range
    private final Object lk = new Object();
    private final LinkedHashMap<Long, byte[]> cache = new LinkedHashMap<Long, byte[]>(16, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Long, byte[]> e) {
            return size() > MAX_CHUNKS;
        }
    };
    private final Set<Long> inflight = new HashSet<>();
    // Khối "ghim" (không bị LRU đá ra): khối đầu + vùng moov ở cuối file (pre-buffer đuôi file)
    private final Set<Long> pinSet = new HashSet<>();
    private final Map<Long, byte[]> pinned = new HashMap<>();
    private ExecutorService pool;

    // chế độ tuần tự (không Range)
    private File tmpFile;
    private FileChannel tmpCh;
    private RandomAccessFile tmpRaf;
    private volatile long downloaded;
    private volatile boolean dlDone;
    private volatile IOException dlError;

    private volatile HttpURLConnection cur;

    HttpMediaSource(Context c, String url, Map<String, String> headers) {
        this.app = c.getApplicationContext();
        this.origUrl = url;
        this.finalUrl = url;
        this.headers = headers;
    }

    // ---------------- thông tin cho MpEngine ----------------

    boolean isRangeOk() {
        return rangeOk;
    }

    String finalUrl() {
        return finalUrl;
    }

    String contentType() {
        String t = contentType;
        return (t == null || t.isEmpty() || "null".equals(t)) ? "video/mp4" : t;
    }

    /** Gọi dưới lk. Tìm khối trong cache LRU hoặc trong vùng ghim. */
    private byte[] peek(long idx) {
        byte[] c = cache.get(idx);
        return c != null ? c : pinned.get(idx);
    }

    /** Tổng số byte đã nhận từ mạng (để MpEngine biết còn đang có dữ liệu về hay đã đứng). */
    long receivedBytes() {
        return received.get();
    }

    boolean looksLikeHls() {
        String t = contentType == null ? "" : contentType.toLowerCase(Locale.ROOT);
        String u = finalUrl.toLowerCase(Locale.ROOT);
        return sniffedHls || t.contains("mpegurl") || u.contains(".m3u8");
    }

    /** Nội dung bắt đầu bằng #EXTM3U (cho phép BOM / khoảng trắng đầu) = playlist HLS, dù URL không có đuôi .m3u8. */
    static boolean startsWithExtM3u(byte[] b, int n) {
        int i = 0;
        while (i < n && (b[i] == (byte) 0xEF || b[i] == (byte) 0xBB || b[i] == (byte) 0xBF
                || b[i] == ' ' || b[i] == '\r' || b[i] == '\n' || b[i] == '\t')) i++;
        byte[] m = {'#', 'E', 'X', 'T', 'M', '3', 'U'};
        if (n - i < m.length) return false;
        for (int k = 0; k < m.length; k++) if (b[i + k] != m[k]) return false;
        return true;
    }

    /** Vị trí (byte) kết thúc vùng đã có sẵn liên tục kể từ byte 'from'. */
    long contiguousEnd(long from) {
        if (size <= 0) return from;
        if (!rangeOk) return Math.max(from, downloaded);
        synchronized (lk) {
            long idx = from / CHUNK;
            long end = from;
            byte[] c;
            while ((c = peek(idx)) != null) {
                end = idx * CHUNK + c.length;
                if (c.length < CHUNK) break;
                idx++;
            }
            return end;
        }
    }

    // ---------------- mở kết nối ----------------

    private HttpURLConnection connect(String url, String range) throws IOException {
        String u = url;
        for (int i = 0; i < 10; i++) {
            if (closed) throw new IOException("closed");
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setInstanceFollowRedirects(false); // tự theo để đi được cả https -> http
            c.setConnectTimeout(CONNECT_MS);
            c.setReadTimeout(READ_MS);
            c.setUseCaches(false);
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    c.setRequestProperty(e.getKey(), e.getValue());
                }
            }
            c.setRequestProperty("Accept", "*/*");
            c.setRequestProperty("Accept-Encoding", "identity"); // gzip làm sai Range
            if (range != null) c.setRequestProperty("Range", range);
            cur = c;
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && code != 304) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null || loc.isEmpty()) throw new HttpStatusException(code);
                u = new URL(new URL(u), loc).toString();
                continue;
            }
            finalUrl = u;
            return c;
        }
        throw new IOException("Quá nhiều chuyển hướng");
    }

    /** Kết nối, đọc thông tin, nạp khối đầu. Ném HttpStatusException nếu server trả mã lỗi. */
    void open() throws IOException {
        try {
            HttpURLConnection c = connect(origUrl, "bytes=0-" + (CHUNK - 1));
            int code = c.getResponseCode();
            contentType = String.valueOf(c.getContentType());
            if (code == 206) {
                rangeOk = true;
                size = parseTotal(c.getHeaderField("Content-Range"));
                pool = Executors.newFixedThreadPool(4);
                // Đọc khối đầu; ngay khi có vài KB đầu đã biết moov ở đâu -> tải đuôi SONG SONG với phần còn lại của khối đầu.
                byte[] first = readHeadStaged(c);
                if (first.length == 0) throw new IOException("Server trả body rỗng");
                sniffedHls = startsWithExtM3u(first, Math.min(first.length, 32));
                if (size < 0 && first.length < CHUNK) size = first.length;
                synchronized (lk) {
                    cache.put(0L, first);
                    pinned.put(0L, first);
                    pinSet.add(0L);
                }
            } else if (code == 200) {
                rangeOk = false;
                size = c.getContentLengthLong();
                if (size <= 0) size = -1;
                java.io.BufferedInputStream bis = new java.io.BufferedInputStream(c.getInputStream(), 8192);
                bis.mark(64);
                byte[] pk = new byte[32];
                int pn = 0, pr;
                while (pn < pk.length && (pr = bis.read(pk, pn, pk.length - pn)) > 0) pn += pr;
                bis.reset();
                if (startsWithExtM3u(pk, pn)) { // playlist HLS: không cần tải file, proxy HLS sẽ lo
                    sniffedHls = true;
                    try { c.disconnect(); } catch (Exception ignored) { }
                    return;
                }
                startLinear(c, bis);
            } else if (code == 416) {
                throw new IOException("File rỗng (416)");
            } else {
                try {
                    c.disconnect();
                } catch (Exception ignored) {
                }
                throw new HttpStatusException(code);
            }
        } catch (IOException e) {
            lastError = e.toString();
            throw e;
        }
    }

    /**
     * Pre-buffer đuôi file: mp4 mà moov nằm SAU mdat thì MediaPlayer sẽ đòi cuối file ngay.
     * Đọc trước (song song với luồng đầu file) và ghim vào RAM để trả về tức thì.
     * Nếu moov nằm ngay đầu file (faststart) thì bỏ qua, không tốn băng thông.
     */
    private void prebufferTail(byte[] head) {
        if (size < 3L * CHUNK) return; // file nhỏ: đọc tuần tự là đủ
        long moovOff = findMoovOffset(head);
        if (moovOff == -2) return; // moov ở đầu file
        long last = (size - 1) / CHUNK;
        long first = (moovOff >= 0 && moovOff < size) ? moovOff / CHUNK : last - 1;
        first = Math.max(1, Math.max(first, last - (MAX_TAIL_CHUNKS - 1))); // tối đa ~6MB cuối file
        synchronized (lk) {
            for (long i = first; i <= last; i++) pinSet.add(i);
        }
        // Tải từ đầu vùng moov đi lên: parser mp4 đọc moov từ đầu nên nhận sớm phần đầu là có lợi.
        // Các khối này vào hàng đợi trước prefetch phía trước, nên được ưu tiên băng thông.
        for (long i = first; i <= last; i++) prefetch(i);
    }

    /** Đọc khối đầu (tối đa CHUNK byte); khi đã có STAGE_BYTES byte đầu thì gọi prebufferTail ngay, không chờ đọc hết khối. */
    private byte[] readHeadStaged(HttpURLConnection c) throws IOException {
        InputStream in = c.getInputStream();
        byte[] buf = new byte[CHUNK];
        int n = 0;
        boolean kicked = false;
        try {
            while (n < CHUNK) {
                if (closed) throw new IOException("closed");
                int r = in.read(buf, n, CHUNK - n);
                if (r < 0) break;
                n += r;
                received.addAndGet(r);
                if (!kicked && n >= STAGE_BYTES) {
                    kicked = true;
                    prebufferTail(Arrays.copyOf(buf, n));
                }
            }
        } finally {
            try {
                in.close();
            } catch (Exception ignored) {
            }
        }
        if (!kicked && n > 0) prebufferTail(Arrays.copyOf(buf, n));
        return n == CHUNK ? buf : Arrays.copyOf(buf, n);
    }

    /** Duyệt các box mp4 cấp cao nhất trong khối đầu. -2: có moov ở đầu; >=0: vị trí box sau mdat; -1: không rõ. */
    static long findMoovOffset(byte[] b) {
        long off = 0;
        while (off + 8 <= b.length) {
            int o = (int) off;
            long sz = ((b[o] & 0xffL) << 24) | ((b[o + 1] & 0xffL) << 16) | ((b[o + 2] & 0xffL) << 8) | (b[o + 3] & 0xffL);
            String type = new String(b, o + 4, 4, java.nio.charset.StandardCharsets.ISO_8859_1);
            if (sz == 1) {
                if (o + 16 > b.length) return -1;
                sz = 0;
                for (int i = 0; i < 8; i++) sz = (sz << 8) | (b[o + 8 + i] & 0xffL);
            }
            if ("moov".equals(type)) return -2;
            if ("mdat".equals(type)) return sz >= 8 ? off + sz : -1;
            if (sz < 8) return -1;
            off += sz;
        }
        return -1;
    }

    private static long parseTotal(String cr) {
        // "bytes 0-524287/1234567"
        if (cr == null) return -1;
        int i = cr.lastIndexOf('/');
        if (i < 0) return -1;
        try {
            return Long.parseLong(cr.substring(i + 1).trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private byte[] readBody(HttpURLConnection c, int max) throws IOException {
        InputStream in = c.getInputStream();
        byte[] buf = new byte[max];
        int n = 0;
        try {
            while (n < max) {
                if (closed) throw new IOException("closed");
                int r = in.read(buf, n, max - n);
                if (r < 0) break;
                n += r;
                received.addAndGet(r);
            }
        } finally {
            try {
                in.close(); // đọc hết + close = tái dùng được kết nối (keep-alive)
            } catch (Exception ignored) {
            }
        }
        if (n == max) return buf;
        byte[] out = new byte[n];
        System.arraycopy(buf, 0, out, 0, n);
        return out;
    }

    // ---------------- chế độ Range ----------------

    private byte[] fetch(long idx) throws IOException {
        long start = idx * CHUNK;
        long end = start + CHUNK - 1;
        if (size >= 0) end = Math.min(end, size - 1);
        if (size >= 0 && start >= size) return new byte[0];
        IOException last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            if (closed) throw new IOException("closed");
            try {
                // lần đầu dùng địa chỉ cuối; thất bại thì thử lại từ địa chỉ gốc (link redirect có thể hết hạn)
                HttpURLConnection c = connect(attempt == 0 ? finalUrl : origUrl, "bytes=" + start + "-" + end);
                int code = c.getResponseCode();
                if (code == 416) return new byte[0];
                if (code != 206) throw new HttpStatusException(code);
                return readBody(c, (int) (end - start + 1));
            } catch (IOException e) {
                last = e;
                lastError = e.toString();
                if (closed) break;
                try {
                    Thread.sleep(300L * (attempt + 1));
                } catch (InterruptedException ie) {
                    throw new IOException("interrupted");
                }
            }
        }
        throw last != null ? last : new IOException("fetch failed");
    }

    private byte[] getChunk(long idx) throws IOException {
        synchronized (lk) {
            while (true) {
                if (closed) throw new IOException("closed");
                byte[] c = peek(idx);
                if (c != null) return c;
                if (!inflight.contains(idx)) break;
                try {
                    lk.wait(200);
                } catch (InterruptedException e) {
                    throw new IOException("interrupted");
                }
            }
            inflight.add(idx);
        }
        byte[] data = null;
        IOException err = null;
        try {
            data = fetch(idx);
        } catch (IOException e) {
            err = e;
        }
        synchronized (lk) {
            inflight.remove(idx);
            if (data != null) {
                cache.put(idx, data);
                if (pinSet.contains(idx)) pinned.put(idx, data);
            }
            lk.notifyAll();
        }
        if (err != null) throw err;
        return data;
    }

    private void prefetch(final long idx) {
        if (closed || pool == null) return;
        if (size >= 0 && idx * (long) CHUNK >= size) return;
        synchronized (lk) {
            if (peek(idx) != null || inflight.contains(idx)) return;
        }
        try {
            pool.execute(() -> {
                try {
                    getChunk(idx);
                } catch (Exception ignored) {
                }
            });
        } catch (Exception ignored) { // pool đã đóng
        }
    }

    private int readRange(long position, byte[] buffer, int offset, int len) throws IOException {
        int total = 0;
        while (total < len) {
            long p = position + total;
            if (size >= 0 && p >= size) break;
            long idx = p / CHUNK;
            byte[] ck = getChunk(idx);
            int off = (int) (p - idx * CHUNK);
            if (off >= ck.length) break; // hết file
            int n = Math.min(len - total, ck.length - off);
            System.arraycopy(ck, off, buffer, offset + total, n);
            total += n;
            prefetch(idx + 1);
            prefetch(idx + 2);
            prefetch(idx + 3);
        }
        return total == 0 ? -1 : total;
    }

    // ---------------- chế độ tuần tự ----------------

    private void startLinear(final HttpURLConnection c, final InputStream body) throws IOException {
        tmpFile = File.createTempFile("np_", ".tmp", app.getCacheDir());
        tmpRaf = new RandomAccessFile(tmpFile, "rw");
        tmpCh = tmpRaf.getChannel();
        Thread t = new Thread(() -> {
            byte[] buf = new byte[64 * 1024];
            try (InputStream in = body) {
                while (!closed) {
                    int r = in.read(buf);
                    if (r < 0) break;
                    tmpCh.write(ByteBuffer.wrap(buf, 0, r), downloaded);
                    received.addAndGet(r);
                    synchronized (lk) {
                        downloaded += r;
                        lk.notifyAll();
                    }
                }
            } catch (IOException e) {
                if (!closed) {
                    dlError = e;
                    lastError = e.toString();
                }
            } finally {
                synchronized (lk) {
                    dlDone = true;
                    lk.notifyAll();
                }
            }
        }, "np-linear-dl");
        t.setDaemon(true);
        t.start();
    }

    private int readLinear(long position, byte[] buffer, int offset, int len) throws IOException {
        long need = position + len;
        long lastMove = System.currentTimeMillis();
        long lastVal = downloaded;
        synchronized (lk) {
            while (!closed && downloaded < need && !dlDone) {
                try {
                    lk.wait(500);
                } catch (InterruptedException e) {
                    throw new IOException("interrupted");
                }
                if (downloaded != lastVal) {
                    lastVal = downloaded;
                    lastMove = System.currentTimeMillis();
                } else if (System.currentTimeMillis() - lastMove > LINEAR_STALL_MS) {
                    throw new IOException("Không nhận thêm dữ liệu " + (LINEAR_STALL_MS / 1000) + "s");
                }
            }
            if (closed) throw new IOException("closed");
        }
        long avail = downloaded;
        if (position >= avail) {
            if (dlError != null && !dlDone) throw dlError;
            if (dlError != null) throw dlError;
            return -1;
        }
        int n = (int) Math.min(len, avail - position);
        ByteBuffer bb = ByteBuffer.wrap(buffer, offset, n);
        int got = 0;
        while (got < n) {
            int r = tmpCh.read(bb, position + got);
            if (r < 0) break;
            got += r;
        }
        return got == 0 ? -1 : got;
    }

    // ---------------- MediaDataSource ----------------

    @Override
    public int readAt(long position, byte[] buffer, int offset, int size) throws IOException {
        if (closed) throw new IOException("closed");
        if (size == 0) return 0;
        if (position < 0) return -1;
        try {
            return rangeOk ? readRange(position, buffer, offset, size)
                    : readLinear(position, buffer, offset, size);
        } catch (IOException e) {
            lastError = e.toString();
            throw e;
        }
    }

    @Override
    public long getSize() {
        return size;
    }

    @Override
    public void close() {
        if (closed) return;
        closed = true;
        HttpURLConnection c = cur;
        if (c != null) {
            try {
                c.disconnect();
            } catch (Exception ignored) {
            }
        }
        if (pool != null) pool.shutdownNow();
        synchronized (lk) {
            cache.clear();
            pinned.clear();
            lk.notifyAll();
        }
        try {
            if (tmpCh != null) tmpCh.close();
            if (tmpRaf != null) tmpRaf.close();
        } catch (Exception ignored) {
        }
        if (tmpFile != null) //noinspection ResultOfMethodCallIgnored
            tmpFile.delete();
    }
}
