package com.duy.netplayer;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Hút khung hình của một SurfaceTexture khi không có TextureView nào hiển thị (phát nền).
 * Không vẽ gì, chỉ gọi updateTexImage cho mỗi khung để decoder MediaPlayer không bị nghẽn hàng đợi
 * và vẫn chạy đúng nhịp. Nhờ đó MediaPlayer không phải đổi mặt hiển thị -> không dựng lại decoder / không tua lùi.
 */
final class SurfaceDrain {
    private final Context app;
    private final SurfaceTexture st;
    private HandlerThread th;
    private Handler dh;
    private EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
    private EGLContext ctx = EGL14.EGL_NO_CONTEXT;
    private EGLSurface pb = EGL14.EGL_NO_SURFACE;
    private int tex;
    private boolean eglOk, attached, stopped;
    private boolean logged;

    SurfaceDrain(Context c, SurfaceTexture st) {
        this.app = c.getApplicationContext();
        this.st = st;
    }

    void start() {
        th = new HandlerThread("surface-drain");
        th.start();
        dh = new Handler(th.getLooper());
        dh.post(() -> tryAttach(0));
    }

    /** Chạy trên luồng hút. TextureView cũ có thể chưa nhả SurfaceTexture ngay nên thử lại vài lần. */
    private void tryAttach(int n) {
        if (stopped) return;
        try {
            if (!eglOk) setupEgl();
            st.attachToGLContext(tex);
            attached = true;
            st.setOnFrameAvailableListener(t -> drainOne(), dh);
            drainOne(); // khung đã kẹt sẵn
        } catch (Throwable t) {
            if (n < 150) {
                dh.postDelayed(() -> tryAttach(n + 1), 40);
            } else if (!logged) {
                logged = true;
                App.saveLog(app, "SurfaceDrain không gắn được SurfaceTexture", t);
            }
        }
    }

    private void drainOne() {
        if (stopped || !attached) return;
        try {
            st.updateTexImage();
        } catch (Throwable ignored) {
        }
    }

    private void setupEgl() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] v = new int[2];
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw new IllegalStateException("eglInitialize");
        int[] cfgAttr = {EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE};
        EGLConfig[] cfg = new EGLConfig[1];
        int[] num = new int[1];
        if (!EGL14.eglChooseConfig(dpy, cfgAttr, 0, cfg, 0, 1, num, 0) || num[0] < 1)
            throw new IllegalStateException("eglChooseConfig");
        ctx = EGL14.eglCreateContext(dpy, cfg[0], EGL14.EGL_NO_CONTEXT,
                new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE}, 0);
        if (ctx == EGL14.EGL_NO_CONTEXT) throw new IllegalStateException("eglCreateContext");
        pb = EGL14.eglCreatePbufferSurface(dpy, cfg[0],
                new int[]{EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE}, 0);
        if (pb == EGL14.EGL_NO_SURFACE) throw new IllegalStateException("eglCreatePbufferSurface");
        if (!EGL14.eglMakeCurrent(dpy, pb, pb, ctx)) throw new IllegalStateException("eglMakeCurrent");
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        tex = t[0];
        eglOk = true;
    }

    /** Dừng và nhả SurfaceTexture về trạng thái tách rời (đồng bộ, tối đa 1s) để TextureView mới nhận. */
    void stop() {
        final Handler h = dh;
        final HandlerThread t = th;
        if (h == null || t == null) return;
        final CountDownLatch cd = new CountDownLatch(1);
        h.removeCallbacksAndMessages(null);
        h.post(() -> {
            stopped = true;
            try {
                st.setOnFrameAvailableListener(null);
                if (attached) st.detachFromGLContext();
            } catch (Throwable ignored) {
            }
            attached = false;
            try {
                if (eglOk) {
                    GLES20.glDeleteTextures(1, new int[]{tex}, 0);
                    EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                    EGL14.eglDestroySurface(dpy, pb);
                    EGL14.eglDestroyContext(dpy, ctx);
                }
            } catch (Throwable ignored) {
            }
            eglOk = false;
            cd.countDown();
        });
        try {
            cd.await(1000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }
        t.quitSafely();
        dh = null;
        th = null;
    }
}
