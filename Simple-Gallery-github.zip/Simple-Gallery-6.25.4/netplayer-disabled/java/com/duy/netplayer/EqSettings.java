package com.duy.netplayer;

import android.content.Context;
import android.content.SharedPreferences;

/** Cài đặt bộ cân bằng: 10 băng + tăng trầm + ảo hóa + âm vang. Lưu SharedPreferences. */
final class EqSettings {
    static final int N = 10;
    static final float MAX_DB = 15f;
    static final float[] FREQ = {31.25f, 62.5f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f};
    static final String[] LABEL = {"31HZ", "62HZ", "125HZ", "250HZ", "500HZ",
            "1KHZ", "2KHZ", "4KHZ", "8KHZ", "16KHZ"};

    static final String[] PRESET_NAMES = {"Bình thường", "Tin tức", "To tiếng", "Phòng chờ",
            "Đàn piano", "RB", "Rock", "Pop", "Jazz", "Cổ điển", "Trầm mạnh"};
    //                              31    62   125   250   500    1k    2k    4k    8k   16k
    static final float[][] PRESET = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {-4, -3, -1, 1, 3, 4, 4, 3, 1, -1},
            {5, 4, 2, 0, 0, 0, 1, 3, 4, 3},
            {3, 0.5f, -2, -4.5f, -2, 3, 7, 9, 10.5f, 12},
            {-1, 0, 1, 2, 1, 2, 3, 4, 3, 2},
            {7, 6, 4, 1, -1, -1, 0, 1, 2, 2},
            {5, 4, 2, 1, -1, -1, 1, 3, 4, 4},
            {-1, -1, 0, 2, 3, 3, 2, 0, -1, -1},
            {3, 2, 1, 2, -1, -1, 0, 1, 2, 3},
            {0, 0, 0, 0, 0, 0, -3, -3, -3, -4},
            {8, 7, 5, 2, 0, 0, 0, 0, 0, 0},
    };

    static final String[] REVERB_NAMES = {"Không", "Phòng nhỏ", "Phòng vừa", "Phòng lớn", "Sảnh lớn", "Tấm sáng"};
    // {room, damp, wet}
    static final float[][] REVERB = {
            {0, 0, 0},
            {0.30f, 0.55f, 0.16f},
            {0.50f, 0.45f, 0.20f},
            {0.70f, 0.40f, 0.24f},
            {0.86f, 0.30f, 0.28f},
            {0.60f, 0.12f, 0.22f},
    };

    /** Ảnh chụp bất biến, luồng âm thanh đọc cái này. */
    static final class Snapshot {
        final boolean enabled, neutral;
        final float[] gains;
        final float bass, virt;
        final int reverb;

        Snapshot(boolean enabled, float[] gains, float bass, float virt, int reverb) {
            this.enabled = enabled;
            this.gains = gains;
            this.bass = bass;
            this.virt = virt;
            this.reverb = reverb;
            boolean flat = bass < 0.01f && virt < 0.01f && reverb == 0;
            for (float g : gains) if (Math.abs(g) >= 0.05f) flat = false;
            this.neutral = flat;
        }
    }

    volatile Snapshot snap;
    /** Được gọi mỗi khi publish(): MpEngine dùng để áp bộ cân bằng ngay lúc đang phát. */
    volatile Runnable listener;
    boolean enabled = true;
    final float[] gains = new float[N];
    float bass, virt;
    int reverb;
    int preset = 0; // -1 = tùy chỉnh
    private final SharedPreferences sp;

    EqSettings(Context c) {
        sp = c.getSharedPreferences("eq", 0);
        enabled = sp.getBoolean("on", true);
        String g = sp.getString("gains", "");
        String[] p = g.split(",");
        if (p.length == N) {
            try {
                for (int i = 0; i < N; i++) gains[i] = Float.parseFloat(p[i]);
            } catch (NumberFormatException e) {
                java.util.Arrays.fill(gains, 0f);
            }
        }
        bass = sp.getFloat("bass", 0f);
        virt = sp.getFloat("virt", 0f);
        reverb = Math.max(0, Math.min(REVERB_NAMES.length - 1, sp.getInt("rv", 0)));
        preset = sp.getInt("preset", 0);
        publish();
    }

    void publish() {
        snap = new Snapshot(enabled, gains.clone(), bass, virt, reverb);
        Runnable cb = listener;
        if (cb != null) cb.run();
    }

    void applyPreset(int i) {
        preset = i;
        System.arraycopy(PRESET[i], 0, gains, 0, N);
    }

    void reset() {
        java.util.Arrays.fill(gains, 0f);
        bass = 0;
        virt = 0;
        reverb = 0;
        preset = 0;
    }

    void save() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < N; i++) sb.append(i > 0 ? "," : "").append(gains[i]);
        sp.edit().putBoolean("on", enabled).putString("gains", sb.toString())
                .putFloat("bass", bass).putFloat("virt", virt)
                .putInt("rv", reverb).putInt("preset", preset).apply();
    }
}
