package com.duy.netplayer;

import android.media.MediaPlayer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.DynamicsProcessing;
import android.media.audiofx.Equalizer;
import android.media.audiofx.PresetReverb;
import android.media.audiofx.Virtualizer;
import android.os.Build;

/**
 * Bộ cân bằng cho MediaPlayer (MediaPlayer không cho chen vào luồng PCM nên dùng audiofx của hệ thống):
 * - 10 băng: DynamicsProcessing (Android 9+, đúng 10 băng như giao diện); máy không có thì Equalizer
 *   của máy (thường 5 băng, 10 băng được nội suy theo tần số).
 * - Tăng trầm = BassBoost, ảo hóa âm thanh = Virtualizer, âm vang = PresetReverb.
 * Hiệu ứng nào máy không hỗ trợ thì bỏ qua, không làm hỏng việc phát.
 */
final class EqEffects {
    private static final int N = EqSettings.N;
    // chỉ số kiểu âm vang trong EqSettings.REVERB_NAMES -> preset của PresetReverb
    private static final short[] RV = {PresetReverb.PRESET_NONE, PresetReverb.PRESET_SMALLROOM,
            PresetReverb.PRESET_MEDIUMROOM, PresetReverb.PRESET_LARGEROOM,
            PresetReverb.PRESET_LARGEHALL, PresetReverb.PRESET_PLATE};

    private final EqSettings s;
    private DynamicsProcessing dp;
    private Equalizer eqz;
    private BassBoost bb;
    private Virtualizer vz;
    private PresetReverb rv;

    EqEffects(EqSettings s) {
        this.s = s;
    }

    void attach(MediaPlayer mp) {
        release();
        int session = mp.getAudioSessionId();
        if (session == 0) return;
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                dp = createDp(session);
            } catch (Throwable t) {
                dp = null;
            }
        }
        if (dp == null) {
            try {
                eqz = new Equalizer(0, session);
            } catch (Throwable t) {
                eqz = null;
            }
        }
        try {
            bb = new BassBoost(0, session);
        } catch (Throwable t) {
            bb = null;
        }
        try {
            vz = new Virtualizer(0, session);
        } catch (Throwable t) {
            vz = null;
        }
        try {
            rv = new PresetReverb(0, 0); // gắn kiểu aux (send) như tài liệu Android hướng dẫn
            mp.attachAuxEffect(rv.getId());
            mp.setAuxEffectSendLevel(1f);
        } catch (Throwable t) {
            if (rv != null) {
                try {
                    rv.release();
                } catch (Throwable ignored) {
                }
            }
            rv = null;
        }
        apply();
    }

    /** Dùng cho ExoPlayer: gắn hiệu ứng vào audio session; trả về id PresetReverb (0 nếu không có) để ExoPlayer gắn aux. */
    int attachSession(int session) {
        release();
        if (session == 0) return 0;
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                dp = createDp(session);
            } catch (Throwable t) {
                dp = null;
            }
        }
        if (dp == null) {
            try {
                eqz = new Equalizer(0, session);
            } catch (Throwable t) {
                eqz = null;
            }
        }
        try {
            bb = new BassBoost(0, session);
        } catch (Throwable t) {
            bb = null;
        }
        try {
            vz = new Virtualizer(0, session);
        } catch (Throwable t) {
            vz = null;
        }
        int rid = 0;
        try {
            rv = new PresetReverb(0, 0);
            rid = rv.getId();
        } catch (Throwable t) {
            rv = null;
        }
        apply();
        return rid;
    }

    private DynamicsProcessing createDp(int session) {
        DynamicsProcessing.Config cfg = new DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
                true, N, false, 0, false, 0, true).build();
        return new DynamicsProcessing(0, session, cfg);
    }

    void release() {
        if (dp != null) safeRelease(dp);
        if (eqz != null) safeRelease(eqz);
        if (bb != null) safeRelease(bb);
        if (vz != null) safeRelease(vz);
        if (rv != null) safeRelease(rv);
        dp = null;
        eqz = null;
        bb = null;
        vz = null;
        rv = null;
    }

    private static void safeRelease(android.media.audiofx.AudioEffect e) {
        try {
            e.release();
        } catch (Throwable ignored) {
        }
    }

    /** Đọc EqSettings.snap và áp lên các hiệu ứng (gọi lúc attach và mỗi lần người dùng chỉnh). */
    void apply() {
        EqSettings.Snapshot n = s.snap;
        if (n == null) return;
        boolean on = n.enabled && !n.neutral;
        try {
            if (dp != null) applyDp(n, on);
            else if (eqz != null) applyEqualizer(n, on);
        } catch (Throwable ignored) {
        }
        try {
            if (bb != null) {
                boolean e = n.enabled && n.bass > 0.01f;
                if (e) bb.setStrength((short) Math.max(0, Math.min(1000, Math.round(n.bass * 1000))));
                bb.setEnabled(e);
            }
        } catch (Throwable ignored) {
        }
        try {
            if (vz != null) {
                boolean e = n.enabled && n.virt > 0.01f;
                if (e) vz.setStrength((short) Math.max(0, Math.min(1000, Math.round(n.virt * 1000))));
                vz.setEnabled(e);
            }
        } catch (Throwable ignored) {
        }
        try {
            if (rv != null) {
                int i = Math.max(0, Math.min(RV.length - 1, n.reverb));
                boolean e = n.enabled && i > 0;
                rv.setPreset(RV[i]);
                rv.setEnabled(e);
            }
        } catch (Throwable ignored) {
        }
    }

    private void applyDp(EqSettings.Snapshot n, boolean on) {
        float maxBoost = 0;
        for (int b = 0; b < N; b++) {
            float g = on ? n.gains[b] : 0f;
            // cutoff của băng b = trung bình nhân giữa tâm băng b và b+1; băng cuối lên tới 20kHz
            float cutoff = b < N - 1 ? (float) Math.sqrt(EqSettings.FREQ[b] * EqSettings.FREQ[b + 1]) : 20000f;
            dp.setPreEqBandAllChannelsTo(b, new DynamicsProcessing.EqBand(true, cutoff, g));
            maxBoost = Math.max(maxBoost, g);
        }
        dp.setInputGainAllChannelsTo(-0.6f * maxBoost); // hạ preamp khi tăng nhiều, tránh vỡ tiếng
        dp.setLimiterAllChannelsTo(new DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f));
        dp.setEnabled(on);
    }

    private void applyEqualizer(EqSettings.Snapshot n, boolean on) {
        short bands = eqz.getNumberOfBands();
        short[] range = eqz.getBandLevelRange(); // mB (1/100 dB)
        for (short i = 0; i < bands; i++) {
            float fc = eqz.getCenterFreq(i) / 1000f; // mHz -> Hz
            float g = on ? gainAt(n.gains, fc) : 0f;
            int lv = Math.round(g * 100f);
            eqz.setBandLevel(i, (short) Math.max(range[0], Math.min(range[1], lv)));
        }
        eqz.setEnabled(on);
    }

    /** Nội suy độ lợi (dB) tại tần số f từ 10 băng, theo thang log. */
    private static float gainAt(float[] g, float f) {
        if (f <= EqSettings.FREQ[0]) return g[0];
        if (f >= EqSettings.FREQ[N - 1]) return g[N - 1];
        for (int i = 0; i < N - 1; i++) {
            float a = EqSettings.FREQ[i], b = EqSettings.FREQ[i + 1];
            if (f >= a && f <= b) {
                float t = (float) (Math.log(f / a) / Math.log(b / a));
                return g[i] + (g[i + 1] - g[i]) * t;
            }
        }
        return 0f;
    }
}
