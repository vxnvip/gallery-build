package com.duy.netplayer;

import com.simplemobiletools.gallery.pro.R;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Trang "Tỉ lệ": công tắc hiện / ẩn từng tỉ lệ khung hình. Ẩn thì vuốt / bấm đổi sẽ bỏ qua; luôn giữ lại ít nhất 1. */
public class AspectSettingsActivity extends Activity {
    private static final int TEXT = 0xFFFFFFFF, SUB = 0xFF9E9E9E;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121212);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(16), dp(8));
        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setPadding(dp(12), dp(12), dp(12), dp(12));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView title = new TextView(this);
        title.setText("Tỉ lệ");
        title.setTextSize(22);
        title.setTextColor(TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = dp(12);
        bar.addView(title, tp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        for (int i = 0; i < SettingsActivity.ASPECT_NAMES.length; i++) list.addView(row(i));

        TextView note = new TextView(this);
        note.setText("Tỉ lệ bị ẩn sẽ được bỏ qua khi vuốt / bấm đổi. Phải giữ lại ít nhất 1 tỉ lệ.");
        note.setTextColor(SUB);
        note.setTextSize(14);
        note.setPadding(dp(20), dp(16), dp(20), dp(16));
        list.addView(note);

        setContentView(root);
    }

    private View row(final int idx) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(16), dp(20), dp(16));
        TextView name = new TextView(this);
        name.setText(SettingsActivity.ASPECT_NAMES[idx]);
        name.setTextColor(TEXT);
        name.setTextSize(17);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.rightMargin = dp(12);
        row.addView(name, lp);

        final Switch sw = new Switch(this);
        sw.setChecked(SettingsActivity.aspectEnabled(this, idx));
        sw.setOnCheckedChangeListener((b, on) -> {
            if (!on && SettingsActivity.aspectEnabledCount(this) <= 1 && SettingsActivity.aspectEnabled(this, idx)) {
                sw.setChecked(true); // gạt hết: không cho, bật lại cái cuối
                Toast.makeText(this, "Phải giữ lại ít nhất 1 tỉ lệ", Toast.LENGTH_SHORT).show();
                return;
            }
            SettingsActivity.setAspectEnabled(this, idx, on);
        });
        row.addView(sw);
        row.setOnClickListener(v -> sw.toggle());
        return row;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
