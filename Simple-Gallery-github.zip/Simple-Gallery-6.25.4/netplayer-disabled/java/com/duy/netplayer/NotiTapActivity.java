package com.duy.netplayer;

import android.app.Activity;
import android.os.Bundle;

/**
 * Chỉ để thông báo có contentIntent (Samsung cần nó mới hiện chip tai nghe + tên trên thanh trạng thái).
 * Chạm chip / thân thông báo KHÔNG làm gì cả (tránh chạm nhầm khi tua). Mở video bằng nút "Mở" trên thẻ media.
 */
public class NotiTapActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        finish();
        overridePendingTransition(0, 0);
    }
}
