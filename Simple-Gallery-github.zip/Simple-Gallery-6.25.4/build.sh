#!/data/data/com.termux/files/usr/bin/bash
# Build Simple Gallery tren Termux.  Dung: bash build.sh
PROJ="$(cd "$(dirname "$0")" && pwd)"
GV=8.10.2
GH="$HOME/gradle-$GV"
cd "$PROJ" || exit 1

command -v java >/dev/null || { echo "Thieu Java -> pkg install openjdk-21"; exit 1; }
[ -x /data/data/com.termux/files/usr/bin/aapt2 ] || { echo "Thieu aapt2 -> pkg install aapt2"; exit 1; }
[ -f local.properties ] || echo "sdk.dir=/storage/emulated/0/termux-build/sdk" > local.properties
grep -q "^sdk.dir" local.properties && [ -d "$(sed -n 's/^sdk.dir=//p' local.properties)/platforms" ] || echo "!! Kiem tra sdk.dir trong local.properties (can platforms;android-35)"

if [ ! -x "$GH/bin/gradle" ]; then
  echo ">> Tai Gradle $GV ..."
  (cd "$HOME" && curl -fLO "https://services.gradle.org/distributions/gradle-$GV-bin.zip" \
    && unzip -q "gradle-$GV-bin.zip" && rm "gradle-$GV-bin.zip") || { echo "Tai Gradle that bai"; exit 1; }
fi

# aapt2 cua Termux dat o cau hinh RIENG cua may (khong nam trong project -> project build duoc ca tren GitHub)
mkdir -p "$HOME/.gradle"
grep -q "aapt2FromMavenOverride" "$HOME/.gradle/gradle.properties" 2>/dev/null || \
  echo "android.aapt2FromMavenOverride=/data/data/com.termux/files/usr/bin/aapt2" >> "$HOME/.gradle/gradle.properties"

echo ">> Build debug (mat vai phut, dung tat Termux) ..."
"$GH/bin/gradle" assembleDebug --no-daemon --console=plain > build.log 2>&1
code=$?
if [ $code -ne 0 ]; then
  echo "❌ BUILD THAT BAI (exit $code)"
  grep -E "^e: |What went wrong|OutOfMemory|Unsupported|Could not resolve" -A2 build.log | head -40
  echo "Log day du: $PROJ/build.log"
  exit $code
fi

APK="$(ls app/build/outputs/apk/debug/*.apk | head -1)"
mkdir -p /sdcard/Download
cp "$APK" /sdcard/Download/SimpleGallery-debug.apk
echo "✅ XONG: /sdcard/Download/SimpleGallery-debug.apk"
command -v termux-open >/dev/null && termux-open /sdcard/Download/SimpleGallery-debug.apk
