/*
 * Copyright (C) 2012 CyberAgent
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.gsyvideoplayer.effect;

import android.opengl.GLSurfaceView;

import com.shuyu.gsyvideoplayer.render.view.GSYVideoGLView;

/**
 * 马赛克效果
 * Created by guoshuyu on 2017/09/20.
 */
public class PixelationEffect implements GSYVideoGLView.ShaderInterface {

    private float pixel = 40f;

    public PixelationEffect() {
    }

    /**
     * 1 - 100
     */
    public PixelationEffect(float pixel) {
        this.pixel = pixel;
    }

    @Override
    public String getShader(GLSurfaceView mGlSurfaceView) {
        return "#extension GL_OES_EGL_image_external : require\n"
                + "precision mediump float;\n"
                + "uniform vec2 uViewSize;\n"
                + "varying vec2 vTextureCoord;\n"
                + "uniform samplerExternalOES sTexture;\n"
                + "void main()\n"
                + "{\n"
                + "  vec2 uv = vTextureCoord.xy;\n"
                + "  vec2 imageFactor = 1.0 / max(uViewSize, vec2(1.0));\n"
                + "  float pixel = " + pixel + ";\n"
                + "  vec2 delta = pixel * imageFactor;\n"
                + "  vec2 coord = vec2(delta.x * floor(uv.x / delta.x), delta.y * floor(uv.y / delta.y));\n"
                + "  vec4 tc = texture2D(sTexture, coord);\n"
                + "  gl_FragColor = vec4(tc.rgb, tc.a);\n"
                + "}";
    }
}
