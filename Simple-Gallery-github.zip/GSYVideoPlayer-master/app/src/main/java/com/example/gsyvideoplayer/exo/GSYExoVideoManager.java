package com.example.gsyvideoplayer.exo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Message;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import com.shuyu.gsyvideoplayer.GSYVideoBaseManager;
import com.shuyu.gsyvideoplayer.player.IPlayerManager;
import com.shuyu.gsyvideoplayer.utils.CommonUtil;
import com.shuyu.gsyvideoplayer.video.base.GSYVideoPlayer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.shuyu.gsyvideoplayer.utils.CommonUtil.hideNavKey;

/**
 * Created by guoshuyu on 2018/5/16.
 * 自定义管理器，连接自定义exo view 和 exo player，实现无缝切换效果
 */
public class GSYExoVideoManager extends GSYVideoBaseManager {
    public static final int SMALL_ID = com.shuyu.gsyvideoplayer.R.id.small_id;

    public static final int FULLSCREEN_ID = com.shuyu.gsyvideoplayer.R.id.full_id;

    public static String TAG = "GSYExoVideoManager";

    @SuppressLint("StaticFieldLeak")
    private static GSYExoVideoManager videoManager;


    private GSYExoVideoManager() {
        init();
    }

    /**
     * 单例管理器
     */
    public static synchronized GSYExoVideoManager instance() {
        if (videoManager == null) {
            videoManager = new GSYExoVideoManager();
        }
        return videoManager;
    }

    @Override
    protected IPlayerManager getPlayManager() {
        return new GSYExoPlayerManager();
    }

    public void prepare(List<String> urls, Map<String, String> mapHeadData, int index,  boolean loop, float speed, boolean cache, File cachePath, String overrideExtension) {
        if (urls.size() == 0) return;
        Message msg = new Message();
        msg.what = HANDLER_PREPARE;
        msg.obj = new GSYExoModel(urls, mapHeadData, index, loop, speed, cache, cachePath, overrideExtension);
        sendMessage(msg);
    }


    /**
     * 上一集
     */
    public void previous() {
        if (playerManager == null) {
            return;
        }
        ((GSYExoPlayerManager)playerManager).previous();
    }


    public void setDisplayNew (Object holder) {
        Message msg = new Message();
        msg.what = HANDLER_SETDISPLAY;
        msg.obj = holder;
        if (playerManager != null) {
            playerManager.showDisplay(msg);
        }
    }

    /**
     * 下一集
     */
    public void next() {
        if (playerManager == null) {
            return;
        }
        ((GSYExoPlayerManager)playerManager).next();
    }

    public List<GSYExo2MediaPlayer.VideoTrackInfo> getVideoTrackInfoList() {
        if (playerManager == null) {
            return new ArrayList<>();
        }
        List<GSYExo2MediaPlayer.VideoTrackInfo> tracks =
            ((GSYExoPlayerManager) playerManager).getVideoTrackInfoList();
        return tracks == null ? new ArrayList<GSYExo2MediaPlayer.VideoTrackInfo>() : tracks;
    }

    public boolean clearVideoTrackOverride() {
        return playerManager != null && ((GSYExoPlayerManager) playerManager).clearVideoTrackOverride();
    }

    public boolean setVideoTrackOverride(int groupIndex, int trackIndex) {
        return playerManager != null
            && ((GSYExoPlayerManager) playerManager).setVideoTrackOverride(groupIndex, trackIndex);
    }

    /**
     * 退出全屏，主要用于返回键
     *
     * @return 返回是否全屏
     */
    @SuppressWarnings("ResourceType")
    public static boolean backFromWindowFull(Context context) {
        boolean backFrom = false;
        ViewGroup vp = (ViewGroup) (CommonUtil.scanForActivity(context)).findViewById(Window.ID_ANDROID_CONTENT);
        View oldF = vp.findViewById(FULLSCREEN_ID);
        if (oldF != null) {
            backFrom = true;
            hideNavKey(context);
            if (GSYExoVideoManager.instance().lastListener() != null) {
                GSYExoVideoManager.instance().lastListener().onBackFullscreen();
            }
        }
        return backFrom;
    }

    /**
     * 页面销毁了记得调用是否所有的video
     */
    public static void releaseAllVideos() {
        if (GSYExoVideoManager.instance().listener() != null) {
            GSYExoVideoManager.instance().listener().onCompletion();
        }
        GSYExoVideoManager.instance().releaseMediaPlayer();
    }


    /**
     * 暂停播放
     */
    public static void onPause() {
        if (GSYExoVideoManager.instance().listener() != null) {
            GSYExoVideoManager.instance().listener().onVideoPause();
        }
    }

    /**
     * 恢复播放
     */
    public static void onResume() {
        if (GSYExoVideoManager.instance().listener() != null) {
            GSYExoVideoManager.instance().listener().onVideoResume();
        }
    }


    /**
     * 恢复暂停状态
     *
     * @param seek 是否产生seek动作,直播设置为false
     */
    public static void onResume(boolean seek) {
        if (GSYExoVideoManager.instance().listener() != null) {
            GSYExoVideoManager.instance().listener().onVideoResume(seek);
        }
    }

    /**
     * 当前是否全屏状态
     *
     * @return 当前是否全屏状态， true代表是。
     */
    @SuppressWarnings("ResourceType")
    public static boolean isFullState(Activity activity) {
        ViewGroup vp = (ViewGroup) (CommonUtil.scanForActivity(activity)).findViewById(Window.ID_ANDROID_CONTENT);
        final View full = vp.findViewById(FULLSCREEN_ID);
        GSYVideoPlayer gsyVideoPlayer = null;
        if (full != null) {
            gsyVideoPlayer = (GSYVideoPlayer) full;
        }
        return gsyVideoPlayer != null;
    }
}
