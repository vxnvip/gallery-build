package kotlinx.android.synthetic.main.activity_video_player.view

import android.app.Activity
import android.app.Dialog
import android.view.View
import androidx.fragment.app.Fragment
import com.simplemobiletools.gallery.pro.R

val View.video_player_holder get() = findViewById<android.widget.RelativeLayout>(R.id.video_player_holder)
val View.video_surface_frame get() = findViewById<com.alexvasilkov.gestures.GestureFrameLayout>(R.id.video_surface_frame)
val View.video_surface get() = findViewById<android.view.TextureView>(R.id.video_surface)
val View.video_volume_controller get() = findViewById<com.simplemobiletools.gallery.pro.views.MediaSideScroll>(R.id.video_volume_controller)
val View.video_brightness_controller get() = findViewById<com.simplemobiletools.gallery.pro.views.MediaSideScroll>(R.id.video_brightness_controller)
val View.top_shadow get() = findViewById<android.widget.ImageView>(R.id.top_shadow)
val View.video_bottom_gradient get() = findViewById<android.widget.TextView>(R.id.video_bottom_gradient)
val View.slide_info get() = findViewById<android.widget.TextView>(R.id.slide_info)
val View.video_appbar get() = findViewById<com.google.android.material.appbar.AppBarLayout>(R.id.video_appbar)
val View.video_toolbar get() = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.video_toolbar)
