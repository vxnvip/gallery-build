package com.example.nokiac5;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Standalone Java/Android Canvas recreation of the supplied "Vỏ Nokia C5 đen.html".
 * Not wired into J2ME Loader yet. The black display rectangle is intentionally a slot
 * where a real CanvasView/GlesView can later be layered by the host Activity.
 *
 * Design coordinates follow the HTML's 310px-wide .chrome and CSS layout as closely
 * as practical. Call getScreenBounds(out) to obtain the display slot in this View's
 * local coordinates after layout.
 */
public class NokiaC5SkinView extends View {
    public interface KeyListener {
        void onKey(String key, boolean pressed);
    }

    private static final float DESIGN_W = 310f;
    // Based on the original CSS dimensions: chrome + top/logo/display/controls/keypad.
    private static final float DESIGN_H = 792f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF r = new RectF();
    private final RectF screenRect = new RectF(37, 85, 273, 400);
    private final Map<String, RectF> hitboxes = new LinkedHashMap<>();
    private final Map<String, Boolean> pressed = new LinkedHashMap<>();
    private KeyListener keyListener;
    private float scale = 1f, offsetX, offsetY;
    private String activeKey;

    public NokiaC5SkinView(Context context) { super(context); init(); }
    public NokiaC5SkinView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public NokiaC5SkinView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); init(); }

    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null); // CSS-like shadow layers are more consistent in software.
        setFocusable(true);
        setClickable(true);
        buildHitboxes();
    }

    public void setKeyListener(KeyListener listener) { keyListener = listener; }

    /** Returns the real-screen placeholder in this View's coordinates. */
    public void getScreenBounds(RectF out) {
        out.set(screenRect);
        out.offset(offsetX, offsetY);
        out.left = offsetX + screenRect.left * scale;
        out.top = offsetY + screenRect.top * scale;
        out.right = offsetX + screenRect.right * scale;
        out.bottom = offsetY + screenRect.bottom * scale;
    }

    private void buildHitboxes() {
        hitboxes.clear();
        // Soft keys and call/end row.
        add("SOFT_L", 31, 454, 97, 492); add("SOFT_R", 213, 454, 279, 492);
        add("MENU", 37, 494, 95, 526); add("CLEAR", 215, 494, 273, 526);
        add("CALL", 36, 526, 94, 578); add("END", 216, 526, 274, 578);
        // Four-way nav + centre OK.
        add("UP", 104, 405, 206, 454); add("DOWN", 104, 518, 206, 567);
        add("LEFT", 91, 442, 135, 508); add("RIGHT", 175, 442, 219, 508);
        add("OK", 135, 444, 175, 484);
        // T9 keypad: 3 columns x 4 rows.
        String[][] keys = {{"1","2","3"},{"4","5","6"},{"7","8","9"},{"*","0","#"}};
        float x0 = 18, y0 = 580, w = 91, h = 52, gapX = 4, gapY = 5;
        for (int row = 0; row < 4; row++) for (int col = 0; col < 3; col++) {
            float x = x0 + col * (w + gapX), y = y0 + row * (h + gapY);
            add(keys[row][col], x, y, x + w, y + h);
        }
    }

    private void add(String key, float l, float t, float rr, float b) {
        hitboxes.put(key, new RectF(l, t, rr, b)); pressed.put(key, false);
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int availableW = MeasureSpec.getSize(widthMeasureSpec);
        int desiredH = (int) (availableW * DESIGN_H / DESIGN_W + .5f);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        if (heightMode == MeasureSpec.EXACTLY) desiredH = heightSize;
        else if (heightMode == MeasureSpec.AT_MOST) desiredH = Math.min(desiredH, heightSize);
        setMeasuredDimension(availableW, desiredH);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float sx = getWidth() / DESIGN_W;
        float sy = getHeight() / DESIGN_H;
        scale = Math.min(sx, sy);
        offsetX = (getWidth() - DESIGN_W * scale) / 2f;
        offsetY = (getHeight() - DESIGN_H * scale) / 2f;
        canvas.save(); canvas.translate(offsetX, offsetY); canvas.scale(scale, scale);

        // Page background, matching the neutral HTML preview background.
        p.clearShadowLayer(); p.setShader(null); p.setColor(Color.rgb(233,235,237));
        canvas.drawColor(Color.rgb(233,235,237));

        // Metallic outer rim and body silhouette.
        roundGradient(canvas, 0, 0, 310, 792, 50, 54,
                new int[]{0xfffafafa,0xff7a7d80,0xffe4e6e8,0xff55585b,0xffc9cbcd}, true, 18, 0, 8, 0x66000000);
        roundGradient(canvas, 4, 4, 306, 788, 45, 50,
                new int[]{0xff2b2d30,0xff0d0e10,0xff17191b}, false, 0, 0, 0, 0);
        strokeRound(canvas, 5, 5, 305, 787, 44, 49, 0xff000000, 2f);
        // Inner top highlight.
        p.setShader(new LinearGradient(10, 5, 300, 80, 0x33ffffff, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(new RectF(6, 6, 304, 786), 43, 48, p); p.setShader(null);

        // Earpiece and camera.
        fillCircle(canvas, 125, 24, 4.5f, 0xff08090a);
        roundGradient(canvas, 137, 21, 191, 27, 3, 3, new int[]{0xff050607,0xff17191b}, false, 0,0,0,0);
        fillCircle(canvas, 111, 24, 4.5f, 0xff08090a);
        text(canvas, "NOKIA", 155, 57, 15, 0xffc8ccd0, true, Paint.Align.CENTER);

        // Glass frame and screen opening (native game surface goes here later).
        roundGradient(canvas, 26, 70, 284, 407, 10, 10,
                new int[]{0xff000000,0xff08090a,0xff000000}, false, 0,0,0,0);
        strokeRound(canvas, 27, 71, 283, 406, 9, 9, 0xff2a2d31, 1f);
        // screenRect = 37,85 .. 273,400; solid black placeholder, not a mock game image.
        p.setShader(null); p.setColor(Color.BLACK); canvas.drawRect(screenRect, p);

        // Key panel.
        roundGradient(canvas, 26, 414, 284, 788, 3, 3,
                new int[]{0xff131416,0xff0a0b0c}, false, 0,0,0,0);
        p.setShader(new LinearGradient(26, 414, 26, 470, 0x55000000, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawRect(26, 414, 284, 470, p); p.setShader(null);

        // Soft key bars and two small silver pill buttons.
        drawSoftKey(canvas, 31, 424, 97, 462, "SOFT_L");
        drawSoftKey(canvas, 213, 424, 279, 462, "SOFT_R");
        drawPill(canvas, 37, 466, 95, 482, "☰", "MENU");
        drawPill(canvas, 215, 466, 273, 482, "C", "CLEAR");
        drawCallButton(canvas, 65, 510, true, "CALL");
        drawCallButton(canvas, 245, 510, false, "END");
        drawDpad(canvas);
        drawKeypad(canvas);

        canvas.restore();
    }

    private void drawSoftKey(Canvas c, float l, float t, float rr, float b, String key) {
        boolean down = isPressed(key);
        roundGradient(c,l,t,rr,b,9,9,new int[]{0xfffbfbfc,0xffc4c7ca,0xff7d8185},true,0,0,2,0x99000000);
        p.setShader(null); p.setColor(0xff4aa3ff); p.setStrokeWidth(2); p.setStrokeCap(Paint.Cap.ROUND);
        float yy=(t+b)/2; c.drawLine(l+18,yy,rr-18,yy,p); p.setStrokeCap(Paint.Cap.BUTT);
        if(down){ p.setColor(0x55000000); c.drawRoundRect(new RectF(l,t,rr,b),9,9,p); }
    }

    private void drawPill(Canvas c, float l,float t,float rr,float b,String label,String key) {
        roundGradient(c,l,t,rr,b,8,8,new int[]{0xfffbfbfc,0xffc4c7ca,0xff7d8185},true,0,0,3,0xbb000000);
        text(c,label,(l+rr)/2,(t+b)/2+3,10,0xff222222,true,Paint.Align.CENTER);
        if(isPressed(key)){ p.setShader(null); p.setColor(0x55000000); c.drawRoundRect(new RectF(l,t,rr,b),8,8,p); }
    }

    private void drawCallButton(Canvas c,float cx,float cy,boolean call,String key) {
        // Grey metallic navigation/call key, with a small green/red handset glyph.
        float l=cx-29, t=cy-20, rr=cx+29, b=cy+20;
        roundGradient(c,l,t,rr,b,19,19,new int[]{0xfff2f3f4,0xff9da1a5,0xff55595d},true,0,0,4,0xaa000000);
        roundGradient(c,l+2,t+2,rr-2,b-2,17,17,new int[]{0xff32363b,0xff202329,0xff17191c},false,0,0,0,0);
        Path phone=new Path();
        phone.moveTo(cx-15,cy+1); phone.cubicTo(cx-8,cy-9,cx+8,cy-9,cx+15,cy+1);
        phone.lineTo(cx+11,cy+7); phone.lineTo(cx+4,cy+4); phone.lineTo(cx+4,cy-1);
        phone.cubicTo(cx,cy-3,cx,cy-3,cx-4,cy-1); phone.lineTo(cx-4,cy+4); phone.lineTo(cx-11,cy+7); phone.close();
        p.setShader(null); p.setColor(call?0xff2fb85a:0xffd8392f); c.drawPath(phone,p);
        if(isPressed(key)){ p.setColor(0x66000000); c.drawRoundRect(new RectF(l,t,rr,b),19,19,p); }
    }

    private void drawDpad(Canvas c) {
        // Four-way black navigation pad with silver perimeter and raised central OK.
        roundGradient(c,93,420,217,544,34,34,new int[]{0xfff4f4f4,0xff6c6f72,0xffd2d4d6},true,0,0,6,0xaa000000);
        roundGradient(c,99,426,211,538,29,29,new int[]{0xff2a2c2f,0xff08090a},false,0,0,0,0);
        drawTriangle(c,155,434,145,450,165,450,"UP");
        drawTriangle(c,155,530,145,514,165,514,"DOWN");
        drawTriangle(c,105,482,121,472,121,492,"LEFT");
        drawTriangle(c,205,482,189,472,189,492,"RIGHT");
        boolean down=isPressed("OK");
        roundGradient(c,135,462,175,502,20,20,down?new int[]{0xff101113,0xff050506}:new int[]{0xff3b3e42,0xff17181a,0xff09090a},true,0,0,4,0xcc000000);
        text(c,"OK",155,486,14,0xffd9dde1,true,Paint.Align.CENTER);
    }

    private void drawTriangle(Canvas c,float x1,float y1,float x2,float y2,float x3,float y3,String key) {
        Path path=new Path(); path.moveTo(x1,y1); path.lineTo(x2,y2); path.lineTo(x3,y3); path.close();
        p.setShader(null); p.setColor(isPressed(key)?0xffe7e9eb:0xff8a9096); c.drawPath(path,p);
    }

    private void drawKeypad(Canvas c) {
        String[][] nums={{"1","∞"},{"2","abc"},{"3","def"},{"4","ghi"},{"5","jkl"},{"6","mno"},{"7","pqrs"},{"8","tuv"},{"9","wxyz"},{"*","+"},{"0","␣"},{"#","⇧"}};
        float x0=18, y0=580, w=91, h=52, gx=4, gy=5;
        for(int i=0;i<12;i++){
            int row=i/3,col=i%3; float l=x0+col*(w+gx), t=y0+row*(h+gy), rr=l+w, b=t+h;
            String key=nums[i][0]; boolean down=isPressed(key);
            roundGradient(c,l,t,rr,b,18,18,down?new int[]{0xff0f1011,0xff1a1c1e}:new int[]{0xff34373b,0xff222528,0xff141618},true,0,0,2,0x99000000);
            // Fine top edge and subtle inset shading, mimicking the CSS multi-shadow.
            p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xff050607); c.drawRoundRect(new RectF(l+.5f,t+.5f,rr-.5f,b-.5f),18,18,p); p.setStyle(Paint.Style.FILL);
            if(col==0){ text(c,nums[i][0],l+29,t+32,25,0xffd9dde1,false,Paint.Align.CENTER); }
            else if(col==1){ text(c,nums[i][0],l+38,t+32,25,0xffd9dde1,false,Paint.Align.CENTER); }
            else { text(c,nums[i][0],rr-28,t+32,25,0xffd9dde1,false,Paint.Align.CENTER); }
            if(!nums[i][1].isEmpty()) {
                float tx = col==0? l+54 : col==1? l+63 : rr-12;
                text(c,nums[i][1],tx,t+30,10,0xff8c949c,false,Paint.Align.CENTER);
            }
        }
    }

    private boolean isPressed(String key) { Boolean v=pressed.get(key); return v!=null && v; }

    private void roundGradient(Canvas c,float l,float t,float rr,float b,float rx,float ry,int[] colors,boolean vertical,float shadowDx,float shadowDy,float shadowRadius,int shadowColor) {
        r.set(l,t,rr,b); p.setStyle(Paint.Style.FILL);
        if(shadowRadius>0 && shadowColor!=0) p.setShadowLayer(shadowRadius,shadowDx,shadowDy,shadowColor); else p.clearShadowLayer();
        if(colors.length==1) p.setShader(null); else p.setShader(vertical?new LinearGradient(l,t,l,b,colors,null,Shader.TileMode.CLAMP):new LinearGradient(l,t,rr,b,colors,null,Shader.TileMode.CLAMP));
        p.setColor(colors[0]); c.drawRoundRect(r,rx,ry,p); p.setShader(null); p.clearShadowLayer();
    }
    private void strokeRound(Canvas c,float l,float t,float rr,float b,float rx,float ry,int color,float width) {
        p.clearShadowLayer(); p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(width); p.setColor(color);
        c.drawRoundRect(new RectF(l,t,rr,b),rx,ry,p); p.setStyle(Paint.Style.FILL);
    }
    private void fillCircle(Canvas c,float x,float y,float radius,int color) { p.clearShadowLayer(); p.setShader(null); p.setColor(color); c.drawCircle(x,y,radius,p); }
    private void text(Canvas c,String s,float x,float baseline,float size,int color,boolean bold,Paint.Align align) {
        p.clearShadowLayer(); p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(bold?android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD):android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL));
        c.drawText(s,x,baseline,p);
    }

    private String keyAt(float x,float y) {
        float dx=(x-offsetX)/scale, dy=(y-offsetY)/scale;
        // Resolve central OK before directional sectors, then use declared hitboxes.
        RectF ok=hitboxes.get("OK"); if(ok!=null && ok.contains(dx,dy)) return "OK";
        for(Map.Entry<String,RectF> e:hitboxes.entrySet()) if(!"OK".equals(e.getKey()) && e.getValue().contains(dx,dy)) return e.getKey();
        return null;
    }

    private void setKey(String key,boolean down) {
        if(key==null) return;
        Boolean old=pressed.get(key); if(old!=null && old==down) return;
        pressed.put(key,down); invalidate();
        if(keyListener!=null) keyListener.onKey(key,down);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        float x=event.getX(), y=event.getY();
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                String next=keyAt(x,y); if(next!=null){ activeKey=next; setKey(activeKey,true); return true; } return true;
            case MotionEvent.ACTION_MOVE:
                if(activeKey!=null){ String now=keyAt(x,y); if(!activeKey.equals(now)){ setKey(activeKey,false); activeKey=now; if(activeKey!=null)setKey(activeKey,true); } }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                if(activeKey!=null) setKey(activeKey,false); activeKey=null; performClick(); return true;
        }
        return true;
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}
