package com.example.nokiac5;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Standalone Java/Android Canvas recreation of the supplied "Vỏ Nokia C5 đen.html".
 * Not wired into J2ME Loader yet. The black display rectangle is intentionally a slot
 * where a real CanvasView/GlesView can later be layered by the host Activity.
 *
 * Design coordinates follow the HTML's 310px-wide .chrome and CSS layout as closely
 * as practical. Call getScreenBounds(out) to obtain the display slot in this View's
 * local coordinates after layout.
 */
public class NokiaC5SkinView extends View {
    public interface KeyListener {
        void onKey(String key, boolean pressed);
    }

    private static final float DESIGN_W = 310f;
    // Based on the original CSS dimensions: chrome + top/logo/display/controls/keypad.
    private static final float DESIGN_H = 792f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF r = new RectF();
    private final RectF screenRect = new RectF(37, 84, 273, 399);
    private final Map<String, RectF> hitboxes = new LinkedHashMap<>();
    private final Map<String, Boolean> pressed = new LinkedHashMap<>();
    private KeyListener keyListener;
    private float scale = 1f, offsetX, offsetY;
    private String activeKey;

    public NokiaC5SkinView(Context context) { super(context); init(); }
    public NokiaC5SkinView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public NokiaC5SkinView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); init(); }

    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null); // CSS-like shadow layers are more consistent in software.
        setFocusable(true);
        setClickable(true);
        buildHitboxes();
    }

    public void setKeyListener(KeyListener listener) { keyListener = listener; }

    /** Returns the real-screen placeholder in this View's coordinates. */
    public void getScreenBounds(RectF out) {
        out.set(screenRect);
        out.offset(offsetX, offsetY);
        out.left = offsetX + screenRect.left * scale;
        out.top = offsetY + screenRect.top * scale;
        out.right = offsetX + screenRect.right * scale;
        out.bottom = offsetY + screenRect.bottom * scale;
    }

    private void buildHitboxes() {
        hitboxes.clear();
        add("SOFT_L", 26.5f, 429.7f, 92.5f, 467.7f); add("SOFT_R", 217.5f, 429.7f, 283.5f, 467.7f);
        add("MENU", 26.5f, 468.7f, 92.5f, 500.7f); add("CLEAR", 217.5f, 468.7f, 283.5f, 500.7f);
        add("CALL", 30.5f, 502.7f, 88.5f, 552.7f); add("END", 221.5f, 502.7f, 279.5f, 552.7f);
        // D-pad (UP/DOWN/LEFT/RIGHT/OK) is resolved by geometry in keyAt(). Number keypad removed for now.
    }

    private void add(String key, float l, float t, float rr, float b) {
        hitboxes.put(key, new RectF(l, t, rr, b)); pressed.put(key, false);
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int availableW = MeasureSpec.getSize(widthMeasureSpec);
        int desiredH = (int) (availableW * DESIGN_H / DESIGN_W + .5f);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        if (heightMode == MeasureSpec.EXACTLY) desiredH = heightSize;
        else if (heightMode == MeasureSpec.AT_MOST) desiredH = Math.min(desiredH, heightSize);
        setMeasuredDimension(availableW, desiredH);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float sx = getWidth() / DESIGN_W;
        float sy = getHeight() / DESIGN_H;
        scale = Math.min(sx, sy);
        offsetX = (getWidth() - DESIGN_W * scale) / 2f;
        offsetY = (getHeight() - DESIGN_H * scale) / 2f;
        canvas.save(); canvas.translate(offsetX, offsetY); canvas.scale(scale, scale);

        // Page background, matching the neutral HTML preview background.
        p.clearShadowLayer(); p.setShader(null); p.setColor(Color.rgb(233,235,237));
        canvas.drawColor(Color.rgb(233,235,237));

        // Metallic outer rim and body silhouette.
        roundGradient(canvas, 0, 0, 310, 792, 50, 54,
                new int[]{0xfffafafa,0xff7a7d80,0xffe4e6e8,0xff55585b,0xffc9cbcd}, true, 18, 0, 8, 0x66000000);
        roundGradient(canvas, 4, 4, 306, 788, 45, 50,
                new int[]{0xff2b2d30,0xff0d0e10,0xff17191b}, false, 0, 0, 0, 0);
        strokeRound(canvas, 5, 5, 305, 787, 44, 49, 0xff000000, 2f);
        // Inner top highlight.
        p.setShader(new LinearGradient(10, 5, 300, 80, 0x33ffffff, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(new RectF(6, 6, 304, 786), 43, 48, p); p.setShader(null);

        // Earpiece and camera.
        fillCircle(canvas, 120, 32, 4.5f, 0xff08090a);
        roundGradient(canvas, 140.5f, 29, 194.5f, 35, 3, 3, new int[]{0xff050607,0xff17191b}, false, 0,0,0,0);
        text(canvas, "NOKIA", 155, 62, 15, 0xffc8ccd0, true, Paint.Align.CENTER);

        // Glass frame and screen opening (native game surface goes here later).
        roundGradient(canvas, 26, 73, 284, 410, 10, 10,
                new int[]{0xff000000,0xff08090a,0xff000000}, false, 0,0,0,0);
        strokeRound(canvas, 27, 74, 283, 409, 9, 9, 0xff2a2d31, 1f);
        // screenRect = 37,85 .. 273,400; solid black placeholder, not a mock game image.
        p.setShader(null); p.setColor(Color.BLACK); canvas.drawRect(screenRect, p);

        // Key panel, clipped to the body silhouette (overflow:hidden in the HTML).
        canvas.save(); Path clip = new Path(); clip.addRoundRect(new RectF(4, 4, 306, 788), 43, 49, Path.Direction.CW); canvas.clipPath(clip);
        roundGradient(canvas, 4, 424, 306, 788, 0, 0, new int[]{0xff131416,0xff0a0b0c}, true, 0,0,0,0);
        p.setShader(new LinearGradient(4, 424, 4, 440, 0xb3000000, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawRect(4, 424, 306, 440, p); p.setShader(null);
        canvas.restore();

        drawSoftKey(canvas, 26.5f, 429.7f, 92.5f, 467.7f, "SOFT_L");
        drawSoftKey(canvas, 217.5f, 429.7f, 283.5f, 467.7f, "SOFT_R");
        drawPill(canvas, 30.5f, 476.7f, 88.5f, 492.7f, "\u2630", "MENU");
        drawPill(canvas, 221.5f, 476.7f, 279.5f, 492.7f, "C", "CLEAR");
        drawCallButton(canvas, 59.5f, 527.7f, true, "CALL");
        drawCallButton(canvas, 250.5f, 527.7f, false, "END");
        drawDpad(canvas);

        canvas.restore();
    }

    private void drawSoftKey(Canvas c, float l, float t, float rr, float b, String key) {
        // HTML .sk is transparent: only a 40x2 blue glow line at (13,12).
        p.setStyle(Paint.Style.FILL); p.setShader(null);
        p.setColor(isPressed(key) ? 0xff8cc8ff : 0xff4aa3ff); p.setShadowLayer(6, 0, 0, 0xff4aa3ff);
        c.drawRoundRect(new RectF(l + 13, t + 12, l + 53, t + 14), 1, 1, p); p.clearShadowLayer();
    }

    private void drawPill(Canvas c, float l,float t,float rr,float b,String label,String key) {
        roundGradient(c,l,t,rr,b,8,8,new int[]{0xfffbfbfc,0xffc4c7ca,0xff7d8185},true,0,0,3,0xbb000000);
        text(c,label,(l+rr)/2,(t+b)/2+3,10,0xff222222,true,Paint.Align.CENTER);
        if(isPressed(key)){ p.setShader(null); p.setColor(0x55000000); c.drawRoundRect(new RectF(l,t,rr,b),8,8,p); }
    }

    private void drawCallButton(Canvas c,float cx,float cy,boolean call,String key) {
        // HTML .hs is transparent: only the 34x23 SVG handset (viewBox 30x20) with drop shadow.
        Path ph=new Path();
        ph.moveTo(3,12); ph.cubicTo(9,4,21,4,27,12); ph.lineTo(25,16); ph.lineTo(19,14); ph.lineTo(19,10);
        ph.cubicTo(16,9,14,9,11,10); ph.lineTo(11,14); ph.lineTo(5,16); ph.close();
        android.graphics.Matrix m=new android.graphics.Matrix(); m.postScale(34f/30f,34f/30f);
        m.postTranslate(cx-17, cy-11.33f+(isPressed(key)?1:0)); ph.transform(m);
        p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(call?0xff2fb85a:0xffd8392f);
        if(!isPressed(key)) p.setShadowLayer(2,0,2,0xd9000000);
        c.drawPath(ph,p); p.clearShadowLayer();
    }

    private void drawDpad(Canvas c) {
        // .navwrap 93,429.7..217,553.7 ; .navin 99,435.7..211,547.7 ; .ok circle r=26 at (155,491.7)
        roundGradient(c,93,429.7f,217,553.7f,34,34,new int[]{0xfff4f4f4,0xff6c6f72,0xffd2d4d6},true,0,6,10,0xbf000000);
        roundGradient(c,99,435.7f,211,547.7f,28,28,new int[]{0xff2a2c2f,0xff08090a},false,0,0,0,0);
        // Direction zones are invisible in the HTML; only a 14% white wedge shows while pressed.
        float ox=99, oy=435.7f;
        if(isPressed("UP")) wedge(c,ox,oy,ox+112,oy,ox+56,oy+56);
        if(isPressed("DOWN")) wedge(c,ox,oy+112,ox+112,oy+112,ox+56,oy+56);
        if(isPressed("LEFT")) wedge(c,ox,oy,ox,oy+112,ox+56,oy+56);
        if(isPressed("RIGHT")) wedge(c,ox+112,oy,ox+112,oy+112,ox+56,oy+56);
        boolean down=isPressed("OK");
        roundGradient(c,129,465.7f,181,517.7f,26,26,down?new int[]{0xff101113,0xff050506}:new int[]{0xff3b3e42,0xff17181a,0xff09090a},true,0,down?1:4,down?2:6,0xe6000000);
    }

    private void wedge(Canvas c,float x1,float y1,float x2,float y2,float x3,float y3) {
        Path path=new Path(); path.moveTo(x1,y1); path.lineTo(x2,y2); path.lineTo(x3,y3); path.close();
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(0x24ffffff); c.drawPath(path,p);
    }

    private boolean isPressed(String key) { Boolean v=pressed.get(key); return v!=null && v; }

    private void roundGradient(Canvas c,float l,float t,float rr,float b,float rx,float ry,int[] colors,boolean vertical,float shadowDx,float shadowDy,float shadowRadius,int shadowColor) {
        r.set(l,t,rr,b); p.setStyle(Paint.Style.FILL);
        if(shadowRadius>0 && shadowColor!=0) p.setShadowLayer(shadowRadius,shadowDx,shadowDy,shadowColor); else p.clearShadowLayer();
        if(colors.length==1) p.setShader(null); else p.setShader(vertical?new LinearGradient(l,t,l,b,colors,null,Shader.TileMode.CLAMP):new LinearGradient(l,t,rr,b,colors,null,Shader.TileMode.CLAMP));
        p.setColor(colors[0]); c.drawRoundRect(r,rx,ry,p); p.setShader(null); p.clearShadowLayer();
    }
    private void strokeRound(Canvas c,float l,float t,float rr,float b,float rx,float ry,int color,float width) {
        p.clearShadowLayer(); p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(width); p.setColor(color);
        c.drawRoundRect(new RectF(l,t,rr,b),rx,ry,p); p.setStyle(Paint.Style.FILL);
    }
    private void fillCircle(Canvas c,float x,float y,float radius,int color) { p.clearShadowLayer(); p.setShader(null); p.setColor(color); c.drawCircle(x,y,radius,p); }
    private void text(Canvas c,String s,float x,float baseline,float size,int color,boolean bold,Paint.Align align) {
        p.clearShadowLayer(); p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(bold?android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD):android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL));
        c.drawText(s,x,baseline,p);
    }

    private String keyAt(float x,float y) {
        float dx=(x-offsetX)/scale, dy=(y-offsetY)/scale;
        if(dx>=99 && dx<=211 && dy>=435.7f && dy<=547.7f) {
            float ox=dx-155, oy=dy-491.7f;
            if(ox*ox+oy*oy<=26*26) return "OK";
            return Math.abs(ox)>Math.abs(oy) ? (ox<0?"LEFT":"RIGHT") : (oy<0?"UP":"DOWN");
        }
        for(Map.Entry<String,RectF> e:hitboxes.entrySet()) if(e.getValue().contains(dx,dy)) return e.getKey();
        return null;
    }

    private void setKey(String key,boolean down) {
        if(key==null) return;
        Boolean old=pressed.get(key); if(old!=null && old==down) return;
        pressed.put(key,down); invalidate();
        if(keyListener!=null) keyListener.onKey(key,down);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        float x=event.getX(), y=event.getY();
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                String next=keyAt(x,y); if(next!=null){ activeKey=next; setKey(activeKey,true); return true; } return true;
            case MotionEvent.ACTION_MOVE:
                if(activeKey!=null){ String now=keyAt(x,y); if(!activeKey.equals(now)){ setKey(activeKey,false); activeKey=now; if(activeKey!=null)setKey(activeKey,true); } }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                if(activeKey!=null) setKey(activeKey,false); activeKey=null; performClick(); return true;
        }
        return true;
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}
