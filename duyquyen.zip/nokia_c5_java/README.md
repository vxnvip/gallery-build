# Nokia C5 Java Canvas prototype

Android Studio/Gradle project for rendering the Nokia C5 shell using `NokiaC5SkinView`.

- Java 17, Android Gradle Plugin 8.6.1, Gradle 8.10.2, compile SDK 35.
- GitHub Actions workflow: `.github/workflows/build.yml` (`Build APK` → `Run workflow`).
- Configure repository secret `DEBUG_KEYSTORE_B64` with the Base64 content of the fixed debug keystore. It must use password `android`, alias `androiddebugkey`, and its certificate SHA-256 must contain the expected prefix `322a8179607bd784` for the workflow verification to pass.
- The APK is a runnable visual prototype only. The screen is still a black placeholder; J2ME Loader game rendering and key event integration are not included yet.

Original standalone source is retained at the project root; the Android app source is under `app/src/main/java/com/example/nokiac5/`.
