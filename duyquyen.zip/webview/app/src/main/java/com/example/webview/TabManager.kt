package com.example.webview

import android.content.Context
import android.app.Presentation
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.view.ViewGroup
import android.view.InputDevice
import android.view.MotionEvent
import android.os.SystemClock
import kotlin.random.Random
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** Giữ các WebView "tab" chạy nền, mỗi tab 1 profile riêng (cookie/localStorage/cache tách hẳn). */
object TabManager {
    class Tab(
        val id: String, val profile: String, val web: WebView,
        val w: Int, val h: Int,
        val vd: VirtualDisplay, val pres: Presentation, val reader: ImageReader
    ) {
        @Volatile var latch: CountDownLatch? = null
        @Volatile var shotLatch: CountDownLatch? = null
        @Volatile var shot: Bitmap? = null
    }

    private lateinit var app: Context
    private val tabs = ConcurrentHashMap<String, Tab>()
    private val ui by lazy { Handler(Looper.getMainLooper()) }
    private val ID_RE = Regex("^[A-Za-z0-9_]{1,32}$")

    fun init(c: Context) { app = c.applicationContext }

    /** Chạy block trên main thread và chờ kết quả (gọi từ thread HTTP). */
    private fun <T> onUi(timeoutMs: Long = 10_000, block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val latch = CountDownLatch(1)
        var out: Any? = null
        var err: Throwable? = null
        ui.post {
            try { out = block() } catch (e: Throwable) { err = e }
            latch.countDown()
        }
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) throw TimeoutException("UI thread bận")
        err?.let { throw it }
        @Suppress("UNCHECKED_CAST")
        return out as T
    }

    private fun get(id: String): Tab =
        tabs[id] ?: throw NoSuchElementException("Không có tab '$id' (gọi /open trước)")

    /** Mỗi tab chạy trong 1 màn hình ảo riêng (VirtualDisplay + Presentation) nên WebView thật sự được vẽ/hiển thị. */
    private fun create(id: String, account: String?, w: Int, h: Int): Tab {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE))
            throw IllegalStateException("WebView chưa hỗ trợ MULTI_PROFILE, cập nhật Android System WebView")
        val profile = if (account != null) {
            Store.all(app).firstOrNull { it.name.equals(account, true) }?.profileId
                ?: throw NoSuchElementException("Chưa lưu tài khoản '$account' trong app")
        } else "api_$id"

        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        val dm = app.getSystemService(DisplayManager::class.java)
        val vd = dm.createVirtualDisplay(
            "tab_$id", w, h, 160, reader.surface,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        )
        val pres = Presentation(app, vd.display)
        val web = WebView(pres.context)
        WebConfig.apply(web, profile)
        pres.setContentView(web, ViewGroup.LayoutParams(-1, -1))
        pres.show()

        val tab = Tab(id, profile, web, w, h, vd, pres, reader)
        web.webViewClient = object : SpoofClient(profile) {
            override fun onPageFinished(view: WebView, url: String?) { tab.latch?.countDown() }
        }
        reader.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (_: Throwable) { null } ?: return@setOnImageAvailableListener
            try {
                val want = tab.shotLatch
                if (want != null) {
                    val pl = img.planes[0]
                    val rowPx = pl.rowStride / pl.pixelStride
                    val full = Bitmap.createBitmap(rowPx, img.height, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(pl.buffer)
                    tab.shot = if (rowPx != img.width) Bitmap.createBitmap(full, 0, 0, img.width, img.height).also { full.recycle() } else full
                    tab.shotLatch = null
                    want.countDown()
                }
            } catch (_: Throwable) {
            } finally { img.close() }
        }, ui)
        web.onResume()
        web.resumeTimers()
        tabs[id] = tab
        return tab
    }

    private fun checkId(id: String) {
        require(ID_RE.matches(id)) { "id chỉ gồm chữ/số/_ (tối đa 32 ký tự)" }
    }

    private fun infoOf(t: Tab): JSONObject = onUi {
        JSONObject().put("id", t.id).put("profile", t.profile)
            .put("url", t.web.url ?: JSONObject.NULL)
            .put("title", t.web.title ?: JSONObject.NULL)
            .put("progress", t.web.progress)
    }

    private fun navigate(t: Tab, url: String, wait: Boolean, timeoutMs: Long): Boolean {
        require(url.startsWith("http://") || url.startsWith("https://")) { "url phải bắt đầu bằng http(s)://" }
        val latch = CountDownLatch(1)
        t.latch = latch
        onUi { t.web.loadUrl(url) }
        return if (wait) latch.await(timeoutMs, TimeUnit.MILLISECONDS) else true
    }

    fun open(id: String, account: String?, url: String?, wait: Boolean, timeoutMs: Long, w: Int = 1280, h: Int = 800): JSONObject {
        checkId(id)
        val t = tabs[id] ?: onUi { tabs[id] ?: create(id, account, w.coerceIn(200, 4000), h.coerceIn(200, 4000)) }
        val loaded = if (url != null) navigate(t, url, wait, timeoutMs) else true
        return infoOf(t).put("loaded", loaded)
    }

    fun goto(id: String, url: String, wait: Boolean, timeoutMs: Long): JSONObject {
        val t = get(id)
        val loaded = navigate(t, url, wait, timeoutMs)
        return infoOf(t).put("loaded", loaded)
    }

    fun js(id: String, code: String, timeoutMs: Long): Any {
        val t = get(id)
        val latch = CountDownLatch(1)
        val res = arrayOfNulls<String>(1)
        ui.post { t.web.evaluateJavascript(code) { res[0] = it; latch.countDown() } }
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) throw TimeoutException("JS timeout")
        val raw = res[0] ?: "null"
        return try { JSONTokener(raw).nextValue() } catch (_: Exception) { raw }
    }


    private fun touch(web: WebView, action: Int, downTime: Long, x: Float, y: Float) {
        val ev = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, x, y, 1f, 1f, 0, 1f, 1f, 0, 0)
        ev.source = InputDevice.SOURCE_TOUCHSCREEN
        try { web.dispatchTouchEvent(ev) } finally { ev.recycle() }
    }

    /**
     * Bấm bằng MotionEvent thật (touchscreen) đưa thẳng vào WebView => trình duyệt sinh
     * sự kiện isTrusted=true, khác hẳn element.click()/dispatchEvent bằng JS.
     * x,y: pixel trong tab (cùng hệ tọa độ với /screenshot).
     * hold: ms giữ ngón (0 = ngẫu nhiên 40-110). jitter: lệch ngẫu nhiên ±px. count: số lần bấm (2 = double tap).
     */
    fun click(id: String, x: Float, y: Float, hold: Long, jitter: Float, count: Int): JSONObject {
        val t = get(id)
        require(x >= 0f && y >= 0f && x < t.w && y < t.h) { "tọa độ ngoài tab (${t.w}x${t.h})" }
        val n = count.coerceIn(1, 5)
        var lastX = x; var lastY = y
        repeat(n) { i ->
            val j = jitter.coerceIn(0f, 20f)
            val px = (x + if (j > 0f) Random.nextFloat() * 2 * j - j else 0f).coerceIn(0f, t.w - 1f)
            val py = (y + if (j > 0f) Random.nextFloat() * 2 * j - j else 0f).coerceIn(0f, t.h - 1f)
            lastX = px; lastY = py
            val h = if (hold > 0) hold.coerceAtMost(5000) else Random.nextLong(40, 110)
            val down = SystemClock.uptimeMillis()
            onUi { t.web.requestFocus(); touch(t.web, MotionEvent.ACTION_DOWN, down, px, py) }
            if (h > 70) {   // ngón tay thật hơi rung khi giữ lâu
                Thread.sleep(h / 2)
                onUi { touch(t.web, MotionEvent.ACTION_MOVE, down, px + Random.nextFloat() - 0.5f, py + Random.nextFloat() - 0.5f) }
                Thread.sleep(h - h / 2)
            } else Thread.sleep(h)
            onUi { touch(t.web, MotionEvent.ACTION_UP, down, px, py) }
            if (i < n - 1) Thread.sleep(Random.nextLong(60, 130))
        }
        return JSONObject().put("x", lastX.toDouble()).put("y", lastY.toDouble()).put("count", n)
    }

    fun info(id: String) = infoOf(get(id))

    /** Chụp tab -> PNG base64 (lấy frame mới nhất từ màn hình ảo). */
    fun screenshot(id: String): JSONObject {
        val t = get(id)
        val latch = CountDownLatch(1)
        t.shot = null
        t.shotLatch = latch
        onUi { t.web.invalidate() }   // ép vẽ lại để có frame mới
        if (!latch.await(5_000, TimeUnit.MILLISECONDS)) { t.shotLatch = null; throw TimeoutException("Không có frame để chụp") }
        val bmp = t.shot ?: throw IllegalStateException("Ảnh rỗng")
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
        return JSONObject().put("width", bmp.width).put("height", bmp.height).put("format", "png")
            .put("data", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
    }

    fun cookies(id: String, url: String): String {
        val t = get(id)
        return onUi {
            ProfileStore.getInstance().getOrCreateProfile(t.profile).cookieManager.getCookie(url) ?: ""
        }
    }

    fun close(id: String) {
        val t = tabs.remove(id) ?: throw NoSuchElementException("Không có tab '$id'")
        onUi { release(t) }
    }

    private fun release(t: Tab) {
        try { t.web.stopLoading() } catch (_: Throwable) {}
        try { t.pres.dismiss() } catch (_: Throwable) {}
        try { t.web.destroy() } catch (_: Throwable) {}
        try { t.vd.release() } catch (_: Throwable) {}
        try { t.reader.close() } catch (_: Throwable) {}
    }

    fun list(): JSONArray {
        val a = JSONArray()
        tabs.values.forEach { a.put(infoOf(it)) }
        return a
    }

    fun closeAll() {
        val all = tabs.values.toList()
        tabs.clear()
        ui.post { all.forEach { try { release(it) } catch (_: Throwable) {} } }
    }
}
