package com.example.webview

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.view.View.MeasureSpec
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** Giữ các WebView "tab" chạy nền, mỗi tab 1 profile riêng (cookie/localStorage/cache tách hẳn). */
object TabManager {
    class Tab(val id: String, val profile: String, val web: WebView) {
        @Volatile var latch: CountDownLatch? = null
    }

    private lateinit var app: Context
    private val tabs = ConcurrentHashMap<String, Tab>()
    private val ui by lazy { Handler(Looper.getMainLooper()) }
    private val ID_RE = Regex("^[A-Za-z0-9_]{1,32}$")

    fun init(c: Context) { app = c.applicationContext }

    /** Chạy block trên main thread và chờ kết quả (gọi từ thread HTTP). */
    private fun <T> onUi(timeoutMs: Long = 10_000, block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val latch = CountDownLatch(1)
        var out: Any? = null
        var err: Throwable? = null
        ui.post {
            try { out = block() } catch (e: Throwable) { err = e }
            latch.countDown()
        }
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) throw TimeoutException("UI thread bận")
        err?.let { throw it }
        @Suppress("UNCHECKED_CAST")
        return out as T
    }

    private fun get(id: String): Tab =
        tabs[id] ?: throw NoSuchElementException("Không có tab '$id' (gọi /open trước)")

    private fun create(id: String, account: String?): Tab {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE))
            throw IllegalStateException("WebView chưa hỗ trợ MULTI_PROFILE, cập nhật Android System WebView")
        val profile = if (account != null) {
            Store.all(app).firstOrNull { it.name.equals(account, true) }?.profileId
                ?: throw NoSuchElementException("Chưa lưu tài khoản '$account' trong app")
        } else "api_$id"

        val web = WebView(app)
        WebConfig.apply(web, profile)
        val tab = Tab(id, profile, web)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) { tab.latch?.countDown() }
        }
        // Không gắn vào màn hình: tự layout cỡ desktop để trang có kích thước thật
        web.measure(
            MeasureSpec.makeMeasureSpec(1280, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(800, MeasureSpec.EXACTLY)
        )
        web.layout(0, 0, 1280, 800)
        web.onResume()
        web.resumeTimers()
        tabs[id] = tab
        return tab
    }

    private fun checkId(id: String) {
        require(ID_RE.matches(id)) { "id chỉ gồm chữ/số/_ (tối đa 32 ký tự)" }
    }

    private fun infoOf(t: Tab): JSONObject = onUi {
        JSONObject().put("id", t.id).put("profile", t.profile)
            .put("url", t.web.url ?: JSONObject.NULL)
            .put("title", t.web.title ?: JSONObject.NULL)
            .put("progress", t.web.progress)
    }

    private fun navigate(t: Tab, url: String, wait: Boolean, timeoutMs: Long): Boolean {
        require(url.startsWith("http://") || url.startsWith("https://")) { "url phải bắt đầu bằng http(s)://" }
        val latch = CountDownLatch(1)
        t.latch = latch
        onUi { t.web.loadUrl(url) }
        return if (wait) latch.await(timeoutMs, TimeUnit.MILLISECONDS) else true
    }

    fun open(id: String, account: String?, url: String?, wait: Boolean, timeoutMs: Long): JSONObject {
        checkId(id)
        val t = tabs[id] ?: onUi { tabs[id] ?: create(id, account) }
        val loaded = if (url != null) navigate(t, url, wait, timeoutMs) else true
        return infoOf(t).put("loaded", loaded)
    }

    fun goto(id: String, url: String, wait: Boolean, timeoutMs: Long): JSONObject {
        val t = get(id)
        val loaded = navigate(t, url, wait, timeoutMs)
        return infoOf(t).put("loaded", loaded)
    }

    fun js(id: String, code: String, timeoutMs: Long): Any {
        val t = get(id)
        val latch = CountDownLatch(1)
        val res = arrayOfNulls<String>(1)
        ui.post { t.web.evaluateJavascript(code) { res[0] = it; latch.countDown() } }
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) throw TimeoutException("JS timeout")
        val raw = res[0] ?: "null"
        return try { JSONTokener(raw).nextValue() } catch (_: Exception) { raw }
    }

    fun info(id: String) = infoOf(get(id))

    /** Chụp WebView (cỡ tab, mặc định 1280x800) -> PNG base64. */
    fun screenshot(id: String): JSONObject {
        val t = get(id)
        return onUi(15_000) {
            val w = t.web.width.coerceAtLeast(1)
            val h = t.web.height.coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            t.web.draw(Canvas(bmp))
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            bmp.recycle()
            JSONObject().put("width", w).put("height", h).put("format", "png")
                .put("data", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
        }
    }

    fun cookies(id: String, url: String): String {
        val t = get(id)
        return onUi {
            ProfileStore.getInstance().getOrCreateProfile(t.profile).cookieManager.getCookie(url) ?: ""
        }
    }

    fun close(id: String) {
        val t = tabs.remove(id) ?: throw NoSuchElementException("Không có tab '$id'")
        onUi { t.web.stopLoading(); t.web.destroy() }
    }

    fun list(): JSONArray {
        val a = JSONArray()
        tabs.values.forEach { a.put(infoOf(it)) }
        return a
    }

    fun closeAll() {
        val all = tabs.values.toList()
        tabs.clear()
        ui.post { all.forEach { try { it.web.destroy() } catch (_: Throwable) {} } }
    }
}
