package com.example.webview

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.widget.Toast
import androidx.core.app.ServiceCompat

class ApiService : Service() {
    companion object { const val PORT = 8765 }
    private var server: ApiServer? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        TabManager.init(applicationContext)
        val ch = "api"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "API local", NotificationManager.IMPORTANCE_LOW))
        }
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        val n = nb.setContentTitle("Golike Multi")
            .setContentText("API 127.0.0.1:$PORT đang chạy")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "webview:api").apply { setReferenceCounted(false); acquire() }
        try {
            server = ApiServer(applicationContext, PORT) { Store.token(applicationContext) }.also { it.start() }
        } catch (e: Exception) {
            Toast.makeText(this, "Không mở được port $PORT: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        server?.stop()
        try { wl?.takeIf { it.isHeld }?.release() } catch (_: Throwable) {}
        TabManager.closeAll()
        super.onDestroy()
    }
}
