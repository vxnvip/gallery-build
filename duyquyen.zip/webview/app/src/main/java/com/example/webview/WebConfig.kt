package com.example.webview

import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.ProfileStore
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.net.HttpURLConnection
import java.net.URL

/** Cấu hình chung cho mọi WebView (cả WebActivity lẫn tab điều khiển từ Termux). Giống GolikeMulti-14. */
object WebConfig {
    const val UA = "Mozilla/5.0 (Linux; iPhone; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/115.0.0.0 Mobile Safari/537.36"

    /** Gọi ngay sau khi tạo WebView, TRƯỚC mọi lệnh khác (setProfile yêu cầu vậy). */
    fun apply(web: WebView, profile: String) {
        ProfileStore.getInstance().getOrCreateProfile(profile)
        WebViewCompat.setProfile(web, profile)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA

        // sec-ch-ua-platform = "iOS" cho MỌI request (kể cả POST)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
            try {
                fun bv(b: String, v: String) = UserAgentMetadata.BrandVersion.Builder()
                    .setBrand(b).setMajorVersion(v).setFullVersion("$v.0.0.0").build()
                val md = UserAgentMetadata.Builder()
                    .setBrandVersionList(listOf(bv("Android WebView", "153"), bv("Not_A Brand", "8"), bv("Chromium", "153")))
                    .setFullVersion("153.0.0.0")
                    .setPlatform("iOS")
                    .setMobile(true)
                    .build()
                WebSettingsCompat.setUserAgentMetadata(web.settings, md)
            } catch (_: Throwable) { }
        }
    }
}

/** WebViewClient tự gửi lại request GET để đổi sec-ch-ua-platform thành "iOS" (y hệt GolikeMulti-14). */
open class SpoofClient(profile: String) : WebViewClient() {
    private val cm: CookieManager = ProfileStore.getInstance().getOrCreateProfile(profile).cookieManager

    override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
        val url = req.url.toString()
        if (req.method != "GET" || !url.startsWith("http")) return null
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "GET"
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = !req.isForMainFrame
            req.requestHeaders.forEach { (k, v) ->
                if (k.equals("sec-ch-ua-platform", true)) {
                    c.setRequestProperty(k, "\"iOS\"")
                } else if (
                    !k.equals("Accept-Encoding", true) &&
                    !k.equals("User-Agent", true) &&
                    !k.equals("Cookie", true)) c.setRequestProperty(k, v)
            }
            c.setRequestProperty("User-Agent", WebConfig.UA)
            cm.getCookie(url)?.let { c.setRequestProperty("Cookie", it) }

            val code = c.responseCode
            c.headerFields["Set-Cookie"]?.forEach { cm.setCookie(url, it) }
            // redirect trang chính: để WebView tự xử lý để URL đổi đúng
            if (code in 300..399) { c.disconnect(); return null }

            val ct = c.contentType ?: "text/html"
            val mime = ct.substringBefore(';').trim()
            val enc = Regex("charset=([^;]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)?.trim()
            val hdr = mutableMapOf<String, String>()
            c.headerFields.forEach { (k, v) ->
                if (k != null && !k.equals("Set-Cookie", true) &&
                    !k.equals("Content-Encoding", true) &&
                    !k.equals("Content-Length", true) &&
                    !k.equals("Transfer-Encoding", true)) hdr[k] = v.joinToString(",")
            }
            val stream = if (code >= 400) c.errorStream else c.inputStream
            WebResourceResponse(mime, enc, code, c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK", hdr, stream)
        } catch (e: Exception) { null }
    }
}
