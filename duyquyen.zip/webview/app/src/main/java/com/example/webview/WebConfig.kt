package com.example.webview

import android.webkit.WebView
import androidx.webkit.ProfileStore
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/** Cấu hình chung cho mọi WebView (cả WebActivity lẫn tab điều khiển từ Termux). */
object WebConfig {
    private const val MAJOR = "139"

    const val UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/$MAJOR.0.0.0 Safari/537.36"

    /** Gọi ngay sau khi tạo WebView, TRƯỚC mọi lệnh khác (setProfile yêu cầu vậy). */
    fun apply(web: WebView, profile: String) {
        ProfileStore.getInstance().getOrCreateProfile(profile)
        WebViewCompat.setProfile(web, profile)

        val m = MAJOR
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = UA
            useWideViewPort = true          // render như trang desktop
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }

        // sec-ch-ua-* cho MỌI request (kể cả POST) -> khớp UA Linux
        if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
            try {
                fun bv(b: String, v: String) = UserAgentMetadata.BrandVersion.Builder()
                    .setBrand(b).setMajorVersion(v).setFullVersion("$v.0.0.0").build()
                val md = UserAgentMetadata.Builder()
                    .setBrandVersionList(listOf(bv("Chromium", m), bv("Google Chrome", m), bv("Not_A Brand", "8")))
                    .setFullVersion("$m.0.0.0")
                    .setPlatform("Linux")
                    .setPlatformVersion("6.5.0")
                    .setArchitecture("x86")
                    .setBitness(64)
                    .setModel("")
                    .setMobile(false)
                    .build()
                WebSettingsCompat.setUserAgentMetadata(web.settings, md)
            } catch (_: Throwable) { }
        }
    }
}
