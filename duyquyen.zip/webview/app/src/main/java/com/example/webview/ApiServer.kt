package com.example.webview

import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.InputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.TimeoutException
import kotlin.concurrent.thread

/** HTTP/JSON server tối giản, chỉ bind 127.0.0.1, bắt buộc header X-Token. */
class ApiServer(private val ctx: android.content.Context, private val port: Int, private val token: () -> String) {
    private var ss: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        val s = ServerSocket(port, 16, InetAddress.getByName("127.0.0.1"))
        ss = s
        thread(isDaemon = true, name = "api-accept") {
            while (!s.isClosed) {
                try { val c = s.accept(); pool.execute { handle(c) } } catch (_: Exception) { }
            }
        }
    }

    fun stop() { try { ss?.close() } catch (_: Exception) {}; pool.shutdownNow() }

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
            if (sb.length > 8192) return null
        }
    }

    private fun handle(sock: Socket) {
        sock.use {
            sock.soTimeout = 30_000
            val inp = BufferedInputStream(sock.getInputStream())
            val first = readLine(inp) ?: return
            val parts = first.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val path = parts[1].substringBefore('?')
            var len = 0
            var tok = ""
            while (true) {
                val h = readLine(inp) ?: break
                if (h.isEmpty()) break
                val i = h.indexOf(':')
                if (i > 0) {
                    val k = h.substring(0, i).trim().lowercase()
                    val v = h.substring(i + 1).trim()
                    if (k == "content-length") len = v.toIntOrNull() ?: 0
                    if (k == "x-token") tok = v
                }
            }
            if (!MessageDigest.isEqual(tok.toByteArray(), token().toByteArray())) {
                send(sock, 401, err("token sai hoặc thiếu (header X-Token)")); return
            }
            if (len > 1_000_000) { send(sock, 413, err("body quá lớn")); return }
            val buf = ByteArray(len)
            var off = 0
            while (off < len) {
                val n = inp.read(buf, off, len - off)
                if (n < 0) break
                off += n
            }
            val (code, out) = try {
                val body = if (len > 0) JSONObject(String(buf, Charsets.UTF_8)) else JSONObject()
                route(method, path, body)
            } catch (e: JSONException) { 400 to err("JSON lỗi: ${e.message}") }
            catch (e: IllegalArgumentException) { 400 to err(e.message) }
            catch (e: NoSuchElementException) { 404 to err(e.message) }
            catch (e: TimeoutException) { 504 to err(e.message) }
            catch (e: Exception) { 500 to err(e.message ?: e.javaClass.simpleName) }
            send(sock, code, out)
        }
    }

    private fun err(m: String?) = JSONObject().put("ok", false).put("error", m ?: "lỗi")
    private fun ok() = JSONObject().put("ok", true)

    private fun JSONObject.str(k: String): String {
        val v = optString(k, "")
        require(v.isNotEmpty()) { "thiếu '$k'" }
        return v
    }

    private fun route(method: String, path: String, b: JSONObject): Pair<Int, JSONObject> {
        val wait = b.optBoolean("wait", true)
        val to = b.optLong("timeout", 20_000)
        return when ("$method $path") {
            "GET /ping" -> 200 to ok().put("port", port)
            "GET /accounts" -> {
                val a = org.json.JSONArray()
                Store.all(ctx).forEach { a.put(JSONObject().put("name", it.name).put("profile", it.profileId)) }
                200 to ok().put("accounts", a)
            }
            "GET /tabs" -> 200 to ok().put("tabs", TabManager.list())
            "POST /open" -> {
                val acc = b.optString("account", "").ifEmpty { null }
                val url = b.optString("url", "").ifEmpty { null }
                200 to ok().put("tab", TabManager.open(b.str("id"), acc, url, wait, to))
            }
            "POST /goto" -> 200 to ok().put("tab", TabManager.goto(b.str("id"), b.str("url"), wait, to))
            "POST /js" -> 200 to ok().put("result", TabManager.js(b.str("id"), b.str("code"), b.optLong("timeout", 15_000)))
            "POST /info" -> 200 to ok().put("tab", TabManager.info(b.str("id")))
            "POST /cookies" -> 200 to ok().put("cookies", TabManager.cookies(b.str("id"), b.str("url")))
            "POST /close" -> { TabManager.close(b.str("id")); 200 to ok() }
            else -> 404 to err("không có route $method $path")
        }
    }

    private fun send(s: Socket, code: Int, o: JSONObject) {
        val body = o.toString().toByteArray(Charsets.UTF_8)
        val reason = when (code) { 200 -> "OK"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 404 -> "Not Found"; 413 -> "Payload Too Large"; 504 -> "Gateway Timeout"; else -> "Error" }
        val head = "HTTP/1.1 $code $reason\r\nContent-Type: application/json; charset=utf-8\r\n" +
            "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n"
        try { s.getOutputStream().apply { write(head.toByteArray()); write(body); flush() } } catch (_: Exception) {}
    }
}
