// Chay trong trang (main world) truoc moi script khac de doi navigator.*
(function () {
  var code = '(' + function () {
    var UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1';
    var APP = UA.replace('Mozilla/', '');
    var map = {
      appVersion: APP,
      platform: 'iPhone',
      vendor: 'Apple Computer, Inc.',
      maxTouchPoints: 5,
      userAgentData: undefined
    };
    var proto = Navigator.prototype;
    Object.keys(map).forEach(function (k) {
      try {
        var v = map[k];
        Object.defineProperty(proto, k, { get: function () { return v; }, configurable: true, enumerable: true });
      } catch (e) {}
    });
  } + ')();';
  try {
    var s = document.createElement('script');
    s.textContent = code;
    (document.documentElement || document.head).appendChild(s);
    s.remove();
  } catch (e) {}
})();
