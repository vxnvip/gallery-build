package app.eqclean;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

/** Port of hr.podlanica.receivers.AudioSessionReceiver (same logic, running flag instead of getRunningServices). */
public class AudioSessionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context context, Intent intent) {
        if ("android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION".equals(intent.getAction())) {
            Cfg.session = intent.getIntExtra("android.media.extra.AUDIO_SESSION", 0);
        }
        Cfg.session = intent.getIntExtra("android.media.extra.AUDIO_SESSION", 0);
        if ("android.media.action.CLOSE_AUDIO_EFFECT_CONTROL_SESSION".equals(intent.getAction())) {
            Cfg.session = 0;
        }
        if (EqService.running) {
            Intent stop = new Intent(context, EqService.class);
            stop.putExtra("STOP", true);
            context.startService(stop);
            new Handler(Looper.getMainLooper()).postDelayed(
                    () -> EqService.start(context), 1000L);
        }
    }
}
