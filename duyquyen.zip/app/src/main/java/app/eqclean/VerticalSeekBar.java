package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.widget.SeekBar;

/** SeekBar rotated 90deg: bottom = 0, top = max. */
public class VerticalSeekBar extends SeekBar {
    public VerticalSeekBar(Context c) { super(c); }
    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) { super.onSizeChanged(h, w, oldh, oldw); }
    @Override protected synchronized void onMeasure(int wSpec, int hSpec) { super.onMeasure(hSpec, wSpec); setMeasuredDimension(getMeasuredHeight(), getMeasuredWidth()); }
    @Override protected void onDraw(Canvas canvas) {
        canvas.rotate(-90);
        canvas.translate(-getHeight(), 0);
        super.onDraw(canvas);
    }
    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!isEnabled()) return false;
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
            case MotionEvent.ACTION_UP:
                int p = getMax() - (int) (getMax() * e.getY() / getHeight());
                p = Math.max(0, Math.min(getMax(), p));
                setProgress(p);
                onSizeChanged(getWidth(), getHeight(), 0, 0);
                return true;
        }
        return super.onTouchEvent(e);
    }
}
