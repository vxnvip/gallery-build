package app.eqclean;

import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Studio-styled settings panel. Options are stored in the "prefsSettings" SharedPreferences. */
public final class SettingsDialog {
    private SettingsDialog() {}
    public static final String PREFS = "prefsSettings";
    public static final String STOP_ON_DISCONNECT = "stopOnDisconnect";

    public static void show(Activity a) {
        SharedPreferences sp = a.getSharedPreferences(PREFS, 0);
        float d = Studio.dens(a);
        int p = Studio.dp(a, 20);

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, Studio.dp(a, 16));
        root.setBackground(Studio.panel(a, Studio.BLACK));

        TextView title = new TextView(a);
        title.setText("CÀI ĐẶT");
        title.setTextColor(Studio.WHITE); title.setTextSize(Studio.SP_TITLE + 2); title.setTypeface(Studio.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-2, -2));

        CheckBox cb = new CheckBox(a);
        cb.setText("Tắt khi ngắt kết nối tai nghe");
        cb.setTextColor(Studio.WHITE); cb.setTextSize(14); cb.setTypeface(Studio.BOLD);
        cb.setButtonTintList(ColorStateList.valueOf(Studio.CYAN));
        cb.setChecked(sp.getBoolean(STOP_ON_DISCONNECT, false));
        cb.setOnCheckedChangeListener((b, on) -> sp.edit().putBoolean(STOP_ON_DISCONNECT, on).apply());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = Studio.dp(a, 14);
        root.addView(cb, cp);

        TextView hint = new TextView(a);
        hint.setText("Tắt bộ cân bằng khi tai nghe có dây, USB hoặc Bluetooth bị rút hoặc ngắt kết nối.");
        hint.setTextColor(Studio.GREY_TXT); hint.setTextSize(12);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.leftMargin = Studio.dp(a, 32);
        root.addView(hint, hp);

        TextView close = new TextView(a);
        close.setText("ĐÓNG");
        close.setTextColor(Studio.CYAN); close.setTextSize(Studio.SP_TITLE); close.setTypeface(Studio.BOLD);
        close.setGravity(Gravity.CENTER);
        close.setBackground(Studio.presetBox(a));
        close.setPadding(Studio.dp(a, 22), Studio.dp(a, 8), Studio.dp(a, 22), Studio.dp(a, 8));
        LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(-2, -2);
        xp.gravity = Gravity.END; xp.topMargin = Studio.dp(a, 16);
        root.addView(close, xp);

        Dialog dlg = new Dialog(a);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.setContentView(root);
        close.setOnClickListener(v -> dlg.dismiss());
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            int sw = a.getResources().getDisplayMetrics().widthPixels;
            w.setLayout((int) Math.min(sw * 0.9f, 360 * d), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dlg.show();
    }
}
