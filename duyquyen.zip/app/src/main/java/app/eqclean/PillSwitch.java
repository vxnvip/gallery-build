package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/**
 * Studio pill switch. The outline is 90% x 58% of the box (like the original bitmap).
 * ONOFF: off = white thumb left + "OFF"; on = cyan thumb right + "ON".
 * BAND:  checked = "10 EQ" + thumb right; unchecked = thumb left + "5 EQ" (bold, cyan).
 */
public class PillSwitch extends View {
    public interface Listener { void onToggle(boolean checked); }
    public static final int ONOFF = 0, BAND = 1;
    private boolean checked;
    private final int mode;
    private Listener listener;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d;

    public PillSwitch(Context c, int mode) {
        super(c);
        this.mode = mode;
        d = Studio.dens(c);
        setClickable(true);
        setOnClickListener(v -> { checked = !checked; invalidate(); if (listener != null) listener.onToggle(checked); });
    }
    public void setListener(Listener l) { listener = l; }
    public void setChecked(boolean c) { checked = c; invalidate(); }
    public boolean isChecked() { return checked; }

    @Override protected void onMeasure(int ws, int hs) {
        setMeasuredDimension((int) (Studio.ONOFF_W * d + 0.5f), (int) (Studio.ONOFF_H * d + 0.5f));
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float rw = w * 0.90f, rh = h * 0.58f;
        float l = (w - rw) / 2f, t = (h - rh) / 2f;
        float sw = Math.max(1.5f, 1.6f * d);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(0xE6D8D8D8);
        rf.set(l + sw / 2, t + sw / 2, l + rw - sw / 2, t + rh - sw / 2);
        c.drawRoundRect(rf, rh, rh, p);

        float tr = rh * 0.43f, pad = rh * 0.07f + sw;
        float tx = checked ? l + rw - pad - tr : l + pad + tr;
        boolean cyan = mode == BAND || checked;
        p.setStyle(Paint.Style.FILL);
        p.setColor(cyan ? Studio.CYAN : Studio.WHITE);
        c.drawCircle(tx, h / 2f, tr, p);

        String s; int col;
        if (mode == BAND) { s = checked ? "10 EQ" : "5 EQ"; col = Studio.CYAN; }
        else { s = checked ? "ON" : "OFF"; col = checked ? Studio.CYAN : Studio.WHITE; }
        p.setColor(col);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(mode == BAND ? Typeface.DEFAULT_BOLD : Studio.THIN);
        p.setTextSize(rh * 0.66f);
        float free0 = checked ? l + pad : l + pad + 2 * tr, free1 = checked ? l + rw - pad - 2 * tr : l + rw - pad;
        c.drawText(s, (free0 + free1) / 2f, h / 2f + rh * 0.23f, p);
    }
}
