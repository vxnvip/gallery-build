package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/**
 * Studio pill switch (onoff_studio / onoffeq10_studio), 64 x 29 dp.
 * ON/OFF mode: off = white thumb left + "OFF"; on = cyan thumb right + "ON".
 * BAND mode:   checked = "10 EQ" + thumb right; unchecked = thumb left + "5 EQ" (all cyan, bold).
 */
public class PillSwitch extends View {
    public interface Listener { void onToggle(boolean checked); }
    public static final int ONOFF = 0, BAND = 1;
    private boolean checked;
    private final int mode;
    private Listener listener;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d;

    public PillSwitch(Context c, int mode) {
        super(c);
        this.mode = mode;
        d = Studio.dens(c);
        setClickable(true);
        setOnClickListener(v -> { checked = !checked; invalidate(); if (listener != null) listener.onToggle(checked); });
    }
    public void setListener(Listener l) { listener = l; }
    public void setChecked(boolean c) { checked = c; invalidate(); }
    public boolean isChecked() { return checked; }

    @Override protected void onMeasure(int ws, int hs) {
        setMeasuredDimension((int) (Studio.ONOFF_W * d + 0.5f), (int) (Studio.ONOFF_H * d + 0.5f));
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), sw = 1.6f * d;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(0xD0FFFFFF);
        rf.set(sw, sw, w - sw, h - sw);
        c.drawRoundRect(rf, h, h, p);

        float tr = h * 0.36f, pad = h * 0.15f + sw;
        float tx = checked ? w - pad - tr : pad + tr;
        boolean cyan = mode == BAND || checked;
        p.setStyle(Paint.Style.FILL);
        p.setColor(cyan ? Studio.CYAN : Studio.WHITE);
        c.drawCircle(tx, h / 2f, tr, p);

        String s; int col;
        if (mode == BAND) { s = checked ? "10 EQ" : "5 EQ"; col = Studio.CYAN; }
        else { s = checked ? "ON" : "OFF"; col = checked ? Studio.CYAN : Studio.WHITE; }
        p.setColor(col);
        p.setTextAlign(Paint.Align.CENTER);
        if (mode == BAND) { p.setFakeBoldText(true); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); p.setTextSize(h * 0.42f); }
        else { p.setFakeBoldText(false); p.setTypeface(Studio.THIN); p.setTextSize(h * 0.44f); }
        float free0 = checked ? pad : pad + 2 * tr, free1 = checked ? w - pad - 2 * tr : w - pad;
        c.drawText(s, (free0 + free1) / 2f, h / 2f + h * 0.15f, p);
        p.setFakeBoldText(false);
    }
}
