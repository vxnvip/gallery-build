package app.eqclean;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Slide-in navigation drawer (opens from the hamburger). Sits under the toolbar, dimmed scrim behind it,
 * same tiled "studio" background as the home screen.
 */
public final class DrawerMenu {
    public interface Listener { void onToggle(boolean open); }

    private final Activity a;
    private final Listener listener;
    private final View scrim;
    private final FrameLayout panel;
    private final int width;
    private boolean open = false;

    public DrawerMenu(Activity a, FrameLayout host, int topInsetPx, Listener listener) {
        this.a = a;
        this.listener = listener;
        float d = Studio.dens(a);
        int sw = a.getResources().getDisplayMetrics().widthPixels;
        width = Math.round(Math.min(sw * 0.72f, 320 * d));

        scrim = new View(a);
        scrim.setBackgroundColor(0xB3000000);
        scrim.setAlpha(0f);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> close());
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -1);
        sp.topMargin = topInsetPx;
        host.addView(scrim, sp);

        panel = new FrameLayout(a);
        panel.setBackground(Studio.tileBg(a));
        panel.setClickable(true);                       // swallow touches so they don't reach the home screen
        panel.setVisibility(View.GONE);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(width, -1, Gravity.START);
        pp.topMargin = topInsetPx;
        host.addView(panel, pp);

        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(a);
        title.setText("MUSIC VOLUME EQ");
        title.setTypeface(Studio.MONO, android.graphics.Typeface.BOLD);
        title.setTextColor(0xFFD2D2D2);
        title.setTextSize(17);
        title.setLetterSpacing(0.08f);
        title.setSingleLine(true);
        title.setPadding(Studio.dp(a, 20), Studio.dp(a, 28), Studio.dp(a, 12), Studio.dp(a, 22));
        col.addView(title, new LinearLayout.LayoutParams(-1, -2));

        View line = new View(a);
        line.setBackgroundColor(0xFF1D3236);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Math.max(1, Studio.dp(a, 1)));
        lp.bottomMargin = Studio.dp(a, 6);
        col.addView(line, lp);

        item(col, IconView.EQBARS, "Equalizer", () -> a.startActivity(new Intent(a, EqActivity.class)));
        item(col, IconView.GEAR, "Settings", () -> a.startActivity(new Intent(a, SettingsActivity.class)));
        item(col, IconView.SHARE, "Share the app", this::share);
        item(col, IconView.STAR, "Rate this app", this::rate);

        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        View edge = new View(a);                         // thin cyan-ish edge on the right side
        edge.setBackgroundColor(0xFF2A4A52);
        panel.addView(edge, new FrameLayout.LayoutParams(Math.max(1, Studio.dp(a, 1)), -1, Gravity.END));
    }

    private void item(LinearLayout col, int icon, String label, Runnable action) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Studio.dp(a, 18), 0, Studio.dp(a, 12), 0);
        row.setBackground(new RippleDrawable(ColorStateList.valueOf(0x558DE3FC), null, new ColorDrawable(0xFFFFFFFF)));
        row.addView(new IconView(a, icon), new LinearLayout.LayoutParams(Studio.dp(a, 32), Studio.dp(a, 32)));

        TextView t = new TextView(a);
        t.setText(label);
        t.setTextColor(Studio.WHITE);
        t.setTextSize(19);
        t.setTypeface(Studio.BOLD);
        t.setSingleLine(true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = Studio.dp(a, 18);
        row.addView(t, tp);

        row.setOnClickListener(v -> { close(); action.run(); });
        col.addView(row, new LinearLayout.LayoutParams(-1, Studio.dp(a, 66)));
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "Music Volume EQ\nhttps://play.google.com/store/apps/details?id=" + a.getPackageName());
        a.startActivity(Intent.createChooser(i, "Share the app"));
    }

    private void rate() {
        String id = a.getPackageName();
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + id))); }
        catch (ActivityNotFoundException e) {
            try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + id))); }
            catch (ActivityNotFoundException ignored) {}
        }
    }

    public boolean isOpen() { return open; }
    public void toggle() { if (open) close(); else open(); }

    public void open() {
        if (open) return;
        open = true;
        scrim.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        panel.setTranslationX(-width);
        scrim.animate().alpha(1f).setDuration(200).start();
        panel.animate().translationX(0).setDuration(220).start();
        listener.onToggle(true);
    }

    public void close() {
        if (!open) return;
        open = false;
        scrim.animate().alpha(0f).setDuration(180).start();
        panel.animate().translationX(-width).setDuration(200).withEndAction(() -> {
            if (!open) { panel.setVisibility(View.GONE); scrim.setVisibility(View.GONE); }
        }).start();
        listener.onToggle(false);
    }
}
