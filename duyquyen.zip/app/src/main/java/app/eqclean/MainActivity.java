package app.eqclean;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Home screen, Studio theme (activity_booster_studio): toolbar + logo, dB scale | spectrum/volume/toggles panel |
 * 0..100 scale | volume fader, "VOLUME" caption and the hexagon EQ button.
 */
public class MainActivity extends Activity {
    private EqService svc;
    private AudioManager am;
    private SharedPreferences onPrefs;
    private SpectrumView spec;
    private FaderView fader;
    private TextView volValue;
    private final TextToggle[] tabs = new TextToggle[3];
    private final boolean[] tabOn = new boolean[3];
    private Visualizer vis;
    private boolean fullscreen = false;
    private float d;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long lastFft = 0;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    /** keeps the fader in sync with hardware keys and lets spectrum bars fall when audio stops. */
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!fader.isDragging()) refreshVolume();
            if (System.currentTimeMillis() - lastFft > 200) spec.decay();
            ui.postDelayed(this, 100);
        }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Studio.init(this);
        if (s == null && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        d = Studio.dens(this);
        tabOn[0] = onPrefs.getBoolean("prefsEQOn1", true);
        tabOn[1] = onPrefs.getBoolean("prefsBASSOn1", false);
        tabOn[2] = onPrefs.getBoolean("prefsVIRTOn1", false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Studio.tileBg(this));
        root.addView(toolbar());
        View sh = new View(this);
        sh.setBackground(Studio.shadow());
        root.addView(sh, new LinearLayout.LayoutParams(-1, dp(3)));

        // container
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(mainRow(), new LinearLayout.LayoutParams(-2, -2));   // wrap, like the XML: match_parent here collapses the row
        col.addView(volumeCaption(), cp(-2, -2, Gravity.END, 0, 0, 0, 0));
        box.addView(col, cp(-2, -2, Gravity.CENTER_HORIZONTAL, 0, 5, 0, 0));

        HexButton eq = new HexButton(this, HexButton.EQ);
        eq.setOnClickListener(v -> startActivity(new Intent(this, EqActivity.class)));
        box.addView(eq, cp(-2, -2, Gravity.CENTER_HORIZONTAL, 0, 5, 0, 8));

        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setVerticalScrollBarEnabled(false);
        sc.addView(box, new FrameLayout.LayoutParams(-1, -2));
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onResume() {
        super.onResume();
        tabOn[0] = onPrefs.getBoolean("prefsEQOn1", true);   // EqActivity may have changed them
        tabOn[1] = onPrefs.getBoolean("prefsBASSOn1", false);
        tabOn[2] = onPrefs.getBoolean("prefsVIRTOn1", false);
        for (int i = 0; i < 3; i++) tabs[i].setChecked(tabOn[i]);
        refreshVolume();
        startVis();
        ui.post(tick);
    }
    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(tick); stopVis(); }
    @Override protected void onDestroy() { super.onDestroy(); try { unbindService(conn); } catch (Exception ignored) {} }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        startVis();
    }

    // ---------------------------------------------------------------- helpers
    private int dp(float v) { return Studio.dp(this, v); }
    private LinearLayout.LayoutParams lp(int w, int h, float weight) { return new LinearLayout.LayoutParams(w, h, weight); }
    private LinearLayout.LayoutParams cp(int w, int h, int gravity, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.gravity = gravity; p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }
    private TextView tv(String t, float sp, int color) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        v.setTypeface(Studio.BOLD);
        return v;
    }

    // ---------------------------------------------------------------- toolbar (black, 48dp, logo left)
    private View toolbar() {
        LinearLayout h = new LinearLayout(this);
        h.setBackgroundColor(Studio.BLACK);
        h.setGravity(Gravity.CENTER_VERTICAL);
        IconView menu = new IconView(this, IconView.MENU);
        menu.setOnClickListener(this::effectsMenu);
        IconView full = new IconView(this, IconView.FULLSCREEN);
        full.setOnClickListener(v -> toggleFullscreen());
        IconView more = new IconView(this, IconView.DOTS);
        more.setOnClickListener(this::moreMenu);
        h.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(48)));
        h.addView(new LogoView(this), new LinearLayout.LayoutParams(-2, -2));
        h.addView(new View(this), lp(0, 1, 1));
        h.addView(full, new LinearLayout.LayoutParams(dp(44), dp(48)));
        h.addView(more, new LinearLayout.LayoutParams(dp(36), dp(48)));
        h.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(48)));
        return h;
    }

    // ---------------------------------------------------------------- main row
    private View mainRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(10), dp(10), dp(10), 0);
        row.addView(leftScale(), cp(-2, dp(Studio.SLIDER_H), Gravity.CENTER, 1, 0, 0, 0));
        row.addView(ekran(), cp(dp(Studio.EKRAN_W), dp(Studio.SLIDER_H), 0, 0, 0, 10, 0));
        row.addView(rightScale(), cp(-2, dp(Studio.SLIDER_H), Gravity.CENTER, 1, 0, 0, 0));
        fader = new FaderView(this);
        fader.setListener(f -> {
            int max = am.getStreamMaxVolume(3);
            int v = Math.round(f * max);
            am.setStreamVolume(3, v, 0);
            if (EqService.volumeLock) EqService.lockedVolume = v;
            volValue.setText(String.valueOf(v));
        });
        row.addView(fader, new LinearLayout.LayoutParams(dp(Studio.FADER_W), dp(Studio.SLIDER_H)));
        return row;
    }

    /** dB labels, one equal weight (0.3) per row, bottom padding 40dp - same as the XML. */
    private View leftScale() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(0, 0, 0, dp(40));
        String[] labels = {"+38 ", "+30 ", "+20 ", "+10 ", "+7 ", "+4 ", "+2 ", "  0", " -2", " -4", " -7", "-10", "-20", "-30", "-38"};
        for (String s : labels) c.addView(tv(s, Studio.SP_SMALL, Studio.WHITE), lp(-2, 0, 0.3f));
        return c;
    }

    /** 100 / 80 / 60 / 40 / 20 / 0 with weights .3 .4 .3 .3 .4 .3, top/bottom padding 20dp on the end labels. */
    private View rightScale() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        String[] t = {"100", " 80", " 60", " 40", " 20", "  0"};
        float[] w = {0.3f, 0.4f, 0.3f, 0.3f, 0.4f, 0.3f};
        for (int i = 0; i < t.length; i++) {
            TextView v = tv(t[i], Studio.SP_SMALL, Studio.WHITE);
            if (i == 0) v.setPadding(0, dp(20), 0, 0);
            if (i == t.length - 1) v.setPadding(0, 0, 0, dp(20));
            c.addView(v, lp(-2, 0, w[i]));
        }
        return c;
    }

    /** ekran: black rounded panel with spectrum, VOLUME value and the EQ / BASS / VIRT toggles. */
    private View ekran() {
        LinearLayout e = new LinearLayout(this);
        e.setOrientation(LinearLayout.VERTICAL);
        e.setBackground(Studio.panel(this, Studio.BLACK));

        FrameLayout holder = new FrameLayout(this);
        holder.setBackgroundColor(Studio.BLACK);
        spec = new SpectrumView(this);
        holder.addView(spec, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 1f);
        hp.setMargins(dp(10), dp(10), dp(10), dp(5));
        e.addView(holder, hp);

        // VOLUME  15
        LinearLayout vrow = new LinearLayout(this);
        vrow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        vrow.setBackgroundColor(Studio.BLACK);
        TextView vl = tv("VOLUME", Studio.SP_BUTTON, Studio.WHITE);
        vl.setSingleLine(true);
        volValue = tv("15", Studio.SP_BUTTON, Studio.CYAN);
        vrow.addView(vl, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-2, -2);
        vp.leftMargin = dp(3);
        vrow.addView(volValue, vp);
        LinearLayout.LayoutParams vrp = new LinearLayout.LayoutParams(-1, -2);
        vrp.setMargins(dp(10), 0, dp(10), dp(5));
        e.addView(vrow, vrp);

        // EQ | BASS | VIRT
        LinearLayout trow = new LinearLayout(this);
        trow.setBackgroundColor(Studio.BLACK);
        trow.setGravity(Gravity.CENTER_VERTICAL);
        String[] names = {"  EQ  ", " BASS ", " VIRT "};
        String[] actions = {EqService.ACTION_EQ_TOGGLE, EqService.ACTION_BASS_TOGGLE, EqService.ACTION_VIRT_TOGGLE};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextToggle b = new TextToggle(this, names[i]);
            b.setChecked(tabOn[i]);
            tabs[i] = b;
            b.setOnClickListener(v -> {
                startService(new Intent(this, EqService.class).setAction(actions[idx]));
                tabOn[idx] = !tabOn[idx];
                b.setChecked(tabOn[idx]);
            });
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(Studio.BTN_W), dp(Studio.BTN_H));
            if (i > 0) bp.leftMargin = dp(5);
            trow.addView(b, bp);
        }
        LinearLayout.LayoutParams trp = new LinearLayout.LayoutParams(-1, -2);
        trp.setMargins(dp(10), 0, dp(10), dp(5));
        e.addView(trow, trp);
        return e;
    }

    private View volumeCaption() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.END);
        TextView t = tv("VOLUME", Studio.SP_TITLE, Studio.WHITE);
        t.setGravity(Gravity.END);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.rightMargin = dp(22);
        r.addView(t, p);
        return r;
    }

    // ---------------------------------------------------------------- volume
    private void refreshVolume() {
        int max = Math.max(1, am.getStreamMaxVolume(3)), v = am.getStreamVolume(3);
        fader.setFraction((float) v / max);
        volValue.setText(String.valueOf(v));
    }

    // ---------------------------------------------------------------- menus
    private void effectsMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Preamp & Loudness");
        m.getMenu().add(0, 2, 1, "Balance");
        m.getMenu().add(0, 3, 2, "Limiter");
        m.setOnMenuItemClickListener(it -> {
            Dialogs.Svc g = () -> svc;
            if (it.getItemId() == 1) Dialogs.preampLoudness(this, g);
            else if (it.getItemId() == 2) Dialogs.balance(this, g);
            else Dialogs.limiter(this, g);
            return true;
        });
        m.show();
    }

    private void moreMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        MenuItem lock = m.getMenu().add(0, 1, 0, "Lock volume");
        lock.setCheckable(true); lock.setChecked(EqService.volumeLock);
        m.getMenu().add(0, 2, 1, "Stop & exit");
        m.setOnMenuItemClickListener(it -> {
            if (it.getItemId() == 1) { if (svc != null) svc.setVolumeLock(!EqService.volumeLock); }
            else {
                startService(new Intent(this, EqService.class).putExtra("STOP", true));
                finishAndRemoveTask();
            }
            return true;
        });
        m.show();
    }

    @SuppressWarnings("deprecation")
    private void toggleFullscreen() {
        fullscreen = !fullscreen;
        getWindow().getDecorView().setSystemUiVisibility(fullscreen
                ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                : View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ---------------------------------------------------------------- spectrum (Visualizer FFT on the output mix)
    private void startVis() {
        if (vis != null) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        try {
            Visualizer v = new Visualizer(Cfg.session);
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
            v.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override public void onWaveFormDataCapture(Visualizer x, byte[] w, int sr) {}
                @Override public void onFftDataCapture(Visualizer x, byte[] fft, int sr) { lastFft = System.currentTimeMillis(); spec.pushFft(fft, sr); }
            }, Visualizer.getMaxCaptureRate() / 2, false, true);
            v.setEnabled(true);
            vis = v;
        } catch (Throwable t) { vis = null; }
    }
    private void stopVis() {
        if (vis == null) return;
        try { vis.setEnabled(false); vis.release(); } catch (Throwable ignored) {}
        vis = null;
    }
}
