package app.eqclean;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Round knob (roundknob_studio + CircularSeekBarBass): cyan ring with two decorative arcs and MIN/MAX,
 * grey seek arc 130 -> 409 degrees (white progress), white ring with cyan glow while touched. 88 x 88 dp.
 */
public class KnobView extends View {
    public interface Listener { void onChange(int value); }
    private static final float START = 130f, END = 409f, SWEEP = END - START;
    private int max = 1000, value = 0;
    private boolean on = false, touching = false;
    private Listener listener;
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float d;

    public KnobView(Context c) {
        super(c);
        d = Studio.dens(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        ring.setStyle(Paint.Style.STROKE);
        arc.setStyle(Paint.Style.STROKE); arc.setStrokeCap(Paint.Cap.BUTT);
        glow.setStyle(Paint.Style.STROKE); glow.setColor(Studio.CYAN);
        glow.setMaskFilter(new BlurMaskFilter(5 * d, BlurMaskFilter.Blur.NORMAL));
        txt.setTypeface(Studio.THIN); txt.setTextSize(9 * d * 1.15f);
    }
    public void setup(int max, int value, Listener l) { this.max = max; this.value = value; this.listener = l; invalidate(); }
    public void setActive(boolean a) { on = a; invalidate(); }
    public void setValue(int v) { value = Math.max(0, Math.min(max, v)); invalidate(); }
    public int getValue() { return value; }

    @Override protected void onMeasure(int ws, int hs) {
        int s = (int) (Studio.WHEEL * d + 0.5f);
        setMeasuredDimension(s, s);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f - 4 * d;
        float a = on ? 1f : 0.5f;
        int cyan = Studio.CYAN, white = Studio.WHITE;

        // outer ring
        if (touching) { glow.setStrokeWidth(5 * d); c.drawCircle(cx, cy, r, glow); }
        ring.setStrokeWidth((touching ? 2.4f : 1.8f) * d);
        ring.setColor(touching ? white : cyan);
        ring.setAlpha((int) (255 * a));
        c.drawCircle(cx, cy, r, ring);

        // decorative arcs (upper-left and lower-right quarter pairs)
        ring.setStrokeWidth(1.5f * d);
        ring.setColor(touching ? white : cyan); ring.setAlpha((int) (255 * a));
        for (float k : new float[]{0.64f, 0.53f}) {
            oval.set(cx - r * k, cy - r * k, cx + r * k, cy + r * k);
            c.drawArc(oval, 180, 90, false, ring);
            c.drawArc(oval, 0, 90, false, ring);
        }

        // seek arc: grey track + white progress
        float ar = r - 8 * d;
        oval.set(cx - ar, cy - ar, cx + ar, cy + ar);
        arc.setStrokeWidth(3.5f * d);
        arc.setColor(0xFF5D5D5D);
        c.drawArc(oval, START, SWEEP, false, arc);
        float sweep = SWEEP * value / max;
        if (on && sweep > 0) { arc.setColor(white); c.drawArc(oval, START, sweep, false, arc); }
        double ang = Math.toRadians(START + sweep);
        dot.setColor(on ? white : 0xFF8A8A8A);
        c.drawCircle((float) (cx + ar * Math.cos(ang)), (float) (cy + ar * Math.sin(ang)), 3 * d, dot);

        // MIN / MAX
        txt.setColor(white); txt.setAlpha((int) (255 * a));
        float by = cy + r - 1 * d;
        txt.setTextAlign(Paint.Align.LEFT);  c.drawText("MIN", cx - r - 1 * d, by, txt);
        txt.setTextAlign(Paint.Align.RIGHT); c.drawText("MAX", cx + r + 1 * d, by, txt);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_CANCEL || act == MotionEvent.ACTION_UP) { touching = false; invalidate(); return true; }
        if (act != MotionEvent.ACTION_DOWN && act != MotionEvent.ACTION_MOVE) return false;
        touching = true;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        double ang = Math.toDegrees(Math.atan2(e.getY() - getHeight() / 2f, e.getX() - getWidth() / 2f));
        if (ang < 0) ang += 360;
        double rel = ang - START;
        if (rel < 0) rel += 360;
        if (rel > SWEEP) rel = (rel - SWEEP) < (360 - rel) ? SWEEP : 0;   // dead zone -> nearest end
        int v = (int) Math.round(rel / SWEEP * max);
        if (v != value) { value = v; if (listener != null) listener.onChange(v); }
        invalidate();
        return true;
    }
}
