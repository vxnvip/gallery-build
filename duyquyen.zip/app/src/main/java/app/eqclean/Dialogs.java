package app.eqclean;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** Audio Effects dialogs. Ranges, formulas and pref keys are taken 1:1 from the original (d2.q / limiter_dialog.xml). */
public final class Dialogs {
    private Dialogs() {}

    public interface Svc { EqService get(); }
    interface Change { void on(int p); }

    private static TextView text(Context c, String t, int sp, int gravity) {
        TextView v = new TextView(c);
        v.setText(t); v.setTextSize(sp); v.setGravity(gravity); v.setTextColor(Color.WHITE);
        v.setPadding(0, 24, 0, 8);
        return v;
    }
    private static SeekBar bar(Context c, int max, int progress, Change onChange, Runnable onStop) {
        SeekBar b = new SeekBar(c);
        b.setMax(max);
        b.setProgress(progress);
        b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { onChange.on(p); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) { if (onStop != null) onStop.run(); }
        });
        return b;
    }
    private static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 24, 48, 8);
        return l;
    }
    private static AlertDialog.Builder builder(Context c) { return new AlertDialog.Builder(c, AlertDialog.THEME_DEVICE_DEFAULT_DARK); }

    // ===== Preamp & Loudness =====
    public static void preampLoudness(Context c, Svc svc) {
        Cfg.preamp = c.getSharedPreferences("prefsPreamp", 0).getInt("prefsPreampValue2", 20);
        Cfg.loudness = c.getSharedPreferences("prefsLoudness", 0).getInt("prefsLoudnessValue", 0);
        LinearLayout root = col(c);
        TextView title = text(c, "Tiền khuếch đại", 20, Gravity.CENTER);
        TextView val = text(c, preampText(Cfg.preamp), 24, Gravity.CENTER);
        SharedPreferences pp = c.getSharedPreferences("prefsPreamp", 0);
        SeekBar pre = bar(c, 40, Cfg.preamp, p -> {
            Cfg.preamp = p; val.setText(preampText(p));
            if (svc.get() != null && Build.VERSION.SDK_INT >= 28) svc.get().applyPreamp();   // ACTION_PREAMP
        }, () -> pp.edit().putInt("prefsPreampValue2", Cfg.preamp).apply());
        TextView lt = text(c, "Tăng độ lớn", 20, Gravity.CENTER);
        LinearLayout mm = new LinearLayout(c);
        TextView mn = text(c, "Nhỏ", 14, Gravity.START), mx = text(c, "Lớn", 14, Gravity.END);
        mn.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1)); mx.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        mm.addView(mn); mm.addView(mx);
        SharedPreferences lp = c.getSharedPreferences("prefsLoudness", 0);
        SeekBar loud = bar(c, 1000, Cfg.loudness, p -> {
            Cfg.loudness = p;
            if (svc.get() != null) svc.get().applyLoudness();                                 // ACTION_LOUDNESS
        }, null);
        root.addView(title); root.addView(val); root.addView(pre); root.addView(lt); root.addView(mm); root.addView(loud);
        AlertDialog d = builder(c).setView(root)
                .setNegativeButton("Đặt lại", null)
                .setPositiveButton("Xong", (x, i) -> {
                    lp.edit().putInt("prefsLoudnessValue", Cfg.loudness).apply();
                    pp.edit().putInt("prefsPreampValue2", Cfg.preamp).apply();
                }).create();
        d.show();
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            loud.setProgress(0); Cfg.loudness = 0;
            if (svc.get() != null) svc.get().applyLoudness();
            pre.setProgress(20); Cfg.preamp = 20;
            if (svc.get() != null && Build.VERSION.SDK_INT >= 28) svc.get().applyPreamp();
        });
    }
    private static String preampText(int i) {
        if (i < 20) return "-" + (20 - i) + " dB";
        if (i == 20) return (20 - (40 - i)) + " dB";
        return "+" + (20 - (40 - i)) + " dB";
    }

    // ===== Balance =====
    public static void balance(Context c, Svc svc) {
        SharedPreferences bp = c.getSharedPreferences("prefsBalance", 0);
        Cfg.balance = bp.getFloat("prefsBalanceValue", 50.0f);
        LinearLayout root = col(c);
        TextView title = text(c, "Cân bằng trái/phải", 20, Gravity.CENTER);
        LinearLayout lr = new LinearLayout(c);
        TextView l = text(c, "L", 18, Gravity.START), r = text(c, "R", 18, Gravity.END);
        l.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1)); r.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        lr.addView(l); lr.addView(r);
        SeekBar[] ref = new SeekBar[1];
        ref[0] = bar(c, 100, (int) Cfg.balance, p -> {
            Cfg.balance = p;
            if (p > 47 && p < 53) { ref[0].setProgress(50); Cfg.balance = 50.0f; }   // snap to centre
            if (svc.get() != null && Build.VERSION.SDK_INT >= 28) svc.get().applyBalance();
        }, () -> bp.edit().putFloat("prefsBalanceValue", Cfg.balance).apply());
        root.addView(title); root.addView(lr); root.addView(ref[0]);
        AlertDialog d = builder(c).setView(root).setNegativeButton("Đặt lại", null)
                .setPositiveButton("Xong", (x, i) -> bp.edit().putFloat("prefsBalanceValue", Cfg.balance).apply()).create();
        d.show();
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            ref[0].setProgress(50); Cfg.balance = 50.0f;
            bp.edit().putFloat("prefsBalanceValue", 50.0f).apply();
            if (svc.get() != null && Build.VERSION.SDK_INT >= 28) svc.get().applyBalance();
        });
    }

    // ===== Limiter =====
    public static void limiter(Context c, Svc svc) {
        SharedPreferences sp = c.getSharedPreferences("prefsLimiter", 0);
        Cfg.limAttack = sp.getFloat("prefAttackValue", 1.0f);
        Cfg.limRelease = sp.getFloat("prefReleaseValue", 60.0f);
        Cfg.limRatio = sp.getFloat("prefRatioValue", 10.0f);
        Cfg.limThreshold = sp.getFloat("prefThresholdValue", -2.0f);
        Cfg.limPostGain = sp.getFloat("prefGainValue", 0.0f);
        Runnable apply = () -> { if (svc.get() != null && Build.VERSION.SDK_INT >= 28) svc.get().applyLimiter(); };

        float g = Cfg.limPostGain; float gp = 100f;
        if (g > 0f) gp = 100f + g * 10f; else if (g < 0f) gp = 100f - g * -10f;

        LinearLayout root = col(c);
        root.addView(text(c, "Bộ giới hạn", 22, Gravity.CENTER));
        TextView ta = text(c, ((int) Cfg.limAttack) + "ms", 16, Gravity.CENTER);
        TextView tr = text(c, ((int) Cfg.limRelease) + "ms", 16, Gravity.CENTER);
        TextView tq = text(c, String.valueOf(Cfg.limRatio), 16, Gravity.CENTER);
        TextView tt = text(c, ((int) Cfg.limThreshold) + "dB", 16, Gravity.CENTER);
        TextView tg = text(c, Cfg.limPostGain + "dB", 16, Gravity.CENTER);

        SeekBar a = bar(c, 99, ((int) Cfg.limAttack) - 1, p -> {                                  // 1..100 ms
            Cfg.limAttack = p + 1.0f; ta.setText(((int) Cfg.limAttack) + "ms"); apply.run();
            sp.edit().putFloat("prefAttackValue", Cfg.limAttack).apply(); }, null);
        SeekBar rl = bar(c, 299, ((int) Cfg.limRelease) - 1, p -> {                               // 1..300 ms
            Cfg.limRelease = p + 1.0f; tr.setText(((int) Cfg.limRelease) + "ms"); apply.run();
            sp.edit().putFloat("prefReleaseValue", Cfg.limRelease).apply(); }, null);
        SeekBar rt = bar(c, 190, (int) ((Cfg.limRatio - 1.0f) * 10.0f), p -> {                    // 1.0..20.0
            Cfg.limRatio = (p / 10.0f) + 1.0f; tq.setText(String.valueOf(Cfg.limRatio)); apply.run();
            sp.edit().putFloat("prefRatioValue", Cfg.limRatio).apply(); }, null);
        SeekBar th = bar(c, 59, (int) (Cfg.limThreshold + 59.0f + 1.0f), p -> {                   // -60..-1 dB
            Cfg.limThreshold = -(59.0f - (p - 1.0f)); tt.setText(((int) Cfg.limThreshold) + "dB"); apply.run();
            sp.edit().putFloat("prefThresholdValue", Cfg.limThreshold).apply(); }, null);
        SeekBar gn = bar(c, 200, (int) gp, p -> {                                                 // -10.0..+10.0 dB
            float f = 0f; if (p > 100) f = p - 100f; else if (p < 100) f = -(100f - p);
            Cfg.limPostGain = f / 10.0f; tg.setText(Cfg.limPostGain + "dB"); apply.run();
            sp.edit().putFloat("prefGainValue", Cfg.limPostGain).apply(); }, null);

        String[] names = {"Attack", "Release", "Tỷ lệ", "Ngưỡng", "Độ khuếch đại"};
        TextView[] vals = {ta, tr, tq, tt, tg};
        SeekBar[] bars = {a, rl, rt, th, gn};
        for (int i = 0; i < 5; i++) { root.addView(text(c, names[i], 18, Gravity.CENTER)); root.addView(vals[i]); root.addView(bars[i]); }
        android.widget.ScrollView sv = new android.widget.ScrollView(c); sv.addView(root);
        AlertDialog d = builder(c).setView(sv).setNegativeButton("Đặt lại", null).setPositiveButton("Xong", null).create();
        d.show();
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {                        // Reset values from original
            a.setProgress(0); rl.setProgress(59); rt.setProgress(90); th.setProgress(58); gn.setProgress(100); apply.run();
        });
    }
}
