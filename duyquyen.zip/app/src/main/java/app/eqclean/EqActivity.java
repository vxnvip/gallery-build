package app.eqclean;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.TextUtils;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Equalizer page, Studio theme (eq10_studio): toolbar, [EQ on/off | EQUALIZER | 10 EQ], 10-band curve panel,
 * [BASS on/off | PRESET box | VIRT on/off], then BASS BOOST knob | VU hex button | VIRTUALIZER knob.
 * The speaker icon opens volume + lock + Preamp/Balance/Limiter. All audio goes through EqService.
 */
public class EqActivity extends Activity {
    private static final int GREEN = Studio.CYAN;
    private static final String[] N10 = {"32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K"};
    private static final String[][] BUILTIN_NAMES = {{"Flat"}, {"Rock"}, {"Pop"}, {"Bass"}, {"Treble"}, {"Vocal"}};
    /** dB per 10 bands (32..16k). */
    private static final float[][] BUILTIN = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {5, 4, 3, 1, -1, -1, 1, 3, 4, 5},
            {-1, 1, 3, 4, 3, 0, -1, -1, -1, -1},
            {7, 6, 5, 3, 1, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 1, 3, 5, 6, 7},
            {-2, -3, -3, 1, 3, 3, 3, 1, 0, -1}};
    private EqService svc;
    private SharedPreferences pos, onPrefs, presets;
    private EqView eqView;
    private PillSwitch swEq, swBass, swVirt;
    private KnobView knobBass, knobVirt;
    private TextView presetName;
    private AudioManager am;
    private float d;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable save10 = () -> {
        StringBuilder sb = new StringBuilder();
        for (float f : Cfg.bands10) sb.append(f).append(",");
        getSharedPreferences("eq10_save_prefs", 0).edit().putString("eq10_save_prefs", sb.toString()).apply();
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        pos = getSharedPreferences("prefsEQPos", 0);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        presets = getSharedPreferences("prefsPresets", 0);
        Studio.init(this);
        d = Studio.dens(this);
        Cfg.tenBand = true;
        load10();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Studio.tileBg(this));
        root.addView(toolbar());
        View sh = new View(this);
        sh.setBackground(Studio.shadow());
        root.addView(sh, new LinearLayout.LayoutParams(-1, dp(3)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(titleRow(), fm((int) Studio.EQ_MARGIN, 0));
        col.addView(eqPanel(), fm(2, 2));
        col.addView(toggleRow(), fm((int) Studio.EQ_MARGIN, 20));
        col.addView(knobRow(), fm((int) Studio.EQ_MARGIN, 20));

        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setVerticalScrollBarEnabled(false);
        sc.addView(col, new FrameLayout.LayoutParams(-1, -2));
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        showEq();
        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        try { unbindService(conn); } catch (Exception ignored) {}
    }

    // ---------------------------------------------------------------- helpers
    private int dp(float v) { return Studio.dp(this, v); }
    private LinearLayout.LayoutParams fm(int topDp, int sideDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(sideDp), dp(topDp), dp(sideDp), 0);
        return p;
    }
    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp));
        return g;
    }
    private TextView label(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        v.setTypeface(Studio.BOLD);
        return v;
    }

    // ---------------------------------------------------------------- layout (eq10_studio)
    private View toolbar() {
        LinearLayout h = new LinearLayout(this);
        h.setBackgroundColor(Studio.BLACK);
        h.setGravity(Gravity.CENTER_VERTICAL);
        IconView back = new IconView(this, IconView.BACK);
        back.setOnClickListener(v -> finish());
        IconView spk = new IconView(this, IconView.SPEAKER);
        spk.setOnClickListener(v -> volumeDialog());
        h.addView(back, new LinearLayout.LayoutParams(dp(44), dp(48)));
        h.addView(new LogoView(this), new LinearLayout.LayoutParams(-2, -2));
        h.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        h.addView(spk, new LinearLayout.LayoutParams(dp(44), dp(48)));
        h.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(48)));
        return h;
    }

    /** EQUALIZER (centre) ........ [on/off pill] (right) */
    private View titleRow() {
        FrameLayout f = new FrameLayout(this);
        swEq = new PillSwitch(this, PillSwitch.ONOFF);
        swEq.setChecked(onPrefs.getBoolean("prefsEQOn1", true));
        swEq.setListener(on -> {
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_EQ_TOGGLE));
            eqView.setAlpha(on ? 1f : 0.4f);
        });
        FrameLayout.LayoutParams l = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        l.rightMargin = dp(5);
        f.addView(swEq, l);

        TextView t = label("EQUALIZER", Studio.SP_TITLE, Studio.WHITE, true);
        f.addView(t, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        return f;
    }

    /** podlogaeq panel with the 210dp black curve view. */
    private View eqPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setBackground(Studio.panel(this, Studio.BLACK));
        p.setPadding(dp(1), dp(1), dp(1), dp(1));
        eqView = new EqView(this);
        p.addView(eqView, new LinearLayout.LayoutParams(-1, dp(Studio.EQ10_H)));
        return p;
    }

    /** [bass on/off]   PRESET + box   [virt on/off] */
    private View toggleRow() {
        FrameLayout f = new FrameLayout(this);
        swBass = new PillSwitch(this, PillSwitch.ONOFF);
        swBass.setChecked(onPrefs.getBoolean("prefsBASSOn1", false));
        swVirt = new PillSwitch(this, PillSwitch.ONOFF);
        swVirt.setChecked(onPrefs.getBoolean("prefsVIRTOn1", false));
        f.addView(swBass, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.BOTTOM));
        f.addView(swVirt, new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.BOTTOM));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        mid.addView(label("PRESET", Studio.SP_TITLE, Studio.WHITE, false), new LinearLayout.LayoutParams(-2, -2));
        presetName = label(pos.getString("PresetName", "Custom"), Studio.SP_TITLE, Studio.CYAN, true);
        presetName.setBackground(Studio.presetBox(this));
        presetName.setSingleLine(true);
        presetName.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        presetName.setMarqueeRepeatLimit(-1);
        presetName.setSelected(true);
        presetName.setOnClickListener(v -> presetDialog());
        mid.addView(presetName, new LinearLayout.LayoutParams(dp(Studio.PRESET_W), dp(Studio.PRESET_H)));
        f.addView(mid, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        swBass.setListener(on -> {
            knobBass.setActive(on);
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_BASS_TOGGLE));
        });
        swVirt.setListener(on -> {
            knobVirt.setActive(on);
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_VIRT_TOGGLE));
        });
        return f;
    }

    /** BASS BOOST knob | VU hex | VIRTUALIZER knob */
    private View knobRow() {
        FrameLayout f = new FrameLayout(this);

        knobBass = new KnobView(this);
        knobBass.setup(1000, pos.getInt("BassLevel", 0), v -> { pos.edit().putInt("BassLevel", v).apply(); if (svc != null) svc.setBass(v); });
        knobBass.setActive(swBass.isChecked());
        knobVirt = new KnobView(this);
        knobVirt.setup(1000, pos.getInt("VirtLevel", 0), v -> { pos.edit().putInt("VirtLevel", v).apply(); if (svc != null) svc.setVirt(v); });
        knobVirt.setActive(swVirt.isChecked());

        f.addView(knobColumn(knobBass, "BASS BOOST"), new FrameLayout.LayoutParams(-2, -2, Gravity.START));
        HexButton vu = new HexButton(this, HexButton.BARS);
        vu.setOnClickListener(v -> vuDialog());
        f.addView(vu, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        f.addView(knobColumn(knobVirt, "VIRTUALIZER"), new FrameLayout.LayoutParams(-2, -2, Gravity.END));
        return f;
    }

    private View knobColumn(KnobView k, String name) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(k, new LinearLayout.LayoutParams(-2, -2));
        TextView t = label(name, Studio.SP_TITLE, Studio.WHITE, false);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.topMargin = dp(3);
        c.addView(t, tp);
        return c;
    }

    // ---------------------------------------------------------------- EQ modes
    private void load10() {
        String saved = getSharedPreferences("eq10_save_prefs", 0).getString("eq10_save_prefs", "");
        if (!saved.isEmpty()) {
            String[] sp = saved.split(",");
            for (int i = 0; i < 10 && i < sp.length; i++) try { Cfg.bands10[i] = Float.parseFloat(sp[i]); } catch (Exception ignored) {}
        }
    }

    private void showEq() {
        swEq.setChecked(onPrefs.getBoolean("prefsEQOn1", true));
        eqView.setAlpha(swEq.isChecked() ? 1f : 0.4f);
        int[] v = new int[10];
        for (int i = 0; i < 10; i++) v[i] = Math.max(0, Math.min(300, Math.round(Cfg.bands10[i] * 10f) + 150));
        eqView.configure(N10, 300, v, (i, p) -> dbText(Math.round((p - 150) / 10f)), this::on10);
    }

    private static String dbText(int v) { return v > 0 ? "+" + v : String.valueOf(v); }

    private void on10(int i, int p) {
        Cfg.bands10[i] = (p - 150) / 10f;
        if (svc != null && swEq.isChecked()) svc.dpEqApply(Cfg.bands10);
        ui.removeCallbacks(save10);
        ui.postDelayed(save10, 300);
        markCustom();
    }

    // ---------------------------------------------------------------- presets
    private void markCustom() {
        if (!"Custom".equals(presetName.getText().toString())) setPresetName("Custom");
    }
    private void setPresetName(String n) {
        presetName.setText(n);
        pos.edit().putString("PresetName", n).apply();
    }

    /** Set all bands (progress values for the current mode) and push them to the service. */
    private void applyValues(int[] vals) {
        for (int i = 0; i < vals.length && i < eqView.count(); i++) {
            eqView.setValue(i, vals[i]);
            on10(i, eqView.getValue(i));
        }
    }

    private int[] builtinValues(float[] db10) {
        int[] v = new int[10];
        for (int i = 0; i < 10; i++) v[i] = Math.max(0, Math.min(300, Math.round((db10[i] + 15f) * 10f)));
        return v;
    }

    private String userPrefix() { return "u10_"; }

    private void presetDialog() {
        final List<String> names = new ArrayList<>();
        final List<int[]> vals = new ArrayList<>();
        final List<String> keys = new ArrayList<>();          // non-null for user presets (deletable)
        for (int i = 0; i < BUILTIN.length; i++) { names.add(BUILTIN_NAMES[i][0]); vals.add(builtinValues(BUILTIN[i])); keys.add(null); }
        for (Map.Entry<String, ?> e : presets.getAll().entrySet()) {
            if (!e.getKey().startsWith(userPrefix())) continue;
            try {
                String[] sp = String.valueOf(e.getValue()).split(",");
                int[] v = new int[sp.length];
                for (int i = 0; i < sp.length; i++) v[i] = Integer.parseInt(sp[i].trim());
                names.add(e.getKey().substring(userPrefix().length())); vals.add(v); keys.add(e.getKey());
            } catch (Exception ignored) {}
        }
        names.add("+ Save current...");
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Preset")
                .setItems(names.toArray(new String[0]), (dd, which) -> {
                    if (which == names.size() - 1) { saveDialog(); return; }
                    applyValues(vals.get(which));
                    setPresetName(names.get(which));
                }).create();
        dlg.show();
        dlg.getListView().setOnItemLongClickListener((p, v, which, id) -> {
            if (which < keys.size() && keys.get(which) != null) {
                presets.edit().remove(keys.get(which)).apply();
                Toast.makeText(this, "Deleted " + names.get(which), Toast.LENGTH_SHORT).show();
                dlg.dismiss();
                return true;
            }
            return false;
        });
    }

    private void saveDialog() {
        final EditText in = new EditText(this);
        in.setSingleLine(true); in.setHint("Preset name");
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Save preset").setView(in)
                .setPositiveButton("Save", (dd, w) -> {
                    String n = in.getText().toString().trim().replace(",", " ");
                    if (n.isEmpty()) return;
                    StringBuilder sb = new StringBuilder();
                    for (int v : eqView.getValues()) sb.append(v).append(",");
                    presets.edit().putString(userPrefix() + n, sb.toString()).apply();
                    setPresetName(n);
                })
                .setNegativeButton("Cancel", null).show();
    }

    // ---------------------------------------------------------------- volume / effects dialog (speaker icon)
    private void volumeDialog() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(20), dp(12), dp(20), dp(4));
        TextView t = label("", 18, Color.WHITE, true);
        SeekBar bar = new SeekBar(this);
        bar.setMax(am.getStreamMaxVolume(3));
        bar.setProgress(am.getStreamVolume(3));
        t.setText(String.format("VOLUME %02d", bar.getProgress()));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                am.setStreamVolume(3, p, 0);
                t.setText(String.format("VOLUME %02d", p));
                if (EqService.volumeLock) EqService.lockedVolume = p;
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        CheckBox lock = new CheckBox(this);
        lock.setText("Lock volume"); lock.setTextColor(Color.WHITE);
        lock.setChecked(EqService.volumeLock);
        lock.setOnCheckedChangeListener((b, on) -> { if (svc != null) svc.setVolumeLock(on); });
        c.addView(t); c.addView(bar); c.addView(lock);
        Dialogs.Svc g = () -> svc;
        c.addView(menuButton("Preamp & Loudness", () -> Dialogs.preampLoudness(this, g)));
        c.addView(menuButton("Balance", () -> Dialogs.balance(this, g)));
        c.addView(menuButton("Limiter", () -> Dialogs.limiter(this, g)));
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setView(c).setPositiveButton("OK", null).show();
    }

    private Button menuButton(String text, Runnable r) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(GREEN); b.setBackground(rounded(0xFF2A2A2C, 12));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
        p.topMargin = dp(8);
        b.setLayoutParams(p);
        return b;
    }

    // ---------------------------------------------------------------- VU meter (Visualizer peak/RMS on the output mix)
    private void vuDialog() {
        final VuView vu = new VuView(this);
        vu.setPadding(dp(20), dp(8), dp(20), dp(8));
        Visualizer vis = null;
        try {
            vis = new Visualizer(Cfg.session);
            vis.setMeasurementMode(Visualizer.MEASUREMENT_MODE_PEAK_RMS);
            vis.setEnabled(true);
        } catch (Throwable e) {
            Toast.makeText(this, "VU needs the microphone permission (RECORD_AUDIO)", Toast.LENGTH_LONG).show();
            if (vis != null) try { vis.release(); } catch (Exception ignored) {}
            return;
        }
        final Visualizer v = vis;
        final Visualizer.MeasurementPeakRms m = new Visualizer.MeasurementPeakRms();
        final Runnable poll = new Runnable() {
            @Override public void run() {
                try {
                    v.getMeasurementPeakRms(m);
                    vu.set(clamp01((m.mPeak + 6000f) / 6000f), clamp01((m.mRms + 6000f) / 6000f));
                } catch (Exception ignored) {}
                ui.postDelayed(this, 50);
            }
        };
        ui.post(poll);
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle("VU").setView(vu)
                .setPositiveButton("Close", null).create();
        dlg.setOnDismissListener(x -> { ui.removeCallbacks(poll); try { v.setEnabled(false); v.release(); } catch (Exception ignored) {} });
        dlg.show();
    }
    private static float clamp01(float f) { return Math.max(0f, Math.min(1f, f)); }
}
