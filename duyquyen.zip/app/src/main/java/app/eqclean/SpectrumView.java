package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.media.audiofx.Visualizer;
import android.view.Choreographer;
import android.view.View;

/**
 * Segmented spectrum (20 bars). Polls Visualizer.getFft() on every display frame (vsync, 60fps+) and smooths
 * with a time-based attack/release, so it moves fluidly instead of at the Visualizer callback rate (<=20Hz).
 */
public class SpectrumView extends View implements Choreographer.FrameCallback {
    public static final int BARS = 20;
    private final float[] levels = new float[BARS];
    private final float[] target = new float[BARS];
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private Visualizer vis;
    private byte[] fft;
    private int sampleRateMilliHz = 44100000;
    private long lastNs = 0;
    private boolean running = false;

    public SpectrumView(Context c) { super(c); d = Studio.dens(c); }

    /** Pass the enabled Visualizer (or null to let the bars fall). */
    public void setVisualizer(Visualizer v) {
        vis = v;
        if (v != null) {
            try { fft = new byte[v.getCaptureSize()]; sampleRateMilliHz = v.getSamplingRate(); } catch (Throwable t) { vis = null; }
        }
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); start(); }
    @Override protected void onDetachedFromWindow() { stop(); super.onDetachedFromWindow(); }
    @Override protected void onVisibilityChanged(View v, int vis) { super.onVisibilityChanged(v, vis); if (vis == VISIBLE && isAttachedToWindow()) start(); }

    private void start() {
        if (running) return;
        running = true; lastNs = 0;
        Choreographer.getInstance().postFrameCallback(this);
    }
    private void stop() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
    }

    private void readFft() {
        Visualizer v = vis;
        if (v == null || fft == null) { for (int i = 0; i < BARS; i++) target[i] = 0; return; }
        try {
            if (v.getFft(fft) != Visualizer.SUCCESS) return;
        } catch (Throwable t) { return; }
        int n = fft.length;
        float binHz = (sampleRateMilliHz / 1000f) / n;
        if (binHz <= 0) return;
        float maxHz = Math.min(16000f, sampleRateMilliHz / 2000f);
        for (int b = 0; b < BARS; b++) {
            float lo = 40f * (float) Math.pow(maxHz / 40f, (float) b / BARS);
            float hi = 40f * (float) Math.pow(maxHz / 40f, (float) (b + 1) / BARS);
            int k0 = Math.max(1, Math.round(lo / binHz)), k1 = Math.max(k0 + 1, Math.round(hi / binHz));
            float mag = 0;
            for (int k = k0; k < k1 && 2 * k + 1 < n; k++) mag = Math.max(mag, (float) Math.hypot(fft[2 * k], fft[2 * k + 1]));
            float db = 20f * (float) Math.log10(mag + 1f);
            target[b] = Math.max(0f, Math.min(1f, (db - 4f) / 38f));
        }
    }

    @Override public void doFrame(long frameTimeNanos) {
        if (!running) return;
        float dt = lastNs == 0 ? 1f / 60f : Math.min(0.05f, (frameTimeNanos - lastNs) / 1e9f);
        lastNs = frameTimeNanos;
        readFft();
        float up = 1f - (float) Math.exp(-dt / 0.020f);     // fast attack
        float down = 1f - (float) Math.exp(-dt / 0.110f);   // smooth release
        boolean any = false;
        for (int i = 0; i < BARS; i++) {
            float t = target[i];
            levels[i] += (t - levels[i]) * (t > levels[i] ? up : down);
            if (levels[i] < 0.002f && t == 0f) levels[i] = 0f; else any = true;
        }
        if (any) invalidate();
        Choreographer.getInstance().postFrameCallback(this);
    }

    private static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cw = w / BARS, cellW = cw * 0.75f;
        float rowH = 3.5f * d, gap = 1f * d;
        int rows = Math.max(1, (int) (h / rowH));
        for (int b = 0; b < BARS; b++) {
            int lit = Math.round(levels[b] * rows);
            float x0 = b * cw + (cw - cellW) / 2f, x1 = x0 + cellW;
            for (int r = 0; r < rows; r++) {
                float yb = h - r * rowH;
                if (r < lit) p.setColor(lerp(Studio.CYAN, 0xFFFFFFFF, Math.max(0f, Math.min(1f, ((float) r / rows - 0.45f) / 0.4f))));
                else p.setColor(0xFF101314);
                c.drawRect(x0, yb - rowH + gap, x1, yb, p);
            }
        }
    }
}
