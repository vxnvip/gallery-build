package app.eqclean;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Full-screen Settings page, Studio look (toolbar + tiled background, rows with icon / title / hint / checkbox). */
public class SettingsActivity extends Activity {
    public static final String KEY_EQ_FROM_NOTIF = "eqFromNotification";

    private EqService svc;
    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Studio.init(this);
        SharedPreferences sp = getSharedPreferences(SettingsDialog.PREFS, 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Studio.tileBg(this));

        // toolbar: black, back arrow + title
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Studio.BLACK);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        IconView back = new IconView(this, IconView.BACK);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(48)));
        TextView title = new TextView(this);
        title.setText("Cài đặt");
        title.setTextColor(Studio.WHITE); title.setTextSize(20); title.setTypeface(Studio.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = dp(8);
        bar.addView(title, tp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(48)));
        View sh = new View(this);
        sh.setBackground(Studio.shadow());
        root.addView(sh, new LinearLayout.LayoutParams(-1, dp(3)));

        // rows
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        row(list, IconView.HEADPHONE, "Tắt khi ngắt kết nối tai nghe",
                "Tắt bộ cân bằng khi tai nghe có dây, USB hoặc Bluetooth bị rút hoặc ngắt kết nối.",
                sp.getBoolean(SettingsDialog.STOP_ON_DISCONNECT, false),
                on -> sp.edit().putBoolean(SettingsDialog.STOP_ON_DISCONNECT, on).apply());

        row(list, IconView.HEADPHONE, "Bật khi kết nối tai nghe",
                "Tự động bật bộ cân bằng khi tai nghe có dây, USB hoặc Bluetooth được kết nối.",
                sp.getBoolean("startOnConnect", false),
                on -> sp.edit().putBoolean("startOnConnect", on).apply());

        row(list, IconView.LOCK, "Khóa âm lượng media",
                "Âm lượng media bị khóa. Chỉ được thay đổi trong ứng dụng Music Volume EQ.",
                EqService.volumeLock,
                on -> {
                    if (svc != null) svc.setVolumeLock(on);
                    else {
                        EqService.volumeLock = on;
                        if (on) EqService.lockedVolume = ((android.media.AudioManager) getSystemService(AUDIO_SERVICE)).getStreamVolume(3);
                    }
                });

        row(list, IconView.EQBARS, "Mở màn hình EQ từ thông báo",
                "Nếu bật, bấm vào thông báo sẽ mở màn hình bộ cân bằng. Nếu tắt sẽ mở màn hình âm lượng. Áp dụng ở lần dịch vụ khởi động tiếp theo.",
                sp.getBoolean(KEY_EQ_FROM_NOTIF, false),
                on -> sp.edit().putBoolean(KEY_EQ_FROM_NOTIF, on).apply());

        ScrollView sc = new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.addView(list, new FrameLayout.LayoutParams(-1, -2));
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unbindService(conn); } catch (Exception ignored) {}
    }

    private interface OnChange { void on(boolean checked); }

    private void row(LinearLayout list, int icon, String name, String hint, boolean checked, OnChange cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), dp(14), dp(14), dp(14));
        r.setBackground(new RippleDrawable(ColorStateList.valueOf(0x558DE3FC), null, new ColorDrawable(0xFFFFFFFF)));

        r.addView(new IconView(this, icon), new LinearLayout.LayoutParams(dp(36), dp(36)));

        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(name); t.setTextColor(Studio.WHITE); t.setTextSize(19); t.setTypeface(Studio.BOLD);
        txt.addView(t, new LinearLayout.LayoutParams(-2, -2));
        TextView h = new TextView(this);
        h.setText(hint); h.setTextColor(Studio.GREY_TXT); h.setTextSize(14); h.setTypeface(Studio.BOLD);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-2, -2);
        hp.topMargin = dp(3);
        txt.addView(h, hp);
        LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(0, -2, 1f);
        xp.leftMargin = dp(16); xp.rightMargin = dp(10);
        r.addView(txt, xp);

        CheckBox c = new CheckBox(this);
        c.setButtonTintList(ColorStateList.valueOf(Studio.CYAN));
        c.setChecked(checked);
        c.setClickable(false); c.setFocusable(false);
        r.addView(c, new LinearLayout.LayoutParams(-2, -2));

        r.setOnClickListener(v -> { c.toggle(); cb.on(c.isChecked()); });
        list.addView(r, new LinearLayout.LayoutParams(-1, -2));

        View line = new View(this);
        line.setBackgroundColor(0xFF2A4A52);
        list.addView(line, new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));
    }

    private int dp(float v) { return Studio.dp(this, v); }
}
