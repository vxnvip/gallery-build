package app.eqclean;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.view.View;

/** Toolbar logo: "MUSIC VOLUME EQ" in a dotted pixel look (drawn, no bitmap). 240 x 14 dp like logo_toolbar_studio. */
public class LogoView extends View {
    private Bitmap bmp;
    private final float d;

    public LogoView(Context c) { super(c); d = Studio.dens(c); }

    @Override protected void onMeasure(int ws, int hs) { setMeasuredDimension((int) (240 * d), (int) (24 * d)); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        if (w <= 0 || h <= 0) return;
        float th = 14 * d;
        bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD));
        t.setColor(0xFFD2D2D2);
        t.setTextSize(th * 1.05f);
        String s = "MUSIC VOLUME EQ";
        float tw = t.measureText(s);
        t.setTextScaleX(Math.min(1.6f, (w - 2 * d) / tw));
        Rect r = new Rect();
        t.getTextBounds("M", 0, 1, r);
        c.drawText(s, 0, (h + r.height()) / 2f, t);
        // dot mask
        Bitmap mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas mc = new Canvas(mask);
        Paint m = new Paint(Paint.ANTI_ALIAS_FLAG);
        m.setColor(0xFFFFFFFF);
        float step = 1.6f * d;
        for (float y = step / 2; y < h; y += step)
            for (float x = step / 2; x < w; x += step) mc.drawCircle(x, y, step * 0.42f, m);
        Paint x = new Paint();
        x.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawBitmap(mask, 0, 0, x);
        mask.recycle();
    }

    @Override protected void onDraw(Canvas c) { if (bmp != null) c.drawBitmap(bmp, 0, 0, null); }
}
