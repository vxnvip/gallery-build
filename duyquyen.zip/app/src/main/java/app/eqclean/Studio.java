package app.eqclean;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

/**
 * Studio theme: palette, metrics and procedural drawables.
 * Metrics follow the original values/dimens.xml + values-sw***dp overrides (see init()).
 */
public final class Studio {
    private Studio() {}

    public static final int CYAN = 0xFF8DE3FC;      // measured from the original screenshots
    public static final int WHITE = 0xFFFFFFFF;
    public static final int BLACK = 0xFF000000;
    public static final int PANEL = 0xFF1A1C1B;     // fader panel
    public static final int BORDER = 0xFF414141;    // panel outline
    public static final int EDGE = 0xFF232424;      // idle toggle stroke
    public static final int GREY_TXT = 0xFF888F99;  // EQ frequency / value labels
    public static final int GUIDE = 0xFF2B2E33;     // EQ band guide lines

    // metrics (dp / sp), defaults = values/dimens.xml
    public static float ONOFF_W = 64, ONOFF_H = 29;
    public static float BTN_W = 40, BTN_H = 15;
    public static float HEX = 60;
    public static float WHEEL = 88;
    public static float PRESET_W = 98, PRESET_H = 28;
    public static float EKRAN_W = 180, SLIDER_H = 310;
    public static float FADER_W = 72;
    public static float EQ10_H = 210;
    public static float EQ_MARGIN = 3;
    public static float SP_SMALL = 9, SP_BUTTON = 11, SP_BAR = 12, SP_TITLE = 12;

    public static final Typeface THIN = Typeface.create("sans-serif-light", Typeface.NORMAL);
    public static final Typeface BOLD = Typeface.DEFAULT_BOLD;
    public static final Typeface MONO = Typeface.MONOSPACE;

    /** Same resolution as Android: every values-swNNNdp that fits overrides the previous ones. */
    public static void init(Context c) {
        int sw = c.getResources().getConfiguration().smallestScreenWidthDp;
        ONOFF_W = 64; ONOFF_H = 29; BTN_W = 40; BTN_H = 15; HEX = 60; WHEEL = 88;
        PRESET_W = 98; PRESET_H = 28; EKRAN_W = 180; SLIDER_H = 310; FADER_W = 72; EQ10_H = 210;
        EQ_MARGIN = 3; SP_SMALL = 9; SP_BUTTON = 11; SP_BAR = 12; SP_TITLE = 12;
        if (sw >= 320) { EQ_MARGIN = 8; }
        if (sw >= 360) {
            FADER_W = 78; EKRAN_W = 186; SLIDER_H = 350; BTN_H = 20; BTN_W = 50; EQ10_H = 342;
            SP_SMALL = 10; SP_BAR = 14; SP_TITLE = 14; HEX = 73; ONOFF_W = 70; ONOFF_H = 32;
            PRESET_W = 112; PRESET_H = 32; WHEEL = 100;
        }
        if (sw >= 400) {
            FADER_W = 90; EKRAN_W = 226; SLIDER_H = 430; EQ10_H = 300; HEX = 80; ONOFF_W = 73; ONOFF_H = 33;
            PRESET_W = 125; PRESET_H = 36; WHEEL = 110;
        }
        if (sw >= 480) {
            FADER_W = 83; EKRAN_W = 186; SLIDER_H = 350; BTN_W = 80; EQ10_H = 380; EQ_MARGIN = 20;
            SP_SMALL = 14; SP_BAR = 18; SP_TITLE = 18; HEX = 96; ONOFF_W = 80; PRESET_W = 157; PRESET_H = 45; WHEEL = 130;
        }
        if (sw >= 600) { FADER_W = 100; EKRAN_W = 350; SLIDER_H = 630; EQ10_H = 440; ONOFF_W = 100; ONOFF_H = 41; }
        if (sw >= 720) {
            EKRAN_W = 460; SLIDER_H = 700; BTN_H = 30; SP_BUTTON = 18; BTN_W = 122; EQ_MARGIN = 25;
            SP_TITLE = 22; ONOFF_H = 45; WHEEL = 150;
        }
    }

    public static float dens(Context c) { return c.getResources().getDisplayMetrics().density; }
    public static int dp(Context c, float v) { return (int) (v * dens(c) + 0.5f); }

    /** back_studio: tiled dark grid with a diagonal and a soft dot in each tile (56dp tile). */
    public static Drawable tileBg(Context c) {
        float d = dens(c);
        int s = Math.max(8, Math.round(56 * d));
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        cv.drawColor(0xFF0A0A0A);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFF16262A);
        p.setStrokeWidth(Math.max(1f, d * 0.8f));
        for (int i = 0; i < 4; i++) {
            float v = s * (i + 0.5f) / 4f;
            cv.drawLine(v, 0, v, s, p);
            cv.drawLine(0, v, s, v, p);
        }
        p.setColor(0xFF14232A);
        p.setStrokeWidth(d * 1.6f);
        cv.drawLine(0, s, s, 0, p);
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(s / 2f, s / 2f, 5 * d, 0xFF1D3236, 0x00000000, Shader.TileMode.CLAMP));
        cv.drawCircle(s / 2f, s / 2f, 5 * d, g);
        BitmapDrawable bd = new BitmapDrawable(c.getResources(), b);
        bd.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        return bd;
    }

    /** Rounded panel with the grey outline seen in the original (ekran / fader / EQ panels). */
    public static GradientDrawable panel(Context c, int fill) {
        float d = dens(c);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(8 * d);
        g.setStroke(Math.max(1, Math.round(2 * d)), BORDER);
        return g;
    }

    /** podloga_preset_studio: black box, thin white outline. */
    public static GradientDrawable presetBox(Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(BLACK);
        g.setCornerRadius(3 * dens(c));
        g.setStroke(Math.max(1, Math.round(1f * dens(c))), WHITE);
        return g;
    }

    /** sjena: toolbar shadow, black at the top fading out downwards. */
    public static GradientDrawable shadow() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF000000, 0x80000000, 0x00000000});
    }
}
