package app.eqclean;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

/** Studio theme: palette, metrics (same values as the original dimens.xml) and procedural drawables. */
public final class Studio {
    private Studio() {}

    public static final int CYAN = 0xFF6DE5FF;      // plava_studio
    public static final int WHITE = 0xFFFFFFFF;     // bijela
    public static final int BLACK = 0xFF000000;
    public static final int PANEL = 0xFF191C1B;     // podlogaeq fill
    public static final int EDGE = 0xFF232424;      // idle toggle stroke

    // dimens.xml
    public static final float ONOFF_W = 64, ONOFF_H = 29;       // onoff_sirina / onoff_visina
    public static final float BTN_W = 40, BTN_H = 15;           // button_width / button_height
    public static final float HEX = 60;                         // fwdrev2
    public static final float WHEEL = 88;                       // wheel_bass
    public static final float PRESET_W = 98, PRESET_H = 28;     // preset_sirina / preset_visina
    public static final float EKRAN_W = 180, SLIDER_H = 310;    // bar2_sirina_slider_vu / bar_visina_slider
    public static final float FADER_W = 72;                     // bar2_sirina_slider
    public static final float EQ10_H = 210;                     // eq10_visina
    public static final float SP_SMALL = 9, SP_BUTTON = 11, SP_TITLE = 12;   // eq_text / button_text / eqnaslov_text

    public static final Typeface THIN = Typeface.create("sans-serif-light", Typeface.NORMAL);
    public static final Typeface MONO = Typeface.MONOSPACE;

    public static float dens(Context c) { return c.getResources().getDisplayMetrics().density; }
    public static int dp(Context c, float v) { return (int) (v * dens(c) + 0.5f); }

    /** back_studio: tiled dark grid with a diagonal and a soft dot in the middle of each tile (56dp tile). */
    public static Drawable tileBg(Context c) {
        float d = dens(c);
        int s = Math.max(8, Math.round(56 * d));
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        cv.drawColor(0xFF080B0C);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFF15262A);
        p.setStrokeWidth(Math.max(1f, d * 0.8f));
        for (int i = 0; i < 4; i++) {
            float v = s * (i + 0.5f) / 4f;
            cv.drawLine(v, 0, v, s, p);
            cv.drawLine(0, v, s, v, p);
        }
        p.setColor(0xFF12201F);
        p.setStrokeWidth(d * 1.6f);
        cv.drawLine(0, s, s, 0, p);
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(s / 2f, s / 2f, 5 * d, 0xFF1D3236, 0x00000000, Shader.TileMode.CLAMP));
        cv.drawCircle(s / 2f, s / 2f, 5 * d, g);
        BitmapDrawable bd = new BitmapDrawable(c.getResources(), b);
        bd.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        return bd;
    }

    /** podloga / podlogaeq: solid rounded (5dp) panel. */
    public static GradientDrawable panel(Context c, int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(5 * dens(c));
        return g;
    }

    /** podloga_preset_studio: black box, 0.5dp white outline, 3dp corners. */
    public static GradientDrawable presetBox(Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(BLACK);
        g.setCornerRadius(3 * dens(c));
        g.setStroke(Math.max(1, Math.round(0.5f * dens(c))), WHITE);
        return g;
    }

    /** sjena: toolbar shadow, black at the top fading out downwards. */
    public static GradientDrawable shadow() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF000000, 0x80000000, 0x00000000});
    }
}
