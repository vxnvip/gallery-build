package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Tiny vector icons for the header: back arrow and speaker. */
public class IconView extends View {
    public static final int BACK = 0, SPEAKER = 1, MENU = 2, FULLSCREEN = 3, DOTS = 4,
            EQBARS = 5, GEAR = 6, SHARE = 7, STAR = 8;
    private int type;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public IconView(Context c, int type) {
        super(c);
        this.type = type;
        d = c.getResources().getDisplayMetrics().density;
        p.setColor(0xFFEDEDED); p.setStrokeWidth(2.6f * d); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setType(int t) { if (type != t) { type = t; invalidate(); } }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, u = 11 * d;
        p.setStyle(Paint.Style.STROKE);
        if (type == BACK) {
            c.drawLine(cx - u, cy, cx + u, cy, p);
            c.drawLine(cx - u, cy, cx - u * 0.1f, cy - u * 0.9f, p);
            c.drawLine(cx - u, cy, cx - u * 0.1f, cy + u * 0.9f, p);
        } else if (type == MENU) {
            c.drawLine(cx - u, cy - u * 0.7f, cx + u, cy - u * 0.7f, p);
            c.drawLine(cx - u, cy, cx + u, cy, p);
            c.drawLine(cx - u, cy + u * 0.7f, cx + u, cy + u * 0.7f, p);
        } else if (type == FULLSCREEN) {
            float a = u * 0.95f, b = u * 0.45f;
            for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) {
                c.drawLine(cx + sx * a, cy + sy * a, cx + sx * (a - b), cy + sy * a, p);
                c.drawLine(cx + sx * a, cy + sy * a, cx + sx * a, cy + sy * (a - b), p);
            }
        } else if (type == DOTS) {
            p.setStyle(Paint.Style.FILL);
            for (int i = -1; i <= 1; i++) c.drawCircle(cx, cy + i * u * 0.75f, 2.6f * d, p);
        } else if (type == EQBARS) {
            p.setStyle(Paint.Style.FILL);
            c.drawRect(cx - u, cy - u * 0.1f, cx - u * 0.45f, cy + u, p);
            c.drawRect(cx - u * 0.27f, cy - u, cx + u * 0.27f, cy + u, p);
            c.drawRect(cx + u * 0.45f, cy + u * 0.25f, cx + u, cy + u, p);
        } else if (type == GEAR) {
            c.drawCircle(cx, cy, u * 0.62f, p);
            p.setStrokeCap(Paint.Cap.BUTT); p.setStrokeWidth(u * 0.5f);
            for (int i = 0; i < 8; i++) {
                double an = Math.PI / 4 * i;
                float cs = (float) Math.cos(an), sn = (float) Math.sin(an);
                c.drawLine(cx + cs * u * 0.85f, cy + sn * u * 0.85f, cx + cs * u * 1.08f, cy + sn * u * 1.08f, p);
            }
            p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(2.6f * d);
        } else if (type == SHARE) {
            float ax = cx - u * 0.7f, ay = cy, bx = cx + u * 0.7f, by = cy - u * 0.8f, qx = cx + u * 0.7f, qy = cy + u * 0.8f;
            p.setStrokeWidth(1.8f * d);
            c.drawLine(ax, ay, bx, by, p); c.drawLine(ax, ay, qx, qy, p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(ax, ay, u * 0.32f, p); c.drawCircle(bx, by, u * 0.32f, p); c.drawCircle(qx, qy, u * 0.32f, p);
            p.setStrokeWidth(2.6f * d);
        } else if (type == STAR) {
            p.setStyle(Paint.Style.FILL);
            Path st = new Path();
            for (int i = 0; i < 10; i++) {
                double an = -Math.PI / 2 + Math.PI / 5 * i;
                float r = (i % 2 == 0) ? u * 1.1f : u * 0.46f;
                float px = cx + (float) Math.cos(an) * r, py = cy + (float) Math.sin(an) * r;
                if (i == 0) st.moveTo(px, py); else st.lineTo(px, py);
            }
            st.close();
            c.drawPath(st, p);
        } else {
            p.setStyle(Paint.Style.FILL);
            Path s = new Path();
            s.moveTo(cx - u, cy - u * 0.4f); s.lineTo(cx - u * 0.4f, cy - u * 0.4f);
            s.lineTo(cx + u * 0.3f, cy - u); s.lineTo(cx + u * 0.3f, cy + u);
            s.lineTo(cx - u * 0.4f, cy + u * 0.4f); s.lineTo(cx - u, cy + u * 0.4f); s.close();
            c.drawPath(s, p);
            p.setStyle(Paint.Style.STROKE);
            c.drawArc(cx - u * 0.2f, cy - u * 0.6f, cx + u * 0.9f, cy + u * 0.6f, -55, 110, false, p);
            c.drawArc(cx - u * 0.2f, cy - u * 1.0f, cx + u * 1.4f, cy + u * 1.0f, -55, 110, false, p);
        }
    }
}
