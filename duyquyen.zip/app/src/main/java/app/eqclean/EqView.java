package app.eqclean;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.View;

/**
 * 10-band equalizer (EqualizerView, Studio colours): black field, band guides, 0 dB line,
 * smooth cyan curve with a cyan->transparent fill, cyan knobs. Frequency on top, dB value at the bottom.
 */
public class EqView extends View {
    public interface Listener { void onChange(int index, int value); }
    public interface Labeler { String label(int index, int value); }

    private String[] names = new String[0];
    private int[] values = new int[0];
    private int max = 100;
    private Labeler labeler;
    private Listener listener;
    private final SparseIntArray pointers = new SparseIntArray();
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint guide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint curve = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint curveGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private float yTop, yBot, padX, colW;

    public EqView(Context c) {
        super(c);
        d = Studio.dens(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Studio.MONO); text.setTextSize(11 * d);
        grid.setColor(0x30FFFFFF); grid.setStrokeWidth(Math.max(1f, 0.8f * d));
        guide.setColor(0x24FFFFFF); guide.setStrokeWidth(Math.max(1f, 0.8f * d));
        curve.setColor(Studio.CYAN); curve.setStyle(Paint.Style.STROKE); curve.setStrokeWidth(3 * d); curve.setStrokeJoin(Paint.Join.ROUND);
        curveGlow.set(curve); curveGlow.setStrokeWidth(6 * d); curveGlow.setAlpha(150);
        curveGlow.setMaskFilter(new BlurMaskFilter(5 * d, BlurMaskFilter.Blur.NORMAL));
        fill.setStyle(Paint.Style.FILL);
        knob.setColor(Studio.CYAN); knob.setAlpha(0xE6);
        halo.setColor(Studio.WHITE); halo.setAlpha(0x5A);
    }

    public void configure(String[] names, int max, int[] values, Labeler labeler, Listener listener) {
        this.names = names; this.max = max; this.values = values.clone();
        this.labeler = labeler; this.listener = listener;
        invalidate();
    }
    public void setValue(int i, int v) { if (i >= 0 && i < values.length) { values[i] = Math.max(0, Math.min(max, v)); invalidate(); } }
    public int getValue(int i) { return values[i]; }
    public int[] getValues() { return values.clone(); }
    public int count() { return values.length; }

    private float px(int i) { return padX + colW * (i + 0.5f); }
    private float py(int v) { return yBot - (float) v / max * (yBot - yTop); }

    @Override protected void onDraw(Canvas c) {
        int n = values.length;
        if (n == 0) return;
        float w = getWidth(), h = getHeight();
        float r = 9 * d;
        padX = 4 * d; colW = (w - 2 * padX) / n;
        float areaTop = 28 * d, areaBot = h - 26 * d;
        yTop = areaTop + r; yBot = areaBot - r;

        // 5 dB grid (+-15 range => 7 lines), 0 dB line brighter
        for (int g = 0; g <= 6; g++) {
            float y = yTop + (yBot - yTop) * g / 6f;
            grid.setAlpha(g == 3 ? 0x80 : 0x30);
            c.drawLine(padX, y, w - padX, y, grid);
        }
        for (int i = 0; i < n; i++) c.drawLine(px(i), areaTop, px(i), areaBot, guide);

        // labels
        text.setColor(Studio.WHITE);
        for (int i = 0; i < n; i++) c.drawText(names[i], px(i), 17 * d, text);
        text.setColor(Studio.CYAN);
        for (int i = 0; i < n; i++)
            c.drawText(labeler != null ? labeler.label(i, values[i]) : String.valueOf(values[i]), px(i), h - 8 * d, text);

        float[] xs = new float[n], ys = new float[n];
        for (int i = 0; i < n; i++) { xs[i] = px(i); ys[i] = py(values[i]); }
        Path line = new Path();
        line.moveTo(xs[0], ys[0]);
        for (int i = 0; i < n - 1; i++) {
            int p0 = Math.max(0, i - 1), p3 = Math.min(n - 1, i + 2);
            float c1x = xs[i] + (xs[i + 1] - xs[p0]) / 6f, c1y = ys[i] + (ys[i + 1] - ys[p0]) / 6f;
            float c2x = xs[i + 1] - (xs[p3] - xs[i]) / 6f, c2y = ys[i + 1] - (ys[p3] - ys[i]) / 6f;
            c1y = Math.max(yTop, Math.min(yBot, c1y)); c2y = Math.max(yTop, Math.min(yBot, c2y));
            line.cubicTo(c1x, c1y, c2x, c2y, xs[i + 1], ys[i + 1]);
        }
        Path area = new Path(line);
        area.lineTo(xs[n - 1], areaBot); area.lineTo(xs[0], areaBot); area.close();
        fill.setShader(new LinearGradient(0, yTop, 0, areaBot, 0x80000000 | (Studio.CYAN & 0xFFFFFF), 0x00000000, Shader.TileMode.CLAMP));
        c.drawPath(area, fill);

        c.drawPath(line, curveGlow);
        c.drawPath(line, curve);
        for (int i = 0; i < n; i++) {
            if (pointers.indexOfValue(i) >= 0) c.drawCircle(xs[i], ys[i], r + 5 * d, halo);
            c.drawCircle(xs[i], ys[i], r, knob);
        }
    }

    private void update(int col, float y) {
        if (col < 0 || col >= values.length) return;
        int v = Math.round((yBot - y) / (yBot - yTop) * max);
        v = Math.max(0, Math.min(max, v));
        if (v != values[col]) {
            values[col] = v;
            invalidate();
            if (listener != null) listener.onChange(col, v);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (values.length == 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int k = e.getActionIndex();
                int col = (int) ((e.getX(k) - padX) / colW);
                col = Math.max(0, Math.min(values.length - 1, col));
                pointers.put(e.getPointerId(k), col);
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                update(col, e.getY(k));
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                for (int k = 0; k < e.getPointerCount(); k++) update(pointers.get(e.getPointerId(k), -1), e.getY(k));
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                pointers.delete(e.getPointerId(e.getActionIndex()));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pointers.clear();
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }
}
