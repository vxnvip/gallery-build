package app.eqclean;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.view.View;
import android.widget.RemoteViews;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.audiofx.BassBoost;
import android.media.audiofx.DynamicsProcessing;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.Virtualizer;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Audio engine. Ported from hr.podlanica.MusicVolumeEQ (v7.0).
 * 1:1 = same effects, same math, same prefs keys. Parts marked [RECONSTRUCTED] / [INFERRED]
 * were NOT recoverable from the decompile (see README).
 */
@SuppressLint("NewApi")
public class EqService extends Service {
    public static final String ACTION_EQ_TOGGLE = "hr.podlanica.action.ACTION_EQ_TOGGLE";
    public static final String ACTION_BASS_TOGGLE = "hr.podlanica.action.ACTION_BASS_TOGGLE";
    public static final String ACTION_VIRT_TOGGLE = "hr.podlanica.action.ACTION_VIRT_TOGGLE";
    public static final String ACTION_SET_EQ10 = "hr.podlanica.action.ACTION_SET_EQ10";
    public static final String ACTION_RELAISE_EQ10 = "hr.podlanica.action.ACTION_RELAISE_EQ10";
    public static final String ACTION_LOUDNESS = "hr.podlanica.action.ACTION_LOUDNESS";
    public static final String ACTION_PREAMP = "hr.podlanica.action.ACTION_PREAMP";
    /** explicit on/off (no toggling): extras "which" = eq | bass | virt, "on" = boolean */
    public static final String ACTION_SET_STATE = "app.eqclean.action.SET_STATE";
    public static final String ACTION_LIMITER = "hr.podlanica.MusicVolumeEQ.ACTION_LIMITER";
    static final int[] DP_CUTOFFS = {32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000}; // f17981z

    public static volatile boolean running = false;
    // effects (U, V, W)
    public static Equalizer eq;
    public static BassBoost bass;
    public static Virtualizer virt;
    // flags (X, Y, Z)
    public static boolean eqOn, bassOn, virtOn;
    // 5-band slider positions (f17960a0 .. f17964e0): 60Hz=band0, 230=band1, 910=band2, 3k=band3, 14k=band4
    public static int pos60, pos230, pos910, pos3k, pos14k;
    public static int bassLevel, virtLevel;            // f17965f0, f17966g0 (0..1000)
    public static short minLevel, maxLevel;            // f17967h0, f17968i0

    private DynamicsProcessing dp;
    private DynamicsProcessing.Limiter limiter;
    private DynamicsProcessing.Mbc mbc;
    private DynamicsProcessing.Eq dpEq;
    private LoudnessEnhancer loudnessEnhancer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;
    private AudioManager audioManager;
    private AudioDeviceCallback deviceCallback;
    private AudioSessionReceiver sessionReceiver;
    private String deviceType = Cfg.DEVICE_KEYS[0];
    private final IBinder binder = new LocalBinder();
    // Volume lock (R, S, runnable Q): every 1 s, if stream volume != saved value -> restore it
    public static boolean volumeLock = false;   // R
    public static int lockedVolume = 0;         // S
    private final Runnable lockRunnable = new Runnable() {
        @Override public void run() {
            if (volumeLock) {
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                if (am.getStreamVolume(3) != lockedVolume) {
                    am.setStreamVolume(3, lockedVolume, 0);
                    android.widget.Toast.makeText(EqService.this, "Volume locked", android.widget.Toast.LENGTH_SHORT).show();
                }
            }
            handler.postDelayed(this, 1000L);
        }
    };
    public void setVolumeLock(boolean on) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (on) lockedVolume = am.getStreamVolume(3);
        volumeLock = on;
        handler.removeCallbacks(lockRunnable);
        if (on) handler.post(lockRunnable);
    }
    /** Loudness: Cfg.loudness already set by caller. (ACTION_LOUDNESS) */
    public void applyLoudness() {
        if (Cfg.loudness == 0) loudnessOff(); else { loudnessOn(); setLoudness(Cfg.loudness); }
    }

    public class LocalBinder extends Binder { public EqService get() { return EqService.this; } }

    public static void start(Context c) {
        Intent i = new Intent(c, EqService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    // ---------- effect creation (J, K, M) ----------
    private static Equalizer ensureEq() {
        if (eq == null) { eq = new Equalizer(Cfg.PRIORITY, Cfg.session); eq.setEnabled(true); }
        return eq;
    }
    public static synchronized BassBoost ensureBass() {
        if (bass == null) { bass = new BassBoost(Cfg.PRIORITY, Cfg.session); bass.setEnabled(true); }
        return bass;
    }
    public static synchronized Virtualizer ensureVirt() {
        if (virt == null) { virt = new Virtualizer(Cfg.PRIORITY, Cfg.session); virt.setEnabled(true); }
        return virt;
    }
    public static void eqStart() { try { ensureEq(); minLevel = eq.getBandLevelRange()[0]; maxLevel = eq.getBandLevelRange()[1]; } catch (Exception ignored) {} } // s()
    public static void eqRelease() { if (eq != null) { eq.setEnabled(false); eq.release(); eq = null; } }                    // r()
    public static void bassStart() { try { ensureBass(); } catch (Exception ignored) {} }                                    // f()
    public static void bassRelease() { if (bass != null) { bass.setEnabled(false); bass.release(); bass = null; } }          // e()
    public static void virtStart() { try { ensureVirt(); } catch (Exception ignored) {} }                                    // y()
    public static void virtRelease() { if (virt != null) { virt.setEnabled(false); virt.release(); virt = null; } }          // x()

    // ---------- 5-band (i,k,m,o,q + h,j,l,n,p) ----------
    /** scaled = pos * (range / viewHeight); level = scaled + min, clamped to max-1. Identical math to original. */
    public static void setBand(int band, int pos) {
        if (!eqOn) return;
        int range = maxLevel - minLevel;
        if (range == 0) range = 3000;
        double scaled = pos * ((double) range / Cfg.viewHeight);
        double level = scaled + minLevel;
        if (level >= maxLevel) level = maxLevel - 1;
        try { eq.setBandLevel((short) band, (short) level); } catch (Exception ignored) {}
    }
    /** dB label shown in original UI: (scaled+min)/95, capped at 15, "+" prefix when > 0. */
    public static String bandLabel(int pos) {
        int range = maxLevel - minLevel;
        if (range == 0) range = 3000;
        double scaled = pos * ((double) range / Cfg.viewHeight);
        int v = (((int) scaled) + minLevel) / 95;
        if (v > 15) v = 15;
        return v > 0 ? "+" + v : String.valueOf(v);
    }
    public void set60(int p)  { pos60 = p;  setBand(0, p); }
    public void set230(int p) { pos230 = p; setBand(1, p); }
    public void set910(int p) { pos910 = p; setBand(2, p); }
    public void set3k(int p)  { pos3k = p;  setBand(3, p); }
    public void set14k(int p) { pos14k = p; setBand(4, p); }

    public void setBass(int v) { bassLevel = v; if (bassOn) try { bass.setStrength((short) v); } catch (Exception ignored) {} }  // g()
    public void setVirt(int v) { virtLevel = v; if (virtOn) try { virt.setStrength((short) v); } catch (Exception ignored) {} } // z()

    // ---------- loudness (L, t, u, v) ----------
    public synchronized LoudnessEnhancer loudness() {
        if (loudnessEnhancer == null && Cfg.loudness > 0) {
            loudnessEnhancer = new LoudnessEnhancer(Cfg.session);
            loudnessEnhancer.setEnabled(true);
        }
        return loudnessEnhancer;
    }
    public void setLoudness(int mB) {                       // t(i)
        if (loudnessEnhancer == null) { try { loudness(); } catch (Exception ignored) {} }
        try {
            if (loudnessEnhancer != null) loudnessEnhancer.setTargetGain(mB); else Cfg.loudness = 0;
        } catch (Exception e) { System.out.println("GOTCHA EX " + e); }
    }
    public void loudnessOff() {                              // u()
        if (loudnessEnhancer != null) { loudnessEnhancer.setEnabled(false); loudnessEnhancer.release(); loudnessEnhancer = null; }
    }
    public void loudnessOn() { try { loudness(); } catch (Exception ignored) {} }   // v()

    // ---------- DynamicsProcessing (O, P, U, Y, Z, a0, c0, d0) ----------
    private void dpInit() {                                  // O()
        if (Build.VERSION.SDK_INT < 28 || dp != null) return;
        try {
            DynamicsProcessing.Config.Builder b = new DynamicsProcessing.Config.Builder(0, 2, true, 10, true, 10, false, 10, true);
            b.setPreferredFrameDuration(10.0f);
            DynamicsProcessing.Config cfg = b.build();
            if (limiter == null) limiter = new DynamicsProcessing.Limiter(Cfg.limEnabled, Cfg.limInUse, Cfg.limLinkGroup,
                    Cfg.limAttack, Cfg.limRelease, Cfg.limRatio, Cfg.limThreshold, Cfg.limPostGain);
            if (!limiter.isEnabled()) limiter.setEnabled(true);
            if (dp == null) dp = new DynamicsProcessing(Integer.MAX_VALUE, Cfg.session, cfg);
            if (!dp.getEnabled()) dp.setEnabled(true);
        } catch (Exception e) { System.out.println(e.getMessage()); }
        try { dp.setLimiterAllChannelsTo(limiter); } catch (Exception e) { System.out.println(e.getMessage()); }
    }
    private void dpEqInit() {                                // P()
        if (dpEq == null && Build.VERSION.SDK_INT >= 28 && Cfg.tenBand) {
            dpEq = new DynamicsProcessing.Eq(true, true, Cfg.DP_BANDS);
            dpEq.setEnabled(true);
            for (int i = 0; i < Cfg.DP_BANDS; i++) {
                try { dpEq.getBand(i).setCutoffFrequency(DP_CUTOFFS[i]); } catch (Exception e) { e.printStackTrace(); }
            }
            dpEqApply(Cfg.bands10);
        }
    }
    public void dpEqApply(float[] gains) {                   // a0()
        if (Build.VERSION.SDK_INT < 28 || !Cfg.tenBand) return;
        if (dpEq == null) dpEqInit();
        if (dp == null) dpInit();
        if (dpEq == null || dp == null) return;
        for (int i = 0; i < Cfg.DP_BANDS; i++) {
            try {
                DynamicsProcessing.EqBand band = dpEq.getBand(i);
                band.setEnabled(true);
                band.setGain(gains[i]);
                dp.setPreEqBandAllChannelsTo(i, band);
            } catch (UnsupportedOperationException e) { e.printStackTrace(); return; }
        }
    }
    private void dpRelease() {                               // U()
        try {
            if (dp != null) { dp.setEnabled(false); dp.release(); dp = null; }
            if (limiter != null) { limiter.setEnabled(false); limiter = null; }
        } catch (Exception ignored) {}
    }
    public void applyBalance() {                             // Y()
        if (Build.VERSION.SDK_INT < 28) return;
        if (dp == null) dpInit();
        float f5 = Cfg.balance, left = 0f, right = 0f;
        if (f5 > 50f) left = -(f5 - 50f); else if (f5 < 50f) right = -(50f - f5);
        try { dp.setInputGainbyChannel(0, left); dp.setInputGainbyChannel(1, right); } catch (Exception e) { System.out.println(e.getMessage()); }
    }
    public void applyPreamp() {                              // d0()
        if (dp == null) dpInit();
        int i = Cfg.preamp;
        try { dp.setInputGainAllChannelsTo(i < 20 ? 0.0f - (20.0f - i) : 0.0f + (20.0f - (40.0f - i))); } catch (Exception e) { e.printStackTrace(); }
    }
    public void applyLimiter() {                             // c0()
        if (Build.VERSION.SDK_INT < 28) return;
        if (dp == null) dpInit();
        try {
            if (limiter == null) limiter = new DynamicsProcessing.Limiter(Cfg.limEnabled, Cfg.limInUse, Cfg.limLinkGroup,
                    Cfg.limAttack, Cfg.limRelease, Cfg.limRatio, Cfg.limThreshold, Cfg.limPostGain);
            if (!limiter.isEnabled()) { limiter.setEnabled(true); if (!dp.getEnabled()) { dp.setEnabled(true); dp.setLimiterAllChannelsTo(limiter); } }
        } catch (Exception e) { System.out.println(e.getMessage()); }
        try {
            if (limiter == null || !limiter.isEnabled()) return;
            limiter.setAttackTime(Cfg.limAttack);
            limiter.setReleaseTime(Cfg.limRelease);
            limiter.setRatio(Cfg.limRatio);
            limiter.setThreshold(Cfg.limThreshold);
            limiter.setPostGain(Cfg.limPostGain);
            dp.setLimiterAllChannelsTo(limiter);
        } catch (Exception e) { System.out.println(e.getMessage()); }
    }
    /** Z() - MBC setup. [INFERRED] setter order: Android API wrapper bodies were stripped by the decompiler. Original never calls it from recoverable code. */
    public void setupMbc() {
        if (Build.VERSION.SDK_INT < 28) return;
        if (dp == null) dpInit();
        try {
            if (mbc == null) mbc = new DynamicsProcessing.Mbc(true, true, Cfg.DP_BANDS);
            if (!mbc.isEnabled()) { mbc.setEnabled(true); if (!dp.getEnabled()) { dp.setEnabled(true); dp.setMbcAllChannelsTo(mbc); } }
        } catch (Exception e) { System.out.println(e.getMessage()); }
        try {
            if (mbc == null || !mbc.isEnabled()) return;
            for (int i = 0; i < Cfg.DP_BANDS; i++) {
                try {
                    DynamicsProcessing.MbcBand b = mbc.getBand(i);
                    b.setEnabled(true); b.setAttackTime(3.0f); b.setReleaseTime(80.0f); b.setRatio(1.0f);
                    b.setThreshold(-45.0f); b.setKneeWidth(0.0f); b.setPostGain(10.0f);   // [INFERRED]
                    b.setNoiseGateThreshold(-90.0f); b.setExpanderRatio(1.0f);
                } catch (UnsupportedOperationException e) { e.printStackTrace(); }
            }
            dp.setMbcAllChannelsTo(mbc);
        } catch (Exception e) { System.out.println(e.getMessage()); }
    }

    // ---------- toggles (R, S, T) ----------
    private SharedPreferences on() { return getSharedPreferences("prefsEQOn", 0); }
    private void toggleBass() {
        bassOn = on().getBoolean("prefsBASSOn1", false);
        if (bassOn) { bassOn = false; bassRelease(); on().edit().putBoolean("prefsBASSOn1", false).apply(); }
        else { bassOn = true; bassStart(); on().edit().putBoolean("prefsBASSOn1", true).apply(); }
    }
    public static Intent stateIntent(Context c, String which, boolean on) {
        return new Intent(c, EqService.class).setAction(ACTION_SET_STATE).putExtra("which", which).putExtra("on", on);
    }

    /**
     * EQ on/off. OFF = the same hard stop used on headphone disconnect: the DynamicsProcessing effect is fully
     * released, so nothing is left on the output. ON = recreate it, apply the saved bands (+ preamp / balance).
     */
    public void dpEqSet(boolean enable) {
        if (Build.VERSION.SDK_INT < 28 || !Cfg.tenBand) return;
        if (!enable) {
            dpRelease();
            dpEq = null; mbc = null;
            return;
        }
        dpEqApply(Cfg.bands10);                           // creates dp + dpEq again if they are gone
        if (Cfg.preamp != 20) applyPreamp();
        if (Cfg.balance != 50f) applyBalance();
    }

    private void setState(String which, boolean want) {
        SharedPreferences.Editor ed = on().edit();
        if ("eq".equals(which)) {
            eqOn = want; ed.putBoolean("prefsEQOn1", want).apply();
            dpEqSet(want);
        } else if ("bass".equals(which)) {
            bassOn = want; ed.putBoolean("prefsBASSOn1", want).apply();
            if (want) bassStart(); else bassRelease();
        } else if ("virt".equals(which)) {
            virtOn = want; ed.putBoolean("prefsVIRTOn1", want).apply();
            if (want) virtStart(); else virtRelease();
        }
    }

    /** 10-band EQ on/off: off = flat (all gains 0 dB). */
    private void toggleEq() {
        eqOn = !on().getBoolean("prefsEQOn1", true);
        on().edit().putBoolean("prefsEQOn1", eqOn).apply();
        try { dpEqSet(eqOn); } catch (Exception ignored) {}
    }
    private void load10() {
        String saved = getSharedPreferences("eq10_save_prefs", 0).getString("eq10_save_prefs", "");
        if (saved.isEmpty()) return;
        String[] sp = saved.split(",");
        for (int i = 0; i < Cfg.DP_BANDS && i < sp.length; i++) try { Cfg.bands10[i] = Float.parseFloat(sp[i]); } catch (Exception ignored) {}
    }
    private void toggleVirt() {
        virtOn = on().getBoolean("prefsVIRTOn1", false);
        if (virtOn) { virtOn = false; virtRelease(); on().edit().putBoolean("prefsVIRTOn1", false).apply(); }
        else { virtOn = true; virtStart(); on().edit().putBoolean("prefsVIRTOn1", true).apply(); }
    }

    private void applyEffects() { setBass(bassLevel); setVirt(virtLevel); }

    // ---------- apply everything (b0) ----------
    private void applyAll() {
        SharedPreferences p = getSharedPreferences("prefsLoudness", 0);
        Cfg.loudness = p.getInt("prefsLoudnessValue", 0);
        if (Cfg.loudness == 0) loudnessOff();
        else { loudnessOn(); handler.postDelayed(() -> { setLoudness(0); setLoudness(Cfg.loudness); }, 500L); }
        setBass(bassLevel); setVirt(virtLevel);
        if (Build.VERSION.SDK_INT >= 28 && Cfg.preamp != 20) applyPreamp();
        if (Build.VERSION.SDK_INT >= 28 && Cfg.balance != 50f) applyBalance();
    }

    // ---------- output device detection (I(), callback b) ----------
    private void detectDevice(AudioDeviceInfo[] devices) {
        deviceType = Cfg.DEVICE_KEYS[0];
        for (AudioDeviceInfo d : devices) {
            int t = d.getType();
            if (t == 2 || t == 24 || t == 27) { Cfg.deviceName = "Speaker"; deviceType = Cfg.DEVICE_KEYS[0]; }
            else if (t == 8 || t == 7) { Cfg.deviceName = String.valueOf(d.getProductName()); deviceType = Cfg.DEVICE_KEYS[2]; }
            else if (t == 4 || t == 3) { Cfg.deviceName = "Headphones"; deviceType = Cfg.DEVICE_KEYS[1]; }
            else if (t == 22 || t == 26 || t == 11) { Cfg.deviceName = String.valueOf(d.getProductName()); deviceType = Cfg.DEVICE_KEYS[3]; }
        }
        if (!effectsStopped) showNotification();
        // [NOT PORTED] original also looked up a per-headphone preset in its SQLite DB (X(), W()) and applied it.
    }

    // ---------- lifecycle ----------
    // ---------- effects lifecycle (init / full stop) ----------
    private boolean effectsStopped = false;

    private void initEffects() {
        // [RECONSTRUCTED] flags + effect creation (done in the lost part of onStartCommand originally)
        eqOn = on().getBoolean("prefsEQOn1", true); bassOn = on().getBoolean("prefsBASSOn1", false); virtOn = on().getBoolean("prefsVIRTOn1", false);
        try { if (eqOn && !Cfg.tenBand) eqStart(); if (bassOn) bassStart(); if (virtOn) virtStart(); } catch (Exception ignored) {}
        applyAll();
        Cfg.tenBand = true; load10();                         // 10-band only
        try { dpEqSet(eqOn); } catch (Exception ignored) {}
    }

    /** Releases every audio effect and the notification. Safe even while activities are still bound to the service. */
    private void stopEffects(boolean keepNotification) {
        effectsStopped = true;
        handler.removeCallbacks(lockRunnable);
        try { eqRelease(); bassRelease(); virtRelease(); loudnessOff(); } catch (Exception ignored) {}
        try { if (Build.VERSION.SDK_INT >= 28) { dpRelease(); } } catch (Exception ignored) {}
        dpEq = null; mbc = null;
        volumeLock = false;
        if (!keepNotification) {
            try { stopForeground(true); } catch (Exception ignored) {}
            if (nm != null) nm.cancel(Cfg.NOTIF_ID);
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
    }

    /**
     * Stop button / "Stop & exit": release every effect, remove the notification, drop the device listener and the
     * session receiver, cancel all timers and stop the service. Nothing keeps watching afterwards.
     * (stopSelf() alone is not enough: bound activities would keep the service alive.)
     */
    private void fullStop() {
        stopEffects(false);                                  // effects, volume lock, notification, wakelock
        waiting = false;
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (Build.VERSION.SDK_INT >= 23 && audioManager != null && deviceCallback != null) {
            try { audioManager.unregisterAudioDeviceCallback(deviceCallback); } catch (Exception ignored) {}
            deviceCallback = null;
        }
        if (sessionReceiver != null) {
            try { unregisterReceiver(sessionReceiver); } catch (Exception ignored) {}
            sessionReceiver = null;
        }
        try { stopForeground(true); } catch (Exception ignored) {}
        if (nm != null) nm.cancel(Cfg.NOTIF_ID);
        stopSelf();
    }

    private boolean waiting = false;        // effects are off and we are only waiting for headphones to come back
    private long cbRegisteredAt = 0;

    /** "Turn off when headphones disconnect": remember what was on, switch everything off, release all effects (service + notification stay). */
    private void shutdownOnDisconnect() {
        SharedPreferences st = getSharedPreferences("prefsSettings", 0);
        st.edit().putBoolean("prevBass", on().getBoolean("prefsBASSOn1", false))
                 .putBoolean("prevVirt", on().getBoolean("prefsVIRTOn1", false)).apply();
        on().edit().putBoolean("prefsEQOn1", false).putBoolean("prefsBASSOn1", false).putBoolean("prefsVIRTOn1", false).apply();
        eqOn = false; bassOn = false; virtOn = false;
        // Never stop the service here: keep it alive in the foreground with its notification ("Waiting for headphones...")
        // so the reconnect can be detected (and Android 12+ still lets us call startForeground later).
        stopEffects(true);
        waiting = true;
        showNotification();
    }

    /** "Turn on when headphones connect": EQ on, Bass/Virt back to what they were before the disconnect. */
    private void turnOnForHeadphones() {
        SharedPreferences st = getSharedPreferences("prefsSettings", 0);
        SharedPreferences.Editor ed = on().edit().putBoolean("prefsEQOn1", true);
        if (st.contains("prevBass")) {
            ed.putBoolean("prefsBASSOn1", st.getBoolean("prevBass", false)).putBoolean("prefsVIRTOn1", st.getBoolean("prevVirt", false));
            st.edit().remove("prevBass").remove("prevVirt").apply();
        }
        ed.apply();
        running = true;
        waiting = false;
        if (effectsStopped) { effectsStopped = false; initEffects(); }
        else {
            setState("eq", true);
            setState("bass", on().getBoolean("prefsBASSOn1", false));
            setState("virt", on().getBoolean("prefsVIRTOn1", false));
        }
        applyEffects();
        showNotification();
        if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
    }

    @Override public IBinder onBind(Intent i) { return binder; }

    /** wired / USB / Bluetooth / hearing-aid / BLE headset outputs */
    private static boolean anyHeadphone(AudioDeviceInfo[] list) {
        if (list == null) return false;
        for (AudioDeviceInfo i : list) {
            int t = i.getType();
            if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                    || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                    || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == AudioDeviceInfo.TYPE_USB_DEVICE
                    || t == AudioDeviceInfo.TYPE_HEARING_AID || t == 26 /* TYPE_BLE_HEADSET */) return true;
        }
        return false;
    }

    @Override public void onCreate() {
        super.onCreate();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) wakeLock = pm.newWakeLock(1, "Music Volume EQ::WakelockTag");
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Cfg.viewHeight = (int) (155 * getResources().getDisplayMetrics().density);   // original: 155dp
        SharedPreferences sp = getSharedPreferences("prefsEQPos", 0);
        int mid = Cfg.viewHeight / 2;
        pos60 = sp.getInt("prefsEQ60", mid); pos14k = sp.getInt("prefsEQ14", mid); pos3k = sp.getInt("prefsEQ3", mid);
        pos230 = sp.getInt("prefsEQ230", mid); pos910 = sp.getInt("prefsEQ910", mid);
        bassLevel = sp.getInt("BassLevel", 0); virtLevel = sp.getInt("VirtLevel", 0);
        Cfg.preamp = getSharedPreferences("prefsPreamp", 0).getInt("prefsPreampValue2", 20);
        Cfg.balance = getSharedPreferences("prefsBalance", 0).getFloat("prefsBalanceValue", 50.0f);
        SharedPreferences lp = getSharedPreferences("prefsLimiter", 0);
        Cfg.limAttack = lp.getFloat("prefAttackValue", 1.0f);
        Cfg.limRelease = lp.getFloat("prefReleaseValue", 60.0f);
        Cfg.limRatio = lp.getFloat("prefRatioValue", 10.0f);
        Cfg.limThreshold = lp.getFloat("prefThresholdValue", -2.0f);
        Cfg.limPostGain = lp.getFloat("prefGainValue", 0.0f);
        initEffects();
        if (Build.VERSION.SDK_INT >= 23) {
            audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            detectDevice(audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS));
            deviceCallback = new AudioDeviceCallback() {
                @Override public void onAudioDevicesAdded(AudioDeviceInfo[] d) {
                    // the system replays the current devices right after registering: ignore that first burst
                    boolean fresh = System.currentTimeMillis() - cbRegisteredAt > 1500;
                    if (fresh && anyHeadphone(d)
                            && getSharedPreferences("prefsSettings", 0).getBoolean("startOnConnect", false)) {
                        detectDevice(d);
                        turnOnForHeadphones();
                        return;
                    }
                    detectDevice(d);
                }
                @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] d) {
                    AudioDeviceInfo[] left = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
                    // Settings: "turn off when headphones disconnect"
                    if (getSharedPreferences("prefsSettings", 0).getBoolean("stopOnDisconnect", false)
                            && anyHeadphone(d) && !anyHeadphone(left)) {
                        shutdownOnDisconnect();
                        return;
                    }
                    detectDevice(left);
                }
            };
            cbRegisteredAt = System.currentTimeMillis();
            audioManager.registerAudioDeviceCallback(deviceCallback, null);
        }
    }

    /** [RECONSTRUCTED] original onStartCommand body was lost in decompile; rebuilt from its callers/actions. */
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        running = true;
        if (intent != null && intent.getBooleanExtra("STOP", false)) { fullStop(); return START_NOT_STICKY; }
        if (effectsStopped) { effectsStopped = false; waiting = false; initEffects(); }   // coming back after a headphone-disconnect shutdown
        showNotification();
        if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
        if (sessionReceiver == null) {
            sessionReceiver = new AudioSessionReceiver();
            IntentFilter f = new IntentFilter();
            f.addAction("android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION");
            f.addAction("android.media.action.CLOSE_AUDIO_EFFECT_CONTROL_SESSION");
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(sessionReceiver, f, Context.RECEIVER_EXPORTED);
            else registerReceiver(sessionReceiver, f);
        }
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_SET_STATE.equals(a)) { setState(intent.getStringExtra("which"), intent.getBooleanExtra("on", false)); applyEffects(); }
        else if (ACTION_EQ_TOGGLE.equals(a)) { toggleEq(); applyEffects(); }
        else if (ACTION_BASS_TOGGLE.equals(a)) { toggleBass(); applyEffects(); }
        else if (ACTION_VIRT_TOGGLE.equals(a)) { toggleVirt(); applyEffects(); }
        else if (ACTION_SET_EQ10.equals(a)) { Cfg.tenBand = true; eqRelease(); dpEqApply(Cfg.bands10); }
        else if (ACTION_RELAISE_EQ10.equals(a)) {
            Cfg.tenBand = false; dpRelease(); dpEq = null; mbc = null;
            if (eqOn) { eqStart(); applyEffects(); }
            if (Build.VERSION.SDK_INT >= 28 && Cfg.preamp != 20) applyPreamp();
            if (Build.VERSION.SDK_INT >= 28 && Cfg.balance != 50f) applyBalance();
        }
        else if (ACTION_LOUDNESS.equals(a)) applyLoudness();
        else if (ACTION_PREAMP.equals(a)) applyPreamp();
        else if (ACTION_LIMITER.equals(a)) applyLimiter();
        if (a != null) showNotification();                   // refresh the on/off pill in the notification
        return START_STICKY;
    }

    @Override public void onDestroy() {                      // V()
        super.onDestroy();
        running = false;
        eqRelease(); bassRelease(); virtRelease(); loudnessOff();
        if (Build.VERSION.SDK_INT >= 28 && dp != null) dpRelease();
        nm.cancel(Cfg.NOTIF_ID); stopForeground(true);
        handler.removeCallbacksAndMessages(null);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (sessionReceiver != null) { try { unregisterReceiver(sessionReceiver); } catch (Exception e) { e.printStackTrace(); } sessionReceiver = null; }
        if (Build.VERSION.SDK_INT >= 23 && audioManager != null && deviceCallback != null) {
            try { audioManager.unregisterAudioDeviceCallback(deviceCallback); } catch (Exception ignored) {}
        }
    }

    // ---------- notification (simplified e0) ----------
    private void showNotification() {
        String ch = "";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("EqChannel", getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c); ch = "EqChannel";
        }
        Intent stop = new Intent(this, EqService.class); stop.putExtra("STOP", true);
        int fl = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent stopPi = PendingIntent.getService(this, 5, stop, fl);
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, getSharedPreferences("prefsSettings", 0).getBoolean("eqFromNotification", false) ? EqActivity.class : MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), fl);
        // custom content: title + device name on the left, on/off pill on the right (tap = toggle EQ)
        boolean eqNow = on().getBoolean("prefsEQOn1", true);
        String sub = waiting ? "Waiting for headphones..." : Cfg.deviceName;
        RemoteViews rv = new RemoteViews(getPackageName(), R.layout.notification_eq);
        rv.setTextViewText(R.id.notif_title, getString(R.string.app_name));
        rv.setTextViewText(R.id.notif_text, sub);
        rv.setImageViewResource(R.id.notif_pill_img, eqNow ? R.drawable.notif_pill_on : R.drawable.notif_pill_off);
        rv.setViewVisibility(R.id.notif_tv_on, eqNow ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(R.id.notif_tv_off, eqNow ? View.GONE : View.VISIBLE);
        rv.setOnClickPendingIntent(R.id.notif_pill, PendingIntent.getService(this, 7, stateIntent(this, "eq", !eqNow), fl));

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        Notification n = b.setContentTitle(getString(R.string.app_name)).setContentText(sub)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off).setOngoing(true)
                .setStyle(new Notification.DecoratedCustomViewStyle()).setCustomContentView(rv)
                .setContentIntent(open).addAction(new Notification.Action.Builder(0, "Stop", stopPi).build()).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(Cfg.NOTIF_ID, n, 2); else startForeground(Cfg.NOTIF_ID, n);
        } catch (Exception e) { e.printStackTrace(); }
    }
}
