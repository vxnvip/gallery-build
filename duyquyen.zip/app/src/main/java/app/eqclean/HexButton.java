package app.eqclean;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Hexagon button (botuneqxml_studio / botunvuxml_studio). Idle: white outline. Pressed: cyan glow. 60 x 60 dp. */
public class HexButton extends View {
    public static final int EQ = 0, BARS = 1;
    private final int type;
    private final float d;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path hex = new Path();

    public HexButton(Context c, int type) {
        super(c);
        this.type = type;
        d = Studio.dens(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setClickable(true);
        line.setStyle(Paint.Style.STROKE); line.setStrokeJoin(Paint.Join.ROUND);
        glow.setStyle(Paint.Style.STROKE); glow.setStrokeJoin(Paint.Join.ROUND);
        glow.setColor(Studio.CYAN); glow.setMaskFilter(new BlurMaskFilter(5 * d, BlurMaskFilter.Blur.NORMAL));
        fill.setStyle(Paint.Style.FILL);
        txt.setTextAlign(Paint.Align.CENTER); txt.setTypeface(Studio.THIN);
    }

    @Override protected void onMeasure(int ws, int hs) {
        int s = (int) (Studio.HEX * d + 0.5f);
        setMeasuredDimension(s, s);
    }

    @Override protected void drawableStateChanged() { super.drawableStateChanged(); invalidate(); }

    @Override protected void onDraw(Canvas c) {
        boolean down = isPressed();
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f - 5 * d;
        hex.reset();
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(-90 + 60 * i);
            float x = (float) (cx + r * Math.cos(a)), y = (float) (cy + r * Math.sin(a));
            if (i == 0) hex.moveTo(x, y); else hex.lineTo(x, y);
        }
        hex.close();
        if (down) {
            glow.setStrokeWidth(5 * d); glow.setAlpha(210);
            c.drawPath(hex, glow);
        }
        line.setColor(down ? Studio.WHITE : 0xCCFFFFFF);
        line.setStrokeWidth((down ? 2.6f : 1.7f) * d);
        c.drawPath(hex, line);

        int ic = Studio.WHITE;
        if (type == EQ) {
            txt.setColor(ic);
            txt.setTextSize(r * 0.95f);
            if (down) txt.setShadowLayer(5 * d, 0, 0, Studio.CYAN); else txt.clearShadowLayer();
            c.drawText("EQ", cx, cy + r * 0.33f, txt);
        } else {
            fill.setColor(ic);
            if (down) fill.setShadowLayer(5 * d, 0, 0, Studio.CYAN); else fill.clearShadowLayer();
            float bw = r * 0.30f, gap = r * 0.12f, base = cy + r * 0.38f;
            float[] hh = {r * 0.50f, r * 0.95f, r * 0.70f};
            float x0 = cx - (3 * bw + 2 * gap) / 2f;
            RectF b = new RectF();
            for (int i = 0; i < 3; i++) {
                b.set(x0 + i * (bw + gap), base - hh[i], x0 + i * (bw + gap) + bw, base);
                c.drawRect(b, fill);
            }
        }
    }
}
