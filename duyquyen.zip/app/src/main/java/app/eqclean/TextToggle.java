package app.eqclean;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.widget.TextView;

/** EQ / BASS / VIRT toggle (buttonxml_studio + toggle_color_studio), 40 x 15 dp, 11 sp. */
public class TextToggle extends TextView {
    private boolean checked;

    public TextToggle(Context c, String text) {
        super(c);
        float d = Studio.dens(c);
        setText(text);
        setTextSize(Studio.SP_BUTTON);
        setGravity(Gravity.CENTER);
        setPadding(0, 0, 0, 0);
        setIncludeFontPadding(false);
        setSingleLine(true);
        setAllCaps(false);
        setTypeface(Studio.BOLD);
        setClickable(true);

        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(Studio.CYAN); pressed.setCornerRadius(d); pressed.setStroke(Math.max(1, Math.round(d)), Studio.WHITE);
        GradientDrawable on = new GradientDrawable();
        on.setColor(Studio.BLACK); on.setCornerRadius(d); on.setStroke(Math.max(1, Math.round(0.5f * d)), Studio.CYAN);
        GradientDrawable off = new GradientDrawable();
        off.setColor(0x00000000); off.setCornerRadius(d); off.setStroke(Math.max(1, Math.round(d)), Studio.EDGE);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{android.R.attr.state_selected}, on);
        sl.addState(new int[]{}, off);
        setBackground(sl);

        setTextColor(new ColorStateList(
                new int[][]{{android.R.attr.state_pressed}, {android.R.attr.state_selected}, {}},
                new int[]{Studio.BLACK, Studio.CYAN, Studio.WHITE}));
    }

    public void setChecked(boolean c) { checked = c; setSelected(c); }
    public boolean isChecked() { return checked; }
}
