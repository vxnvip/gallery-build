package app.eqclean;

/** Audio settings shared by service + UI. Names map to original b2.a fields (value defaults identical). */
public final class Cfg {
    private Cfg() {}
    public static int session = 0;                       // b2.a.f6167w0  (0 = global output mix)
    public static final int PRIORITY = Integer.MAX_VALUE; // b2.a.f6169x0
    public static boolean tenBand = true;                // b2.a.A0  (DynamicsProcessing 10-band mode)
    public static int preamp = 20;                       // b2.a.B0  (0..40, 20 = 0 dB)
    public static final int DP_BANDS = 10;               // b2.a.C0
    public static float[] bands10 = new float[10];       // b2.a.D0  (dB per band)
    public static float balance = 50f;                   // b2.a.f6118c1 (0..100, 50 = centre)
    public static int loudness = 0;                      // b2.a.f6135i0 (LoudnessEnhancer target gain, mB)
    public static int viewHeight = 310;                  // b2.a.f6132h0 (slider height; EQ scale = range/viewHeight)
    public static final int NOTIF_ID = 111;              // b2.a.f6173z0
    // Limiter (b2.a.f6121d1..f6142k1)
    public static boolean limEnabled = true, limInUse = true;
    public static int limLinkGroup = 0;
    public static float limAttack = 1.0f, limRelease = 60.0f, limRatio = 10.0f, limThreshold = -2.0f, limPostGain = 0.0f;
    // Output device
    public static final String[] DEVICE_KEYS = {"speaker", "headphones", "bluetooth", "usb"}; // b2.a.Z0
    public static String deviceName = "";                // b2.a.E0
}
