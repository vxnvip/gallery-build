package app.eqclean;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Vertical fader (slider_studio + knob_studio): panel, black track with ticks on both sides, big black cap
 * with a cyan line. Track glows cyan while touched. 72 x 310 dp, cap 70 x 80 dp.
 */
public class FaderView extends View {
    public interface Listener { void onFraction(float f); }
    private float frac = 0f;
    private boolean dragging = false;
    private Listener listener;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d;

    public FaderView(Context c) {
        super(c);
        d = Studio.dens(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        glow.setColor(Studio.CYAN);
        glow.setMaskFilter(new BlurMaskFilter(4 * d, BlurMaskFilter.Blur.NORMAL));
    }
    public void setListener(Listener l) { listener = l; }
    public boolean isDragging() { return dragging; }
    public void setFraction(float f) { frac = Math.max(0f, Math.min(1f, f)); invalidate(); }

    private float capW() { return Math.min(70 * d, getWidth() - 2 * d); }
    private float capH() { return 80 * d; }
    private float top() { return capH() / 2f; }
    private float bottom() { return getHeight() - capH() / 2f; }

    @Override protected void onMeasure(int ws, int hs) {
        setMeasuredDimension((int) (Studio.FADER_W * d + 0.5f), (int) (Studio.SLIDER_H * d + 0.5f));
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, tp = top(), bt = bottom();
        // panel
        p.setStyle(Paint.Style.FILL); p.setColor(Studio.PANEL);
        rf.set(0, 0, w, h);
        c.drawRoundRect(rf, 5 * d, 5 * d, p);

        // ticks: 16 divisions, every 4th is a major one
        p.setStrokeWidth(Math.max(1f, 0.9f * d));
        p.setColor(dragging ? 0xFFB5F1FF : 0xFFC8C8C8);
        for (int i = 0; i <= 16; i++) {
            float y = bt - (bt - tp) * i / 16f;
            float len = (i % 4 == 0) ? 19 * d : 8 * d;
            c.drawLine(cx - len, y, cx + len, y, p);
        }
        // track
        float tw = 3.5f * d;
        rf.set(cx - tw, tp - 6 * d, cx + tw, bt + 6 * d);
        if (dragging) { glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(3 * d); c.drawRoundRect(rf, tw, tw, glow); }
        p.setStyle(Paint.Style.FILL); p.setColor(Studio.BLACK);
        c.drawRoundRect(rf, tw, tw, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f, 1.1f * d));
        p.setColor(dragging ? Studio.CYAN : 0xFFE6E6E6);
        c.drawRoundRect(rf, tw, tw, p);

        // cap
        float cy = bt - (bt - tp) * frac, cw = capW(), ch = capH();
        rf.set(cx - cw / 2f, cy - ch / 2f, cx + cw / 2f, cy + ch / 2f);
        p.setStyle(Paint.Style.FILL); p.setColor(Studio.BLACK);
        c.drawRoundRect(rf, 7 * d, 7 * d, p);
        p.setColor(Studio.CYAN);
        c.drawRect(rf.left + 2 * d, cy - 2.5f * d, rf.right - 2 * d, cy + 2.5f * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.6f * d);
        p.setColor(dragging ? Studio.WHITE : 0xE6FFFFFF);
        c.drawRoundRect(rf, 7 * d, 7 * d, p);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                // fall through
            case MotionEvent.ACTION_MOVE: {
                float f = (bottom() - e.getY()) / (bottom() - top());
                frac = Math.max(0f, Math.min(1f, f));
                invalidate();
                if (listener != null) listener.onFraction(frac);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false; invalidate(); return true;
        }
        return super.onTouchEvent(e);
    }
}
