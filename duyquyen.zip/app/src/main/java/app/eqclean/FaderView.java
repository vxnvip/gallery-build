package app.eqclean;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Vertical fader (slider_studio + knob_studio), proportions measured from the original:
 * panel (bar2_sirina_slider x bar_visina_slider), 16 tick divisions (major every 4th), black track,
 * cap = 60% of panel width x 18% of panel height with a cyan centre line.
 */
public class FaderView extends View {
    public interface Listener { void onFraction(float f); }
    private float frac = 0f;
    private boolean dragging = false;
    private Listener listener;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d;

    public FaderView(Context c) {
        super(c);
        d = Studio.dens(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        glow.setColor(Studio.CYAN);
        glow.setMaskFilter(new BlurMaskFilter(4 * d, BlurMaskFilter.Blur.NORMAL));
    }
    public void setListener(Listener l) { listener = l; }
    public boolean isDragging() { return dragging; }
    public void setFraction(float f) { frac = Math.max(0f, Math.min(1f, f)); invalidate(); }

    private float capW() { return getWidth() * 0.60f; }
    private float capH() { return getHeight() * 0.18f; }
    private float top() { return capH() / 2f + 1.5f * d; }
    private float bottom() { return getHeight() - capH() / 2f - 1.5f * d; }

    @Override protected void onMeasure(int ws, int hs) {
        setMeasuredDimension((int) (Studio.FADER_W * d + 0.5f), (int) (Studio.SLIDER_H * d + 0.5f));
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, tp = top(), bt = bottom();
        float k = w / 78f;            // everything below was measured at 78dp panel width
        float in = Math.max(1f, d);
        // panel
        float bw = Math.max(1f, 2 * d);
        p.setStyle(Paint.Style.FILL); p.setColor(Studio.PANEL);
        rf.set(bw / 2, bw / 2, w - bw / 2, h - bw / 2);
        c.drawRoundRect(rf, 8 * d, 8 * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(bw); p.setColor(Studio.BORDER);
        c.drawRoundRect(rf, 8 * d, 8 * d, p);

        // ticks: 16 divisions, every 4th is a major one
        p.setStrokeWidth(Math.max(1f, 1.1f * d));
        p.setColor(dragging ? 0xFFC5F1FF : 0xFFC8C8C8);
        for (int i = 0; i <= 16; i++) {
            float y = bt - (bt - tp) * i / 16f;
            float len = (i % 4 == 0 ? 21 : 14) * k * d;
            c.drawLine(cx - len, y, cx + len, y, p);
        }
        // track
        float tw = 6.8f * k * d;
        rf.set(cx - tw, tp - 3 * d, cx + tw, bt + 3 * d);
        if (dragging) { glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(3 * d); c.drawRoundRect(rf, 4 * d, 4 * d, glow); }
        p.setStyle(Paint.Style.FILL); p.setColor(Studio.BLACK);
        c.drawRoundRect(rf, 4 * d, 4 * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f, 1.3f * d));
        p.setColor(dragging ? Studio.CYAN : 0xFFDADADA);
        c.drawRoundRect(rf, 4 * d, 4 * d, p);

        // cap
        float cy = bt - (bt - tp) * frac, cw = capW(), ch = capH();
        rf.set(cx - cw / 2f, cy - ch / 2f, cx + cw / 2f, cy + ch / 2f);
        p.setStyle(Paint.Style.FILL); p.setColor(Studio.BLACK);
        c.drawRoundRect(rf, 5 * d, 5 * d, p);
        p.setColor(Studio.CYAN);
        c.drawRect(rf.left + 1.5f * d, cy - 2f * d, rf.right - 1.5f * d, cy + 2f * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.8f * d);
        p.setColor(0xFFE8E8E8);
        c.drawRoundRect(rf, 5 * d, 5 * d, p);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                // fall through
            case MotionEvent.ACTION_MOVE: {
                float f = (bottom() - e.getY()) / (bottom() - top());
                frac = Math.max(0f, Math.min(1f, f));
                invalidate();
                if (listener != null) listener.onFraction(frac);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false; invalidate(); return true;
        }
        return super.onTouchEvent(e);
    }
}
