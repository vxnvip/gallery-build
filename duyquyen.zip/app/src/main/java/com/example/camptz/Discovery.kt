package com.example.camptz

import android.content.Context
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class FoundCam(val ip: String, val port: Int, val name: String)

/**
 * Dò camera Hikvision/EZVIZ trong LAN, chạy song song 2 cách:
 *  1) SADP (multicast UDP 239.255.255.250:37020): cho tên/serial thật
 *  2) quét TCP cổng SDK (8000) cả dải /24: dự phòng khi mạng chặn multicast (vd. hotspot)
 */
object Discovery {

    private fun ifaces(): List<Pair<NetworkInterface, Inet4Address>> {
        val out = mutableListOf<Pair<NetworkInterface, Inet4Address>>()
        val all = NetworkInterface.getNetworkInterfaces() ?: return out
        for (ni in all) {
            if (!ni.isUp || ni.isLoopback) continue
            val n = ni.name
            if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("tun") || n.startsWith("dummy")) continue
            for (a in ni.inetAddresses) if (a is Inet4Address && a.isSiteLocalAddress) out += ni to a
        }
        return out
    }

    /** Blocking (~4-8s) -> gọi từ thread nền. */
    fun scan(ctx: Context, port: Int = 8000): List<FoundCam> {
        val found = ConcurrentHashMap<String, FoundCam>()
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val lock = try { wm?.createMulticastLock("camptz")?.apply { setReferenceCounted(false); acquire() } } catch (_: Throwable) { null }
        val pool = Executors.newFixedThreadPool(80)
        try {
            for ((ni, addr) in ifaces()) {
                pool.execute { try { sadp(ni, addr, found) } catch (_: Throwable) { } }
                val own = addr.address
                val self = own[3].toInt() and 0xff
                val prefix = "${own[0].toInt() and 0xff}.${own[1].toInt() and 0xff}.${own[2].toInt() and 0xff}."
                for (i in 1..254) {
                    if (i == self) continue
                    val ip = prefix + i
                    pool.execute {
                        try {
                            Socket().use { it.connect(InetSocketAddress(ip, port), 500) }
                            found.putIfAbsent(ip, FoundCam(ip, port, "Camera $ip"))
                        } catch (_: Throwable) { }
                    }
                }
            }
            pool.shutdown()
            pool.awaitTermination(8, TimeUnit.SECONDS)
        } finally {
            pool.shutdownNow()
            try { lock?.release() } catch (_: Throwable) { }
        }
        return found.values.sortedBy { c -> c.ip.split('.').joinToString("") { it.padStart(3, '0') } }
    }

    private fun sadp(ni: NetworkInterface, addr: Inet4Address, found: ConcurrentHashMap<String, FoundCam>) {
        MulticastSocket(InetSocketAddress(addr, 0)).use { s ->
            s.networkInterface = ni
            s.soTimeout = 500
            val msg = ("<?xml version=\"1.0\" encoding=\"utf-8\"?><Probe><Uuid>" +
                UUID.randomUUID().toString().uppercase() + "</Uuid><Types>inquiry</Types></Probe>").toByteArray()
            val grp = InetAddress.getByName("239.255.255.250")
            repeat(2) { s.send(DatagramPacket(msg, msg.size, grp, 37020)) }
            val end = System.currentTimeMillis() + 3500
            val buf = ByteArray(4096)
            while (System.currentTimeMillis() < end) {
                val p = DatagramPacket(buf, buf.size)
                try { s.receive(p) } catch (_: SocketTimeoutException) { continue }
                val x = String(p.data, 0, p.length, Charsets.UTF_8)
                if (!x.contains("ProbeMatch")) continue
                val ip = tag(x, "IPv4Address") ?: p.address.hostAddress ?: continue
                val port = tag(x, "CommandPort")?.toIntOrNull() ?: 8000
                val name = tag(x, "DeviceSN") ?: tag(x, "DeviceDescription") ?: "Camera $ip"
                found[ip] = FoundCam(ip, port, name)
            }
        }
    }

    private fun tag(x: String, t: String) =
        Regex("<$t>([^<]*)</$t>").find(x)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }
}
