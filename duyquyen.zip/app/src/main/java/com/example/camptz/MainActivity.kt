package com.example.camptz

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import java.io.File
import java.util.Calendar
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()      // ONVIF: PTZ, live
    private val sdkIo = Executors.newSingleThreadExecutor()   // HCNetSDK: danh sách, tải
    @Volatile private var cam: OnvifPtz? = null
    @Volatile private var hik: HikSession? = null
    @Volatile private var downloading = false
    @Volatile private var formatting = false

    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var surface: SurfaceView
    private lateinit var info: TextView
    private lateinit var dayTv: TextView
    private lateinit var countTv: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var scanTv: TextView
    private lateinit var camListBox: LinearLayout
    @Volatile private var scanning = false
    private lateinit var panels: List<View>

    private var player: ExoPlayer? = null
    private var playingRec = false
    private var curUser = ""
    private var curPass = ""
    private var selY = 0
    private var selM = 0
    private var selD = 0
    private var listLoaded = false
    private var selectedRow: View? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- dựng giao diện ----------

    private fun field(hint: String, value: String, numeric: Boolean = false, secret: Boolean = false) =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine()
            inputType = when {
                secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                numeric -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT
            }
        }

    private fun wbtn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    private fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f) }

    private fun padBtn(label: String, x: Float, y: Float) = Button(this).apply {
        text = label
        textSize = 24f
        layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; drive(x, y); true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; halt(); true }
                else -> true
            }
        }
    }

    private fun vbox(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(8), dp(12), dp(8))
        views.forEach { addView(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        // ---- khung hình + trạng thái ----
        surface = SurfaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
        }
        status = TextView(this).apply {
            text = "Chưa kết nối"
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8))
        }

        // ---- tab Kết nối ----
        info = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(8), 0, dp(8))
        }
        scanTv = TextView(this).apply { setPadding(0, dp(8), 0, dp(4)) }
        camListBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val connectPanel = vbox(
            row(
                wbtn("Dò camera") { scan() },
                wbtn("Nhập IP") { askLogin("", 8000, "Nhập IP camera", true) }
            ),
            row(wbtn("Quên camera đã lưu") { forget() }),
            scanTv, camListBox, info
        )

        // ---- tab Live + PTZ ----
        val s = SPEED
        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(spacer(), padBtn("▲", 0f, s), spacer()))
            addView(row(padBtn("◀", -s, 0f), padBtn("■", 0f, 0f), padBtn("▶", s, 0f)))
            addView(row(spacer(), padBtn("▼", 0f, -s), spacer()))
        }
        val livePanel = vbox(pad)

        // ---- tab Thẻ nhớ ----
        dayTv = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            text = "--/--/----"
        }
        countTv = TextView(this).apply {
            setPadding(0, dp(8), 0, dp(4))
            text = "Bấm \"Tải danh sách\""
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cardPanel = vbox(
            row(
                Button(this).apply { text = "◀"; setOnClickListener { shiftDay(-1) } },
                dayTv,
                Button(this).apply { text = "▶"; setOnClickListener { shiftDay(1) } }
            ),
            row(wbtn("Tải danh sách") { loadList() }),
            row(
                Button(this).apply {
                    text = "Định dạng thẻ nhớ"
                    setTextColor(Color.RED)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener { confirmFormat() }
                }
            ),
            countTv,
            listBox
        )

        panels = listOf(connectPanel, livePanel, cardPanel)
        val content = FrameLayoutCompat(panels)
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(content)
        }

        val tabs = row(
            wbtn("Kết nối") { showPanel(0) },
            wbtn("Live / PTZ") {
                showPanel(1)
                startLive()   // bấm tab là phát live ngay
            },
            wbtn("Thẻ nhớ") {
                showPanel(2)
                if (hik != null && !listLoaded) loadList()
            }
        )

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            addView(surface)
            addView(status)
            addView(bar)
            addView(tabs)
            addView(scroll)
        })
        // đã lưu camera -> tự kết nối + phát live; chưa có -> dò camera
        val savedHost = prefs.getString("host", "") ?: ""
        val savedName = prefs.getString("camname", "") ?: ""
        if (prefs.getBoolean("auto", false) && (savedName.isNotEmpty() || savedHost.isNotEmpty())) {
            showPanel(1)
            autoConnect(prefs)
        } else {
            showPanel(0)
            scan()
        }
    }

    override fun onStart() {
        super.onStart()
        if (hik != null) startLive()   // quay lại app -> phát live lại
    }

    // ---------- dò camera + đăng nhập ----------

    private fun scan() {
        if (scanning) return
        scanning = true
        scanTv.text = "Đang dò camera trong mạng LAN..."
        camListBox.removeAllViews()
        Thread {
            val list = try { Discovery.scan(this) } catch (_: Throwable) { emptyList() }
            runOnUiThread { scanning = false; showFound(list) }
        }.start()
    }

    private fun showFound(list: List<FoundCam>) {
        camListBox.removeAllViews()
        scanTv.text = if (list.isEmpty()) "Không thấy camera nào. Bấm \"Dò camera\" lại hoặc \"Nhập IP\"."
        else "Tìm thấy ${list.size} camera — bấm vào để đăng nhập"
        list.forEach { camListBox.addView(camRow(it)) }
    }

    private fun camRow(c: FoundCam) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(8), 0, dp(8))
        addView(TextView(context).apply {
            text = "📷"; textSize = 28f; gravity = Gravity.CENTER
            setBackgroundColor(0xFFF2F2F2.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(112), dp(64))
        })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) }
            addView(TextView(context).apply {
                text = c.name; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
                setSingleLine(); ellipsize = TextUtils.TruncateAt.MIDDLE
            })
            addView(TextView(context).apply {
                text = "IP   ${c.ip}:${c.port}"; textSize = 14f; setTextColor(Color.GRAY)
                setPadding(0, dp(6), 0, 0)
            })
        })
        setOnClickListener { askLogin(c.ip, c.port, c.name, false) }
    }

    /** So tên camera (SADP DeviceSN / serial), không phân biệt hoa thường. */
    private fun sameCam(a: String, b: String): Boolean {
        if (a.isBlank() || b.isBlank()) return false
        if (a.equals(b, true)) return true
        return a.length >= 6 && b.length >= 6 && (a.contains(b, true) || b.contains(a, true))
    }

    /** Mở app: thử ngay IP đã lưu (nhanh); IP đó không còn camera thì mới dò LAN tìm theo TÊN. */
    private fun autoConnect(prefs: SharedPreferences) {
        val name = prefs.getString("camname", "") ?: ""
        val host = prefs.getString("host", "") ?: ""
        val port = prefs.getString("sdkport", "8000")!!.toIntOrNull() ?: 8000
        val user = prefs.getString("user", "admin")!!
        val pass = prefs.getString("pass", "")!!
        ui("Đang kết nối $host...")
        scanning = true
        Thread {
            val alive = host.isNotEmpty() && try {
                java.net.Socket().use { it.connect(java.net.InetSocketAddress(host, port), 800) }; true
            } catch (_: Throwable) { false }
            if (alive || name.isEmpty()) {
                runOnUiThread { scanning = false; connect(host, port, user, pass, 4, name) }
                return@Thread
            }
            runOnUiThread { ui("IP cũ không còn, đang tìm camera $name...") }
            val list = try { Discovery.scan(this) } catch (_: Throwable) { emptyList() }
            val hit = list.firstOrNull { sameCam(it.name, name) }
            runOnUiThread {
                scanning = false
                if (hit != null) connect(hit.ip, hit.port, user, pass, 4, name)
                else { showPanel(0); showFound(list) }
            }
        }.start()
    }

    private fun askLogin(host: String, sdkPort: Int, name: String, manual: Boolean) {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val sameHost = prefs.getString("host", "") == host
        val etIp = field("IP camera", host)
        val etUser = field("Tài khoản", prefs.getString("user", "admin")!!)
        val etPass = field("Mật khẩu / mã xác minh", if (sameHost) prefs.getString("pass", "")!! else "", secret = true)
        val box = if (manual) vbox(etIp, etUser, etPass) else vbox(etUser, etPass)
        AlertDialog.Builder(this)
            .setTitle(name)
            .setView(box)
            .setNegativeButton("Hủy", null)
            .setPositiveButton("OK") { _, _ ->
                val ip = if (manual) etIp.text.toString().trim() else host
                if (ip.isNotEmpty()) connect(ip, sdkPort, etUser.text.toString().trim(), etPass.text.toString(), 1, if (manual) "" else name)
            }
            .show()
    }

    /** Đăng nhập; thành công thì lưu lại + chuyển sang tab Live và phát luôn. */
    private fun connect(host: String, sdkPort: Int, user: String, pass: String, tries: Int, camName: String = "") {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val onvifPort = prefs.getString("port", "80")!!.toIntOrNull() ?: 80
        curUser = user; curPass = pass
        info.text = ""
        listLoaded = false
        ui("Đang kết nối $host...")
        io.execute {
            try {
                val c = OnvifPtz(host, onvifPort, user, pass)
                c.init()
                cam = c
                step("ONVIF: OK (PTZ + live)")
            } catch (e: Exception) {
                cam = null
                step("ONVIF lỗi: ${e.message}")
            }
        }
        sdkIo.execute {
            hik?.logout(); hik = null
            var err: String? = "chưa thử"
            var sess: HikSession? = null
            for (i in 1..tries) {
                try {
                    val s = HikSession()
                    err = s.login(host, sdkPort, user, pass)
                    if (err == null) { sess = s; break }
                } catch (t: Throwable) {
                    err = "không nạp được thư viện: ${t.message}"; break
                }
                if (i < tries) try { Thread.sleep(2500) } catch (_: InterruptedException) { }
            }
            val s = sess
            if (s == null) {
                step("SDK: $err")
                runOnUiThread { showPanel(0); if (camListBox.childCount == 0) scan() }
                return@execute
            }
            hik = s
            selY = s.todayY; selM = s.todayM; selD = s.todayD
            // nhớ camera theo TÊN (SADP DeviceSN); nếu chưa có tên thật thì dùng serial lấy lúc đăng nhập
            val saveName = if (camName.isNotBlank() && !camName.startsWith("Camera ")) camName else s.serial
            prefs.edit().putString("camname", saveName)
                .putString("host", host).putString("sdkport", sdkPort.toString())
                .putString("user", user).putString("pass", pass).putBoolean("auto", true).apply()
            step("SDK: OK, serial ${s.serial}, kênh ${s.channel}")
            runOnUiThread { dayTv.text = dayLabel(); showPanel(1); startLive() }
        }
    }

    private fun forget() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .remove("host").remove("camname").remove("pass").putBoolean("auto", false).apply()
        stopPlayer()
        cam = null
        sdkIo.execute { hik?.logout(); hik = null }
        ui("Đã quên camera")
        scan()
    }

    /** Chứa nhiều panel chồng lên nhau, mỗi lúc chỉ hiện một cái. */
    private fun FrameLayoutCompat(views: List<View>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        views.forEach { addView(it) }
    }

    private fun showPanel(i: Int) {
        panels.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
    }

    // ---------- live ----------

    private fun startLive() {
        val h = hik ?: return ui("Hãy kết nối trước (cần đăng nhập SDK)")
        if (formatting) return ui("Đang định dạng thẻ, chưa xem live được")
        stopPlayer()
        playingRec = false
        ui("Đang mở live...")
        val holder = surface.holder
        sdkIo.execute {
            val err = try { h.startLive(holder) } catch (t: Throwable) { t.message }
            if (err == null) { ui("Đang phát live ✔"); return@execute }
            // dự phòng: RTSP qua ONVIF
            val c = cam
            if (c != null) {
                try {
                    val u = withAuth(c.liveUri())
                    runOnUiThread { playingRec = false; play(u) }
                    return@execute
                } catch (_: Exception) { }
            }
            ui("Live lỗi: $err")
        }
    }

    // ---------- thẻ nhớ ----------

    private fun dayLabel() = "%02d/%02d/%04d".format(selD, selM, selY)

    private fun shiftDay(delta: Int) {
        if (selY == 0) return ui("Hãy kết nối trước")
        val c = Calendar.getInstance().apply { clear(); set(selY, selM - 1, selD); add(Calendar.DAY_OF_MONTH, delta) }
        selY = c.get(Calendar.YEAR); selM = c.get(Calendar.MONTH) + 1; selD = c.get(Calendar.DAY_OF_MONTH)
        dayTv.text = dayLabel()
        loadList()
    }

    private fun loadList() {
        val h = hik ?: return ui("Chưa đăng nhập SDK (xem tab Kết nối)")
        listLoaded = true
        countTv.text = "Đang tìm ngày ${dayLabel()}..."
        listBox.removeAllViews()
        val y = selY; val m = selM; val d = selD
        sdkIo.execute {
            try {
                val recs = h.list(y, m, d)
                runOnUiThread { showList(recs) }
            } catch (e: Throwable) {
                runOnUiThread { countTv.text = "Lỗi: ${e.message}" }
            }
        }
    }

    private fun durText(r: RecFile): String {
        val t = ((r.e[3] * 3600 + r.e[4] * 60 + r.e[5]) - (r.s[3] * 3600 + r.s[4] * 60 + r.s[5])).coerceAtLeast(0)
        return "${t / 60}'${t % 60}\""
    }

    private fun cardBg(selected: Boolean) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF5B605C.toInt(), 0xFF383D3A.toInt())
    ).apply {
        cornerRadius = dp(8).toFloat()
        if (selected) setStroke(dp(2), Color.parseColor("#7C8CFF"))
    }

    private fun clipCard(r: RecFile): View = FrameLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, dp(84), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        background = cardBg(false)
        // TODO: ảnh thu nhỏ -> thêm ImageView làm lớp dưới cùng ở đây
        addView(TextView(context).apply {
            text = "%02d:%02d".format(r.s[3], r.s[4])
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(8), dp(6), 0, 0) }
        })
        addView(TextView(context).apply {
            text = durText(r)
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(6), dp(8), 0) }
        })
        setOnClickListener { selectRow(this); playRec(r) }
        setOnLongClickListener { downloadRec(r); true }   // giữ lâu = tải
    }

    private fun showList(recs: List<RecFile>) {
        listBox.removeAllViews()
        selectedRow = null
        countTv.text = if (recs.isEmpty()) "Không có bản ghi ngày ${dayLabel()}"
        else "Tổng cộng ${recs.size} clip ngày ${dayLabel()} (bấm để phát, giữ để tải)"
        // nhóm theo giờ, giờ mới nhất lên trên, trong giờ cũng mới nhất trước
        val byHour = recs.groupBy { it.s[3] }.toSortedMap(compareByDescending { it })
        for ((hour, clips) in byHour) {
            listBox.addView(TextView(this).apply {
                text = "%02d:00".format(hour)
                setTextColor(Color.GRAY); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(8), dp(16), dp(8), dp(4))
            })
            val sorted = clips.sortedByDescending { it.s[4] * 60 + it.s[5] }
            for (chunk in sorted.chunked(3)) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (r in chunk) line.addView(clipCard(r))
                repeat(3 - chunk.size) {   // ô trống để thẻ không bị kéo giãn
                    line.addView(View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, dp(84), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                    })
                }
                listBox.addView(line)
            }
        }
    }


    private fun confirmFormat() {
        if (hik == null) return ui("Chưa đăng nhập SDK (xem tab Kết nối)")
        if (formatting) return ui("Đang định dạng, đợi chút")
        if (downloading) return ui("Đang tải file, đợi tải xong rồi hãy định dạng")
        AlertDialog.Builder(this)
            .setTitle("Định dạng thẻ nhớ?")
            .setMessage("TOÀN BỘ bản ghi trên thẻ sẽ bị xóa vĩnh viễn và không khôi phục được. Camera sẽ ngừng ghi trong lúc format.")
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Xóa hết") { _, _ -> formatCard() }
            .show()
    }

    private fun formatCard() {
        val h = hik ?: return ui("Chưa đăng nhập SDK")
        formatting = true
        stopPlayer()
        listBox.removeAllViews()
        selectedRow = null
        countTv.text = "Đang định dạng thẻ nhớ, không tắt app..."
        ui("Bắt đầu định dạng...")
        sdkIo.execute {
            val err = try { h.formatDisk { p -> ui("Đang định dạng $p%") } } catch (e: Throwable) { e.message }
            formatting = false
            runOnUiThread {
                if (err == null) {
                    status.text = "Đã định dạng xong thẻ nhớ"
                    countTv.text = "Thẻ nhớ đã được xóa sạch"
                } else {
                    status.text = "Định dạng lỗi: $err"
                    countTv.text = "Định dạng lỗi: $err"
                }
            }
        }
    }

    private fun selectRow(v: View) {
        selectedRow?.background = cardBg(false)
        v.background = cardBg(true)
        selectedRow = v
    }

    private fun playRec(r: RecFile) {
        val h = hik ?: return ui("Chưa đăng nhập SDK")
        if (formatting) return ui("Đang định dạng thẻ, chưa phát được")
        stopPlayer()
        playingRec = true
        ui("Đang mở bản ghi ${r.startText()}...")
        val holder = surface.holder
        sdkIo.execute {
            val err = try { h.startPlayback(r, holder) } catch (t: Throwable) { t.message }
            ui(if (err == null) "Đang phát ✔ ${r.startText()}" else "Không phát được: $err")
        }
    }

    /** Thử ghi thật một file vào thư mục (đáng tin hơn là hỏi cờ quyền). */
    private fun canWrite(dir: File): Boolean = try {
        (dir.exists() || dir.mkdirs()) && File(dir, ".w").let { it.createNewFile() || it.exists() }.also { File(dir, ".w").delete() }
    } catch (_: Throwable) { false }

    /** Cần quyền ghi /sdcard: Android 11+ phải cấp "Truy cập tất cả tệp", thấp hơn thì quyền ghi bộ nhớ. */
    private fun ensureStorage(): Boolean {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Environment.isExternalStorageManager()) return true
            ui("Hãy bật \"Truy cập tất cả tệp\" cho app, rồi giữ clip để tải lại")
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
            return false
        }
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
            ui("Hãy cấp quyền bộ nhớ, rồi giữ clip để tải lại")
            return false
        }
        return true
    }

    private fun downloadRec(r: RecFile) {
        val h = hik ?: return ui("Chưa đăng nhập SDK")
        if (formatting) return ui("Đang định dạng thẻ, không tải được")
        if (downloading) return ui("Đang tải file khác, đợi chút")
        var dir = File(Environment.getExternalStorageDirectory(), "Ezviz")
        if (!canWrite(dir)) {
            val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
            if (!prefs.getBoolean("askedStorage", false)) {
                // lần đầu: mở trang cấp quyền đúng một lần (không lặp lại mãi)
                prefs.edit().putBoolean("askedStorage", true).apply()
                ensureStorage()
                return
            }
            // đã xin rồi mà vẫn không ghi được /sdcard/Ezviz -> lưu tạm vào thư mục riêng của app, không cần quyền
            val mgr = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else null
            dir = File(getExternalFilesDir(null), "Ezviz")
            if (!canWrite(dir)) return ui("Không ghi được cả ${dir.absolutePath}")
            ui("Không ghi được /sdcard/Ezviz (manager=$mgr, pkg=$packageName), lưu tạm vào ${dir.absolutePath}")
        } else {
            getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("askedStorage", false).apply()
        }
        downloading = true
        val base = r.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dest = File(dir, "$base.mp4")
        val raw = File(dir, "$base.ps.tmp")   // SDK trả về luồng MPEG-PS, phải đóng gói lại thành MP4
        ui("Bắt đầu tải...")
        sdkIo.execute {
            try { h.stopPlayback() } catch (_: Throwable) { }
            val err = try { h.download(r, raw) { p -> prog("Đang tải từ thẻ nhớ", p) } } catch (e: Throwable) { e.message }
            if (err != null) {
                raw.delete()
                downloading = false
                hideBar()
                ui("Tải lỗi: $err")
                return@execute
            }
            prog("Đang chuyển sang MP4", 0)
            val cerr = if (PsToMp4.isMp4(raw)) {
                dest.delete(); if (raw.renameTo(dest)) null else "không đổi tên được file"
            } else PsToMp4.convert(raw, dest) { p -> prog("Đang chuyển sang MP4", p) }
            if (cerr == null) {
                raw.delete()
                ui("Đã tải xong: ${dest.absolutePath}")
            } else {
                val keep = File(dir, "$base.ps")
                keep.delete(); raw.renameTo(keep)
                ui("$cerr. Giữ file gốc (mở bằng VLC): ${keep.absolutePath}")
            }
            downloading = false
            hideBar()
        }
    }

    // ---------- video ----------

    private fun play(url: String) {
        stopPlayer()
        val p = ExoPlayer.Builder(this).build()
        p.setVideoSurfaceView(surface)
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                ui(
                    if (playingRec) "Không phát lại được (${error.errorCodeName}). Thử nút ⬇ để tải file."
                    else "Lỗi phát: ${error.errorCodeName}"
                )
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && !downloading) ui("Đang phát ✔")
            }
        })
        val src = RtspMediaSource.Factory()
            .setForceUseRtpTcp(true)
            .createMediaSource(MediaItem.fromUri(url))
        p.setMediaSource(src)
        p.prepare()
        p.playWhenReady = true
        player = p
        ui("Đang mở luồng...")
    }

    private fun stopPlayer() {
        player?.release()
        player = null
        hik?.let { sess -> try { sdkIo.execute { sess.stopPlayback() } } catch (_: Exception) { } }
    }

    /** Gắn user:pass vào URL rtsp nếu chưa có. */
    private fun withAuth(raw: String): String {
        val u = Uri.parse(raw.replace("&amp;", "&"))
        if (u.userInfo != null) return u.toString()
        val ui = "${Uri.encode(curUser)}:${Uri.encode(curPass)}"
        return u.buildUpon().encodedAuthority("$ui@${u.encodedAuthority}").build().toString()
    }

    // ---------- PTZ ----------

    private fun drive(x: Float, y: Float) {
        val c = cam ?: return ui("Chưa kết nối")
        io.execute {
            try { if (x == 0f && y == 0f) c.stop() else c.move(x, y) }
            catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun halt() {
        val c = cam ?: return
        io.execute {
            try { c.stop() } catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    // ---------- tiện ích ----------

    private fun ui(msg: String) = runOnUiThread { status.text = msg }

    private fun prog(label: String, pct: Int) = runOnUiThread {
        status.text = "$label: $pct%"
        bar.visibility = View.VISIBLE
        bar.progress = pct
    }

    private fun hideBar() = runOnUiThread { bar.visibility = View.GONE }

    private fun step(msg: String) = runOnUiThread {
        status.text = msg
        info.append(msg + "\n")
    }

    override fun onStop() {
        super.onStop()
        halt()
        stopPlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        sdkIo.execute { hik?.logout(); hik = null }
        sdkIo.shutdown()
        io.shutdown()
    }

    companion object {
        private const val SPEED = 0.5f
    }
}
