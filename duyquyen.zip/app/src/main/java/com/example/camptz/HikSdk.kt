package com.example.camptz

import android.view.SurfaceHolder
import com.sun.jna.Callback
import com.sun.jna.Library
import com.sun.jna.Memory
import com.sun.jna.Native
import com.sun.jna.Pointer
import com.sun.jna.Structure
import com.sun.jna.ptr.IntByReference
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import org.MediaPlayer.PlayM4.Player

/** Binding JNA tới libhcnetsdk.so (HCNetSDK của Hikvision, bản đi kèm app EZVIZ). */
interface HcNet : Library {
    fun NET_DVR_Init(): Boolean
    fun NET_DVR_Cleanup(): Boolean
    fun NET_DVR_SetConnectTime(dwWaitTime: Int, dwTryTimes: Int): Boolean
    fun NET_DVR_GetLastError(): Int
    fun NET_DVR_GetErrorMsg(pErrorNo: IntByReference): String?
    fun NET_DVR_Login_V40(pLoginInfo: LoginInfo, lpDeviceInfo: Pointer): Int
    fun NET_DVR_Logout(lUserID: Int): Boolean
    fun NET_DVR_GetDVRConfig(
        lUserID: Int, dwCommand: Int, lChannel: Int,
        lpOutBuffer: Pointer, dwOutBufferSize: Int, lpBytesReturned: IntByReference
    ): Boolean
    fun NET_DVR_FindFile_V30(lUserID: Int, lpFindCond: FileCond): Int
    fun NET_DVR_FindNextFile_V30(lFindHandle: Int, lpFindData: FindData): Int
    fun NET_DVR_FindClose_V30(lFindHandle: Int): Boolean
    fun NET_DVR_GetFileByName(lUserID: Int, sDVRFileName: String, sSavedFileName: String): Int
    fun NET_DVR_PlayBackControl(lPlayHandle: Int, dwControlCode: Int, dwInValue: Int, lpOutValue: IntByReference?): Boolean
    fun NET_DVR_GetDownloadPos(lFileHandle: Int): Int
    fun NET_DVR_StopGetFile(lFileHandle: Int): Boolean
    fun NET_DVR_PlayBackByTime(lUserID: Int, lChannel: Int, lpStartTime: NetTime, lpStopTime: NetTime, hWnd: Pointer?): Int
    fun NET_DVR_SetPlayDataCallBack_V40(lPlayHandle: Int, fPlayDataCallBack: PlayDataCallBack, pUser: Pointer?): Boolean
    fun NET_DVR_StopPlayBack(lPlayHandle: Int): Boolean
    fun NET_DVR_RealPlay_V40(lUserID: Int, lpPreviewInfo: PreviewInfo, fRealDataCallBack: PlayDataCallBack?, pUser: Pointer?): Int
    fun NET_DVR_StopRealPlay(lRealHandle: Int): Boolean
    fun NET_DVR_GetFileByTime(lUserID: Int, lChannel: Int, lpStartTime: NetTime, lpStopTime: NetTime, sSavedFileName: String): Int
    fun NET_DVR_FormatDisk(lUserID: Int, lDiskNumber: Int): Int
    fun NET_DVR_GetFormatProgress(
        lFormatHandle: Int, pCurrentFormatDisk: IntByReference,
        pCurrentDiskPos: IntByReference, pFormatStatic: IntByReference
    ): Boolean
    fun NET_DVR_CloseFormatHandle(lFormatHandle: Int): Boolean
}

/** Callback dữ liệu phát lại: dwDataType 1 = header (SYSHEAD), 2 = dữ liệu luồng. */
interface PlayDataCallBack : Callback {
    fun invoke(lPlayHandle: Int, dwDataType: Int, pBuffer: Pointer?, dwBufSize: Int, pUser: Pointer?)
}

@Structure.FieldOrder(
    "lChannel", "dwStreamType", "dwLinkMode", "hPlayWnd", "bBlocked", "bPassbackRecord",
    "byPreviewMode", "byStreamID", "byProtoType", "byRes1", "byVideoCodingType",
    "dwDisplayBufNum", "byNPQMode", "byRes"
)
class PreviewInfo : Structure() {
    @JvmField var lChannel: Int = 1
    @JvmField var dwStreamType: Int = 0      // 0 chính, 1 phụ
    @JvmField var dwLinkMode: Int = 0        // 0 TCP
    @JvmField var hPlayWnd: Pointer? = null  // null -> nhận dữ liệu qua callback
    @JvmField var bBlocked: Int = 1
    @JvmField var bPassbackRecord: Int = 0
    @JvmField var byPreviewMode: Byte = 0
    @JvmField var byStreamID = ByteArray(32)
    @JvmField var byProtoType: Byte = 0
    @JvmField var byRes1: Byte = 0
    @JvmField var byVideoCodingType: Byte = 0
    @JvmField var dwDisplayBufNum: Int = 0
    @JvmField var byNPQMode: Byte = 0
    @JvmField var byRes = ByteArray(215)
}

@Structure.FieldOrder(
    "sDeviceAddress", "byUseTransport", "wPort", "sUserName", "sPassword",
    "cbLoginResult", "pUser", "bUseAsynLogin", "byProxyType", "byUseUTCTime",
    "byLoginMode", "byHttps", "iProxyID", "byVerifyMode", "byRes3"
)
class LoginInfo : Structure() {
    @JvmField var sDeviceAddress = ByteArray(129)
    @JvmField var byUseTransport: Byte = 0
    @JvmField var wPort: Short = 0
    @JvmField var sUserName = ByteArray(64)
    @JvmField var sPassword = ByteArray(64)
    @JvmField var cbLoginResult: Pointer? = null
    @JvmField var pUser: Pointer? = null
    @JvmField var bUseAsynLogin: Int = 0
    @JvmField var byProxyType: Byte = 0
    @JvmField var byUseUTCTime: Byte = 0
    @JvmField var byLoginMode: Byte = 0
    @JvmField var byHttps: Byte = 0
    @JvmField var iProxyID: Int = 0
    @JvmField var byVerifyMode: Byte = 0
    @JvmField var byRes3 = ByteArray(119)
}

@Structure.FieldOrder("dwYear", "dwMonth", "dwDay", "dwHour", "dwMinute", "dwSecond")
class NetTime : Structure() {
    @JvmField var dwYear: Int = 0
    @JvmField var dwMonth: Int = 0
    @JvmField var dwDay: Int = 0
    @JvmField var dwHour: Int = 0
    @JvmField var dwMinute: Int = 0
    @JvmField var dwSecond: Int = 0

    fun set(y: Int, mo: Int, d: Int, h: Int, mi: Int, s: Int) {
        dwYear = y; dwMonth = mo; dwDay = d; dwHour = h; dwMinute = mi; dwSecond = s
    }
    fun toArray() = intArrayOf(dwYear, dwMonth, dwDay, dwHour, dwMinute, dwSecond)
}

@Structure.FieldOrder("lChannel", "dwFileType", "dwIsLocked", "dwUseCardNo", "sCardNumber", "struStartTime", "struStopTime")
class FileCond : Structure() {
    @JvmField var lChannel: Int = 1
    @JvmField var dwFileType: Int = 0xff
    @JvmField var dwIsLocked: Int = 0xff
    @JvmField var dwUseCardNo: Int = 0
    @JvmField var sCardNumber = ByteArray(32)
    @JvmField var struStartTime = NetTime()
    @JvmField var struStopTime = NetTime()
}

@Structure.FieldOrder("sFileName", "struStartTime", "struStopTime", "dwFileSize", "sCardNum", "byLocked", "byFileType", "byRes")
class FindData : Structure() {
    @JvmField var sFileName = ByteArray(100)
    @JvmField var struStartTime = NetTime()
    @JvmField var struStopTime = NetTime()
    @JvmField var dwFileSize: Int = 0
    @JvmField var sCardNum = ByteArray(32)
    @JvmField var byLocked: Byte = 0
    @JvmField var byFileType: Byte = 0
    @JvmField var byRes = ByteArray(2)
}

internal object HikSdk {
    val api: HcNet by lazy {
        for (n in listOf("c++_shared", "hpr", "crypto", "ssl", "cryptoPrivate", "sslPrivate", "HCCore", "HCCoreDevCfg", "SystemTransform")) {
            try { System.loadLibrary(n) } catch (_: Throwable) { }
        }
        val a = Native.load("hcnetsdk", HcNet::class.java)
        a.NET_DVR_Init()
        a.NET_DVR_SetConnectTime(5000, 1)
        a
    }
}

/** Một đoạn ghi hình trên thẻ nhớ. Giờ s/e là giờ địa phương của camera: [năm, tháng, ngày, giờ, phút, giây]. */
class RecFile(val name: String, val s: IntArray, val e: IntArray, val size: Long, val type: Int) {
    fun startText() = "%02d:%02d:%02d".format(s[3], s[4], s[5])
    fun endText() = "%02d:%02d:%02d".format(e[3], e[4], e[5])
    fun sizeText() = "%.1f MB".format(size / 1048576.0)
    fun typeText() = when (type) {
        0 -> "liên tục"; 1 -> "chuyển động"; 2 -> "báo động"; 6 -> "thủ công"; else -> "loại $type"
    }
}

/** Phiên đăng nhập SDK vào camera (cổng 8000). Mọi hàm là blocking -> gọi từ thread nền. */
class HikSession {
    private val api = HikSdk.api
    private var uid = -1
    private var host = ""
    var channel = 1; private set
    var serial = ""; private set
    var offsetMs = 0L; private set               // giờ camera - UTC
    var todayY = 0; private set
    var todayM = 0; private set
    var todayD = 0; private set

    /** Trả về null nếu thành công, ngược lại là thông báo lỗi. */
    fun login(host: String, port: Int, user: String, pass: String): String? {
        this.host = host
        val li = LoginInfo()
        fill(li.sDeviceAddress, host); fill(li.sUserName, user); fill(li.sPassword, pass)
        li.wPort = port.toShort()
        li.byLoginMode = 0
        val dev = Memory(1024).also { it.clear() }
        uid = api.NET_DVR_Login_V40(li, dev)
        if (uid < 0) {
            val err = api.NET_DVR_GetLastError()
            return "đăng nhập cổng $port lỗi $err — " + when (err) {
                1 -> "sai mã xác minh"
                7 -> "không kết nối được (cổng có mở không?)"
                10 -> "hết thời gian chờ"
                47 -> "user không tồn tại"
                else -> (try { api.NET_DVR_GetErrorMsg(IntByReference(err)) } catch (_: Throwable) { null }) ?: "xem mã lỗi HCNetSDK"
            }
        }
        serial = String(dev.getByteArray(0, 48), Charsets.US_ASCII).substringBefore('\u0000')
        channel = (dev.getByte(53).toInt() and 0xff).let { if (it == 0) 1 else it }
        readDeviceTime()
        return null
    }

    private fun readDeviceTime() {
        val now = System.currentTimeMillis()
        val mem = Memory(24).also { it.clear() }
        val ok = try { api.NET_DVR_GetDVRConfig(uid, 118, 1, mem, 24, IntByReference()) } catch (_: Throwable) { false }
        val t = IntArray(6) { mem.getInt(it * 4L) }
        if (ok && t[0] in 2000..2100) {
            val asUtc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear(); set(t[0], t[1] - 1, t[2], t[3], t[4], t[5])
            }.timeInMillis
            offsetMs = Math.round((asUtc - now) / 900000.0) * 900000L
            todayY = t[0]; todayM = t[1]; todayD = t[2]
        } else {
            offsetMs = TimeZone.getDefault().getOffset(now).toLong()
            val c = Calendar.getInstance()
            todayY = c.get(Calendar.YEAR); todayM = c.get(Calendar.MONTH) + 1; todayD = c.get(Calendar.DAY_OF_MONTH)
        }
    }

    // ---------- phát lại: HCNetSDK lấy dữ liệu -> PlayCtrl (PlayM4) giải mã + vẽ ----------
    private var pbHandle = -1
    private var pbPort = -1
    @Volatile private var pbError: String? = null
    private var pbCb: PlayDataCallBack? = null

    /** Phát đoạn ghi lên Surface. Trả về null nếu bắt đầu phát được, ngược lại là lỗi. */
    fun startPlayback(r: RecFile, holder: SurfaceHolder): String? {
        check(uid >= 0) { "chưa đăng nhập SDK" }
        stopPlayback()
        pbError = null
        val player = Player.getInstance()
        val t0 = NetTime().also { it.set(r.s[0], r.s[1], r.s[2], r.s[3], r.s[4], r.s[5]) }
        val t1 = NetTime().also { it.set(r.e[0], r.e[1], r.e[2], r.e[3], r.e[4], r.e[5]) }
        val h = api.NET_DVR_PlayBackByTime(uid, channel, t0, t1, null)
        if (h < 0) return "PlayBackByTime lỗi ${api.NET_DVR_GetLastError()}"

        val cb = makeCb(holder)
        pbCb = cb                                                  // giữ tham chiếu, tránh GC
        if (!api.NET_DVR_SetPlayDataCallBack_V40(h, cb, null)) {
            val e = api.NET_DVR_GetLastError()
            api.NET_DVR_StopPlayBack(h)
            return "SetPlayDataCallBack lỗi $e"
        }
        if (!api.NET_DVR_PlayBackControl(h, 1, 0, null)) {
            val e = api.NET_DVR_GetLastError()
            api.NET_DVR_StopPlayBack(h)
            return "PlayBackControl(start) lỗi $e"
        }
        pbHandle = h
        var waited = 0
        while (pbPort < 0 && pbError == null && waited < 6000) { Thread.sleep(100); waited += 100 }
        pbError?.let { stopPlayback(); return it }
        if (pbPort < 0) { stopPlayback(); return "không nhận được dữ liệu sau 6 giây (có thể thẻ đang mã hóa hoặc camera từ chối)" }
        return null
    }

    private fun makeCb(holder: SurfaceHolder): PlayDataCallBack {
        val player = Player.getInstance()
        return object : PlayDataCallBack {
            override fun invoke(lPlayHandle: Int, dwDataType: Int, pBuffer: Pointer?, dwBufSize: Int, pUser: Pointer?) {
                if (pBuffer == null || dwBufSize <= 0) return
                try {
                    if (dwDataType == 1) {                         // header
                        if (pbPort >= 0) return
                        val head = pBuffer.getByteArray(0, dwBufSize)
                        val port = player.acquirePort()
                        if (port < 0) { pbError = "PlayM4 hết port"; return }
                        player.setStreamMode(port, 0)
                        if (!player.openStream(port, head, head.size, 2 * 1024 * 1024)) {
                            pbError = "PlayM4 OpenStream lỗi ${player.lastError(port)}"
                            player.releasePort(port); return
                        }
                        if (!player.playOn(port, holder)) {
                            pbError = "PlayM4 Play lỗi ${player.lastError(port)}"
                            player.closeStream(port); player.releasePort(port); return
                        }
                        pbPort = port
                    } else if (dwDataType == 2) {                  // dữ liệu
                        val port = pbPort
                        if (port < 0) return
                        val data = pBuffer.getByteArray(0, dwBufSize)
                        var tries = 0
                        while (!player.inputData(port, data, data.size) && pbPort == port && tries++ < 200) {
                            Thread.sleep(10)                       // đầy bộ đệm -> chờ (giữ nhịp tải)
                        }
                    }
                } catch (t: Throwable) {
                    pbError = "callback lỗi: ${t.message}"
                }
            }
        }
    }

    private var pbLive = false

    /** Xem live qua HCNetSDK (RealPlay_V40) -> PlayCtrl. */
    fun startLive(holder: SurfaceHolder): String? {
        check(uid >= 0) { "chưa đăng nhập SDK" }
        stopPlayback()
        pbError = null
        val cb = makeCb(holder)
        val pi = PreviewInfo()
        pi.lChannel = channel
        pi.dwStreamType = 0
        pi.dwLinkMode = 0
        pi.bBlocked = 1
        val h = api.NET_DVR_RealPlay_V40(uid, pi, cb, null)
        if (h < 0) return "RealPlay lỗi ${api.NET_DVR_GetLastError()}"
        pbCb = cb
        pbLive = true
        pbHandle = h
        var waited = 0
        while (pbPort < 0 && pbError == null && waited < 6000) { Thread.sleep(100); waited += 100 }
        pbError?.let { stopPlayback(); return it }
        if (pbPort < 0) { stopPlayback(); return "không nhận được dữ liệu live sau 6 giây" }
        return null
    }

    fun stopPlayback() {
        val h = pbHandle; pbHandle = -1
        if (h >= 0) { try { if (pbLive) api.NET_DVR_StopRealPlay(h) else api.NET_DVR_StopPlayBack(h) } catch (_: Throwable) { } }
        pbLive = false
        val p = pbPort; pbPort = -1
        if (p >= 0) {
            val pl = Player.getInstance()
            try { pl.stopPort(p); pl.closeStream(p); pl.releasePort(p) } catch (_: Throwable) { }
        }
        pbCb = null
    }

    fun logout() {
        stopPlayback()
        if (uid >= 0) { try { api.NET_DVR_Logout(uid) } catch (_: Throwable) { } }
        uid = -1
    }

    /** Liệt kê các đoạn ghi trong một ngày (giờ camera). */
    fun list(y: Int, m: Int, d: Int): List<RecFile> {
        check(uid >= 0) { "chưa đăng nhập SDK" }
        val cond = FileCond()
        cond.lChannel = channel
        cond.struStartTime.set(y, m, d, 0, 0, 0)
        cond.struStopTime.set(y, m, d, 23, 59, 59)
        val h = api.NET_DVR_FindFile_V30(uid, cond)
        if (h < 0) error("FindFile lỗi ${api.NET_DVR_GetLastError()}")
        val out = ArrayList<RecFile>()
        try {
            var spins = 0
            while (out.size < 3000) {
                val fd = FindData()
                val r = api.NET_DVR_FindNextFile_V30(h, fd)
                if (r == 1000) {
                    out += RecFile(
                        String(fd.sFileName, Charsets.UTF_8).substringBefore('\u0000'),
                        fd.struStartTime.toArray(), fd.struStopTime.toArray(),
                        fd.dwFileSize.toLong() and 0xffffffffL, fd.byFileType.toInt()
                    )
                } else if (r == 1002) {
                    if (++spins > 300) break
                    Thread.sleep(100)
                } else break          // 1001 không có, 1003 hết, 1004 lỗi
            }
        } finally {
            api.NET_DVR_FindClose_V30(h)
        }
        return out
    }

    /** URL phát lại RTSP kiểu Hikvision, giờ đã đổi sang UTC theo múi giờ của camera. */
    fun rtspUrl(r: RecFile): String {
        fun utc(t: IntArray): String {
            val ms = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear(); set(t[0], t[1] - 1, t[2], t[3], t[4], t[5])
            }.timeInMillis - offsetMs
            return SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(ms))
        }
        return "rtsp://$host:554/Streaming/tracks/${channel * 100 + 1}?starttime=${utc(r.s)}&endtime=${utc(r.e)}"
    }

    /** Tải một đoạn ghi về file. Trả về null nếu xong, ngược lại là lỗi. */
    fun download(r: RecFile, dest: File, onPos: (Int) -> Unit): String? {
        check(uid >= 0) { "chưa đăng nhập SDK" }
        val t0 = NetTime().also { it.set(r.s[0], r.s[1], r.s[2], r.s[3], r.s[4], r.s[5]) }
        val t1 = NetTime().also { it.set(r.e[0], r.e[1], r.e[2], r.e[3], r.e[4], r.e[5]) }
        var h = api.NET_DVR_GetFileByTime(uid, channel, t0, t1, dest.absolutePath)
        if (h < 0) {
            val e1 = api.NET_DVR_GetLastError()
            h = api.NET_DVR_GetFileByName(uid, r.name, dest.absolutePath)
            if (h < 0) return "GetFileByTime lỗi $e1, GetFileByName lỗi ${api.NET_DVR_GetLastError()}"
        }
        try {
            if (!api.NET_DVR_PlayBackControl(h, 1, 0, null)) return "không bắt đầu tải được (lỗi ${api.NET_DVR_GetLastError()})"
            while (true) {
                val pos = api.NET_DVR_GetDownloadPos(h)
                if (pos < 0 || pos >= 200) return "mất kết nối khi tải (mã $pos)"
                onPos(pos)
                if (pos == 100) return null
                Thread.sleep(500)
            }
        } finally {
            api.NET_DVR_StopGetFile(h)
        }
    }


    /**
     * Định dạng (format) thẻ nhớ — XÓA TOÀN BỘ dữ liệu. Blocking, gọi từ thread nền.
     * Thử ổ số 0 trước, nếu SDK từ chối thì thử ổ số 1.
     * onPos nhận phần trăm 0..100. Trả về null nếu xong, ngược lại là lỗi.
     */
    fun formatDisk(onPos: (Int) -> Unit): String? {
        check(uid >= 0) { "chưa đăng nhập SDK" }
        var disk = 0
        var h = api.NET_DVR_FormatDisk(uid, disk)
        if (h < 0) {
            val e0 = api.NET_DVR_GetLastError()
            disk = 1
            h = api.NET_DVR_FormatDisk(uid, disk)
            if (h < 0) {
                return "FormatDisk lỗi $e0 (ổ 0) / ${api.NET_DVR_GetLastError()} (ổ 1)"
            }
        }
        try {
            val cur = IntByReference()
            val pos = IntByReference()
            val st = IntByReference()
            var fails = 0
            while (true) {
                if (!api.NET_DVR_GetFormatProgress(h, cur, pos, st)) {
                    if (++fails > 10) return "mất kết nối khi format (lỗi ${api.NET_DVR_GetLastError()})"
                    Thread.sleep(1000)
                    continue
                }
                fails = 0
                onPos(pos.value.coerceIn(0, 100))
                when (st.value) {
                    0 -> Thread.sleep(1000)           // đang format
                    1 -> return null                  // xong
                    else -> return "format thất bại (trạng thái ${st.value})"
                }
            }
        } finally {
            api.NET_DVR_CloseFormatHandle(h)
        }
    }

    private fun fill(dst: ByteArray, s: String) {
        val b = s.toByteArray(Charsets.UTF_8)
        System.arraycopy(b, 0, dst, 0, minOf(b.size, dst.size - 1))
    }
}
