package com.example.camptz

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer

/**
 * File tải từ thẻ nhớ bằng HCNetSDK là luồng MPEG-PS của Hikvision (H.265), KHÔNG phải MP4,
 * nên đổi đuôi .mp4 thì trình phát không mở được. Object này tách luồng H.265 ra khỏi PS rồi
 * đóng gói lại thành MP4 thật bằng MediaMuxer (không mã hoá lại, nhanh, không tốn thêm thư viện).
 */
object PsToMp4 {

    /** File đã là MP4 thật (có "ftyp") thì khỏi chuyển. */
    fun isMp4(f: File): Boolean = try {
        f.inputStream().use { val b = ByteArray(8); it.read(b) == 8 && String(b, 4, 4, Charsets.US_ASCII) == "ftyp" }
    } catch (_: Throwable) { false }

    /** Trả về null nếu thành công, ngược lại là thông báo lỗi. */
    fun convert(src: File, dst: File): String? {
        dst.delete()
        return try {
            Conv(src, dst).run()
        } catch (e: Throwable) {
            dst.delete()
            "chuyển MP4 lỗi: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private class Rd(f: File) : Closeable {
        private val ins = FileInputStream(f)
        private val buf = ByteArray(1 shl 20)
        private var n = 0
        private var p = 0

        private fun fill(): Boolean {
            n = ins.read(buf); p = 0
            if (n <= 0) { n = 0; return false }
            return true
        }

        fun read(): Int {
            if (p >= n && !fill()) return -1
            return buf[p++].toInt() and 0xff
        }

        fun readFully(dst: ByteArray, len: Int): Int {
            var got = 0
            while (got < len) {
                if (p >= n && !fill()) break
                val c = minOf(len - got, n - p)
                System.arraycopy(buf, p, dst, got, c)
                p += c; got += c
            }
            return got
        }

        fun skip(len: Int) {
            var left = len
            while (left > 0) {
                if (p >= n && !fill()) return
                val c = minOf(left, n - p)
                p += c; left -= c
            }
        }

        /** Tìm 00 00 01 kế tiếp, trả về byte stream_id ngay sau đó, -1 nếu hết file. */
        fun nextCode(): Int {
            var z = 0
            while (true) {
                val b = read()
                if (b < 0) return -1
                if (b == 0) z++
                else if (b == 1 && z >= 2) return read()
                else z = 0
            }
        }

        override fun close() = ins.close()
    }

    private class Bits(private val d: ByteArray) {
        private var pos = 0
        fun u(n: Int): Int {
            var v = 0
            repeat(n) {
                val byte = pos ushr 3
                val bit = if (byte < d.size) (d[byte].toInt() shr (7 - (pos and 7))) and 1 else 0
                v = (v shl 1) or bit
                pos++
            }
            return v
        }
        fun skip(n: Int) { pos += n }
        fun ue(): Int {
            var zeros = 0
            while (u(1) == 0 && zeros < 32) zeros++
            return if (zeros == 0) 0 else ((1 shl zeros) - 1 + u(zeros))
        }
    }

    private class Conv(private val src: File, private val dst: File) {
        // --- bộ đệm luồng ES H.265 ---
        private var es = ByteArray(1 shl 22)
        private var esLen = 0
        private var esBase = 0L          // offset tuyệt đối của es[0]
        private var scan = 0
        private var nalStart = -1
        private val ptsQ = ArrayList<LongArray>()   // [offset tuyệt đối, pts 90kHz]

        // --- access unit đang ghép ---
        private val curNals = ArrayList<ByteArray>()
        private var curHasVcl = false
        private var curKey = false
        private var curPts = -1L

        private var vps: ByteArray? = null
        private var sps: ByteArray? = null
        private var pps: ByteArray? = null

        private var muxer: MediaMuxer? = null
        private var track = -1
        private var firstPts = -1L
        private var lastUs = -1L
        private var frames = 0

        fun run(): String? {
            try {
                Rd(src).use { rd -> demux(rd) }
                if (nalStart >= 0) emit(nalStart, esLen)
                flushAu()
                if (frames == 0) return "không tìm thấy hình H.265 trong file (có thể là H.264?)"
                return null
            } finally {
                try { muxer?.stop() } catch (_: Throwable) { }
                try { muxer?.release() } catch (_: Throwable) { }
            }
        }

        private fun demux(rd: Rd) {
            var tmp = ByteArray(1 shl 16)
            while (true) {
                val c = rd.nextCode()
                if (c < 0) break
                if (c == 0xBA) continue   // pack header: để bộ dò tự bỏ qua
                val isVideo = c in 0xE0..0xEF
                val hasLen = c == 0xBB || c == 0xBC || c == 0xBD || c == 0xBE || c == 0xBF || c in 0xC0..0xEF
                if (!hasLen) continue
                val h = rd.read(); val l = rd.read()
                if (h < 0 || l < 0) break
                val len = (h shl 8) or l
                if (!isVideo || len < 3) { rd.skip(len); continue }
                rd.read()                         // flags 1
                val f2 = rd.read()
                val hl = rd.read()
                if (hl < 0) break
                var pts = -1L
                var used = 0
                if ((f2 and 0x80) != 0 && hl >= 5) {
                    val b = ByteArray(5)
                    rd.readFully(b, 5); used = 5
                    pts = ((b[0].toLong() and 0x0E) shl 29) or
                        ((b[1].toLong() and 0xFF) shl 22) or
                        ((b[2].toLong() and 0xFE) shl 14) or
                        ((b[3].toLong() and 0xFF) shl 7) or
                        ((b[4].toLong() and 0xFE) shr 1)
                }
                rd.skip(hl - used)
                val plen = len - 3 - hl
                if (plen <= 0) continue
                if (tmp.size < plen) tmp = ByteArray(plen)
                val got = rd.readFully(tmp, plen)
                append(tmp, got, pts)
            }
        }

        private fun append(p: ByteArray, len: Int, pts: Long) {
            if (pts >= 0) ptsQ.add(longArrayOf(esBase + esLen, pts))
            if (esLen + len > es.size) es = es.copyOf(maxOf(es.size * 2, esLen + len))
            System.arraycopy(p, 0, es, esLen, len)
            esLen += len
            var i = scan
            while (i + 2 < esLen) {
                if (es[i].toInt() == 0 && es[i + 1].toInt() == 0 && es[i + 2].toInt() == 1) {
                    if (nalStart >= 0) emit(nalStart, i)
                    nalStart = i + 3
                    i += 3
                } else i++
            }
            scan = i
            val drop = if (nalStart >= 0) nalStart else scan
            if (drop > 0) {
                System.arraycopy(es, drop, es, 0, esLen - drop)
                esLen -= drop; scan -= drop; esBase += drop
                if (nalStart >= 0) nalStart -= drop
            }
        }

        private fun ptsFor(abs: Long): Long {
            while (ptsQ.size >= 2 && ptsQ[1][0] <= abs) ptsQ.removeAt(0)
            return if (ptsQ.isNotEmpty() && ptsQ[0][0] <= abs) ptsQ[0][1] else -1L
        }

        private fun emit(a: Int, b: Int) {
            var e = b
            while (e > a && es[e - 1].toInt() == 0) e--
            if (e - a < 3) return
            onNal(es.copyOfRange(a, e), ptsFor(esBase + a))
        }

        private fun onNal(nal: ByteArray, pts: Long) {
            val type = (nal[0].toInt() shr 1) and 0x3f
            val isVcl = type < 32
            val firstSlice = isVcl && (nal[2].toInt() and 0x80) != 0
            val startsAu = type in 32..35 || type == 39 || firstSlice
            if (startsAu && curHasVcl) flushAu()
            if (curNals.isEmpty()) curPts = pts
            curNals.add(nal)
            if (isVcl) {
                curHasVcl = true
                if (type in 16..23) curKey = true
            }
            when (type) { 32 -> vps = nal; 33 -> sps = nal; 34 -> pps = nal }
        }

        private fun annexB(vararg parts: ByteArray): ByteBuffer {
            val bb = ByteBuffer.allocate(parts.sumOf { it.size + 4 })
            for (x in parts) { bb.put(0); bb.put(0); bb.put(0); bb.put(1); bb.put(x) }
            bb.flip()
            return bb
        }

        private fun startMuxer(): Boolean {
            val v = vps; val s = sps; val p = pps
            if (v == null || s == null || p == null) return false
            val (w, h) = parseSps(s)
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_HEVC, w, h)
            fmt.setByteBuffer("csd-0", annexB(v, s, p))
            val m = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            track = m.addTrack(fmt)
            m.start()
            muxer = m
            return true
        }

        private fun flushAu() {
            if (curNals.isEmpty()) return
            val nals = ArrayList(curNals); val key = curKey; val pts = curPts
            curNals.clear(); curHasVcl = false; curKey = false; curPts = -1L
            if (nals.none { ((it[0].toInt() shr 1) and 0x3f) < 32 }) return   // không có slice -> bỏ
            if (muxer == null && !(key && startMuxer())) return              // chờ keyframe đầu tiên
            var us = if (pts >= 0) {
                if (firstPts < 0) firstPts = pts
                (pts - firstPts) * 100 / 9
            } else frames * 66667L
            if (us <= lastUs) us = lastUs + 1000
            lastUs = us
            val info = MediaCodec.BufferInfo()
            val bb = annexB(*nals.toTypedArray())
            info.set(0, bb.remaining(), us, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            muxer!!.writeSampleData(track, bb, info)
            frames++
        }

        /** Đọc width/height từ SPS H.265 (đã trừ phần crop). */
        private fun parseSps(sps: ByteArray): Pair<Int, Int> {
            val o = ByteArrayOutputStream()
            var z = 0
            for (i in 2 until sps.size) {
                val b = sps[i].toInt() and 0xff
                if (z >= 2 && b == 3) { z = 0; continue }
                o.write(b)
                z = if (b == 0) z + 1 else 0
            }
            val br = Bits(o.toByteArray())
            br.skip(4)
            val maxSub = br.u(3)
            br.skip(1)
            br.skip(88); br.skip(8)
            val pp = BooleanArray(8); val lp = BooleanArray(8)
            for (i in 0 until maxSub) { pp[i] = br.u(1) == 1; lp[i] = br.u(1) == 1 }
            if (maxSub > 0) for (i in maxSub until 8) br.skip(2)
            for (i in 0 until maxSub) { if (pp[i]) br.skip(88); if (lp[i]) br.skip(8) }
            br.ue()
            val chroma = br.ue()
            if (chroma == 3) br.skip(1)
            var w = br.ue(); var h = br.ue()
            if (br.u(1) == 1) {
                val l = br.ue(); val r = br.ue(); val t = br.ue(); val b = br.ue()
                val sw = if (chroma == 1 || chroma == 2) 2 else 1
                val sh = if (chroma == 1) 2 else 1
                w -= sw * (l + r); h -= sh * (t + b)
            }
            return Pair(w, h)
        }
    }
}
