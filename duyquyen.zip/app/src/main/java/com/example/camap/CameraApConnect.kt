package com.example.camap

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.os.Handler
import android.os.Looper

/**
 * Nối vào AP camera CHỈ cho app này (WifiNetworkSpecifier + bindProcessToNetwork).
 * App khác (kể cả EZVIZ chính chủ) không dùng được kết nối này.
 * Kết nối tồn tại tới khi gọi disconnect() hoặc app bị đóng.
 *
 * Sau khi Connected, mọi socket/HTTP của process đi qua Wi-Fi camera,
 * camera ở 192.168.8.1.
 */
class CameraApConnect(ctx: Context) {

    private val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val main = Handler(Looper.getMainLooper())
    private var callback: ConnectivityManager.NetworkCallback? = null

    var network: Network? = null
        private set

    sealed class Result {
        data class Connected(val network: Network) : Result()
        object Failed : Result()   // sai mật khẩu, camera tắt AP, hết giờ hoặc người dùng từ chối
        object Lost : Result()     // đã nối rồi mới mất
    }

    /** password = null hoặc rỗng nếu AP mở. */
    fun connect(ssid: String, password: String?, timeoutMs: Int = 30_000, onResult: (Result) -> Unit) {
        disconnect()

        val spec = WifiNetworkSpecifier.Builder()
            .setSsid(ssid)
            .apply { if (!password.isNullOrEmpty()) setWpa2Passphrase(password) }
            .build()

        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(spec)
            .build()

        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) {
                // Bắt buộc: AP không có internet, không bind thì traffic của app đi ra 4G.
                val bound = cm.bindProcessToNetwork(n)
                network = n
                main.post { onResult(if (bound) Result.Connected(n) else Result.Failed) }
            }
            override fun onUnavailable() { main.post { onResult(Result.Failed) } }
            override fun onLost(n: Network) {
                if (network == n) {
                    cm.bindProcessToNetwork(null)
                    network = null
                    main.post { onResult(Result.Lost) }
                }
            }
        }
        callback = cb
        cm.requestNetwork(req, cb, main, timeoutMs)
    }

    fun disconnect() {
        cm.bindProcessToNetwork(null)
        callback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        callback = null
        network = null
    }
}
