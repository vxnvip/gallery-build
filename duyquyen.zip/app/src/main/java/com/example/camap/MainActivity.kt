package com.example.camap

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private companion object {
        const val SSID_PREFIX = "EZVIZ_"
        const val REQ_PERM = 1
    }

    private lateinit var wifi: WifiManager
    private lateinit var ap: CameraApConnect
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var scanBtn: Button
    private lateinit var adapter: ArrayAdapter<String>
    private var found: List<ScanResult> = emptyList()
    private var receiverOn = false

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = showResults()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        ap = CameraApConnect(this)
        buildUi()
        if (hasPerms()) startScan() else requestPerms()
    }

    override fun onDestroy() {
        if (receiverOn) runCatching { unregisterReceiver(scanReceiver) }
        ap.disconnect()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ UI
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Camera đang phát Wi-Fi"
            textSize = 22f
            setTextColor(Color.BLACK)
        })
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)
        val cap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (wifi.isStaConcurrencyForLocalOnlyConnectionsSupported())
                "Máy này hỗ trợ nối 2 Wi-Fi cùng lúc: có thể giữ Wi-Fi chính và nối camera."
            else
                "Máy này KHÔNG hỗ trợ nối 2 Wi-Fi cùng lúc: nối camera sẽ rời Wi-Fi chính."
        } else "Android dưới 12: nối camera sẽ rời Wi-Fi chính."
        root.addView(TextView(this).apply {
            text = cap
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, dp(8))
        })
        scanBtn = Button(this).apply {
            text = "Quét lại"
            setOnClickListener { if (hasPerms()) startScan() else requestPerms() }
        }
        root.addView(scanBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text1) {
            override fun getView(position: Int, convertView: android.view.View?, parent: ViewGroup): android.view.View {
                val v = super.getView(position, convertView, parent)
                val r = found[position]
                v.findViewById<TextView>(android.R.id.text1).text = r.SSID
                v.findViewById<TextView>(android.R.id.text2).text =
                    "Tín hiệu ${r.level} dBm · " + if (isOpen(r)) "mở (không mật khẩu)" else "có mật khẩu"
                return v
            }
        }
        list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> askPassword(found[pos]) }
            emptyView = TextView(this@MainActivity).apply {
                text = "Chưa thấy camera nào. Bật chế độ phát Wi-Fi trên camera rồi bấm Quét lại."
                gravity = Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        (list.emptyView as TextView).let { root.addView(it) }
        setContentView(root)
    }

    private fun isOpen(r: ScanResult): Boolean {
        val c = r.capabilities ?: return false
        return !(c.contains("WPA") || c.contains("WEP") || c.contains("SAE"))
    }

    // ---------------------------------------------------------- Permissions
    private fun neededPerms(): Array<String> {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        return p.toTypedArray()
    }

    private fun hasPerms() = neededPerms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun requestPerms() = requestPermissions(neededPerms(), REQ_PERM)

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) {
            if (hasPerms()) startScan()
            else status.text = "Cần cấp quyền Vị trí/Thiết bị Wi-Fi lân cận để quét Wi-Fi."
        }
    }

    // ------------------------------------------------------------------ Scan
    private fun startScan() {
        if (!receiverOn) {
            registerReceiver(scanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
            receiverOn = true
        }
        if (!wifi.isWifiEnabled) {
            status.text = "Wi-Fi đang tắt. Hãy bật Wi-Fi."
            startActivity(Intent(Settings.Panel.ACTION_WIFI))
            return
        }
        status.text = "Đang quét..."
        @Suppress("DEPRECATION")
        val started = wifi.startScan()
        if (!started) {
            // Android giới hạn tần suất quét: dùng kết quả quét gần nhất.
            status.text = "Quét bị giới hạn tần suất, hiện kết quả gần nhất."
            showResults()
        }
    }

    private fun showResults() {
        val all = try { wifi.scanResults } catch (e: SecurityException) { emptyList() }
        found = all
            .filter { !it.SSID.isNullOrEmpty() && it.SSID.startsWith(SSID_PREFIX) }
            .groupBy { it.SSID }
            .map { (_, v) -> v.maxByOrNull { it.level }!! }
            .sortedByDescending { it.level }
        adapter.clear()
        adapter.addAll(found.map { it.SSID })
        adapter.notifyDataSetChanged()
        status.text = "Tìm thấy ${found.size} camera"
    }

    // --------------------------------------------------------------- Connect
    private fun askPassword(r: ScanResult) {
        if (isOpen(r)) { connect(r.SSID, null); return }
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            hint = "Mật khẩu Wi-Fi"
            setText(SSID_PREFIX)           // gợi ý: EZVIZ_ + mã xác minh trên nhãn camera
            setSelection(text.length)
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this)
            .setTitle(r.SSID)
            .setMessage("Nhập mật khẩu Wi-Fi của camera")
            .setView(box)
            .setPositiveButton("Kết nối") { _, _ -> connect(r.SSID, input.text.toString()) }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun connect(ssid: String, pass: String?) {
        scanBtn.isEnabled = false
        status.text = "Đang kết nối $ssid ..."
        ap.connect(ssid, pass) { res ->
            scanBtn.isEnabled = true
            when (res) {
                is CameraApConnect.Result.Connected ->
                    status.text = "Đã kết nối $ssid (chỉ app này dùng được). Camera ở 192.168.8.1."
                is CameraApConnect.Result.Failed ->
                    status.text = "Không nối được: sai mật khẩu, camera đã tắt AP, hoặc bạn đã từ chối hộp thoại kết nối. Nếu popup lặp lại, vào Cài đặt Wi-Fi và xóa mạng $ssid đã lưu."
                is CameraApConnect.Result.Lost ->
                    status.text = "Đã mất kết nối với $ssid."
            }
        }
    }
}
