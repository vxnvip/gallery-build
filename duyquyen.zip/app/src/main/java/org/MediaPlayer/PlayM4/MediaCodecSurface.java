package org.MediaPlayer.PlayM4;

import android.graphics.SurfaceTexture;
import android.view.Surface;

/** Native gọi qua JNI khi giải mã phần cứng (MediaCodec -> SurfaceTexture). */
public class MediaCodecSurface implements SurfaceTexture.OnFrameAvailableListener {
    private final String TAG = "PlayerSDK";
    private Surface mDecodeSurface = null;
    private boolean mFrameAvailable = false;
    private final Object mFrameSyncObject = new Object();
    private SurfaceTexture mSurfaceTexture = null;
    private final float[] transformMatrix = {1f, 0, 0, 0, 0, 1f, 0, 0, 0, 0, 1f, 0, 0, 0, 0, 1f};

    public int InitST(int texId) {
        mSurfaceTexture = new SurfaceTexture(texId);
        mSurfaceTexture.setOnFrameAvailableListener(this);
        mDecodeSurface = new Surface(mSurfaceTexture);
        return 0;
    }

    public int awaitNewImage() {
        synchronized (mFrameSyncObject) {
            while (!mFrameAvailable) {
                try {
                    mFrameSyncObject.wait(10);
                    if (!mFrameAvailable) break;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    return 0x8004;
                }
            }
            mFrameAvailable = false;
        }
        try {
            mSurfaceTexture.updateTexImage();
            mSurfaceTexture.getTransformMatrix(transformMatrix);
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0x8004;
        }
    }

    public float gettransformMatrix0() { return transformMatrix[0]; }
    public float gettransformMatrix5() { return transformMatrix[5] + transformMatrix[13] * 2.0f; }

    @Override
    public void onFrameAvailable(SurfaceTexture st) {
        synchronized (mFrameSyncObject) {
            mFrameAvailable = true;
            mFrameSyncObject.notifyAll();
        }
    }
}
