package org.MediaPlayer.PlayM4;

/** libPlayCtrl (bản armeabi-v7a) tìm lớp này theo tên khi giải mã phần cứng. */
public class TimeStruct {
    public int size;
    public long time;
}
