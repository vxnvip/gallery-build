package org.MediaPlayer.PlayM4;

import android.view.Surface;
import android.view.SurfaceHolder;

/**
 * Bản rút gọn của org.MediaPlayer.PlayM4.Player (EZVIZ/Hikvision).
 * libPlayCtrl.so gắn hàm native theo tên Java_org_MediaPlayer_PlayM4_Player_* nên
 * package + tên lớp + tên hàm native phải giữ NGUYÊN.
 */
public class Player {
    static { System.loadLibrary("PlayCtrl"); }

    private static Player mPlayer;

    public static synchronized Player getInstance() {
        if (mPlayer == null) mPlayer = new Player();
        return mPlayer;
    }

    private native int GetPort();
    private native int FreePort(int port);
    private native int SetStreamOpenMode(int port, int mode);
    private native int OpenStream(int port, byte[] head, int size, int bufPool);
    private native int InputData(int port, byte[] data, int size);
    private native int Play(int port, Surface surface);
    private native int Stop(int port);
    private native int CloseStream(int port);
    private native int GetLastError(int port);

    public int acquirePort() { return GetPort(); }
    public boolean releasePort(int p) { return FreePort(p) == 1; }
    public boolean setStreamMode(int p, int mode) { return SetStreamOpenMode(p, mode) == 1; }
    public boolean openStream(int p, byte[] head, int size, int pool) { return OpenStream(p, head, size, pool) == 1; }
    public boolean inputData(int p, byte[] d, int n) { return InputData(p, d, n) == 1; }
    public boolean playOn(int p, SurfaceHolder h) { return Play(p, h.getSurface()) == 1; }
    public boolean stopPort(int p) { return Stop(p) == 1; }
    public boolean closeStream(int p) { return CloseStream(p) == 1; }
    public int lastError(int p) { return GetLastError(p); }

    // ---- các lớp JNI_OnLoad của libPlayCtrl tìm theo tên (giữ đúng tên field) ----
    public static class CYCLE_PARAM { public float radiusBottom, radiusLeft, radiusRight, radiusTop; }
    public static class FEC_COLOR { public int nAlpha, nB, nG, nR; }
    public static class PTZ_PARAM { public float ptzPositionX, ptzPositionY; }
    public static class SRTRANS_ELEMENT { public float fAxisX, fAxisY, fAxisZ, fValue; }
    public static class WATERMARK_FONTSIZE { public int nFontHeight, nFontWidth; }
    public static class WATERMARK_NUMBER { public int nColNumber, nRowNumber; }
    public static class WATERMARK_ROTATEINFO { public float fRotateAngle; public int nFillFullScreen; }
    public static class WATERMARK_WINDOWADAPT {
        public int nBaseWindowHeight, nBaseWindowWidth, nColSpace, nRowSpace, nWindowAdaptMode;
    }
}
