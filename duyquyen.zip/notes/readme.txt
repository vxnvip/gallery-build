Harmless placeholder ZIP for testing file detection.
