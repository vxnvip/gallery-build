bluewap test archive
Use only to test ZIP detection.
