package dev.apk2java;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import jadx.api.JadxArgs;
import jadx.api.JadxDecompiler;

public class MainActivity extends Activity {
	private static final int REQ_PICK = 1;
	private static final int REQ_SAVE = 2;

	private Button btnPick, btnSave;
	private CheckBox cbNoRes, cbDeobf;
	private ProgressBar bar;
	private TextView status, log;

	private volatile boolean busy;
	private File zipFile;
	private String baseName = "output";

	@Override
	protected void onCreate(Bundle b) {
		super.onCreate(b);
		setContentView(R.layout.activity_main);
		btnPick = findViewById(R.id.btnPick);
		btnSave = findViewById(R.id.btnSave);
		cbNoRes = findViewById(R.id.cbNoRes);
		cbDeobf = findViewById(R.id.cbDeobf);
		bar = findViewById(R.id.bar);
		status = findViewById(R.id.status);
		log = findViewById(R.id.log);

		btnPick.setOnClickListener(v -> {
			if (busy) return;
			Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.setType("*/*");
			startActivityForResult(i, REQ_PICK);
		});
		btnSave.setOnClickListener(v -> {
			if (zipFile == null || !zipFile.exists()) return;
			Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.setType("application/zip");
			i.putExtra(Intent.EXTRA_TITLE, baseName + "-java.zip");
			startActivityForResult(i, REQ_SAVE);
		});
	}

	@Override
	protected void onActivityResult(int req, int res, Intent data) {
		super.onActivityResult(req, res, data);
		if (res != RESULT_OK || data == null || data.getData() == null) return;
		Uri uri = data.getData();
		if (req == REQ_PICK) {
			startDecompile(uri);
		} else if (req == REQ_SAVE) {
			saveZip(uri);
		}
	}

	private void startDecompile(Uri uri) {
		busy = true;
		btnPick.setEnabled(false);
		btnSave.setEnabled(false);
		log.setText("");
		bar.setProgress(0);
		final boolean noRes = cbNoRes.isChecked();
		final boolean deobf = cbDeobf.isChecked();
		final String name = queryName(uri);
		Runnable task = () -> {
			try {
				setStatus("Đang chép file...");
				String ext = name.contains(".") ? name.substring(name.lastIndexOf('.')) : ".apk";
				File in = new File(getCacheDir(), "input" + ext);
				copy(uri, in);
				baseName = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name;

				File out = new File(getFilesDir(), "out");
				deleteRec(out);
				out.mkdirs();

				setStatus("Đang decompile (có thể lâu)...");
				JadxArgs args = new JadxArgs();
				args.setInputFile(in);
				args.setOutDir(out);
				args.setThreadsCount(2);
				args.setSkipResources(noRes);
				args.setDeobfuscationOn(deobf);
				args.setShowInconsistentCode(true);

				try (JadxDecompiler jadx = new JadxDecompiler(args)) {
					jadx.load();
					jadx.save(500, (done, total) -> runOnUiThread(() -> {
						if (total > 0) bar.setProgress((int) (done * 100 / total));
						status.setText("Decompile: " + done + " / " + total);
					}));
					int err = jadx.getErrorsCount();
					int warn = jadx.getWarnsCount();
					appendLog("Xong decompile. Lỗi: " + err + ", cảnh báo: " + warn);
				}
				in.delete();

				setStatus("Đang nén zip...");
				zipFile = new File(getCacheDir(), "output.zip");
				zipDir(out, zipFile);
				deleteRec(out);

				runOnUiThread(() -> {
					bar.setProgress(100);
					status.setText("Hoàn tất. Bấm 'Lưu kết quả' để lưu zip (" + (zipFile.length() / 1024) + " KB).");
					btnSave.setEnabled(true);
				});
			} catch (Throwable t) {
				appendLog("LỖI: " + android.util.Log.getStackTraceString(t));
				setStatus("Thất bại: " + t);
			} finally {
				busy = false;
				runOnUiThread(() -> btnPick.setEnabled(true));
			}
		};
		// stack lớn vì jadx đệ quy sâu
		new Thread(null, task, "jadx-worker", 128L * 1024 * 1024).start();
	}

	private void saveZip(Uri dest) {
		try (InputStream in = new FileInputStream(zipFile);
				OutputStream os = getContentResolver().openOutputStream(dest)) {
			byte[] buf = new byte[65536];
			int n;
			while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
			Toast.makeText(this, "Đã lưu", Toast.LENGTH_SHORT).show();
		} catch (Exception e) {
			Toast.makeText(this, "Lỗi lưu: " + e, Toast.LENGTH_LONG).show();
		}
	}

	private String queryName(Uri uri) {
		try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
			if (c != null && c.moveToFirst()) {
				int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
				if (idx >= 0) return c.getString(idx);
			}
		} catch (Exception ignored) {
		}
		return "input.apk";
	}

	private void copy(Uri uri, File dest) throws Exception {
		try (InputStream in = getContentResolver().openInputStream(uri);
				OutputStream os = new FileOutputStream(dest)) {
			byte[] buf = new byte[65536];
			int n;
			while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
		}
	}

	private static void zipDir(File dir, File zip) throws Exception {
		try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip))) {
			zipRec(dir, dir.getAbsolutePath().length() + 1, zos);
		}
	}

	private static void zipRec(File f, int prefix, ZipOutputStream zos) throws Exception {
		File[] list = f.listFiles();
		if (list == null) return;
		byte[] buf = new byte[65536];
		for (File c : list) {
			if (c.isDirectory()) {
				zipRec(c, prefix, zos);
			} else {
				zos.putNextEntry(new ZipEntry(c.getAbsolutePath().substring(prefix)));
				try (FileInputStream in = new FileInputStream(c)) {
					int n;
					while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
				}
				zos.closeEntry();
			}
		}
	}

	private static void deleteRec(File f) {
		File[] list = f.listFiles();
		if (list != null) for (File c : list) deleteRec(c);
		f.delete();
	}

	private void setStatus(String s) {
		runOnUiThread(() -> status.setText(s));
	}

	private void appendLog(String s) {
		runOnUiThread(() -> log.append(s + "\n"));
	}
}
