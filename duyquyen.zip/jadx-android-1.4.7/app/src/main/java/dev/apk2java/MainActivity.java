package dev.apk2java;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import jadx.api.JadxArgs;
import jadx.api.JadxDecompiler;
import jadx.api.impl.NoOpCodeCache;

public class MainActivity extends Activity {
	private static final int REQ_PICK = 1;
	private static final int REQ_SAVE = 2;

	private Button btnPick, btnSave;
	private CheckBox cbNoRes, cbDeobf;
	private ProgressBar bar;
	private TextView status, log;

	private volatile boolean busy;
	private File zipFile;
	private String baseName = "output";

	@Override
	protected void onCreate(Bundle b) {
		super.onCreate(b);
		setContentView(R.layout.activity_main);
		btnPick = findViewById(R.id.btnPick);
		btnSave = findViewById(R.id.btnSave);
		cbNoRes = findViewById(R.id.cbNoRes);
		cbDeobf = findViewById(R.id.cbDeobf);
		bar = findViewById(R.id.bar);
		status = findViewById(R.id.status);
		log = findViewById(R.id.log);

		btnPick.setOnClickListener(v -> {
			if (busy) return;
			Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.setType("*/*");
			startActivityForResult(i, REQ_PICK);
		});
		btnSave.setOnClickListener(v -> {
			if (zipFile == null || !zipFile.exists()) return;
			Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.setType("application/zip");
			i.putExtra(Intent.EXTRA_TITLE, baseName + "-java.zip");
			startActivityForResult(i, REQ_SAVE);
		});
	}

	@Override
	protected void onActivityResult(int req, int res, Intent data) {
		super.onActivityResult(req, res, data);
		if (res != RESULT_OK || data == null || data.getData() == null) return;
		Uri uri = data.getData();
		if (req == REQ_PICK) {
			startDecompile(uri);
		} else if (req == REQ_SAVE) {
			saveZip(uri);
		}
	}

	// ===== Quyền ghi ra bộ nhớ chung =====

	private boolean hasStorageAccess() {
		if (Build.VERSION.SDK_INT >= 30) {
			return Environment.isExternalStorageManager();
		}
		if (Build.VERSION.SDK_INT >= 23) {
			return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
		}
		return true;
	}

	private void askStorageAccess() {
		if (Build.VERSION.SDK_INT >= 30) {
			Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
					Uri.parse("package:" + getPackageName()));
			startActivity(i);
		} else if (Build.VERSION.SDK_INT >= 23) {
			requestPermissions(new String[] { Manifest.permission.WRITE_EXTERNAL_STORAGE }, 10);
		}
	}

	// Đổi Uri của file đã chọn thành đường dẫn thật (nếu đổi được)
	private File resolvePath(Uri uri) {
		try {
			String auth = uri.getAuthority();
			String id = DocumentsContract.getDocumentId(uri);
			if ("com.android.externalstorage.documents".equals(auth)) {
				String[] p = id.split(":", 2);
				if (p.length < 2) return null;
				File root = "primary".equalsIgnoreCase(p[0])
						? Environment.getExternalStorageDirectory()
						: new File("/storage/" + p[0]);
				return new File(root, p[1]);
			}
			if (id.startsWith("raw:")) {
				return new File(id.substring(4));
			}
			// File chọn từ Downloads/Recent thường có id dạng "msf:123" hoặc "123"
			String num = id.startsWith("msf:") ? id.substring(4) : id;
			if (num.matches("\\d+")) {
				Uri files = ContentUris.withAppendedId(MediaStore.Files.getContentUri("external"), Long.parseLong(num));
				try (Cursor c = getContentResolver().query(files, new String[] { "_data" }, null, null, null)) {
					if (c != null && c.moveToFirst()) {
						String p = c.getString(0);
						if (p != null) return new File(p);
					}
				}
			}
		} catch (Exception ignored) {
		}
		return null;
	}

	// ===== Decompile =====

	private void startDecompile(Uri uri) {
		final String name = queryName(uri);
		final String base = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name;

		// Nếu biết đường dẫn thật: tạo thư mục ngay cạnh file đã chọn
		File target = null;
		File src = resolvePath(uri);
		if (src != null && src.getParentFile() != null) {
			if (!hasStorageAccess()) {
				askStorageAccess();
				Toast.makeText(this, "Hãy cấp quyền 'Truy cập mọi tệp' rồi chọn file lại", Toast.LENGTH_LONG).show();
				return;
			}
			File parent = src.getParentFile();
			target = new File(parent, base + "-java");
			int n = 2;
			while (target.exists()) {
				target = new File(parent, base + "-java-" + n++);
			}
		}
		final File userOut = target; // null => dùng cách cũ (zip)
		log.setText(userOut != null ? "Xuất vào: " + userOut.getAbsolutePath() + "\n"
				: "Không đoán được đường dẫn file gốc -> sẽ xuất ra zip (bấm 'Lưu kết quả').\n");

		busy = true;
		btnPick.setEnabled(false);
		btnSave.setEnabled(false);
		bar.setProgress(0);
		final boolean noRes = cbNoRes.isChecked();
		final boolean deobf = cbDeobf.isChecked();
		Runnable task = () -> {
			try {
				setStatus("Đang chép file...");
				String ext = name.contains(".") ? name.substring(name.lastIndexOf('.')) : ".apk";
				File in = new File(getCacheDir(), "input" + ext);
				copy(uri, in);
				baseName = base;

				File out = userOut != null ? userOut : new File(getFilesDir(), "out");
				if (userOut == null) deleteRec(out);
				out.mkdirs();

				setStatus("Đang decompile (có thể lâu)...");
				JadxArgs args = new JadxArgs();
				args.setInputFile(in);
				args.setOutDir(out);
				args.setThreadsCount(1);
				args.setSkipResources(noRes);
				args.setDeobfuscationOn(deobf);
				args.setShowInconsistentCode(false);
				args.setDebugInfo(false);
				// Không giữ bản sao code của mọi class trong RAM -> đỡ bị Android giết app
				args.setCodeCache(NoOpCodeCache.INSTANCE);

				try (JadxDecompiler jadx = new JadxDecompiler(args)) {
					jadx.load();
					jadx.save(500, (done, total) -> runOnUiThread(() -> {
						if (total > 0) bar.setProgress((int) (done * 100 / total));
						status.setText("Decompile: " + done + " / " + total);
					}));
					int err = jadx.getErrorsCount();
					int warn = jadx.getWarnsCount();
					appendLog("Xong decompile. Lỗi: " + err + ", cảnh báo: " + warn);
				}
				in.delete();

				if (userOut != null) {
					runOnUiThread(() -> {
						bar.setProgress(100);
						status.setText("Hoàn tất. Đã lưu vào:\n" + userOut.getAbsolutePath());
					});
				} else {
					setStatus("Đang nén zip...");
					zipFile = new File(getCacheDir(), "output.zip");
					zipDir(out, zipFile);
					deleteRec(out);
					runOnUiThread(() -> {
						bar.setProgress(100);
						status.setText("Hoàn tất. Bấm 'Lưu kết quả' để lưu zip (" + (zipFile.length() / 1024) + " KB).");
						btnSave.setEnabled(true);
					});
				}
			} catch (Throwable t) {
				appendLog("LỖI: " + android.util.Log.getStackTraceString(t));
				setStatus("Thất bại: " + t);
			} finally {
				busy = false;
				runOnUiThread(() -> btnPick.setEnabled(true));
			}
		};
		// stack lớn vì jadx đệ quy sâu (32MB là đủ, 128MB nhiều máy không cấp nổi)
		new Thread(null, task, "jadx-worker", 32L * 1024 * 1024).start();
	}

	private void saveZip(Uri dest) {
		try (InputStream in = new FileInputStream(zipFile);
				OutputStream os = getContentResolver().openOutputStream(dest)) {
			byte[] buf = new byte[65536];
			int n;
			while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
			Toast.makeText(this, "Đã lưu", Toast.LENGTH_SHORT).show();
		} catch (Exception e) {
			Toast.makeText(this, "Lỗi lưu: " + e, Toast.LENGTH_LONG).show();
		}
	}

	private String queryName(Uri uri) {
		try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
			if (c != null && c.moveToFirst()) {
				int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
				if (idx >= 0) return c.getString(idx);
			}
		} catch (Exception ignored) {
		}
		return "input.apk";
	}

	private void copy(Uri uri, File dest) throws Exception {
		try (InputStream in = getContentResolver().openInputStream(uri);
				OutputStream os = new FileOutputStream(dest)) {
			byte[] buf = new byte[65536];
			int n;
			while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
		}
	}

	private static void zipDir(File dir, File zip) throws Exception {
		try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip))) {
			zipRec(dir, dir.getAbsolutePath().length() + 1, zos);
		}
	}

	private static void zipRec(File f, int prefix, ZipOutputStream zos) throws Exception {
		File[] list = f.listFiles();
		if (list == null) return;
		byte[] buf = new byte[65536];
		for (File c : list) {
			if (c.isDirectory()) {
				zipRec(c, prefix, zos);
			} else {
				zos.putNextEntry(new ZipEntry(c.getAbsolutePath().substring(prefix)));
				try (FileInputStream in = new FileInputStream(c)) {
					int n;
					while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
				}
				zos.closeEntry();
			}
		}
	}

	private static void deleteRec(File f) {
		File[] list = f.listFiles();
		if (list != null) for (File c : list) deleteRec(c);
		f.delete();
	}

	private void setStatus(String s) {
		runOnUiThread(() -> status.setText(s));
	}

	private void appendLog(String s) {
		runOnUiThread(() -> log.append(s + "\n"));
	}
}
