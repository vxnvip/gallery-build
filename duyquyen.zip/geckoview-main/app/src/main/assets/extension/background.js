// Doi header User-Agent thanh iPhone Safari va xoa Client Hints (Sec-CH-UA*)
var UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1';

chrome.webRequest.onBeforeSendHeaders.addListener(
  function (d) {
    var h = d.requestHeaders || [];
    var out = [];
    for (var i = 0; i < h.length; i++) {
      var n = h[i].name.toLowerCase();
      if (n === 'user-agent') { h[i].value = UA; out.push(h[i]); }
      else if (n.indexOf('sec-ch-ua') !== 0) { out.push(h[i]); }
    }
    return { requestHeaders: out };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestHeaders']
);
