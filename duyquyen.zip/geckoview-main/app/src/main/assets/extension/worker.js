/* global Network, Agent */

if (typeof importScripts !== 'undefined') {
  self.importScripts('context.js');
  self.importScripts('external/ua-parser.min.js', 'agent.js', 'network.js');
  self.importScripts('safeguard.js', 'managed.js');
}

const network = new Network();

chrome.storage.onChanged.addListener((ps, type) => {
  if (
    ps.mode || ps.ua || ps.blacklist || ps.whitelist || ps.custom || ps.sibilings ||
    ps.protected || ps.userAgentData || ps.parser ||
    type === 'session'
  ) {
    network.configure();
  }
});
{
  const once = () => {
    if (once.done) {
      return;
    }
    once.done = true;
    network.configure();
  };
  chrome.runtime.onStartup.addListener(once);
  chrome.runtime.onInstalled.addListener(once);
}

chrome.tabs.onRemoved.addListener(tabId => {
  chrome.storage.session.remove(String(tabId));
});

chrome.runtime.onMessage.addListener((request, sender, response) => {
  if (request.method === 'get-port-string') {
    // opaque-origin frames may message without a usable tab
    if (!sender.tab || !sender.tab.id) {
      response('');
      return true;
    }
    // wait for the first real web request and then resolve the UA
    if (request.cached && request.top) {
      let done = false;
      const reply = str => {
        if (!done) {
          done = true;
          response(str);
        }
      };

      const observe = d => {
        if (d.requestHeaders) {
          for (const o of d.requestHeaders) {
            if (o.name === 'User-Agent') {
              chrome.webRequest.onSendHeaders.removeListener(observe);
              const ua = o.value;
              const agent = new Agent();
              agent.prefs().then(() => {
                const o = agent.parse(ua);
                o.type = 'worker';
                reply(encodeURIComponent(JSON.stringify(o)));
              });

              break;
            }
          }
        }
      };

      chrome.webRequest.onSendHeaders.addListener(observe, {
        urls: ['*://*/*'],
        tabId: sender.tab.id
      }, ['requestHeaders']);

      // fully cached documents may never fire onSendHeaders; without this
      // the requesting frame stays unspoofed forever (a real-UA leak).
      // resolveFor mirrors the DNR scope so out-of-scope or protected URLs
      // resolve to '' (real UA) instead of being spoofed here
      setTimeout(() => {
        chrome.webRequest.onSendHeaders.removeListener(observe);
        const agent = new Agent();
        chrome.tabs.get(sender.tab.id).then(({url}) => agent.resolveFor(url))
          .then(str => {
            if (!str) {
              reply('');
              return;
            }
            const o = agent.parse(str);
            o.type = 'worker';
            reply(encodeURIComponent(JSON.stringify(o)));
          })
          .catch(() => reply(''));
      }, 5000);
    }
    else {
      chrome.scripting.executeScript({
        target: {
          tabId: sender.tab.id
        },
        func: () => {
          try {
            return self.port.dataset.disabled === 'true' ? '' : (self.port.dataset.str || '');
          }
          catch (e) {
            return '';
          }
        }
      }).then(r => response(r && r[0] ? r[0].result : ''), () => response(''));
    }

    return true;
  }
  else if (request.method === 'tab-spoofing') {
    let dir = 'active';
    if (request.type === 'per-tab' || request.type === 'custom' || request.type === 'worker') {
      dir = request.type;
    }

    chrome.action.setIcon({
      tabId: sender.tab.id,
      path: {
        '16': '/data/icons/' + dir + '/16.png',
        '32': '/data/icons/' + dir + '/32.png',
        '48': '/data/icons/' + dir + '/48.png'
      }
    });
    const o = JSON.parse(decodeURIComponent(request.str));
    chrome.action.setTitle({
      tabId: sender.tab.id,
      title: '[' + request.type + '] ' + o.userAgent
    });
  }
  else {
    if (request.method !== 'update-from-remote') {
      console.error('UNKOWN_COMMAND', request);
    }
  }
});

/* FAQs & Feedback */
{
  chrome.management = chrome.management || {
    getSelf(c) {
      c({installType: 'normal'});
    }
  };
  if (navigator.webdriver !== true) {
    const {homepage_url: page, name, version} = chrome.runtime.getManifest();
    chrome.runtime.onInstalled.addListener(({reason, previousVersion}) => {
      chrome.management.getSelf(({installType}) => installType === 'normal' && chrome.storage.local.get({
        'faqs': true,
        'last-update': 0
      }, prefs => {
        if (reason === 'install' || (prefs.faqs && reason === 'update')) {
          const doUpdate = (Date.now() - prefs['last-update']) / 1000 / 60 / 60 / 24 > 45;
          if (doUpdate && previousVersion !== version) {
            chrome.tabs.query({active: true, lastFocusedWindow: true}, tbs => chrome.tabs.create({
              url: page + '?version=' + version + (previousVersion ? '&p=' + previousVersion : '') + '&type=' + reason,
              active: reason === 'install',
              ...(tbs && tbs.length && {index: tbs[0].index + 1})
            }));
            chrome.storage.local.set({'last-update': Date.now()});
          }
        }
      }));
    });
    chrome.runtime.setUninstallURL(page + '?rd=feedback&name=' + encodeURIComponent(name) + '&version=' + version);
  }
}
