package com.example.geckobrowser

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.geckobrowser.databinding.ActivityMainBinding
import org.json.JSONObject
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebRequestError
import java.util.UUID

private const val TAG = "GeckoBrowser"

/** Location of the bundled extension inside app/src/main/assets/extension/ */
private const val EXTENSION_LOCATION = "resource://android/assets/extension/"

/** Must match browser_specific_settings.gecko.id in assets/extension/manifest.json */
private const val EXTENSION_ID = "iphone-ua-simple@local"

private const val NATIVE_APP_ID = "browser"

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var runtime: GeckoRuntime
    private var geckoSession: GeckoSession? = null
    private var geckoView: GeckoView? = null
    private var extensionPort: WebExtension.Port? = null

    private var canGoBackInBrowser = false
    private var lastLoadedUrl: String? = null

    // Tai khoan (tab doc lap) dang mo
    private var accs = mutableListOf<Account>()
    private var currentProfile: String? = null
    private var isNewAccount = false
    private var savedAccount = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        runtime = AppGeckoRuntime.get(this)
        installExtension()

        binding.addAccountButton.setOnClickListener {
            openAccount("acc_" + UUID.randomUUID().toString().replace("-", ""), true)
        }
        binding.accountList.setOnItemClickListener { _, _, i, _ ->
            openAccount(accs[i].profileId, false)
        }
        binding.accountList.setOnItemLongClickListener { _, _, i, _ ->
            showAccountMenu(i)
            true
        }

        binding.goButton.setOnClickListener { goToTypedUrl() }
        binding.urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                goToTypedUrl()
                true
            } else {
                false
            }
        }
        binding.saveButton.setOnClickListener { showSaveDialog() }
        binding.errorRetryButton.setOnClickListener { retryLastLoadedUrl() }
        binding.errorHomeButton.setOnClickListener { leaveBrowser() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    binding.browserContainer.visibility != View.VISIBLE -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                    canGoBackInBrowser -> geckoSession?.goBack()
                    else -> leaveBrowser()
                }
            }
        })

        refreshList()
    }

    // ------------------------------------------------------------------
    // WebExtension install + Android <-> extension messaging
    // ------------------------------------------------------------------

    private fun installExtension() {
        runtime.webExtensionController
            .ensureBuiltIn(EXTENSION_LOCATION, EXTENSION_ID)
            .accept({ extension ->
                if (extension == null) return@accept
                Log.i(TAG, "WebExtension installed: ${extension.id}")

                extension.setMessageDelegate(object : WebExtension.MessageDelegate {
                    override fun onConnect(port: WebExtension.Port) {
                        Log.i(TAG, "Extension opened a native port")
                        extensionPort = port
                        port.setDelegate(object : WebExtension.PortDelegate {
                            override fun onPortMessage(message: Any, port: WebExtension.Port) {
                                Log.i(TAG, "Message from extension: $message")
                            }

                            override fun onDisconnect(port: WebExtension.Port) {
                                Log.i(TAG, "Extension port disconnected")
                                if (extensionPort === port) {
                                    extensionPort = null
                                }
                            }
                        })

                        // Demonstration message: Android -> extension.
                        port.postMessage(JSONObject().apply { put("type", "START") })
                    }
                }, NATIVE_APP_ID)
            }, { exception ->
                Log.e(TAG, "Failed to install bundled WebExtension", exception)
            })
    }

    /** Example of sending an on-demand message from the app to the extension. */
    private fun sendStartMessageToExtension() {
        extensionPort?.postMessage(JSONObject().apply { put("type", "START") })
    }

    // ------------------------------------------------------------------
    // Danh sach tai khoan (port tu GolikeMulti MainActivity)
    // ------------------------------------------------------------------

    private fun refreshList() {
        accs = Store.all(this)
        binding.accountList.adapter = object : ArrayAdapter<String>(
            this, android.R.layout.simple_list_item_1, accs.map { it.name }
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(this@MainActivity.getColor(R.color.on_background))
                return v
            }
        }
    }

    private fun showAccountMenu(i: Int) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Đổi tên", "Xóa")) { _, w -> if (w == 0) renameAccount(i) else deleteAccount(i) }
            .show()
    }

    private fun renameAccount(i: Int) {
        val input = EditText(this).apply { setText(accs[i].name) }
        AlertDialog.Builder(this).setTitle("Đổi tên").setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && accs.none { it.name == n }) {
                    accs[i].name = n
                    Store.save(this, accs)
                    refreshList()
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun deleteAccount(i: Int) {
        AlertDialog.Builder(this).setTitle("Xóa ${accs[i].name}?")
            .setMessage("Dữ liệu đăng nhập của tài khoản này cũng bị xóa.")
            .setPositiveButton("Xóa") { _, _ ->
                runtime.storageController.clearDataForSessionContext(accs[i].profileId)
                accs.removeAt(i)
                Store.save(this, accs)
                refreshList()
            }.setNegativeButton("Hủy", null).show()
    }

    // ------------------------------------------------------------------
    // Mo tai khoan = 1 GeckoSession rieng (contextId rieng => cookie/storage doc lap)
    // ------------------------------------------------------------------

    private fun openAccount(profileId: String, isNew: Boolean) {
        currentProfile = profileId
        isNewAccount = isNew
        savedAccount = false

        binding.saveButton.visibility = if (isNew) View.VISIBLE else View.GONE
        binding.homeContainer.visibility = View.GONE
        binding.browserContainer.visibility = View.VISIBLE
        binding.errorContainer.visibility = View.GONE

        closeSession()
        val settings = GeckoSessionSettings.Builder()
            .contextId(profileId)
            .build()
        val session = GeckoSession(settings)
        session.open(runtime)
        attachDelegates(session)
        geckoSession = session

        val view = GeckoView(this)
        view.setSession(session)
        binding.geckoViewHolder.removeAllViews()
        binding.geckoViewHolder.addView(view)
        geckoView = view
        canGoBackInBrowser = false

        lastLoadedUrl = getString(R.string.target_url)
        binding.urlInput.setText(lastLoadedUrl)
        session.loadUri(lastLoadedUrl!!)
    }

    private fun closeSession() {
        geckoSession?.close()
        geckoSession = null
        geckoView = null
        binding.geckoViewHolder.removeAllViews()
    }

    /** Thoat man hinh trinh duyet. Tai khoan moi chua luu thi hoi xoa du lieu. */
    private fun leaveBrowser() {
        if (isNewAccount && !savedAccount) {
            AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discardAccount() }
                .setNegativeButton("Ở lại", null).show()
        } else {
            showHome()
        }
    }

    private fun discardAccount() {
        currentProfile?.let { runtime.storageController.clearDataForSessionContext(it) }
        showHome()
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(currentProfile!!, name))
                        Store.save(this, list)
                        savedAccount = true
                        showHome()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun showHome() {
        closeSession()
        canGoBackInBrowser = false
        isNewAccount = false
        currentProfile = null
        binding.homeContainer.visibility = View.VISIBLE
        binding.browserContainer.visibility = View.GONE
        refreshList()
    }

    // ------------------------------------------------------------------
    // Thanh dia chi
    // ------------------------------------------------------------------

    private fun goToTypedUrl() {
        val url = normalizeUrl(binding.urlInput.text.toString())
        binding.urlInput.setText(url)
        binding.urlInput.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(binding.urlInput.windowToken, 0)
        binding.errorContainer.visibility = View.GONE
        lastLoadedUrl = url
        geckoSession?.loadUri(url)
    }

    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return getString(R.string.target_url)
        val schemes = listOf("http://", "https://", "resource://", "about:", "moz-extension://")
        if (schemes.any { s.startsWith(it, ignoreCase = true) }) return s
        if (!s.contains(" ") && (s.contains(".") || s.startsWith("localhost"))) return "https://$s"
        return "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(s, "UTF-8")
    }

    private fun retryLastLoadedUrl() {
        binding.errorContainer.visibility = View.GONE
        val url = lastLoadedUrl ?: getString(R.string.target_url)
        geckoSession?.loadUri(url)
    }

    // ------------------------------------------------------------------
    // GeckoSession delegates: loading indicator, navigation, errors
    // ------------------------------------------------------------------

    private fun attachDelegates(session: GeckoSession) {
        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                if (!binding.urlInput.hasFocus()) binding.urlInput.setText(url)
                binding.loadingIndicator.visibility = View.VISIBLE
                binding.errorContainer.visibility = View.GONE
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                binding.loadingIndicator.visibility = View.GONE
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                canGoBackInBrowser = canGoBack
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                runOnUiThread {
                    binding.loadingIndicator.visibility = View.GONE
                    binding.errorContainer.visibility = View.VISIBLE
                    binding.errorMessage.text = describeError(error, uri)
                }
                // Returning null tells GeckoView not to load a replacement error page;
                // we render our own native error UI instead.
                return GeckoResult.fromValue(null)
            }
        }
    }

    private fun describeError(error: WebRequestError, uri: String?): String {
        val target = uri ?: getString(R.string.target_url)
        return "$target\n\n(error code: ${error.code}, category: ${error.category})"
    }

    override fun onDestroy() {
        geckoSession?.close()
        super.onDestroy()
    }
}
