# Music Volume EQ - clean project

Clean Gradle project. UI is programmatic (`MainActivity` + custom views `EqView`, `KnobView`, `PillSwitch`, `IconView`, `VuView`), two screens. Home (`MainActivity`): spectrum analyzer + EQ/BASS/VIRT toggles + vertical volume slider + EQ button. EQ page (`EqActivity`), laid out like the reference screenshot: EQUALIZER card with curve + `10 EQ` pill, PRESET card with BASS BOOST / VIRTUALIZER knobs and a VU button; the speaker icon opens volume/lock + Preamp/Balance/Limiter; the audio engine is `EqService` (port of `hr.podlanica.MusicVolumeEQ` 7.0).

## Build
Push to GitHub; Actions (`.github/workflows/build.yml`) produces `app-debug.apk`. Locally: JDK 17 + Android SDK 34, `gradle assembleDebug`.

## Audio port status
1:1 (same effects/params/math/prefs keys): Equalizer BassBoost, Virtualizer, LoudnessEnhancer (+500 ms re-apply),
DynamicsProcessing (10-band pre-EQ @ 32..16000 Hz, limiter, balance, preamp), device-type detection, session receiver.

NOT recoverable from the decompile - verify against the original APK on a device:
- `onStartCommand` body (decompiler failed) -> rebuilt from callers: STOP extra, EQ/BASS/VIRT toggle actions, SET/RELAISE_EQ10, START_STICKY.
- MBC band setter order (`setupMbc`): API wrapper classes were stripped; values assigned by type/value. Original never reached it from recoverable code.
- Per-headphone preset DB (SQLite `presets10`, AutoEQ) and volume-lock handler: not ported.
- Notification layout simplified.
