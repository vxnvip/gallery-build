package hr.podlanica.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import hr.podlanica.view.EqualizerView;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class EqualizerView extends View {
    private int[] A;
    private final Paint B;
    private final Paint C;
    private final Paint D;
    private final Paint E;
    private final Paint F;
    private final Paint G;
    private final Paint H;
    private final Paint I;
    private final Paint J;
    private final Paint K;
    private final Bitmap L;
    private final BitmapShader M;
    private final Paint N;
    private c O;
    private final List<c> P;
    private android.view.GestureDetector Q;

    /* renamed from: n  reason: collision with root package name */
    private b f18262n;

    /* renamed from: o  reason: collision with root package name */
    private final int f18263o;

    /* renamed from: p  reason: collision with root package name */
    private final String[] f18264p;

    /* renamed from: q  reason: collision with root package name */
    private final int f18265q;

    /* renamed from: r  reason: collision with root package name */
    private float f18266r;

    /* renamed from: s  reason: collision with root package name */
    private float f18267s;

    /* renamed from: t  reason: collision with root package name */
    private float f18268t;

    /* renamed from: u  reason: collision with root package name */
    private float f18269u;

    /* renamed from: v  reason: collision with root package name */
    private float f18270v;

    /* renamed from: w  reason: collision with root package name */
    private float f18271w;

    /* renamed from: x  reason: collision with root package name */
    private final Path f18272x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f18273y;

    /* renamed from: z  reason: collision with root package name */
    private boolean f18274z;

    /* loaded from: classes.dex */
    public final class a extends GestureDetector.SimpleOnGestureListener {
        public a() {
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            float e4;
            EqualizerView.this.f18273y = true;
            EqualizerView.this.O = null;
            EqualizerView equalizerView = EqualizerView.this;
            for (c cVar : EqualizerView.this.P) {
                if (cVar.i(motionEvent.getX(), motionEvent.getY())) {
                    equalizerView.O = cVar;
                    e4 = coerce(motionEvent.getY(), cVar.h(), cVar.d());
                    cVar.j(e4);
                    equalizerView.invalidate();
                    return true;
                }
            }
            return false;
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            float e4;
            c cVar = EqualizerView.this.O;
            if (cVar != null) {
                EqualizerView equalizerView = EqualizerView.this;
                e4 = coerce(motionEvent2.getY(), cVar.h(), cVar.d());
                cVar.j(e4);
                equalizerView.invalidate();
                b onScrollListener = equalizerView.getOnScrollListener();
                if (onScrollListener != null) {
                    onScrollListener.a(equalizerView.O, f4, f5);
                    return true;
                }
                return true;
            }
            return false;
        }
    }

    /* loaded from: classes.dex */
    public interface b {
        void a(c cVar, float f4, float f5);
    }

    /* loaded from: classes.dex */
    public static final class c {

        /* renamed from: a  reason: collision with root package name */
        private final float f18276a;

        /* renamed from: b  reason: collision with root package name */
        private final float f18277b;

        /* renamed from: c  reason: collision with root package name */
        private final float f18278c;

        /* renamed from: d  reason: collision with root package name */
        private final float f18279d;

        /* renamed from: e  reason: collision with root package name */
        private final float f18280e;

        /* renamed from: f  reason: collision with root package name */
        private final int f18281f;

        /* renamed from: g  reason: collision with root package name */
        private float f18282g;

        /* renamed from: h  reason: collision with root package name */
        private float f18283h;

        /* renamed from: i  reason: collision with root package name */
        private final float f18284i;

        /* renamed from: j  reason: collision with root package name */
        private final float f18285j;

        public c(float f4, float f5, float f6, float f7, float f8, int i4, float f9) {
            this.f18276a = f4;
            this.f18277b = f5;
            this.f18278c = f6;
            this.f18279d = f7;
            this.f18280e = f8;
            this.f18281f = i4;
            this.f18282g = f9;
            this.f18283h = (f6 / 2.0f) + f7;
            this.f18284i = f7;
            this.f18285j = f8;
        }

        public final float a() {
            return this.f18283h;
        }

        public final float b() {
            return this.f18282g;
        }

        public final int c() {
            return this.f18281f;
        }

        public final float d() {
            return this.f18285j;
        }

        public final float e() {
            return this.f18278c;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof c) {
                c cVar = (c) obj;
                return Float.compare(this.f18276a, cVar.f18276a) == 0 && Float.compare(this.f18277b, cVar.f18277b) == 0 && Float.compare(this.f18278c, cVar.f18278c) == 0 && Float.compare(this.f18279d, cVar.f18279d) == 0 && Float.compare(this.f18280e, cVar.f18280e) == 0 && this.f18281f == cVar.f18281f && Float.compare(this.f18282g, cVar.f18282g) == 0;
            }
            return false;
        }

        public final float f() {
            return this.f18276a;
        }

        public final float g() {
            return this.f18277b;
        }

        public final float h() {
            return this.f18284i;
        }

        public int hashCode() {
            return (((((((((((Float.floatToIntBits(this.f18276a) * 31) + Float.floatToIntBits(this.f18277b)) * 31) + Float.floatToIntBits(this.f18278c)) * 31) + Float.floatToIntBits(this.f18279d)) * 31) + Float.floatToIntBits(this.f18280e)) * 31) + this.f18281f) * 31) + Float.floatToIntBits(this.f18282g);
        }

        public final boolean i(float f4, float f5) {
            return Math.abs(((this.f18276a + this.f18277b) / 2.0f) - f4) <= 80.0f;
        }

        public final void j(float f4) {
            this.f18283h = f4;
        }

        public final void k(float f4) {
            this.f18282g = f4;
        }

        public String toString() {
            return "Slider(sliderLeft=" + this.f18276a + ", sliderRight=" + this.f18277b + ", sliderHeight=" + this.f18278c + ", sliderTop1=" + this.f18279d + ", sliderBottom1=" + this.f18280e + ", index=" + this.f18281f + ", freq=" + this.f18282g + ')';
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EqualizerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f18263o = 10;
        this.f18264p = new String[]{"32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K"};
        this.f18265q = i(3);
        this.f18266r = 1000.0f;
        this.f18267s = 6.0f;
        this.f18268t = 15.0f;
        this.f18272x = new Path();
        this.f18274z = true;
        this.A = new int[]{-16711936, 0};
        Paint paint = new Paint();
        paint.setColor(androidx.core.content.ContextCompat.getColor(context, R.color.dracula_txt));
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        paint.setAlpha(64);
        this.B = paint;
        Paint paint2 = new Paint();
        paint2.setColor(-16711936);
        paint2.setStyle(Paint.Style.FILL);
        paint2.setAntiAlias(true);
        paint2.setAlpha(230);
        this.C = paint2;
        Paint paint3 = new Paint();
        paint3.setColor(-7829368);
        paint3.setStyle(Paint.Style.FILL);
        paint3.setAntiAlias(true);
        paint3.setAlpha(230);
        this.D = paint3;
        Paint paint4 = new Paint();
        paint4.setColor(-1);
        paint4.setStyle(Paint.Style.FILL);
        paint4.setAntiAlias(true);
        paint4.setAlpha(90);
        this.E = paint4;
        Paint paint5 = new Paint();
        paint5.setColor(-16711936);
        paint5.setStyle(Paint.Style.STROKE);
        paint5.setStrokeWidth(h(3.0f));
        paint5.setAntiAlias(true);
        paint5.setAlpha(128);
        this.F = paint5;
        Paint paint6 = new Paint();
        paint6.setColor(-7829368);
        paint6.setStyle(Paint.Style.STROKE);
        paint6.setStrokeWidth(h(3.0f));
        paint6.setAntiAlias(true);
        paint6.setAlpha(128);
        this.G = paint6;
        Paint paint7 = new Paint();
        paint7.setColor(-16711936);
        paint7.setStyle(Paint.Style.STROKE);
        paint7.setStrokeWidth(h(2.0f));
        paint7.setAntiAlias(true);
        paint7.setAlpha(128);
        this.H = paint7;
        Paint paint8 = new Paint();
        paint8.setColor(-7829368);
        paint8.setStyle(Paint.Style.STROKE);
        paint8.setStrokeWidth(h(2.0f));
        paint8.setAntiAlias(true);
        paint8.setAlpha(128);
        this.I = paint8;
        Paint paint9 = new Paint();
        paint9.setColor(androidx.core.content.ContextCompat.getColor(context, R.color.dracula_txt));
        paint9.setTextSize(h(13.0f));
        paint9.setTextAlign(Paint.Align.CENTER);
        paint9.setAntiAlias(true);
        paint9.setTypeface(Typeface.MONOSPACE);
        paint9.setAlpha(200);
        this.J = paint9;
        Paint paint10 = new Paint();
        paint10.setAntiAlias(true);
        this.K = paint10;
        Bitmap k4 = k(h(1.5f), -7829368, h(2.0f));
        this.L = k4;
        Shader.TileMode tileMode = Shader.TileMode.REPEAT;
        BitmapShader bitmapShader = new BitmapShader(k4, tileMode, tileMode);
        this.M = bitmapShader;
        Paint paint11 = new Paint();
        paint11.setAntiAlias(true);
        paint11.setShader(bitmapShader);
        paint11.setStyle(Paint.Style.FILL);
        paint11.setAlpha(12);
        this.N = paint11;
        this.P = new ArrayList();
        post(new Runnable() { // from class: e2.a
            @Override // java.lang.Runnable
            public final void run() {
                EqualizerView.c(EqualizerView.this);
            }
        });
        this.Q = new android.view.GestureDetector(context, new a());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void c(EqualizerView equalizerView) {
        equalizerView.o();
        equalizerView.K.setShader(new LinearGradient(0.0f, 0.0f, 0.0f, equalizerView.getHeight(), equalizerView.A, (float[]) null, Shader.TileMode.CLAMP));
        equalizerView.K.setAlpha(14);
        int i4 = equalizerView.f18263o;
        for (int i5 = 0; i5 < i4; i5++) {
            float width = (equalizerView.getWidth() / 20.0f) + ((equalizerView.f18265q + ((equalizerView.getWidth() / equalizerView.f18263o) - (equalizerView.getWidth() / 100))) * i5);
            equalizerView.P.add(new c(width, width + equalizerView.f18265q, equalizerView.f18266r, equalizerView.f18269u, equalizerView.f18270v, i5, 0.0f));
        }
        equalizerView.invalidate();
    }

    private final void j(Canvas canvas) {
        Path path;
        Paint paint;
        Object p4;
        Object p5;
        Object p6;
        Object k4;
        Object k5;
        Object k6;
        if (this.P.size() > 1) {
            this.f18272x.reset();
            this.f18272x.moveTo((this.P.get(0).f() + this.P.get(0).g()) / 2.0f, this.P.get(0).a());
            int size = this.P.size();
            for (int i4 = 0; i4 < size; i4++) {
                c cVar = this.P.get(i4);
                float f4 = (cVar.f() + cVar.g()) / 2.0f;
                float a4 = cVar.a();
                if (i4 == 0) {
                    this.f18272x.moveTo(f4, a4);
                } else {
                    c cVar2 = this.P.get(i4 - 1);
                    float a5 = cVar2.a();
                    float f5 = (((cVar2.f() + cVar2.g()) / 2.0f) + f4) / 2;
                    this.f18272x.cubicTo(f5, a5, f5, a4, f4, a4);
                }
            }
            if (this.f18274z) {
                path = this.f18272x;
                paint = this.H;
            } else {
                path = this.f18272x;
                paint = this.I;
            }
            canvas.drawPath(path, paint);
            Path path2 = this.f18272x;
            p4 = this.P.get(this.P.size() - 1);
            float f6 = ((c) p4).f();
            p5 = this.P.get(this.P.size() - 1);
            p6 = this.P.get(this.P.size() - 1);
            path2.lineTo((f6 + ((c) p5).g()) / 2.0f, ((c) p6).d());
            Path path3 = this.f18272x;
            k4 = this.P.get(0);
            float f7 = ((c) k4).f();
            k5 = this.P.get(0);
            k6 = this.P.get(0);
            path3.lineTo((f7 + ((c) k5).g()) / 2.0f, ((c) k6).d());
            this.f18272x.close();
            if (this.f18274z) {
                canvas.drawPath(this.f18272x, this.N);
            }
            if (this.f18274z) {
                canvas.drawPath(this.f18272x, this.K);
            }
        }
    }

    private final void l() {
        this.f18266r = getHeight() - (getHeight() / 4.0f);
        this.f18269u = getHeight() / 8.0f;
        float height = this.f18266r + (getHeight() / 10.0f);
        this.f18270v = height;
        this.f18266r = height - this.f18269u;
        this.f18268t = getHeight() / 20.0f;
        this.f18267s = getHeight() / 40.0f;
        this.F.setStrokeWidth(getWidth() / 120.0f);
        this.H.setStrokeWidth(getHeight() / 130.0f);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void n(c cVar, EqualizerView equalizerView, ValueAnimator valueAnimator) {
        cVar.j(((Integer) valueAnimator.getAnimatedValue()).intValue());
        equalizerView.invalidate();
    }

    private final void o() {
        Paint paint;
        int i4;
        Paint paint2;
        int i5;
        String string = android.preference.PreferenceManager.getDefaultSharedPreferences(getContext()).getString("teme_preference", "2");
        int parseInt = Integer.parseInt(string);
        if (parseInt == -1) {
            this.A = new int[]{-16711936, 0};
            paint = this.F;
            i4 = -16711936;
        } else if (parseInt != 0) {
            if (parseInt == 1) {
                Context context = getContext();
                i5 = R.color.plava_studio;
                this.A = new int[]{androidx.core.content.ContextCompat.getColor(context, R.color.plava_studio), 0};
            } else if (parseInt != 2) {
                return;
            } else {
                Context context2 = getContext();
                i5 = R.color.flat_zelena;
                this.A = new int[]{androidx.core.content.ContextCompat.getColor(context2, R.color.flat_zelena), androidx.core.content.ContextCompat.getColor(getContext(), R.color.flat_podloga)};
            }
            this.F.setColor(androidx.core.content.ContextCompat.getColor(getContext(), i5));
            this.H.setColor(androidx.core.content.ContextCompat.getColor(getContext(), i5));
            paint2 = this.C;
            i4 = androidx.core.content.ContextCompat.getColor(getContext(), i5);
            paint2.setColor(i4);
        } else {
            this.A = new int[]{androidx.core.content.ContextCompat.getColor(getContext(), R.color.material_sivo_plava), 0};
            this.J.setColor(-12303292);
            paint = this.F;
            i4 = -65536;
        }
        paint.setColor(i4);
        this.H.setColor(i4);
        paint2 = this.C;
        paint2.setColor(i4);
    }

    public final b getOnScrollListener() {
        return this.f18262n;
    }

    public final float h(float f4) {
        return f4 * getResources().getDisplayMetrics().density;
    }

    public final int i(int i4) {
        return i4 * ((int) getResources().getDisplayMetrics().density);
    }

    public final Bitmap k(float f4, int i4, float f5) {
        float f6 = 2;
        int i5 = (int) ((f4 * f6) + (f6 * f5));
        Bitmap createBitmap = Bitmap.createBitmap(i5, i5, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint(1);
        paint.setColor(i4);
        float f7 = f5 + f4;
        canvas.drawCircle(f7, f7, f4, paint);
        return createBitmap;
    }

    public final void m(float[] fArr, boolean z3) {
        float e4;
        if (fArr.length != this.P.size()) {
            return;
        }
        int i4 = 0;
        for (Object obj : this.P) {
            int i5 = i4 + 1;
            if (i4 < 0) {
            }
            final c cVar = (c) obj;
            e4 = coerce(fArr[i4], -15.0f, 15.0f);
            float f4 = ((((-e4) - (-15.0f)) / 30.0f) * this.f18266r) + this.f18269u;
            if (z3) {
                ValueAnimator ofInt = ValueAnimator.ofInt((int) cVar.a(), (int) f4);
                ofInt.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: e2.b
                    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                        EqualizerView.n(EqualizerView.c.this, this, valueAnimator);
                    }
                });
                ofInt.setDuration(1000L);
                ofInt.start();
            } else {
                cVar.j(f4);
            }
            i4 = i5;
        }
        if (z3) {
            return;
        }
        invalidate();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        float a4;
        float f4;
        Paint paint;
        int i4 = 0;
        for (Object obj : this.P) {
            int i5 = i4 + 1;
            if (i4 < 0) {
            }
            c cVar = (c) obj;
            canvas.drawRect(cVar.f(), cVar.h(), cVar.g(), cVar.d(), this.B);
            float f5 = (cVar.f() + cVar.g()) / 2.0f;
            this.f18271w = f5;
            if (this.f18274z) {
                a4 = cVar.a();
                f4 = this.f18267s;
                paint = this.C;
            } else {
                a4 = cVar.a();
                f4 = this.f18267s;
                paint = this.D;
            }
            canvas.drawCircle(f5, a4, f4, paint);
            if (this.f18273y && java.util.Objects.equals(cVar, this.O)) {
                float f6 = (cVar.f() + cVar.g()) / 2.0f;
                this.f18271w = f6;
                canvas.drawCircle(f6, cVar.a(), this.f18268t, this.E);
            }
            canvas.drawLine(this.f18271w, cVar.a(), this.f18271w, cVar.d(), this.f18274z ? this.F : this.G);
            this.f18272x.lineTo(this.f18271w, cVar.a());
            j(canvas);
            canvas.drawText(this.f18264p[i4], this.f18271w, getHeight() / 14.0f, this.J);
            float d4 = cVar.d() + (getHeight() / 10.0f);
            float d5 = (((cVar.d() - cVar.a()) / cVar.e()) * 30.0f) - 15.0f;
            cVar.k((float) new BigDecimal(String.valueOf(d5)).setScale(1, RoundingMode.UP).doubleValue());
            StringBuilder sb = new StringBuilder();
            sb.append(d5 > 0.0f ? "+" : "");
            sb.append((int) d5);
            canvas.drawText(sb.toString(), this.f18271w, d4, this.J);
            i4 = i5;
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        super.onSizeChanged(i4, i5, i6, i7);
        l();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f18274z) {
            if (motionEvent.getActionMasked() == 1) {
                this.f18273y = false;
                invalidate();
            }
            return a(motionEvent) || super.onTouchEvent(motionEvent);
        }
        return true;
    }

    @Override // android.view.View
    public void setEnabled(boolean z3) {
        this.f18274z = z3;
        invalidate();
    }

    public final void setOnScrollListener(b bVar) {
        this.f18262n = bVar;
    }

    private static float coerce(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
