package hr.podlanica;

import app.eqclean.EqService;

/**
 * Shim: the original views call static hooks on hr.podlanica.MusicVolumeEQ (the service).
 * Here the hooks forward to app.eqclean.EqService (the ported engine).
 * Field names keep the original jadx names so the ported views compile unchanged:
 *   a0=60Hz, b0=14kHz, c0=230Hz, d0=3kHz, e0=910Hz (knob pixel positions), f0=bass, g0=virtualizer (0..1000)
 */
public final class MusicVolumeEQ {
    private MusicVolumeEQ() {}

    public static int f17960a0, f17961b0, f17962c0, f17963d0, f17964e0, f17965f0, f17966g0;

    public interface BandListener { void onBand(int band, String dbLabel); }
    public static BandListener listener;

    private static void band(int idx, int pos) {
        EqService.setBand(idx, pos);
        if (listener != null) listener.onBand(idx, EqService.bandLabel(pos));
    }

    public static void n() { EqService.pos60  = f17960a0; band(0, f17960a0); }
    public static void j() { EqService.pos230 = f17962c0; band(1, f17962c0); }
    public static void p() { EqService.pos910 = f17964e0; band(2, f17964e0); }
    public static void l() { EqService.pos3k  = f17963d0; band(3, f17963d0); }
    public static void h() { EqService.pos14k = f17961b0; band(4, f17961b0); }

    public static void d() {
        EqService.bassLevel = f17965f0;
        if (EqService.bassOn && EqService.bass != null) try { EqService.bass.setStrength((short) f17965f0); } catch (Exception ignored) {}
    }
    public static void w() {
        EqService.virtLevel = f17966g0;
        if (EqService.virtOn && EqService.virt != null) try { EqService.virt.setStrength((short) f17966g0); } catch (Exception ignored) {}
    }

    /** Call from an activity before inflating, so the views start from the engine's current state. */
    public static void syncFromEngine() {
        f17960a0 = EqService.pos60; f17962c0 = EqService.pos230; f17964e0 = EqService.pos910;
        f17963d0 = EqService.pos3k; f17961b0 = EqService.pos14k;
        f17965f0 = EqService.bassLevel; f17966g0 = EqService.virtLevel;
    }
}
