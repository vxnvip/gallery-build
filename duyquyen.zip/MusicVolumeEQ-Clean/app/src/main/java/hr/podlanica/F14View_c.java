package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* renamed from: hr.podlanica.F14View_c  reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class F14View_c extends View {

    /* renamed from: z  reason: collision with root package name */
    private static int f17842z;

    /* renamed from: n  reason: collision with root package name */
    private int f17843n;

    /* renamed from: o  reason: collision with root package name */
    private float f17844o;

    /* renamed from: p  reason: collision with root package name */
    float[] f17845p;

    /* renamed from: q  reason: collision with root package name */
    private int f17846q;

    /* renamed from: r  reason: collision with root package name */
    private int f17847r;

    /* renamed from: s  reason: collision with root package name */
    private int f17848s;

    /* renamed from: t  reason: collision with root package name */
    private int f17849t;

    /* renamed from: u  reason: collision with root package name */
    private GestureDetector f17850u;

    /* renamed from: v  reason: collision with root package name */
    private Matrix f17851v;

    /* renamed from: w  reason: collision with root package name */
    private Bitmap f17852w;

    /* renamed from: x  reason: collision with root package name */
    private Bitmap f17853x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f17854y;

    /* renamed from: hr.podlanica.F14View_c$a */
    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F14View_c.this.f17854y = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: hr.podlanica.F14View_c$b */
    /* loaded from: classes.dex */
    public class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F14View_c.this.f17854y = false;
        }
    }

    /* renamed from: hr.podlanica.F14View_c$c */
    /* loaded from: classes.dex */
    private class c implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        F14View_c f17857a;

        public c(F14View_c c0252F14View_c) {
            this.f17857a = c0252F14View_c;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            F14View_c.this.f17854y = true;
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            this.f17857a.d(-f4, -f5);
            F14View_c.a();
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    public F14View_c(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17843n = 0;
        this.f17845p = new float[9];
        this.f17854y = false;
    }

    public F14View_c(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17843n = 0;
        this.f17845p = new float[9];
        this.f17854y = false;
    }

    public static void a() {
        EQ.b();
    }

    public void b() {
        Matrix matrix = new Matrix();
        this.f17851v = matrix;
        matrix.postTranslate(0.0f, MusicVolumeEQ.f17961b0);
        this.f17854y = true;
        invalidate();
        new Handler().postDelayed(new b(), 500L);
    }

    public void d(float f4, float f5) {
        this.f17854y = true;
        this.f17851v.postTranslate(0.0f, f5);
        invalidate();
    }

    public void e() {
        MusicVolumeEQ.h();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        this.f17851v.getValues(this.f17845p);
        float[] fArr = this.f17845p;
        float f4 = fArr[5];
        this.f17844o = f4;
        if (f4 <= 0.0f) {
            this.f17844o = 0.0f;
            fArr[5] = 0.0f;
            this.f17851v.setValues(fArr);
        }
        float f5 = this.f17844o;
        int i4 = this.f17849t;
        if (f5 >= i4) {
            float f6 = i4;
            this.f17844o = f6;
            float[] fArr2 = this.f17845p;
            fArr2[5] = f6;
            this.f17851v.setValues(fArr2);
        }
        canvas.drawBitmap(this.f17852w, this.f17851v, null);
        int i5 = ((int) this.f17844o) / f17842z;
        MusicVolumeEQ.f17961b0 = i5;
        MusicVolumeEQ.f17961b0 = this.f17849t - i5;
        if (this.f17854y) {
            e();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0081, code lost:
        if (r1 != 2) goto L9;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        if (!isInEditMode()) {
            f17842z = 1;
            this.f17847r = (int) android.util.TypedValue.applyDimension(1, 40.0f, getResources().getDisplayMetrics());
            this.f17848s = (int) android.util.TypedValue.applyDimension(1, 57.2f, getResources().getDisplayMetrics());
            int h = (int) android.util.TypedValue.applyDimension(1, 155.0f, getResources().getDisplayMetrics());
            this.f17849t = h;
            this.f17846q = h - MusicVolumeEQ.f17961b0;
            Matrix matrix = new Matrix();
            this.f17851v = matrix;
            matrix.postTranslate(this.f17843n, this.f17846q);
            this.f17850u = new GestureDetector(new c(this));
            int teme = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            if (teme == 0) {
                this.f17853x = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq_svitla);
            } else if (teme == -1 || teme == 1 || teme == 2) {
                this.f17853x = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq);
            }
            this.f17852w = Bitmap.createScaledBitmap(this.f17853x, this.f17847r, this.f17848s, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            new Handler().postDelayed(new a(), 500L);
        }
        return this.f17850u.onTouchEvent(motionEvent);
    }
}
