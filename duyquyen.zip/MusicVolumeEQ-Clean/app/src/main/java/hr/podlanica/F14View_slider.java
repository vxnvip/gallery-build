package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class F14View_slider extends View {
    int A;
    private final Paint B;
    private int C;
    private int D;

    /* renamed from: n  reason: collision with root package name */
    private int f17859n;

    /* renamed from: o  reason: collision with root package name */
    float[] f17860o;

    /* renamed from: p  reason: collision with root package name */
    private int f17861p;

    /* renamed from: q  reason: collision with root package name */
    private int f17862q;

    /* renamed from: r  reason: collision with root package name */
    private GestureDetector f17863r;

    /* renamed from: s  reason: collision with root package name */
    private Matrix f17864s;

    /* renamed from: t  reason: collision with root package name */
    private Bitmap f17865t;

    /* renamed from: u  reason: collision with root package name */
    private boolean f17866u;

    /* renamed from: v  reason: collision with root package name */
    private d f17867v;

    /* renamed from: w  reason: collision with root package name */
    private int f17868w;

    /* renamed from: x  reason: collision with root package name */
    private int f17869x;

    /* renamed from: y  reason: collision with root package name */
    int f17870y;

    /* renamed from: z  reason: collision with root package name */
    int f17871z;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F14View_slider.this.f17866u = false;
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F14View_slider.this.f17866u = false;
        }
    }

    /* loaded from: classes.dex */
    private class c implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        F14View_slider f17874a;

        public c(F14View_slider f14View_slider) {
            this.f17874a = f14View_slider;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            this.f17874a.d(-f4, -f5);
            F14View_slider.a();
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    /* loaded from: classes.dex */
    public interface d {
        void a(F14View_slider f14View_slider, int i4, boolean z3);
    }

    public F14View_slider(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17859n = 0;
        this.f17860o = new float[9];
        this.f17866u = false;
        this.f17869x = 0;
        this.B = new Paint();
        this.C = 1;
    }

    public F14View_slider(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17859n = 0;
        this.f17860o = new float[9];
        this.f17866u = false;
        this.f17869x = 0;
        this.B = new Paint();
        this.C = 1;
    }

    public static void a() {
    }

    public void b() {
        Matrix matrix = new Matrix();
        this.f17864s = matrix;
        matrix.postTranslate(0.0f, this.f17862q - this.f17869x);
        this.f17866u = true;
        invalidate();
        new Handler().postDelayed(new b(), 500L);
    }

    public void d(float f4, float f5) {
        this.f17866u = true;
        this.f17864s.postTranslate(this.f17859n, f5);
        invalidate();
    }

    public void e() {
        setProgress(this.f17869x);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        this.f17864s.getValues(this.f17860o);
        float[] fArr = this.f17860o;
        float f4 = fArr[5];
        if (f4 <= 0.0f) {
            fArr[5] = 0.0f;
            this.f17864s.setValues(fArr);
            f4 = 0.0f;
        }
        int i4 = this.f17862q;
        if (f4 >= i4) {
            f4 = i4;
            float[] fArr2 = this.f17860o;
            fArr2[5] = f4;
            this.f17864s.setValues(fArr2);
        }
        if (this.D == 2) {
            canvas.drawLine(getWidth() / 2.0f, getHeight() - (getHeight() / 12.0f), getWidth() / 2.0f, f4 + (this.C / 2.0f), this.B);
        }
        canvas.drawBitmap(this.f17865t, this.f17864s, null);
        this.f17869x = this.f17862q - (((int) f4) / this.f17861p);
        if (this.f17866u) {
            e();
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        Bitmap decodeResource;
        Bitmap decodeResource2 = null;
        if (!isInEditMode()) {
            this.B.setColor(0);
            this.D = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            this.f17861p = 1;
            Resources resources = getResources();
            this.f17870y = resources.getInteger(R.integer.knob_x_slider);
            this.f17871z = resources.getInteger(R.integer.knob_y_slider);
            this.A = resources.getInteger(getResources().getConfiguration().orientation == 2 ? R.integer.visina_y_slider_land : R.integer.visina_y_slider);
            int applyDimension = (int) TypedValue.applyDimension(1, this.f17870y, getResources().getDisplayMetrics());
            int applyDimension2 = (int) TypedValue.applyDimension(1, this.f17871z, getResources().getDisplayMetrics());
            int applyDimension3 = (int) TypedValue.applyDimension(1, this.A, getResources().getDisplayMetrics());
            this.f17862q = applyDimension3;
            int i8 = applyDimension3 - this.f17869x;
            Matrix matrix = new Matrix();
            this.f17864s = matrix;
            matrix.postTranslate(this.f17859n, i8);
            this.f17863r = new GestureDetector(getContext(), new c(this));
            int i9 = this.D;
            if (i9 != -1) {
                if (i9 == 0) {
                    decodeResource2 = BitmapFactory.decodeResource(getResources(), R.drawable.knob_svitla);
                    applyDimension2 = (int) TypedValue.applyDimension(1, resources.getInteger(R.integer.knob_y_slider_svitla), getResources().getDisplayMetrics());
                } else if (i9 == 1) {
                    decodeResource2 = BitmapFactory.decodeResource(getResources(), R.drawable.knob_studio);
                    applyDimension -= (int) TypedValue.applyDimension(1, 5.0f, getResources().getDisplayMetrics());
                } else if (i9 != 2) {
                    decodeResource = null;
                } else {
                    decodeResource2 = BitmapFactory.decodeResource(getResources(), R.drawable.knob_flat);
                    applyDimension2 = (int) TypedValue.applyDimension(1, resources.getInteger(R.integer.knob_y_slider_svitla), getResources().getDisplayMetrics());
                    this.C = applyDimension2;
                    this.B.setColor(androidx.core.content.ContextCompat.getColor(getContext(), R.color.flat_zelena));
                    this.B.setStrokeWidth(getWidth() / 18.0f);
                }
                decodeResource = decodeResource2;
            } else {
                decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.knob);
            }
            this.f17865t = Bitmap.createScaledBitmap(decodeResource, applyDimension, applyDimension2, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            new Handler().postDelayed(new a(), 500L);
            d dVar = this.f17867v;
            if (dVar != null) {
                dVar.a(this, this.f17868w, false);
            }
        }
        if (motionEvent.getAction() == 0) {
            this.f17866u = true;
            d dVar2 = this.f17867v;
            if (dVar2 != null) {
                dVar2.a(this, this.f17868w, true);
            }
        }
        if (motionEvent.getAction() == 2 && this.f17866u) {
            e();
            a();
        }
        return this.f17863r.onTouchEvent(motionEvent);
    }

    public void setOnSeekBarChangeListener(d dVar) {
        this.f17867v = dVar;
    }

    public void setProgress(int i4) {
        if (this.f17868w != i4) {
            this.f17868w = i4;
            d dVar = this.f17867v;
            if (dVar != null) {
                dVar.a(this, i4, this.f17866u);
            }
            this.f17869x = i4;
        }
    }
}
