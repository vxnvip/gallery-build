package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class F910View extends View {

    /* renamed from: z  reason: collision with root package name */
    private static int f17927z;

    /* renamed from: n  reason: collision with root package name */
    private int f17928n;

    /* renamed from: o  reason: collision with root package name */
    private float f17929o;

    /* renamed from: p  reason: collision with root package name */
    float[] f17930p;

    /* renamed from: q  reason: collision with root package name */
    private int f17931q;

    /* renamed from: r  reason: collision with root package name */
    private int f17932r;

    /* renamed from: s  reason: collision with root package name */
    private int f17933s;

    /* renamed from: t  reason: collision with root package name */
    private int f17934t;

    /* renamed from: u  reason: collision with root package name */
    private GestureDetector f17935u;

    /* renamed from: v  reason: collision with root package name */
    private Matrix f17936v;

    /* renamed from: w  reason: collision with root package name */
    private Bitmap f17937w;

    /* renamed from: x  reason: collision with root package name */
    private Bitmap f17938x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f17939y;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F910View.this.f17939y = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F910View.this.f17939y = false;
        }
    }

    /* loaded from: classes.dex */
    private class c implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        F910View f17942a;

        public c(F910View f910View) {
            this.f17942a = f910View;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            F910View.this.f17939y = true;
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            this.f17942a.d(-f4, -f5);
            F910View.a();
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    public F910View(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17928n = 0;
        this.f17930p = new float[9];
        this.f17939y = false;
    }

    public F910View(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17928n = 0;
        this.f17930p = new float[9];
        this.f17939y = false;
    }

    public static void a() {
        /* EQ.b() hook of original EQ activity: not needed */
    }

    public void b() {
        Matrix matrix = new Matrix();
        this.f17936v = matrix;
        matrix.postTranslate(0.0f, MusicVolumeEQ.f17964e0);
        this.f17939y = true;
        invalidate();
        new Handler().postDelayed(new b(), 500L);
    }

    public void d(float f4, float f5) {
        this.f17939y = true;
        this.f17936v.postTranslate(0.0f, f5);
        invalidate();
    }

    public void e() {
        MusicVolumeEQ.p();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        this.f17936v.getValues(this.f17930p);
        float[] fArr = this.f17930p;
        float f4 = fArr[5];
        this.f17929o = f4;
        if (f4 <= 0.0f) {
            this.f17929o = 0.0f;
            fArr[5] = 0.0f;
            this.f17936v.setValues(fArr);
        }
        float f5 = this.f17929o;
        int i4 = this.f17934t;
        if (f5 >= i4) {
            float f6 = i4;
            this.f17929o = f6;
            float[] fArr2 = this.f17930p;
            fArr2[5] = f6;
            this.f17936v.setValues(fArr2);
        }
        canvas.drawBitmap(this.f17937w, this.f17936v, null);
        int i5 = ((int) this.f17929o) / f17927z;
        MusicVolumeEQ.f17964e0 = i5;
        MusicVolumeEQ.f17964e0 = this.f17934t - i5;
        if (this.f17939y) {
            e();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0081, code lost:
        if (r1 != 2) goto L9;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        if (!isInEditMode()) {
            f17927z = 1;
            this.f17932r = (int) android.util.TypedValue.applyDimension(1, 40.0f, getResources().getDisplayMetrics());
            this.f17933s = (int) android.util.TypedValue.applyDimension(1, 57.2f, getResources().getDisplayMetrics());
            int h = (int) android.util.TypedValue.applyDimension(1, 155.0f, getResources().getDisplayMetrics());
            this.f17934t = h;
            this.f17931q = h - MusicVolumeEQ.f17964e0;
            Matrix matrix = new Matrix();
            this.f17936v = matrix;
            matrix.postTranslate(this.f17928n, this.f17931q);
            this.f17935u = new GestureDetector(new c(this));
            int teme = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            if (teme == 0) {
                this.f17938x = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq_svitla);
            } else if (teme == -1 || teme == 1 || teme == 2) {
                this.f17938x = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq);
            }
            this.f17937w = Bitmap.createScaledBitmap(this.f17938x, this.f17932r, this.f17933s, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            new Handler().postDelayed(new a(), 500L);
        }
        return this.f17935u.onTouchEvent(motionEvent);
    }
}
