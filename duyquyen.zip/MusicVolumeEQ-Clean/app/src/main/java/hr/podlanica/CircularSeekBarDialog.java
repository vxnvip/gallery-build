package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class CircularSeekBarDialog extends View {

    /* renamed from: w0  reason: collision with root package name */
    private static final int f17657w0 = Color.argb(235, 74, 138, 255);

    /* renamed from: x0  reason: collision with root package name */
    private static final int f17658x0 = Color.argb(235, 74, 138, 255);

    /* renamed from: y0  reason: collision with root package name */
    private static final int f17659y0 = Color.argb(135, 74, 138, 255);
    private Paint A;
    private float B;
    private float C;
    private float D;
    private float E;
    private float F;
    private float G;
    private float H;
    private float I;
    private RectF J;
    private RectF K;
    private int L;
    private int M;
    private int N;
    private int O;
    private int P;
    private int Q;
    private float R;
    private float S;
    private Path T;
    private Path U;
    private Path V;
    private Path W;

    /* renamed from: a0  reason: collision with root package name */
    private int f17660a0;

    /* renamed from: b0  reason: collision with root package name */
    private int f17661b0;

    /* renamed from: c0  reason: collision with root package name */
    private boolean f17662c0;

    /* renamed from: d0  reason: collision with root package name */
    private boolean f17663d0;

    /* renamed from: e0  reason: collision with root package name */
    private boolean f17664e0;

    /* renamed from: f0  reason: collision with root package name */
    private boolean f17665f0;

    /* renamed from: g0  reason: collision with root package name */
    private boolean f17666g0;

    /* renamed from: h0  reason: collision with root package name */
    private boolean f17667h0;

    /* renamed from: i0  reason: collision with root package name */
    private float f17668i0;

    /* renamed from: j0  reason: collision with root package name */
    private float f17669j0;

    /* renamed from: k0  reason: collision with root package name */
    private float f17670k0;

    /* renamed from: l0  reason: collision with root package name */
    private float f17671l0;

    /* renamed from: m0  reason: collision with root package name */
    private float f17672m0;

    /* renamed from: n  reason: collision with root package name */
    private final float f17673n;

    /* renamed from: n0  reason: collision with root package name */
    private boolean f17674n0;

    /* renamed from: o  reason: collision with root package name */
    private float f17675o;

    /* renamed from: o0  reason: collision with root package name */
    private float f17676o0;

    /* renamed from: p  reason: collision with root package name */
    private float f17677p;

    /* renamed from: p0  reason: collision with root package name */
    private float f17678p0;

    /* renamed from: q  reason: collision with root package name */
    private Matrix f17679q;

    /* renamed from: q0  reason: collision with root package name */
    private float f17680q0;

    /* renamed from: r  reason: collision with root package name */
    private Bitmap f17681r;

    /* renamed from: r0  reason: collision with root package name */
    private float[] f17682r0;

    /* renamed from: s  reason: collision with root package name */
    private int f17683s;

    /* renamed from: s0  reason: collision with root package name */
    private int f17684s0;

    /* renamed from: t  reason: collision with root package name */
    private int f17685t;

    /* renamed from: t0  reason: collision with root package name */
    private int f17686t0;

    /* renamed from: u  reason: collision with root package name */
    private Paint f17687u;

    /* renamed from: u0  reason: collision with root package name */
    private int f17688u0;

    /* renamed from: v  reason: collision with root package name */
    private Paint f17689v;

    /* renamed from: v0  reason: collision with root package name */
    private boolean f17690v0;

    /* renamed from: w  reason: collision with root package name */
    private Paint f17691w;

    /* renamed from: x  reason: collision with root package name */
    private Paint f17692x;

    /* renamed from: y  reason: collision with root package name */
    private Paint f17693y;

    /* renamed from: z  reason: collision with root package name */
    private Paint f17694z;

    /* loaded from: classes.dex */
    public interface a {
    }

    public CircularSeekBarDialog(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17673n = getResources().getDisplayMetrics().density;
        this.f17675o = 250.0f;
        this.f17677p = 45.0f;
        this.J = new RectF();
        this.K = new RectF();
        this.L = f17658x0;
        this.M = f17659y0;
        this.N = -12303292;
        this.O = f17657w0;
        this.P = 135;
        this.Q = 100;
        this.f17665f0 = true;
        this.f17666g0 = false;
        this.f17667h0 = false;
        this.f17682r0 = new float[2];
        this.f17690v0 = true;
        e(attributeSet, 0);
    }

    public CircularSeekBarDialog(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17673n = getResources().getDisplayMetrics().density;
        this.f17675o = 250.0f;
        this.f17677p = 45.0f;
        this.J = new RectF();
        this.K = new RectF();
        this.L = f17658x0;
        this.M = f17659y0;
        this.N = -12303292;
        this.O = f17657w0;
        this.P = 135;
        this.Q = 100;
        this.f17665f0 = true;
        this.f17666g0 = false;
        this.f17667h0 = false;
        this.f17682r0 = new float[2];
        this.f17690v0 = true;
        e(attributeSet, i4);
    }

    private void a() {
        this.f17680q0 = (((this.f17661b0 / this.f17660a0) * this.R) + this.H) % 360.0f;
    }

    private void b() {
        PathMeasure pathMeasure = new PathMeasure(this.V, false);
        if (pathMeasure.getPosTan(pathMeasure.getLength(), this.f17682r0, null)) {
            return;
        }
        new PathMeasure(this.T, false).getPosTan(0.0f, this.f17682r0, null);
    }

    private void c() {
        float f4 = this.f17680q0 - this.H;
        this.S = f4;
        if (f4 < 0.0f) {
            f4 += 360.0f;
        }
        this.S = f4;
    }

    private void d() {
        float f4 = (360.0f - (this.H - this.I)) % 360.0f;
        this.R = f4;
        if (f4 <= 0.0f) {
            this.R = 360.0f;
        }
    }

    private void e(AttributeSet attributeSet, int i4) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.CircularSeekBar, i4, 0);
        f(obtainStyledAttributes);
        obtainStyledAttributes.recycle();
        g();
    }

    private void f(TypedArray typedArray) {
        Resources resources = getResources();
        this.f17677p = 0.0f;
        this.f17686t0 = resources.getInteger(R.integer.interval1);
        this.f17688u0 = resources.getInteger(R.integer.interval2);
        this.C = typedArray.getFloat(3, 30.0f) * this.f17673n;
        this.D = typedArray.getFloat(4, 30.0f) * this.f17673n;
        this.E = typedArray.getFloat(14, 6.0f) * this.f17673n;
        this.F = typedArray.getFloat(13, 6.0f) * this.f17673n;
        this.G = typedArray.getFloat(11, 2.0f) * this.f17673n;
        this.B = typedArray.getFloat(2, 5.0f) * this.f17673n;
        String string = typedArray.getString(10);
        if (string != null) {
            try {
                this.L = Color.parseColor(string);
            } catch (IllegalArgumentException unused) {
                this.L = f17658x0;
            }
        }
        String string2 = typedArray.getString(12);
        if (string2 != null) {
            try {
                this.M = Color.parseColor(string2);
            } catch (IllegalArgumentException unused2) {
                this.M = f17659y0;
            }
        }
        String string3 = typedArray.getString(0);
        if (string3 != null) {
            try {
                this.N = Color.parseColor(string3);
            } catch (IllegalArgumentException unused3) {
                this.N = -12303292;
            }
        }
        String string4 = typedArray.getString(1);
        if (string4 != null) {
            try {
                this.O = Color.parseColor(string4);
            } catch (IllegalArgumentException unused4) {
                this.O = f17657w0;
            }
        }
        this.P = Color.alpha(this.M);
        int i4 = typedArray.getInt(9, 100);
        this.Q = i4;
        if (i4 > 255 || i4 < 0) {
            this.Q = 100;
        }
        this.f17660a0 = typedArray.getInt(7, 100);
        this.f17661b0 = typedArray.getInt(15, 0);
        this.f17662c0 = typedArray.getBoolean(17, false);
        this.f17663d0 = typedArray.getBoolean(6, true);
        this.f17664e0 = typedArray.getBoolean(8, false);
        this.H = ((typedArray.getFloat(16, 270.0f) % 360.0f) + 360.0f) % 360.0f;
        float f4 = ((typedArray.getFloat(5, 270.0f) % 360.0f) + 360.0f) % 360.0f;
        this.I = f4;
        if (this.H == f4) {
            this.I = f4 - 0.1f;
        }
    }

    private void g() {
        this.f17684s0 = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext()).getString("teme_preference", "2"));
        EmbossMaskFilter embossMaskFilter = new EmbossMaskFilter(new float[]{0.0f, -1.0f, 0.5f}, 0.8f, 15.0f, 1.0f);
        Paint paint = new Paint();
        this.f17687u = paint;
        paint.setAntiAlias(true);
        this.f17687u.setDither(true);
        this.f17687u.setColor(this.N);
        this.f17687u.setStrokeWidth(this.B);
        this.f17687u.setStyle(Paint.Style.STROKE);
        Paint paint2 = new Paint();
        this.f17689v = paint2;
        paint2.setAntiAlias(true);
        this.f17689v.setDither(true);
        this.f17689v.setColor(this.O);
        this.f17689v.setStrokeWidth(this.B);
        this.f17689v.setStyle(Paint.Style.STROKE);
        this.f17687u.setStrokeJoin(Paint.Join.ROUND);
        this.f17687u.setStrokeCap(Paint.Cap.ROUND);
        this.f17689v.setStrokeJoin(Paint.Join.ROUND);
        this.f17689v.setStrokeCap(Paint.Cap.ROUND);
        Paint paint3 = new Paint();
        this.f17691w = paint3;
        paint3.set(this.f17689v);
        this.f17691w.setMaskFilter(new BlurMaskFilter(this.f17673n * 4.0f, BlurMaskFilter.Blur.NORMAL));
        Paint paint4 = new Paint();
        this.f17692x = paint4;
        paint4.setAntiAlias(true);
        this.f17692x.setDither(true);
        this.f17692x.setStyle(Paint.Style.FILL);
        this.f17692x.setColor(this.L);
        this.f17692x.setMaskFilter(embossMaskFilter);
        this.f17692x.setStrokeWidth(this.E);
        Paint paint5 = new Paint();
        this.f17693y = paint5;
        paint5.setAntiAlias(true);
        this.f17693y.setDither(true);
        this.f17693y.setStyle(Paint.Style.FILL);
        this.f17693y.setColor(Color.rgb(51, 51, 51));
        this.f17693y.setMaskFilter(embossMaskFilter);
        this.f17693y.setStrokeWidth(this.E);
        Paint paint6 = new Paint();
        this.f17694z = paint6;
        paint6.set(this.f17692x);
        this.f17694z.setColor(this.M);
        this.f17694z.setAlpha(this.P);
        this.f17694z.setStrokeWidth(this.E + this.F);
        Paint paint7 = new Paint();
        this.A = paint7;
        paint7.set(this.f17692x);
        this.A.setStrokeWidth(this.G);
        this.A.setStyle(Paint.Style.STROKE);
    }

    private void h() {
        Path path = new Path();
        this.U = path;
        path.addArc(this.K, this.H, this.R);
        Path path2 = new Path();
        this.T = path2;
        path2.addArc(this.J, this.H, this.R);
        Path path3 = new Path();
        this.W = path3;
        path3.addArc(this.K, this.H, this.S);
        Path path4 = new Path();
        this.V = path4;
        path4.addArc(this.J, this.H, this.S);
    }

    private void i() {
        RectF rectF = this.K;
        float f4 = this.f17676o0;
        float f5 = this.f17678p0;
        rectF.set(-f4, -f5, f4, f5);
        float f6 = this.f17677p * this.f17673n;
        RectF rectF2 = this.J;
        float f7 = this.f17676o0;
        float f8 = this.f17678p0;
        rectF2.set((-f7) + f6, (-f8) + f6, f7 - f6, f8 - f6);
    }

    private void j() {
        d();
        a();
        c();
        i();
        h();
        b();
    }

    private void setProgressBasedOnAngle(float f4) {
        this.f17680q0 = f4;
        c();
        this.f17661b0 = Math.round((this.f17660a0 * this.S) / this.R);
    }

    public int getCircleColor() {
        return this.N;
    }

    public int getCircleProgressColor() {
        return this.O;
    }

    public int getPointerAlpha() {
        return this.P;
    }

    public int getPointerAlphaOnTouch() {
        return this.Q;
    }

    public int getPointerColor() {
        return this.L;
    }

    public int getPointerHaloColor() {
        return this.M;
    }

    public int getProgress() {
        return Math.round((this.f17660a0 * this.S) / this.R);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f17679q.setRotate(this.f17680q0, this.f17683s / 2, this.f17685t / 2);
        canvas.translate(getWidth() / 2.0f, getHeight() / 2.0f);
        canvas.drawPath(this.U, this.f17687u);
        canvas.drawPath(this.W, this.f17689v);
        canvas.drawPath(this.U, this.f17687u);
        canvas.drawPath(this.W, this.f17689v);
        float[] fArr = this.f17682r0;
        canvas.drawCircle(fArr[0], fArr[1], this.E, this.f17692x);
        if (this.f17667h0) {
            float[] fArr2 = this.f17682r0;
            canvas.drawCircle(fArr2[0], fArr2[1], this.E, this.f17692x);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i4, int i5) {
        int defaultSize = View.getDefaultSize(getSuggestedMinimumHeight(), i5);
        int defaultSize2 = View.getDefaultSize(getSuggestedMinimumWidth(), i4);
        if (this.f17663d0) {
            int min = Math.min(defaultSize2, defaultSize);
            setMeasuredDimension(min, min);
        } else {
            setMeasuredDimension(defaultSize2, defaultSize);
        }
        float f4 = this.B;
        float f5 = this.G;
        float f6 = ((defaultSize / 2.0f) - f4) - (f5 * 1.5f);
        this.f17678p0 = f6;
        float f7 = ((defaultSize2 / 2.0f) - f4) - (f5 * 1.5f);
        this.f17676o0 = f7;
        if (this.f17662c0) {
            float f8 = this.D;
            float f9 = this.E;
            if (((f8 - f4) - f9) - f5 < f6) {
                this.f17678p0 = ((f8 - f4) - f9) - (f5 * 1.5f);
            }
            float f10 = this.C;
            if (((f10 - f4) - f9) - f5 < f7) {
                this.f17676o0 = ((f10 - f4) - f9) - (f5 * 1.5f);
            }
        }
        if (this.f17663d0) {
            float min2 = Math.min(this.f17678p0, this.f17676o0);
            this.f17678p0 = min2;
            this.f17676o0 = min2;
        }
        j();
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        Bundle bundle = (Bundle) parcelable;
        super.onRestoreInstanceState(bundle.getParcelable("PARENT"));
        this.f17660a0 = bundle.getInt("MAX");
        this.f17661b0 = bundle.getInt("PROGRESS");
        this.N = bundle.getInt("mCircleColor");
        this.O = bundle.getInt("mCircleProgressColor");
        this.L = bundle.getInt("mPointerColor");
        this.M = bundle.getInt("mPointerHaloColor");
        this.P = bundle.getInt("mPointerAlpha");
        this.Q = bundle.getInt("mPointerAlphaOnTouch");
        g();
        j();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState = super.onSaveInstanceState();
        Bundle bundle = new Bundle();
        bundle.putParcelable("PARENT", onSaveInstanceState);
        bundle.putInt("MAX", this.f17660a0);
        bundle.putInt("PROGRESS", this.f17661b0);
        bundle.putInt("mCircleColor", this.N);
        bundle.putInt("mCircleProgressColor", this.O);
        bundle.putInt("mPointerColor", this.L);
        bundle.putInt("mPointerHaloColor", this.M);
        bundle.putInt("mPointerAlpha", this.P);
        bundle.putInt("mPointerAlphaOnTouch", this.Q);
        return bundle;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        this.f17684s0 = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext()).getString("teme_preference", "2"));
        this.f17683s = i4;
        this.f17685t = i5;
        this.f17679q = new Matrix();
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 2;
        this.f17681r = (Bitmap) new WeakReference(Bitmap.createScaledBitmap((Bitmap) new WeakReference(BitmapFactory.decodeResource(getResources(), R.drawable.round_full_podloga, options)).get(), i4, i5, true)).get();
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f17690v0) {
            float x3 = motionEvent.getX() - (getWidth() / 2.0f);
            float y3 = motionEvent.getY() - (getHeight() / 2.0f);
            float sqrt = (float) Math.sqrt(Math.pow(this.K.centerX() - x3, 2.0d) + Math.pow(this.K.centerY() - y3, 2.0d));
            float f4 = this.f17675o * this.f17673n;
            float f5 = this.B;
            float f6 = f5 < f4 ? f4 / 2.0f : f5 / 2.0f;
            float max = Math.max(this.f17678p0, this.f17676o0) + f6;
            float min = Math.min(this.f17678p0, this.f17676o0) - f6;
            float atan2 = (float) (((Math.atan2(y3, x3) / 3.141592653589793d) * 180.0d) % 360.0d);
            if (atan2 < 0.0f) {
                atan2 += 360.0f;
            }
            float f7 = atan2 - this.H;
            this.f17668i0 = f7;
            if (f7 < 0.0f) {
                f7 += 360.0f;
            }
            this.f17668i0 = f7;
            this.f17669j0 = 360.0f - f7;
            float f8 = atan2 - this.I;
            this.f17670k0 = f8;
            if (f8 < 0.0f) {
                f8 += 360.0f;
            }
            this.f17670k0 = f8;
            this.f17671l0 = 360.0f - f8;
            int action = motionEvent.getAction();
            if (action != 0) {
                if (action == 1) {
                    this.f17694z.setAlpha(this.P);
                    if (!this.f17667h0) {
                        return false;
                    }
                } else if (action != 2) {
                    if (action == 3) {
                        this.f17694z.setAlpha(this.P);
                    }
                } else if (!this.f17667h0) {
                    return false;
                } else {
                    float f9 = this.f17672m0;
                    float f10 = this.f17668i0;
                    if (f9 < f10) {
                        if (f10 - f9 <= 180.0f || this.f17674n0) {
                            this.f17674n0 = true;
                        } else {
                            this.f17665f0 = true;
                            this.f17666g0 = false;
                        }
                    } else if (f9 - f10 <= 180.0f || !this.f17674n0) {
                        this.f17674n0 = false;
                    } else {
                        this.f17666g0 = false;
                        this.f17665f0 = false;
                    }
                    if (this.f17665f0 && this.f17674n0) {
                        this.f17665f0 = false;
                    }
                    if (this.f17666g0 && !this.f17674n0) {
                        this.f17666g0 = false;
                    }
                    if (this.f17665f0 && !this.f17674n0 && this.f17669j0 > 90.0f) {
                        this.f17665f0 = false;
                    }
                    if (this.f17666g0 && this.f17674n0 && this.f17670k0 > 90.0f) {
                        this.f17666g0 = false;
                    }
                    if (!this.f17666g0) {
                        float f11 = this.R;
                        if (f10 > f11 && this.f17674n0 && f9 < f11) {
                            this.f17666g0 = true;
                        }
                    }
                    if (this.f17665f0) {
                        this.f17661b0 = 0;
                    } else if (this.f17666g0) {
                        this.f17661b0 = this.f17660a0;
                    } else if (this.f17664e0 || sqrt <= max) {
                        if (f10 <= this.R) {
                            setProgressBasedOnAngle(atan2);
                        }
                    }
                    j();
                    invalidate();
                    this.f17672m0 = this.f17668i0;
                }
                this.f17667h0 = false;
                invalidate();
            } else if (this.f17668i0 > this.R) {
                this.f17667h0 = false;
                return false;
            } else if (sqrt < min || sqrt > max) {
                this.f17667h0 = false;
                return false;
            } else {
                setProgressBasedOnAngle(atan2);
                this.f17672m0 = this.f17668i0;
                this.f17674n0 = true;
                this.f17694z.setAlpha(this.Q);
                j();
                invalidate();
                this.f17667h0 = true;
                this.f17666g0 = false;
                this.f17665f0 = false;
            }
            if (motionEvent.getAction() == 2 && getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            return true;
        }
        return true;
    }

    public void setCircleColor(int i4) {
        this.N = i4;
        this.f17687u.setColor(i4);
        invalidate();
    }

    public void setCircleProgressColor(int i4) {
        this.O = i4;
        this.f17689v.setColor(i4);
        invalidate();
    }

    @Override // android.view.View
    public void setEnabled(boolean z3) {
        this.f17690v0 = z3;
    }

    public void setOnSeekBarChangeListener(a aVar) {
    }

    public void setPointerAlpha(int i4) {
        if (i4 < 0 || i4 > 255) {
            return;
        }
        this.P = i4;
        this.f17694z.setAlpha(i4);
        invalidate();
    }

    public void setPointerAlphaOnTouch(int i4) {
        if (i4 < 0 || i4 > 255) {
            return;
        }
        this.Q = i4;
    }

    public void setPointerColor(int i4) {
        this.L = i4;
        this.f17692x.setColor(i4);
        invalidate();
    }

    public void setPointerHaloColor(int i4) {
        this.M = i4;
        this.f17694z.setColor(i4);
        invalidate();
    }

    public void setProgress(int i4) {
        if (this.f17661b0 != i4) {
            this.f17661b0 = i4;
            j();
            invalidate();
        }
    }
}
