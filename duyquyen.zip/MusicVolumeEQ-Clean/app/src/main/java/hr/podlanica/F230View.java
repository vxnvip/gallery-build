package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class F230View extends View {

    /* renamed from: z  reason: collision with root package name */
    private static int f17876z;

    /* renamed from: n  reason: collision with root package name */
    private int f17877n;

    /* renamed from: o  reason: collision with root package name */
    private float f17878o;

    /* renamed from: p  reason: collision with root package name */
    float[] f17879p;

    /* renamed from: q  reason: collision with root package name */
    private int f17880q;

    /* renamed from: r  reason: collision with root package name */
    private int f17881r;

    /* renamed from: s  reason: collision with root package name */
    private int f17882s;

    /* renamed from: t  reason: collision with root package name */
    private int f17883t;

    /* renamed from: u  reason: collision with root package name */
    private GestureDetector f17884u;

    /* renamed from: v  reason: collision with root package name */
    private Matrix f17885v;

    /* renamed from: w  reason: collision with root package name */
    private Bitmap f17886w;

    /* renamed from: x  reason: collision with root package name */
    private Bitmap f17887x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f17888y;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F230View.this.f17888y = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F230View.this.f17888y = false;
        }
    }

    /* loaded from: classes.dex */
    private class c implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        F230View f17891a;

        public c(F230View f230View) {
            this.f17891a = f230View;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            F230View.this.f17888y = true;
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            this.f17891a.d(-f4, -f5);
            F230View.a();
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    public F230View(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17877n = 0;
        this.f17879p = new float[9];
        this.f17888y = false;
    }

    public F230View(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17877n = 0;
        this.f17879p = new float[9];
        this.f17888y = false;
    }

    public static void a() {
        EQ.b();
    }

    public void b() {
        Matrix matrix = new Matrix();
        this.f17885v = matrix;
        matrix.postTranslate(0.0f, MusicVolumeEQ.f17962c0);
        this.f17888y = true;
        invalidate();
        new Handler().postDelayed(new b(), 500L);
    }

    public void d(float f4, float f5) {
        this.f17888y = true;
        this.f17885v.postTranslate(0.0f, f5);
        invalidate();
    }

    public void e() {
        MusicVolumeEQ.j();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        this.f17885v.getValues(this.f17879p);
        float[] fArr = this.f17879p;
        float f4 = fArr[5];
        this.f17878o = f4;
        if (f4 <= 0.0f) {
            this.f17878o = 0.0f;
            fArr[5] = 0.0f;
            this.f17885v.setValues(fArr);
        }
        float f5 = this.f17878o;
        int i4 = this.f17883t;
        if (f5 >= i4) {
            float f6 = i4;
            this.f17878o = f6;
            float[] fArr2 = this.f17879p;
            fArr2[5] = f6;
            this.f17885v.setValues(fArr2);
        }
        canvas.drawBitmap(this.f17886w, this.f17885v, null);
        int i5 = ((int) this.f17878o) / f17876z;
        MusicVolumeEQ.f17962c0 = i5;
        MusicVolumeEQ.f17962c0 = this.f17883t - i5;
        if (this.f17888y) {
            e();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0081, code lost:
        if (r1 != 2) goto L9;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        if (!isInEditMode()) {
            f17876z = 1;
            this.f17881r = (int) android.util.TypedValue.applyDimension(1, 40.0f, getResources().getDisplayMetrics());
            this.f17882s = (int) android.util.TypedValue.applyDimension(1, 57.2f, getResources().getDisplayMetrics());
            int h = (int) android.util.TypedValue.applyDimension(1, 155.0f, getResources().getDisplayMetrics());
            this.f17883t = h;
            this.f17880q = h - MusicVolumeEQ.f17962c0;
            Matrix matrix = new Matrix();
            this.f17885v = matrix;
            matrix.postTranslate(this.f17877n, this.f17880q);
            this.f17884u = new GestureDetector(new c(this));
            int teme = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            if (teme == 0) {
                this.f17887x = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq_svitla);
            } else if (teme == -1 || teme == 1 || teme == 2) {
                this.f17887x = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq);
            }
            this.f17886w = Bitmap.createScaledBitmap(this.f17887x, this.f17881r, this.f17882s, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            new Handler().postDelayed(new a(), 500L);
        }
        return this.f17884u.onTouchEvent(motionEvent);
    }
}
