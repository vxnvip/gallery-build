package hr.podlanica;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import app.eqclean.R;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class CircularSeekBarBass extends View {

    /* renamed from: x0  reason: collision with root package name */
    private static final int f17618x0 = Color.argb(235, 74, 138, 255);

    /* renamed from: y0  reason: collision with root package name */
    private static final int f17619y0 = Color.argb(235, 74, 138, 255);

    /* renamed from: z0  reason: collision with root package name */
    private static final int f17620z0 = Color.argb(135, 74, 138, 255);
    private Paint A;
    private float B;
    private float C;
    private float D;
    private float E;
    private float F;
    private float G;
    private float H;
    private float I;
    private RectF J;
    private RectF K;
    private int L;
    private int M;
    private int N;
    private int O;
    private int P;
    private int Q;
    private float R;
    private float S;
    private Path T;
    private Path U;
    private Path V;
    private Path W;

    /* renamed from: a0  reason: collision with root package name */
    private int f17621a0;

    /* renamed from: b0  reason: collision with root package name */
    private int f17622b0;

    /* renamed from: c0  reason: collision with root package name */
    private boolean f17623c0;

    /* renamed from: d0  reason: collision with root package name */
    private boolean f17624d0;

    /* renamed from: e0  reason: collision with root package name */
    private boolean f17625e0;

    /* renamed from: f0  reason: collision with root package name */
    private boolean f17626f0;

    /* renamed from: g0  reason: collision with root package name */
    private boolean f17627g0;

    /* renamed from: h0  reason: collision with root package name */
    private boolean f17628h0;

    /* renamed from: i0  reason: collision with root package name */
    private float f17629i0;

    /* renamed from: j0  reason: collision with root package name */
    private float f17630j0;

    /* renamed from: k0  reason: collision with root package name */
    private float f17631k0;

    /* renamed from: l0  reason: collision with root package name */
    private float f17632l0;

    /* renamed from: m0  reason: collision with root package name */
    private float f17633m0;

    /* renamed from: n  reason: collision with root package name */
    private final float f17634n;

    /* renamed from: n0  reason: collision with root package name */
    private boolean f17635n0;

    /* renamed from: o  reason: collision with root package name */
    private float f17636o;

    /* renamed from: o0  reason: collision with root package name */
    private float f17637o0;

    /* renamed from: p  reason: collision with root package name */
    private float f17638p;

    /* renamed from: p0  reason: collision with root package name */
    private float f17639p0;

    /* renamed from: q  reason: collision with root package name */
    private Matrix f17640q;

    /* renamed from: q0  reason: collision with root package name */
    private float f17641q0;

    /* renamed from: r  reason: collision with root package name */
    private Bitmap f17642r;

    /* renamed from: r0  reason: collision with root package name */
    private float[] f17643r0;

    /* renamed from: s  reason: collision with root package name */
    private int f17644s;

    /* renamed from: s0  reason: collision with root package name */
    private a f17645s0;

    /* renamed from: t  reason: collision with root package name */
    private int f17646t;

    /* renamed from: t0  reason: collision with root package name */
    private int f17647t0;

    /* renamed from: u  reason: collision with root package name */
    private Paint f17648u;

    /* renamed from: u0  reason: collision with root package name */
    private int f17649u0;

    /* renamed from: v  reason: collision with root package name */
    private Paint f17650v;

    /* renamed from: v0  reason: collision with root package name */
    private int f17651v0;

    /* renamed from: w  reason: collision with root package name */
    private Paint f17652w;

    /* renamed from: w0  reason: collision with root package name */
    private boolean f17653w0;

    /* renamed from: x  reason: collision with root package name */
    private Paint f17654x;

    /* renamed from: y  reason: collision with root package name */
    private Paint f17655y;

    /* renamed from: z  reason: collision with root package name */
    private Paint f17656z;

    /* loaded from: classes.dex */
    public interface a {
        void a(CircularSeekBarBass circularSeekBarBass, int i4, boolean z3);
    }

    public CircularSeekBarBass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17634n = getResources().getDisplayMetrics().density;
        this.f17636o = 250.0f;
        this.f17638p = 45.0f;
        this.J = new RectF();
        this.K = new RectF();
        this.L = f17619y0;
        this.M = f17620z0;
        this.N = -12303292;
        this.O = f17618x0;
        this.P = 135;
        this.Q = 100;
        this.f17626f0 = true;
        this.f17627g0 = false;
        this.f17628h0 = false;
        this.f17643r0 = new float[2];
        this.f17653w0 = true;
        e(attributeSet, 0);
    }

    public CircularSeekBarBass(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17634n = getResources().getDisplayMetrics().density;
        this.f17636o = 250.0f;
        this.f17638p = 45.0f;
        this.J = new RectF();
        this.K = new RectF();
        this.L = f17619y0;
        this.M = f17620z0;
        this.N = -12303292;
        this.O = f17618x0;
        this.P = 135;
        this.Q = 100;
        this.f17626f0 = true;
        this.f17627g0 = false;
        this.f17628h0 = false;
        this.f17643r0 = new float[2];
        this.f17653w0 = true;
        e(attributeSet, i4);
    }

    private void a() {
        this.f17641q0 = (((this.f17622b0 / this.f17621a0) * this.R) + this.H) % 360.0f;
    }

    private void b() {
        PathMeasure pathMeasure = new PathMeasure(this.V, false);
        if (pathMeasure.getPosTan(pathMeasure.getLength(), this.f17643r0, null)) {
            return;
        }
        new PathMeasure(this.T, false).getPosTan(0.0f, this.f17643r0, null);
    }

    private void c() {
        float f4 = this.f17641q0 - this.H;
        this.S = f4;
        if (f4 < 0.0f) {
            f4 += 360.0f;
        }
        this.S = f4;
    }

    private void d() {
        float f4 = (360.0f - (this.H - this.I)) % 360.0f;
        this.R = f4;
        if (f4 <= 0.0f) {
            this.R = 360.0f;
        }
    }

    private void e(AttributeSet attributeSet, int i4) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, app.eqclean.R.styleable.CircularSeekBar, i4, 0);
        f(obtainStyledAttributes);
        obtainStyledAttributes.recycle();
        g();
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x0108 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0151  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00e7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00c3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00d5 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00b0 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:49:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void f(TypedArray typedArray) {
        this.f17647t0 = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
        Resources resources = getResources();
        int t = this.f17647t0;
        if (t == -1 || t == 1) {
            this.f17638p = resources.getInteger(app.eqclean.R.integer.odmak_bass);
        } else if (t == 0) {
            this.f17638p = resources.getInteger(app.eqclean.R.integer.odmak_bass_svitla);
        } else if (t == 2) {
            this.f17638p = 0.0f;
        }
        this.f17636o = resources.getInteger(app.eqclean.R.integer.touch_radius_bass);
        this.f17649u0 = resources.getInteger(app.eqclean.R.integer.interval1);
        this.f17651v0 = resources.getInteger(app.eqclean.R.integer.interval2);
        this.C = typedArray.getFloat(3, 30.0f) * this.f17634n;
        this.D = typedArray.getFloat(4, 30.0f) * this.f17634n;
        this.E = typedArray.getFloat(14, 6.0f) * this.f17634n;
        this.F = typedArray.getFloat(13, 6.0f) * this.f17634n;
        this.G = typedArray.getFloat(11, 2.0f) * this.f17634n;
        this.B = typedArray.getFloat(2, 5.0f) * this.f17634n;
        String s10 = typedArray.getString(10);
        if (s10 != null) {
            try { this.L = Color.parseColor(s10); } catch (IllegalArgumentException e) { this.L = f17619y0; }
        }
        String s12 = typedArray.getString(12);
        if (s12 != null) {
            try { this.M = Color.parseColor(s12); } catch (IllegalArgumentException e) { this.M = f17620z0; }
        }
        String s0 = typedArray.getString(0);
        if (s0 != null) {
            try { this.N = Color.parseColor(s0); } catch (IllegalArgumentException e) { this.N = -12303292; }
        }
        String s1 = typedArray.getString(1);
        if (s1 != null) {
            try { this.O = Color.parseColor(s1); } catch (IllegalArgumentException e) { this.O = f17618x0; }
        }
        this.P = Color.alpha(this.M);
        int q = typedArray.getInt(9, 100);
        this.Q = q;
        if (q > 255 || q < 0) {
            this.Q = 100;
        }
        this.f17621a0 = typedArray.getInt(7, 100);
        this.f17622b0 = typedArray.getInt(15, 0);
        this.f17623c0 = typedArray.getBoolean(17, false);
        this.f17624d0 = typedArray.getBoolean(6, true);
        this.f17625e0 = typedArray.getBoolean(8, false);
        this.H = ((typedArray.getFloat(16, 270.0f) % 360.0f) + 360.0f) % 360.0f;
        float end = ((typedArray.getFloat(5, 270.0f) % 360.0f) + 360.0f) % 360.0f;
        this.I = end;
        if (this.H == end) {
            this.I = end - 0.1f;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x007b, code lost:
        if (r1 != 2) goto L7;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void g() {
        this.f17647t0 = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext()).getString("teme_preference", "2"));
        android.graphics.EmbossMaskFilter emboss = new android.graphics.EmbossMaskFilter(new float[]{0.0f, -1.0f, 0.5f}, 0.8f, 15.0f, 1.0f);
        Paint pu = new Paint();
        this.f17648u = pu;
        pu.setAntiAlias(true);
        pu.setDither(true);
        pu.setColor(this.N);
        pu.setStrokeWidth(this.B);
        pu.setStyle(Paint.Style.STROKE);
        Paint pv = new Paint();
        this.f17650v = pv;
        pv.setAntiAlias(true);
        pv.setDither(true);
        pv.setColor(this.O);
        pv.setStrokeWidth(this.B);
        pv.setStyle(Paint.Style.STROKE);
        int t = this.f17647t0;
        if (t == 1) {
            pu.setPathEffect(new android.graphics.DashPathEffect(new float[]{this.f17649u0, this.f17651v0}, 0.0f));
            pv.setPathEffect(new android.graphics.DashPathEffect(new float[]{this.f17649u0, this.f17651v0}, 0.0f));
        } else if (t == -1 || t == 0 || t == 2) {
            pu.setStrokeJoin(Paint.Join.ROUND);
            pu.setStrokeCap(Paint.Cap.ROUND);
            pv.setStrokeJoin(Paint.Join.ROUND);
            pv.setStrokeCap(Paint.Cap.ROUND);
        }
        Paint pw = new Paint();
        this.f17652w = pw;
        pw.set(pv);
        pw.setMaskFilter(new android.graphics.BlurMaskFilter(this.f17634n * 4.0f, android.graphics.BlurMaskFilter.Blur.NORMAL));
        Paint px = new Paint();
        this.f17654x = px;
        px.setAntiAlias(true);
        px.setDither(true);
        px.setStyle(Paint.Style.FILL);
        px.setColor(this.L);
        px.setMaskFilter(emboss);
        px.setStrokeWidth(this.E);
        Paint py = new Paint();
        this.f17655y = py;
        py.setAntiAlias(true);
        py.setDither(true);
        py.setStyle(Paint.Style.FILL);
        py.setColor(Color.rgb(51, 51, 51));
        py.setMaskFilter(emboss);
        py.setStrokeWidth(this.E);
        Paint pz = new Paint();
        this.f17656z = pz;
        pz.set(px);
        pz.setColor(this.M);
        pz.setAlpha(this.P);
        pz.setStrokeWidth(this.E + this.F);
        Paint pa = new Paint();
        this.A = pa;
        pa.set(px);
        pa.setStrokeWidth(this.G);
        pa.setStyle(Paint.Style.STROKE);
    }

    private void h() {
        Path path = new Path();
        this.U = path;
        path.addArc(this.K, this.H, this.R);
        Path path2 = new Path();
        this.T = path2;
        path2.addArc(this.J, this.H, this.R);
        Path path3 = new Path();
        this.W = path3;
        path3.addArc(this.K, this.H, this.S);
        Path path4 = new Path();
        this.V = path4;
        path4.addArc(this.J, this.H, this.S);
    }

    private void i() {
        RectF rectF = this.K;
        float f4 = this.f17637o0;
        float f5 = this.f17639p0;
        rectF.set(-f4, -f5, f4, f5);
        float f6 = this.f17638p * this.f17634n;
        RectF rectF2 = this.J;
        float f7 = this.f17637o0;
        float f8 = this.f17639p0;
        rectF2.set((-f7) + f6, (-f8) + f6, f7 - f6, f8 - f6);
    }

    private void j() {
        d();
        a();
        c();
        i();
        h();
        b();
    }

    private void setProgressBasedOnAngle(float f4) {
        this.f17641q0 = f4;
        c();
        this.f17622b0 = Math.round((this.f17621a0 * this.S) / this.R);
    }

    public int getCircleColor() {
        return this.N;
    }

    public int getCircleProgressColor() {
        return this.O;
    }

    public int getPointerAlpha() {
        return this.P;
    }

    public int getPointerAlphaOnTouch() {
        return this.Q;
    }

    public int getPointerColor() {
        return this.L;
    }

    public int getPointerHaloColor() {
        return this.M;
    }

    public int getProgress() {
        return Math.round((this.f17621a0 * this.S) / this.R);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        float f4;
        float f5;
        super.onDraw(canvas);
        this.f17640q.setRotate(this.f17641q0, this.f17644s / 2, this.f17646t / 2);
        int i4 = this.f17647t0;
        if (i4 == -1) {
            canvas.drawBitmap(this.f17642r, this.f17640q, null);
            canvas.translate(getWidth() / 2, getHeight() / 2);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            float[] fArr = this.f17643r0;
            canvas.drawCircle(fArr[0], fArr[1], this.E, this.f17654x);
            if (!this.f17628h0) {
                return;
            }
            float[] fArr2 = this.f17643r0;
            f4 = fArr2[0];
            f5 = fArr2[1];
        } else if (i4 == 0) {
            canvas.drawBitmap(this.f17642r, this.f17640q, null);
            canvas.translate(getWidth() / 2, getHeight() / 2);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            float[] fArr3 = this.f17643r0;
            canvas.drawCircle(fArr3[0], fArr3[1], this.E, this.f17654x);
            if (!this.f17628h0) {
                return;
            }
            float[] fArr4 = this.f17643r0;
            f4 = fArr4[0];
            f5 = fArr4[1];
        } else if (i4 == 1) {
            canvas.translate(getWidth() / 2, getHeight() / 2);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            return;
        } else if (i4 != 2) {
            return;
        } else {
            canvas.translate(getWidth() / 2.0f, getHeight() / 2.0f);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            canvas.drawPath(this.U, this.f17648u);
            canvas.drawPath(this.W, this.f17650v);
            float[] fArr5 = this.f17643r0;
            canvas.drawCircle(fArr5[0], fArr5[1], this.E, this.f17654x);
            if (!this.f17628h0) {
                return;
            }
            float[] fArr6 = this.f17643r0;
            f4 = fArr6[0];
            f5 = fArr6[1];
        }
        canvas.drawCircle(f4, f5, this.E, this.f17654x);
    }

    @Override // android.view.View
    protected void onMeasure(int i4, int i5) {
        int defaultSize = View.getDefaultSize(getSuggestedMinimumHeight(), i5);
        int defaultSize2 = View.getDefaultSize(getSuggestedMinimumWidth(), i4);
        if (this.f17624d0) {
            int min = Math.min(defaultSize2, defaultSize);
            setMeasuredDimension(min, min);
        } else {
            setMeasuredDimension(defaultSize2, defaultSize);
        }
        float f4 = this.B;
        float f5 = this.G;
        float f6 = ((defaultSize / 2.0f) - f4) - (f5 * 1.5f);
        this.f17639p0 = f6;
        float f7 = ((defaultSize2 / 2.0f) - f4) - (f5 * 1.5f);
        this.f17637o0 = f7;
        if (this.f17623c0) {
            float f8 = this.D;
            float f9 = this.E;
            if (((f8 - f4) - f9) - f5 < f6) {
                this.f17639p0 = ((f8 - f4) - f9) - (f5 * 1.5f);
            }
            float f10 = this.C;
            if (((f10 - f4) - f9) - f5 < f7) {
                this.f17637o0 = ((f10 - f4) - f9) - (f5 * 1.5f);
            }
        }
        if (this.f17624d0) {
            float min2 = Math.min(this.f17639p0, this.f17637o0);
            this.f17639p0 = min2;
            this.f17637o0 = min2;
        }
        j();
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        Bundle bundle = (Bundle) parcelable;
        super.onRestoreInstanceState(bundle.getParcelable("PARENT"));
        this.f17621a0 = bundle.getInt("MAX");
        this.f17622b0 = bundle.getInt("PROGRESS");
        this.N = bundle.getInt("mCircleColor");
        this.O = bundle.getInt("mCircleProgressColor");
        this.L = bundle.getInt("mPointerColor");
        this.M = bundle.getInt("mPointerHaloColor");
        this.P = bundle.getInt("mPointerAlpha");
        this.Q = bundle.getInt("mPointerAlphaOnTouch");
        g();
        j();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState = super.onSaveInstanceState();
        Bundle bundle = new Bundle();
        bundle.putParcelable("PARENT", onSaveInstanceState);
        bundle.putInt("MAX", this.f17621a0);
        bundle.putInt("PROGRESS", this.f17622b0);
        bundle.putInt("mCircleColor", this.N);
        bundle.putInt("mCircleProgressColor", this.O);
        bundle.putInt("mPointerColor", this.L);
        bundle.putInt("mPointerHaloColor", this.M);
        bundle.putInt("mPointerAlpha", this.P);
        bundle.putInt("mPointerAlphaOnTouch", this.Q);
        return bundle;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        Bitmap decodeResource;
        Resources resources = getResources();
        int i8 = app.eqclean.R.drawable.round_full_podloga;
        this.f17647t0 = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext()).getString("teme_preference", "2"));
        this.f17644s = i4;
        this.f17646t = i5;
        this.f17640q = new Matrix();
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 2;
        int i9 = this.f17647t0;
        if (i9 != -1) {
            if (i9 == 0) {
                resources = getResources();
                i8 = app.eqclean.R.drawable.volumefekt_svitla;
            } else if (i9 == 1) {
                resources = getResources();
                i8 = app.eqclean.R.drawable.volumefekt;
            }
            decodeResource = BitmapFactory.decodeResource(resources, i8, options);
            this.f17642r = (Bitmap) new WeakReference(Bitmap.createScaledBitmap((Bitmap) new WeakReference(decodeResource).get(), i4, i5, true)).get();
            super.onSizeChanged(i4, i5, i6, i7);
            return;
        }
        decodeResource = BitmapFactory.decodeResource(getResources(), app.eqclean.R.drawable.round_full_podloga, options);
        this.f17642r = (Bitmap) new WeakReference(Bitmap.createScaledBitmap((Bitmap) new WeakReference(decodeResource).get(), i4, i5, true)).get();
        super.onSizeChanged(i4, i5, i6, i7);
    }

    /* JADX WARN: Code restructure failed: missing block: B:78:0x014b, code lost:
        if (r0 != null) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x014d, code lost:
        r0.a(r11, r11.f17622b0, true);
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x0163, code lost:
        if (r0 != null) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x017f, code lost:
        if (r0 != null) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x0182, code lost:
        r11.f17633m0 = r11.f17629i0;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onTouchEvent(android.view.MotionEvent motionEvent) {
        if (!this.f17653w0) {
            return true;
        }
        float x = motionEvent.getX() - (getWidth() / 2.0f);
        float y = motionEvent.getY() - (getHeight() / 2.0f);
        float dist = (float) Math.sqrt(Math.pow(this.K.centerX() - x, 2.0d) + Math.pow(this.K.centerY() - y, 2.0d));
        float touch = this.f17636o * this.f17634n;
        float stroke = this.B;
        float half = stroke < touch ? touch / 2.0f : stroke / 2.0f;
        float outer = Math.max(this.f17639p0, this.f17637o0) + half;
        float inner = Math.min(this.f17639p0, this.f17637o0) - half;
        float ang = (float) (((Math.atan2(y, x) / 3.141592653589793d) * 180.0d) % 360.0d);
        if (ang < 0.0f) {
            ang += 360.0f;
        }
        float fromStart = ang - this.H;
        this.f17629i0 = fromStart;
        if (fromStart < 0.0f) {
            fromStart += 360.0f;
        }
        this.f17629i0 = fromStart;
        this.f17630j0 = 360.0f - fromStart;
        float fromEnd = ang - this.I;
        this.f17631k0 = fromEnd;
        if (fromEnd < 0.0f) {
            fromEnd += 360.0f;
        }
        this.f17631k0 = fromEnd;
        this.f17632l0 = 360.0f - fromEnd;
        int action = motionEvent.getAction();
        if (action == 0) {
            if (this.f17629i0 > this.R) {
                this.f17628h0 = false;
                return false;
            }
            if (dist < inner || dist > outer) {
                this.f17628h0 = false;
                return false;
            }
            setProgressBasedOnAngle(ang);
            this.f17633m0 = this.f17629i0;
            this.f17635n0 = true;
            this.f17656z.setAlpha(this.Q);
            j();
            invalidate();
            if (this.f17645s0 != null) {
                this.f17645s0.a(this, this.f17622b0, true);
            }
            this.f17628h0 = true;
            this.f17627g0 = false;
            this.f17626f0 = false;
        } else if (action == 1) {
            this.f17656z.setAlpha(this.P);
            if (!this.f17628h0) {
                return false;
            }
            this.f17628h0 = false;
            invalidate();
            if (this.f17645s0 != null) {
                this.f17645s0.a(this, this.f17622b0, false);
            }
        } else if (action == 2) {
            if (!this.f17628h0) {
                return false;
            }
            float last = this.f17633m0;
            float cur = this.f17629i0;
            if (last < cur) {
                if (cur - last > 180.0f && !this.f17635n0) {
                    this.f17626f0 = true;
                    this.f17627g0 = false;
                } else {
                    this.f17635n0 = true;
                }
            } else if (last - cur > 180.0f && this.f17635n0) {
                this.f17627g0 = true;
                this.f17626f0 = false;
            } else {
                this.f17635n0 = false;
            }
            if (this.f17626f0 && this.f17635n0) {
                this.f17626f0 = false;
            }
            if (this.f17627g0 && !this.f17635n0) {
                this.f17627g0 = false;
            }
            if (this.f17626f0 && !this.f17635n0 && this.f17630j0 > 90.0f) {
                this.f17626f0 = false;
            }
            if (this.f17627g0 && this.f17635n0 && this.f17631k0 > 90.0f) {
                this.f17627g0 = false;
            }
            if (!this.f17627g0) {
                float r = this.R;
                if (cur > r && this.f17635n0 && last < r) {
                    this.f17627g0 = true;
                }
            }
            boolean notify = true;
            if (this.f17626f0) {
                this.f17622b0 = 0;
            } else if (this.f17627g0) {
                this.f17622b0 = this.f17621a0;
            } else if (this.f17625e0 || dist <= outer) {
                if (cur <= this.R) {
                    setProgressBasedOnAngle(ang);
                }
            } else {
                notify = false;
            }
            if (notify) {
                j();
                invalidate();
                if (this.f17645s0 != null) {
                    this.f17645s0.a(this, this.f17622b0, true);
                }
                this.f17633m0 = this.f17629i0;
            }
        } else if (action == 3) {
            this.f17656z.setAlpha(this.P);
            this.f17628h0 = false;
            invalidate();
        }
        if (motionEvent.getAction() == 2 && getParent() != null) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        return true;
    }

    public void setCircleColor(int i4) {
        this.N = i4;
        this.f17648u.setColor(i4);
        invalidate();
    }

    public void setCircleProgressColor(int i4) {
        this.O = i4;
        this.f17650v.setColor(i4);
        invalidate();
    }

    @Override // android.view.View
    public void setEnabled(boolean z3) {
        this.f17653w0 = z3;
    }

    public void setOnSeekBarChangeListener(a aVar) {
        this.f17645s0 = aVar;
    }

    public void setPointerAlpha(int i4) {
        if (i4 < 0 || i4 > 255) {
            return;
        }
        this.P = i4;
        this.f17656z.setAlpha(i4);
        invalidate();
    }

    public void setPointerAlphaOnTouch(int i4) {
        if (i4 < 0 || i4 > 255) {
            return;
        }
        this.Q = i4;
    }

    public void setPointerColor(int i4) {
        this.L = i4;
        this.f17654x.setColor(i4);
        invalidate();
    }

    public void setPointerHaloColor(int i4) {
        this.M = i4;
        this.f17656z.setColor(i4);
        invalidate();
    }

    public void setProgress(int i4) {
        if (this.f17622b0 != i4) {
            this.f17622b0 = i4;
            a aVar = this.f17645s0;
            if (aVar != null) {
                aVar.a(this, i4, false);
            }
            j();
            invalidate();
        }
    }
}
