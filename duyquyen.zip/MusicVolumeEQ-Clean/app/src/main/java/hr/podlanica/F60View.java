package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class F60View extends View {
    private boolean A;

    /* renamed from: n  reason: collision with root package name */
    public String f17910n;

    /* renamed from: o  reason: collision with root package name */
    private int f17911o;

    /* renamed from: p  reason: collision with root package name */
    private float f17912p;

    /* renamed from: q  reason: collision with root package name */
    float[] f17913q;

    /* renamed from: r  reason: collision with root package name */
    private int f17914r;

    /* renamed from: s  reason: collision with root package name */
    private int f17915s;

    /* renamed from: t  reason: collision with root package name */
    private int f17916t;

    /* renamed from: u  reason: collision with root package name */
    private int f17917u;

    /* renamed from: v  reason: collision with root package name */
    private int f17918v;

    /* renamed from: w  reason: collision with root package name */
    private GestureDetector f17919w;

    /* renamed from: x  reason: collision with root package name */
    private Matrix f17920x;

    /* renamed from: y  reason: collision with root package name */
    private Bitmap f17921y;

    /* renamed from: z  reason: collision with root package name */
    private Bitmap f17922z;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F60View.this.A = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F60View.this.A = false;
        }
    }

    /* loaded from: classes.dex */
    private class c implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        F60View f17925a;

        public c(F60View f60View) {
            this.f17925a = f60View;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            F60View.this.A = true;
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            this.f17925a.d(-f4, -f5);
            F60View.a();
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    public F60View(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17910n = null;
        this.f17911o = 0;
        this.f17913q = new float[9];
        this.A = false;
    }

    public F60View(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17910n = null;
        this.f17911o = 0;
        this.f17913q = new float[9];
        this.A = false;
    }

    public static void a() {
        EQ.b();
    }

    public void b() {
        Matrix matrix = new Matrix();
        this.f17920x = matrix;
        matrix.postTranslate(0.0f, MusicVolumeEQ.f17960a0);
        this.A = true;
        invalidate();
        new Handler().postDelayed(new b(), 500L);
    }

    public void d(float f4, float f5) {
        this.A = true;
        this.f17920x.postTranslate(0.0f, f5);
        invalidate();
    }

    public void e() {
        MusicVolumeEQ.n();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        this.f17920x.getValues(this.f17913q);
        float[] fArr = this.f17913q;
        float f4 = fArr[5];
        this.f17912p = f4;
        if (f4 <= 0.0f) {
            this.f17912p = 0.0f;
            fArr[5] = 0.0f;
            this.f17920x.setValues(fArr);
        }
        float f5 = this.f17912p;
        int i4 = this.f17917u;
        if (f5 >= i4) {
            float f6 = i4;
            this.f17912p = f6;
            float[] fArr2 = this.f17913q;
            fArr2[5] = f6;
            this.f17920x.setValues(fArr2);
        }
        canvas.drawBitmap(this.f17921y, this.f17920x, null);
        int i5 = ((int) this.f17912p) / this.f17914r;
        MusicVolumeEQ.f17960a0 = i5;
        MusicVolumeEQ.f17960a0 = this.f17917u - i5;
        if (this.A) {
            e();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0081, code lost:
        if (r1 != 2) goto L9;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        if (!isInEditMode()) {
            this.f17914r = 1;
            this.f17915s = (int) android.util.TypedValue.applyDimension(1, 40.0f, getResources().getDisplayMetrics());
            this.f17916t = (int) android.util.TypedValue.applyDimension(1, 57.2f, getResources().getDisplayMetrics());
            int h = (int) android.util.TypedValue.applyDimension(1, 155.0f, getResources().getDisplayMetrics());
            this.f17917u = h;
            this.f17918v = h - MusicVolumeEQ.f17960a0;
            Matrix matrix = new Matrix();
            this.f17920x = matrix;
            matrix.postTranslate(this.f17911o, this.f17918v);
            this.f17919w = new GestureDetector(new c(this));
            int teme = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            if (teme == 0) {
                this.f17922z = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq_svitla);
            } else if (teme == -1 || teme == 1 || teme == 2) {
                this.f17922z = BitmapFactory.decodeResource(getResources(), R.drawable.knobeq);
            }
            this.f17921y = Bitmap.createScaledBitmap(this.f17922z, this.f17915s, this.f17916t, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            new Handler().postDelayed(new a(), 500L);
        }
        return this.f17919w.onTouchEvent(motionEvent);
    }
}
