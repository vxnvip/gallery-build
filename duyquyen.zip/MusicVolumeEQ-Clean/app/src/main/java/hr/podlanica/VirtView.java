package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class VirtView extends View {
    private double A;
    private final float B;
    private final float C;
    private boolean D;
    private float E;

    /* renamed from: n  reason: collision with root package name */
    private float f18064n;

    /* renamed from: o  reason: collision with root package name */
    float[] f18065o;

    /* renamed from: p  reason: collision with root package name */
    private int f18066p;

    /* renamed from: q  reason: collision with root package name */
    private int f18067q;

    /* renamed from: r  reason: collision with root package name */
    private GestureDetector f18068r;

    /* renamed from: s  reason: collision with root package name */
    private Matrix f18069s;

    /* renamed from: t  reason: collision with root package name */
    private Bitmap f18070t;

    /* renamed from: u  reason: collision with root package name */
    private Bitmap f18071u;

    /* renamed from: v  reason: collision with root package name */
    private float f18072v;

    /* renamed from: w  reason: collision with root package name */
    private float f18073w;

    /* renamed from: x  reason: collision with root package name */
    private float f18074x;

    /* renamed from: y  reason: collision with root package name */
    private float f18075y;

    /* renamed from: z  reason: collision with root package name */
    private boolean f18076z;

    /* loaded from: classes.dex */
    private class a implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        VirtView f18077a;

        public a(VirtView virtView) {
            this.f18077a = virtView;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            float x3 = motionEvent.getX() / VirtView.this.getWidth();
            float y3 = motionEvent.getY() / VirtView.this.getHeight();
            VirtView virtView = VirtView.this;
            virtView.E = virtView.s(x3, y3);
            return !Float.isNaN(VirtView.this.E);
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            VirtView virtView;
            float f6;
            VirtView.this.f18074x = motionEvent2.getX();
            VirtView.this.f18075y = motionEvent2.getY();
            float s4 = VirtView.this.s(motionEvent2.getX() / VirtView.this.getWidth(), motionEvent2.getY() / VirtView.this.getHeight());
            float f7 = VirtView.this.E - s4;
            double signum = Math.signum(f7);
            double floor = Math.floor(Math.abs(f7) / 22.5f);
            Double.isNaN(signum);
            int i4 = (int) (signum * floor);
            VirtView.this.f18076z = ((float) ((int) Math.toDegrees((double) (f7 / 90.0f)))) < 0.0f;
            if (VirtView.this.f18076z) {
                virtView = VirtView.this;
                f6 = -10.0f;
            } else {
                virtView = VirtView.this;
                f6 = 10.0f;
            }
            virtView.f18064n = f6;
            VirtView virtView2 = VirtView.this;
            double d4 = virtView2.A;
            double d5 = VirtView.this.f18064n;
            Double.isNaN(d5);
            virtView2.A = d4 + d5;
            if (VirtView.this.A > 280.0d) {
                VirtView.this.A = 280.0d;
                VirtView.this.f18064n = 0.0f;
            }
            if (VirtView.this.A < 0.0d) {
                VirtView.this.A = 0.0d;
                VirtView.this.f18064n = 0.0f;
            }
            VirtView.this.f18069s.postRotate(VirtView.this.f18064n, VirtView.this.f18066p / 2.0f, VirtView.this.f18067q / 2.0f);
            double d6 = VirtView.this.A;
            Double.isNaN(3.5714285f);
            MusicVolumeEQ.f17966g0 = (int) (d6 * r4);
            VirtView.this.r();
            VirtView.this.invalidate();
            VirtView.this.f18072v = motionEvent2.getX();
            VirtView.this.f18073w = motionEvent2.getY();
            if (i4 != 0) {
                VirtView.this.E = s4;
            }
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    public VirtView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f18065o = new float[9];
        this.B = 280.0f;
        this.C = 1000.0f;
        this.D = false;
        this.E = Float.NaN;
    }

    public VirtView(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f18065o = new float[9];
        this.B = 280.0f;
        this.C = 1000.0f;
        this.D = false;
        this.E = Float.NaN;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float s(float f4, float f5) {
        return (float) Math.toDegrees(Math.atan2(f4 - 1.0f, f5 - 1.0f));
    }

    public void a() {
        Matrix matrix = new Matrix();
        this.f18069s = matrix;
        double d4 = (((MusicVolumeEQ.f17966g0 / 3.5714285f) + 5.0f) / 10.0f) * 10.0f;
        this.A = d4;
        if (d4 > 280.0d) {
            this.A = 280.0d;
        }
        if (this.A < 9.0d) {
            this.A = 0.0d;
        }
        matrix.postRotate((float) this.A, this.f18066p / 2.0f, this.f18067q / 2.0f);
        invalidate();
        r();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        canvas.drawBitmap(this.f18070t, this.f18069s, null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0097, code lost:
        if (r0 != 2) goto L15;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        if (!isInEditMode()) {
            this.f18066p = (int) android.util.TypedValue.applyDimension(1, 59.8f, getResources().getDisplayMetrics());
            this.f18067q = (int) android.util.TypedValue.applyDimension(1, 59.8f, getResources().getDisplayMetrics());
            Matrix matrix = new Matrix();
            this.f18069s = matrix;
            double angle = (double) ((((float) MusicVolumeEQ.f17966g0) / 3.5714285f + 5.0f) / 10.0f * 10.0f);
            this.A = angle;
            if (angle > 280.0d) {
                this.A = 280.0d;
            }
            if (this.A < 9.0d) {
                this.A = 0.0d;
            }
            matrix.postRotate((float) this.A, this.f18066p / 2.0f, this.f18067q / 2.0f);
            this.f18068r = new GestureDetector(new a(this));
            int teme = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            if (teme == 0) {
                this.f18071u = BitmapFactory.decodeResource(getResources(), R.drawable.bass_svitla);
            } else if (teme == -1 || teme == 1 || teme == 2) {
                this.f18071u = BitmapFactory.decodeResource(getResources(), R.drawable.bass);
            }
            this.f18070t = Bitmap.createScaledBitmap(this.f18071u, this.f18066p, this.f18067q, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        motionEvent.getAction();
        motionEvent.getAction();
        motionEvent.getAction();
        return this.f18068r.onTouchEvent(motionEvent);
    }

    public void r() {
        MusicVolumeEQ.w();
    }
}
