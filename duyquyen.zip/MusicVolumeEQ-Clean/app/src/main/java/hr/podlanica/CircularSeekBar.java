package hr.podlanica;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import app.eqclean.R;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class CircularSeekBar extends View {

    /* renamed from: x0  reason: collision with root package name */
    private static final int f17579x0 = Color.argb(235, 74, 138, 255);

    /* renamed from: y0  reason: collision with root package name */
    private static final int f17580y0 = Color.argb(235, 74, 138, 255);

    /* renamed from: z0  reason: collision with root package name */
    private static final int f17581z0 = Color.argb(135, 74, 138, 255);
    private Paint A;
    private float B;
    private float C;
    private float D;
    private float E;
    private float F;
    private float G;
    private float H;
    private float I;
    private RectF J;
    private RectF K;
    private int L;
    private int M;
    private int N;
    private int O;
    private int P;
    private int Q;
    private float R;
    private float S;
    private Path T;
    private Path U;
    private Path V;
    private Path W;

    /* renamed from: a0  reason: collision with root package name */
    private int f17582a0;

    /* renamed from: b0  reason: collision with root package name */
    private int f17583b0;

    /* renamed from: c0  reason: collision with root package name */
    private boolean f17584c0;

    /* renamed from: d0  reason: collision with root package name */
    private boolean f17585d0;

    /* renamed from: e0  reason: collision with root package name */
    private boolean f17586e0;

    /* renamed from: f0  reason: collision with root package name */
    private boolean f17587f0;

    /* renamed from: g0  reason: collision with root package name */
    private boolean f17588g0;

    /* renamed from: h0  reason: collision with root package name */
    private boolean f17589h0;

    /* renamed from: i0  reason: collision with root package name */
    private float f17590i0;

    /* renamed from: j0  reason: collision with root package name */
    private float f17591j0;

    /* renamed from: k0  reason: collision with root package name */
    private float f17592k0;

    /* renamed from: l0  reason: collision with root package name */
    private float f17593l0;

    /* renamed from: m0  reason: collision with root package name */
    private float f17594m0;

    /* renamed from: n  reason: collision with root package name */
    private final float f17595n;

    /* renamed from: n0  reason: collision with root package name */
    private boolean f17596n0;

    /* renamed from: o  reason: collision with root package name */
    private float f17597o;

    /* renamed from: o0  reason: collision with root package name */
    private float f17598o0;

    /* renamed from: p  reason: collision with root package name */
    private float f17599p;

    /* renamed from: p0  reason: collision with root package name */
    private float f17600p0;

    /* renamed from: q  reason: collision with root package name */
    private Matrix f17601q;

    /* renamed from: q0  reason: collision with root package name */
    private float f17602q0;

    /* renamed from: r  reason: collision with root package name */
    private Bitmap f17603r;

    /* renamed from: r0  reason: collision with root package name */
    private float[] f17604r0;

    /* renamed from: s  reason: collision with root package name */
    private int f17605s;

    /* renamed from: s0  reason: collision with root package name */
    private a f17606s0;

    /* renamed from: t  reason: collision with root package name */
    private int f17607t;

    /* renamed from: t0  reason: collision with root package name */
    private int f17608t0;

    /* renamed from: u  reason: collision with root package name */
    private Paint f17609u;

    /* renamed from: u0  reason: collision with root package name */
    private int f17610u0;

    /* renamed from: v  reason: collision with root package name */
    private Paint f17611v;

    /* renamed from: v0  reason: collision with root package name */
    private int f17612v0;

    /* renamed from: w  reason: collision with root package name */
    private Paint f17613w;

    /* renamed from: w0  reason: collision with root package name */
    private boolean f17614w0;

    /* renamed from: x  reason: collision with root package name */
    private Paint f17615x;

    /* renamed from: y  reason: collision with root package name */
    private Paint f17616y;

    /* renamed from: z  reason: collision with root package name */
    private Paint f17617z;

    /* loaded from: classes.dex */
    public interface a {
        void a(CircularSeekBar circularSeekBar, int i4, boolean z3);
    }

    public CircularSeekBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17595n = getResources().getDisplayMetrics().density;
        this.f17597o = 250.0f;
        this.f17599p = 45.0f;
        this.J = new RectF();
        this.K = new RectF();
        this.L = f17580y0;
        this.M = f17581z0;
        this.N = -12303292;
        this.O = f17579x0;
        this.P = 135;
        this.Q = 100;
        this.f17587f0 = true;
        this.f17588g0 = false;
        this.f17589h0 = false;
        this.f17604r0 = new float[2];
        this.f17614w0 = true;
        e(attributeSet, 0);
    }

    public CircularSeekBar(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17595n = getResources().getDisplayMetrics().density;
        this.f17597o = 250.0f;
        this.f17599p = 45.0f;
        this.J = new RectF();
        this.K = new RectF();
        this.L = f17580y0;
        this.M = f17581z0;
        this.N = -12303292;
        this.O = f17579x0;
        this.P = 135;
        this.Q = 100;
        this.f17587f0 = true;
        this.f17588g0 = false;
        this.f17589h0 = false;
        this.f17604r0 = new float[2];
        this.f17614w0 = true;
        e(attributeSet, i4);
    }

    private void a() {
        this.f17602q0 = (((this.f17583b0 / this.f17582a0) * this.R) + this.H) % 360.0f;
    }

    private void b() {
        PathMeasure pathMeasure = new PathMeasure(this.V, false);
        if (pathMeasure.getPosTan(pathMeasure.getLength(), this.f17604r0, null)) {
            return;
        }
        new PathMeasure(this.T, false).getPosTan(0.0f, this.f17604r0, null);
    }

    private void c() {
        float f4 = this.f17602q0 - this.H;
        this.S = f4;
        if (f4 < 0.0f) {
            f4 += 360.0f;
        }
        this.S = f4;
    }

    private void d() {
        float f4 = (360.0f - (this.H - this.I)) % 360.0f;
        this.R = f4;
        if (f4 <= 0.0f) {
            this.R = 360.0f;
        }
    }

    private void e(AttributeSet attributeSet, int i4) {
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.CircularSeekBar, i4, 0);
        f(obtainStyledAttributes);
        obtainStyledAttributes.recycle();
        g();
    }

    private void f(TypedArray typedArray) {
        Resources resources = getResources();
        this.f17599p = 0.0f;
        this.f17610u0 = resources.getInteger(R.integer.interval1);
        this.f17612v0 = resources.getInteger(R.integer.interval2);
        this.C = typedArray.getFloat(3, 30.0f) * this.f17595n;
        this.D = typedArray.getFloat(4, 30.0f) * this.f17595n;
        this.E = typedArray.getFloat(14, 6.0f) * this.f17595n;
        this.F = typedArray.getFloat(13, 6.0f) * this.f17595n;
        this.G = typedArray.getFloat(11, 2.0f) * this.f17595n;
        this.B = typedArray.getFloat(2, 5.0f) * this.f17595n;
        String string = typedArray.getString(10);
        if (string != null) {
            try {
                this.L = Color.parseColor(string);
            } catch (IllegalArgumentException unused) {
                this.L = f17580y0;
            }
        }
        String string2 = typedArray.getString(12);
        if (string2 != null) {
            try {
                this.M = Color.parseColor(string2);
            } catch (IllegalArgumentException unused2) {
                this.M = f17581z0;
            }
        }
        String string3 = typedArray.getString(0);
        if (string3 != null) {
            try {
                this.N = Color.parseColor(string3);
            } catch (IllegalArgumentException unused3) {
                this.N = -12303292;
            }
        }
        String string4 = typedArray.getString(1);
        if (string4 != null) {
            try {
                this.O = Color.parseColor(string4);
            } catch (IllegalArgumentException unused4) {
                this.O = f17579x0;
            }
        }
        this.P = Color.alpha(this.M);
        int i4 = typedArray.getInt(9, 100);
        this.Q = i4;
        if (i4 > 255 || i4 < 0) {
            this.Q = 100;
        }
        this.f17582a0 = typedArray.getInt(7, 100);
        this.f17583b0 = typedArray.getInt(15, 0);
        this.f17584c0 = typedArray.getBoolean(17, false);
        this.f17585d0 = typedArray.getBoolean(6, true);
        this.f17586e0 = typedArray.getBoolean(8, false);
        this.H = ((typedArray.getFloat(16, 270.0f) % 360.0f) + 360.0f) % 360.0f;
        float f4 = ((typedArray.getFloat(5, 270.0f) % 360.0f) + 360.0f) % 360.0f;
        this.I = f4;
        if (this.H == f4) {
            this.I = f4 - 0.1f;
        }
    }

    private void g() {
        this.f17608t0 = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext()).getString("teme_preference", "2"));
        EmbossMaskFilter embossMaskFilter = new EmbossMaskFilter(new float[]{0.0f, -1.0f, 0.5f}, 0.8f, 15.0f, 1.0f);
        Paint paint = new Paint();
        this.f17609u = paint;
        paint.setAntiAlias(true);
        this.f17609u.setDither(true);
        this.f17609u.setColor(this.N);
        this.f17609u.setStrokeWidth(this.B);
        this.f17609u.setStyle(Paint.Style.STROKE);
        Paint paint2 = new Paint();
        this.f17611v = paint2;
        paint2.setAntiAlias(true);
        this.f17611v.setDither(true);
        this.f17611v.setColor(this.O);
        this.f17611v.setStrokeWidth(this.B);
        this.f17611v.setStyle(Paint.Style.STROKE);
        this.f17609u.setStrokeJoin(Paint.Join.ROUND);
        this.f17609u.setStrokeCap(Paint.Cap.ROUND);
        this.f17611v.setStrokeJoin(Paint.Join.ROUND);
        this.f17611v.setStrokeCap(Paint.Cap.ROUND);
        Paint paint3 = new Paint();
        this.f17613w = paint3;
        paint3.set(this.f17611v);
        this.f17613w.setMaskFilter(new BlurMaskFilter(this.f17595n * 4.0f, BlurMaskFilter.Blur.NORMAL));
        Paint paint4 = new Paint();
        this.f17615x = paint4;
        paint4.setAntiAlias(true);
        this.f17615x.setDither(true);
        this.f17615x.setStyle(Paint.Style.FILL);
        this.f17615x.setColor(this.L);
        this.f17615x.setMaskFilter(embossMaskFilter);
        this.f17615x.setStrokeWidth(this.E);
        Paint paint5 = new Paint();
        this.f17616y = paint5;
        paint5.setAntiAlias(true);
        this.f17616y.setDither(true);
        this.f17616y.setStyle(Paint.Style.FILL);
        this.f17616y.setColor(Color.rgb(51, 51, 51));
        this.f17616y.setMaskFilter(embossMaskFilter);
        this.f17616y.setStrokeWidth(this.E);
        Paint paint6 = new Paint();
        this.f17617z = paint6;
        paint6.set(this.f17615x);
        this.f17617z.setColor(this.M);
        this.f17617z.setAlpha(this.P);
        this.f17617z.setStrokeWidth(this.E + this.F);
        Paint paint7 = new Paint();
        this.A = paint7;
        paint7.set(this.f17615x);
        this.A.setStrokeWidth(this.G);
        this.A.setStyle(Paint.Style.STROKE);
    }

    private void h() {
        Path path = new Path();
        this.U = path;
        path.addArc(this.K, this.H, this.R);
        Path path2 = new Path();
        this.T = path2;
        path2.addArc(this.J, this.H, this.R);
        Path path3 = new Path();
        this.W = path3;
        path3.addArc(this.K, this.H, this.S);
        Path path4 = new Path();
        this.V = path4;
        path4.addArc(this.J, this.H, this.S);
    }

    private void i() {
        RectF rectF = this.K;
        float f4 = this.f17598o0;
        float f5 = this.f17600p0;
        rectF.set(-f4, -f5, f4, f5);
        float f6 = this.f17599p * this.f17595n;
        RectF rectF2 = this.J;
        float f7 = this.f17598o0;
        float f8 = this.f17600p0;
        rectF2.set((-f7) + f6, (-f8) + f6, f7 - f6, f8 - f6);
    }

    private void j() {
        d();
        a();
        c();
        i();
        h();
        b();
    }

    private void setProgressBasedOnAngle(float f4) {
        this.f17602q0 = f4;
        c();
        this.f17583b0 = Math.round((this.f17582a0 * this.S) / this.R);
    }

    public int getCircleColor() {
        return this.N;
    }

    public int getCircleProgressColor() {
        return this.O;
    }

    public int getPointerAlpha() {
        return this.P;
    }

    public int getPointerAlphaOnTouch() {
        return this.Q;
    }

    public int getPointerColor() {
        return this.L;
    }

    public int getPointerHaloColor() {
        return this.M;
    }

    public int getProgress() {
        return Math.round((this.f17582a0 * this.S) / this.R);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f17601q.setRotate(this.f17602q0, this.f17605s / 2, this.f17607t / 2);
        canvas.translate(getWidth() / 2.0f, getHeight() / 2.0f);
        canvas.drawPath(this.U, this.f17609u);
        canvas.drawPath(this.W, this.f17611v);
        canvas.drawPath(this.U, this.f17609u);
        canvas.drawPath(this.W, this.f17611v);
        float[] fArr = this.f17604r0;
        canvas.drawCircle(fArr[0], fArr[1], this.E, this.f17615x);
        if (this.f17589h0) {
            float[] fArr2 = this.f17604r0;
            canvas.drawCircle(fArr2[0], fArr2[1], this.E, this.f17615x);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i4, int i5) {
        int defaultSize = View.getDefaultSize(getSuggestedMinimumHeight(), i5);
        int defaultSize2 = View.getDefaultSize(getSuggestedMinimumWidth(), i4);
        if (this.f17585d0) {
            int min = Math.min(defaultSize2, defaultSize);
            setMeasuredDimension(min, min);
        } else {
            setMeasuredDimension(defaultSize2, defaultSize);
        }
        float f4 = this.B;
        float f5 = this.G;
        float f6 = ((defaultSize / 2.0f) - f4) - (f5 * 1.5f);
        this.f17600p0 = f6;
        float f7 = ((defaultSize2 / 2.0f) - f4) - (f5 * 1.5f);
        this.f17598o0 = f7;
        if (this.f17584c0) {
            float f8 = this.D;
            float f9 = this.E;
            if (((f8 - f4) - f9) - f5 < f6) {
                this.f17600p0 = ((f8 - f4) - f9) - (f5 * 1.5f);
            }
            float f10 = this.C;
            if (((f10 - f4) - f9) - f5 < f7) {
                this.f17598o0 = ((f10 - f4) - f9) - (f5 * 1.5f);
            }
        }
        if (this.f17585d0) {
            float min2 = Math.min(this.f17600p0, this.f17598o0);
            this.f17600p0 = min2;
            this.f17598o0 = min2;
        }
        j();
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        Bundle bundle = (Bundle) parcelable;
        super.onRestoreInstanceState(bundle.getParcelable("PARENT"));
        this.f17582a0 = bundle.getInt("MAX");
        this.f17583b0 = bundle.getInt("PROGRESS");
        this.N = bundle.getInt("mCircleColor");
        this.O = bundle.getInt("mCircleProgressColor");
        this.L = bundle.getInt("mPointerColor");
        this.M = bundle.getInt("mPointerHaloColor");
        this.P = bundle.getInt("mPointerAlpha");
        this.Q = bundle.getInt("mPointerAlphaOnTouch");
        g();
        j();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState = super.onSaveInstanceState();
        Bundle bundle = new Bundle();
        bundle.putParcelable("PARENT", onSaveInstanceState);
        bundle.putInt("MAX", this.f17582a0);
        bundle.putInt("PROGRESS", this.f17583b0);
        bundle.putInt("mCircleColor", this.N);
        bundle.putInt("mCircleProgressColor", this.O);
        bundle.putInt("mPointerColor", this.L);
        bundle.putInt("mPointerHaloColor", this.M);
        bundle.putInt("mPointerAlpha", this.P);
        bundle.putInt("mPointerAlphaOnTouch", this.Q);
        return bundle;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        this.f17608t0 = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext()).getString("teme_preference", "2"));
        this.f17605s = i4;
        this.f17607t = i5;
        this.f17601q = new Matrix();
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 2;
        this.f17603r = (Bitmap) new WeakReference(Bitmap.createScaledBitmap((Bitmap) new WeakReference(BitmapFactory.decodeResource(getResources(), R.drawable.round_full_podloga, options)).get(), i4, i5, true)).get();
        super.onSizeChanged(i4, i5, i6, i7);
    }

    /* JADX WARN: Code restructure failed: missing block: B:78:0x014b, code lost:
        if (r0 != null) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x014d, code lost:
        r0.a(r11, r11.f17583b0, true);
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x0163, code lost:
        if (r0 != null) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x017f, code lost:
        if (r0 != null) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x0182, code lost:
        r11.f17594m0 = r11.f17590i0;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onTouchEvent(android.view.MotionEvent motionEvent) {
        if (!this.f17614w0) {
            return true;
        }
        float x = motionEvent.getX() - (getWidth() / 2.0f);
        float y = motionEvent.getY() - (getHeight() / 2.0f);
        float dist = (float) Math.sqrt(Math.pow(this.K.centerX() - x, 2.0d) + Math.pow(this.K.centerY() - y, 2.0d));
        float touch = this.f17597o * this.f17595n;
        float stroke = this.B;
        float half = stroke < touch ? touch / 2.0f : stroke / 2.0f;
        float outer = Math.max(this.f17600p0, this.f17598o0) + half;
        float inner = Math.min(this.f17600p0, this.f17598o0) - half;
        float ang = (float) (((Math.atan2(y, x) / 3.141592653589793d) * 180.0d) % 360.0d);
        if (ang < 0.0f) {
            ang += 360.0f;
        }
        float fromStart = ang - this.H;
        this.f17590i0 = fromStart;
        if (fromStart < 0.0f) {
            fromStart += 360.0f;
        }
        this.f17590i0 = fromStart;
        this.f17591j0 = 360.0f - fromStart;
        float fromEnd = ang - this.I;
        this.f17592k0 = fromEnd;
        if (fromEnd < 0.0f) {
            fromEnd += 360.0f;
        }
        this.f17592k0 = fromEnd;
        this.f17593l0 = 360.0f - fromEnd;
        int action = motionEvent.getAction();
        if (action == 0) {
            if (this.f17590i0 > this.R) {
                this.f17589h0 = false;
                return false;
            }
            if (dist < inner || dist > outer) {
                this.f17589h0 = false;
                return false;
            }
            setProgressBasedOnAngle(ang);
            this.f17594m0 = this.f17590i0;
            this.f17596n0 = true;
            this.z.setAlpha(this.Q);
            j();
            invalidate();
            if (this.f17606s0 != null) {
                this.f17606s0.a(this, this.f17583b0, true);
            }
            this.f17589h0 = true;
            this.f17588g0 = false;
            this.f17587f0 = false;
        } else if (action == 1) {
            this.z.setAlpha(this.P);
            if (!this.f17589h0) {
                return false;
            }
            this.f17589h0 = false;
            invalidate();
            if (this.f17606s0 != null) {
                this.f17606s0.a(this, this.f17583b0, false);
            }
        } else if (action == 2) {
            if (!this.f17589h0) {
                return false;
            }
            float last = this.f17594m0;
            float cur = this.f17590i0;
            if (last < cur) {
                if (cur - last > 180.0f && !this.f17596n0) {
                    this.f17587f0 = true;
                    this.f17588g0 = false;
                } else {
                    this.f17596n0 = true;
                }
            } else if (last - cur > 180.0f && this.f17596n0) {
                this.f17588g0 = true;
                this.f17587f0 = false;
            } else {
                this.f17596n0 = false;
            }
            if (this.f17587f0 && this.f17596n0) {
                this.f17587f0 = false;
            }
            if (this.f17588g0 && !this.f17596n0) {
                this.f17588g0 = false;
            }
            if (this.f17587f0 && !this.f17596n0 && this.f17591j0 > 90.0f) {
                this.f17587f0 = false;
            }
            if (this.f17588g0 && this.f17596n0 && this.f17592k0 > 90.0f) {
                this.f17588g0 = false;
            }
            if (!this.f17588g0) {
                float r = this.R;
                if (cur > r && this.f17596n0 && last < r) {
                    this.f17588g0 = true;
                }
            }
            boolean notify = true;
            if (this.f17587f0) {
                this.f17583b0 = 0;
            } else if (this.f17588g0) {
                this.f17583b0 = this.f17582a0;
            } else if (this.f17586e0 || dist <= outer) {
                if (cur <= this.R) {
                    setProgressBasedOnAngle(ang);
                }
            } else {
                notify = false;
            }
            if (notify) {
                j();
                invalidate();
                if (this.f17606s0 != null) {
                    this.f17606s0.a(this, this.f17583b0, true);
                }
                this.f17594m0 = this.f17590i0;
            }
        } else if (action == 3) {
            this.z.setAlpha(this.P);
            this.f17589h0 = false;
            invalidate();
        }
        if (motionEvent.getAction() == 2 && getParent() != null) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        return true;
    }

    public void setCircleColor(int i4) {
        this.N = i4;
        this.f17609u.setColor(i4);
        invalidate();
    }

    public void setCircleProgressColor(int i4) {
        this.O = i4;
        this.f17611v.setColor(i4);
        invalidate();
    }

    @Override // android.view.View
    public void setEnabled(boolean z3) {
        this.f17614w0 = z3;
    }

    public void setOnSeekBarChangeListener(a aVar) {
        this.f17606s0 = aVar;
    }

    public void setPointerAlpha(int i4) {
        if (i4 < 0 || i4 > 255) {
            return;
        }
        this.P = i4;
        this.f17617z.setAlpha(i4);
        invalidate();
    }

    public void setPointerAlphaOnTouch(int i4) {
        if (i4 < 0 || i4 > 255) {
            return;
        }
        this.Q = i4;
    }

    public void setPointerColor(int i4) {
        this.L = i4;
        this.f17615x.setColor(i4);
        invalidate();
    }

    public void setPointerHaloColor(int i4) {
        this.M = i4;
        this.f17617z.setColor(i4);
        invalidate();
    }

    public void setProgress(int i4) {
        if (this.f17583b0 != i4) {
            this.f17583b0 = i4;
            a aVar = this.f17606s0;
            if (aVar != null) {
                aVar.a(this, i4, false);
            }
            j();
            invalidate();
        }
    }
}
