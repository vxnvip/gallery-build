package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class BassView extends View {
    private double A;
    private final float B;
    private final float C;
    private boolean D;
    private float E;

    /* renamed from: n  reason: collision with root package name */
    private float f17564n;

    /* renamed from: o  reason: collision with root package name */
    float[] f17565o;

    /* renamed from: p  reason: collision with root package name */
    private int f17566p;

    /* renamed from: q  reason: collision with root package name */
    private int f17567q;

    /* renamed from: r  reason: collision with root package name */
    private GestureDetector f17568r;

    /* renamed from: s  reason: collision with root package name */
    private Matrix f17569s;

    /* renamed from: t  reason: collision with root package name */
    private Bitmap f17570t;

    /* renamed from: u  reason: collision with root package name */
    private Bitmap f17571u;

    /* renamed from: v  reason: collision with root package name */
    private float f17572v;

    /* renamed from: w  reason: collision with root package name */
    private float f17573w;

    /* renamed from: x  reason: collision with root package name */
    private float f17574x;

    /* renamed from: y  reason: collision with root package name */
    private float f17575y;

    /* renamed from: z  reason: collision with root package name */
    private boolean f17576z;

    /* loaded from: classes.dex */
    private class a implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        BassView f17577a;

        public a(BassView bassView) {
            this.f17577a = bassView;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            float x3 = motionEvent.getX() / BassView.this.getWidth();
            float y3 = motionEvent.getY() / BassView.this.getHeight();
            BassView bassView = BassView.this;
            bassView.E = bassView.s(x3, y3);
            return !Float.isNaN(BassView.this.E);
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            BassView bassView;
            float f6;
            BassView.this.f17574x = motionEvent2.getX();
            BassView.this.f17575y = motionEvent2.getY();
            float s4 = BassView.this.s(motionEvent2.getX() / BassView.this.getWidth(), motionEvent2.getY() / BassView.this.getHeight());
            float f7 = BassView.this.E - s4;
            double signum = Math.signum(f7);
            double floor = Math.floor(Math.abs(f7) / 22.5f);
            Double.isNaN(signum);
            int i4 = (int) (signum * floor);
            BassView.this.f17576z = ((float) ((int) Math.toDegrees((double) (f7 / 90.0f)))) < 0.0f;
            if (BassView.this.f17576z) {
                bassView = BassView.this;
                f6 = -10.0f;
            } else {
                bassView = BassView.this;
                f6 = 10.0f;
            }
            bassView.f17564n = f6;
            BassView bassView2 = BassView.this;
            double d4 = bassView2.A;
            double d5 = BassView.this.f17564n;
            Double.isNaN(d5);
            bassView2.A = d4 + d5;
            if (BassView.this.A > 280.0d) {
                BassView.this.A = 280.0d;
                BassView.this.f17564n = 0.0f;
            }
            if (BassView.this.A < 0.0d) {
                BassView.this.A = 0.0d;
                BassView.this.f17564n = 0.0f;
            }
            BassView.this.f17569s.postRotate(BassView.this.f17564n, BassView.this.f17566p / 2.0f, BassView.this.f17567q / 2.0f);
            double d6 = BassView.this.A;
            MusicVolumeEQ.f17965f0 = (int) (d6 * 3.5714285f);
            BassView.this.r();
            BassView.this.invalidate();
            BassView.this.f17572v = motionEvent2.getX();
            BassView.this.f17573w = motionEvent2.getY();
            if (i4 != 0) {
                BassView.this.E = s4;
            }
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    public BassView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17565o = new float[9];
        this.B = 280.0f;
        this.C = 1000.0f;
        this.D = false;
        this.E = Float.NaN;
    }

    public BassView(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17565o = new float[9];
        this.B = 280.0f;
        this.C = 1000.0f;
        this.D = false;
        this.E = Float.NaN;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float s(float f4, float f5) {
        return (float) Math.toDegrees(Math.atan2(f4 - 1.0f, f5 - 1.0f));
    }

    public void a() {
        Matrix matrix = new Matrix();
        this.f17569s = matrix;
        double d4 = (((MusicVolumeEQ.f17965f0 / 3.5714285f) + 5.0f) / 10.0f) * 10.0f;
        this.A = d4;
        if (d4 > 280.0d) {
            this.A = 280.0d;
        }
        if (this.A < 9.0d) {
            this.A = 0.0d;
        }
        matrix.postRotate((float) this.A, this.f17566p / 2.0f, this.f17567q / 2.0f);
        invalidate();
        r();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        canvas.drawBitmap(this.f17570t, this.f17569s, null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0097, code lost:
        if (r0 != 2) goto L15;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        if (!isInEditMode()) {
            this.f17566p = (int) android.util.TypedValue.applyDimension(1, 59.8f, getResources().getDisplayMetrics());
            this.f17567q = (int) android.util.TypedValue.applyDimension(1, 59.8f, getResources().getDisplayMetrics());
            Matrix matrix = new Matrix();
            this.f17569s = matrix;
            double angle = (double) ((((float) MusicVolumeEQ.f17965f0) / 3.5714285f + 5.0f) / 10.0f * 10.0f);
            this.A = angle;
            if (angle > 280.0d) {
                this.A = 280.0d;
            }
            if (this.A < 9.0d) {
                this.A = 0.0d;
            }
            matrix.postRotate((float) this.A, this.f17566p / 2.0f, this.f17567q / 2.0f);
            this.f17568r = new GestureDetector(new a(this));
            int teme = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            if (teme == 0) {
                this.f17571u = BitmapFactory.decodeResource(getResources(), R.drawable.bass_svitla);
            } else if (teme == -1 || teme == 1 || teme == 2) {
                this.f17571u = BitmapFactory.decodeResource(getResources(), R.drawable.bass);
            }
            this.f17570t = Bitmap.createScaledBitmap(this.f17571u, this.f17566p, this.f17567q, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        motionEvent.getAction();
        motionEvent.getAction();
        motionEvent.getAction();
        return this.f17568r.onTouchEvent(motionEvent);
    }

    public void r() {
        MusicVolumeEQ.d();
    }
}
