package hr.podlanica;

import app.eqclean.R;
import app.eqclean.Cfg;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class F14View extends View {
    private d A;
    private int B;
    private int C;
    int D;
    int E;
    int F;
    private int G;
    private final Paint H;
    private final Paint I;
    private int J;
    private boolean K;

    /* renamed from: n  reason: collision with root package name */
    private int f17825n;

    /* renamed from: o  reason: collision with root package name */
    private float f17826o;

    /* renamed from: p  reason: collision with root package name */
    float[] f17827p;

    /* renamed from: q  reason: collision with root package name */
    private int f17828q;

    /* renamed from: r  reason: collision with root package name */
    private int f17829r;

    /* renamed from: s  reason: collision with root package name */
    private int f17830s;

    /* renamed from: t  reason: collision with root package name */
    private int f17831t;

    /* renamed from: u  reason: collision with root package name */
    private int f17832u;

    /* renamed from: v  reason: collision with root package name */
    private GestureDetector f17833v;

    /* renamed from: w  reason: collision with root package name */
    private Matrix f17834w;

    /* renamed from: x  reason: collision with root package name */
    private Bitmap f17835x;

    /* renamed from: y  reason: collision with root package name */
    private Bitmap f17836y;

    /* renamed from: z  reason: collision with root package name */
    private boolean f17837z;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F14View.this.f17837z = false;
            if (F14View.this.A != null) {
                d dVar = F14View.this.A;
                F14View f14View = F14View.this;
                dVar.a(f14View, f14View.B, false);
            }
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            F14View.this.f17837z = false;
        }
    }

    /* loaded from: classes.dex */
    private class c implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

        /* renamed from: a  reason: collision with root package name */
        F14View f17840a;

        public c(F14View f14View) {
            this.f17840a = f14View;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        @SuppressLint({"SuspiciousIndentation"})
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f4, float f5) {
            if (F14View.this.K) {
                this.f17840a.g(-f4, -f5);
                F14View.a();
                return true;
            }
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent motionEvent) {
        }

        @Override // android.view.GestureDetector.OnDoubleTapListener
        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            return true;
        }
    }

    /* loaded from: classes.dex */
    public interface d {
        void a(F14View f14View, int i4, boolean z3);
    }

    public F14View(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17825n = 0;
        this.f17827p = new float[9];
        this.f17837z = false;
        this.C = 0;
        this.H = new Paint();
        this.I = new Paint();
        this.J = 1;
        this.K = true;
    }

    public F14View(Context context, AttributeSet attributeSet, int i4) {
        super(context, attributeSet, i4);
        this.f17825n = 0;
        this.f17827p = new float[9];
        this.f17837z = false;
        this.C = 0;
        this.H = new Paint();
        this.I = new Paint();
        this.J = 1;
        this.K = true;
    }

    public static void a() {
    }

    public void b() {
        Matrix matrix = new Matrix();
        this.f17834w = matrix;
        matrix.postTranslate(0.0f, this.f17832u - this.C);
        this.f17837z = true;
        invalidate();
        new Handler().postDelayed(new b(), 500L);
    }

    public void g(float f4, float f5) {
        this.f17837z = true;
        this.f17834w.postTranslate(0.0f, f5);
        invalidate();
    }

    public void h() {
        setProgress(this.C);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        float width;
        float height;
        float width2;
        float f4;
        Paint paint;
        this.f17834w.getValues(this.f17827p);
        float[] fArr = this.f17827p;
        float f5 = fArr[5];
        this.f17826o = f5;
        if (f5 <= 0.0f) {
            this.f17826o = 0.0f;
            fArr[5] = 0.0f;
            this.f17834w.setValues(fArr);
        }
        float f6 = this.f17826o;
        int i4 = this.f17832u;
        if (f6 >= i4) {
            float f7 = i4;
            this.f17826o = f7;
            float[] fArr2 = this.f17827p;
            fArr2[5] = f7;
            this.f17834w.setValues(fArr2);
        }
        if (this.G == 2) {
            if (this.K) {
                width = getWidth() / 2.0f;
                height = getHeight() - (getHeight() / 12.0f);
                width2 = getWidth() / 2.0f;
                f4 = this.f17826o + (this.J / 2.0f);
                paint = this.H;
            } else {
                width = getWidth() / 2.0f;
                height = getHeight() - (getHeight() / 12.0f);
                width2 = getWidth() / 2.0f;
                f4 = this.f17826o + (this.J / 2.0f);
                paint = this.I;
            }
            canvas.drawLine(width, height, width2, f4, paint);
        }
        canvas.drawBitmap(this.f17835x, this.f17834w, null);
        this.C = this.f17832u - (((int) this.f17826o) / this.f17828q);
        if (this.f17837z) {
            h();
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int i4, int i5, int i6, int i7) {
        Resources resources;
        int i8;
        if (!isInEditMode()) {
            this.G = Integer.parseInt(android.preference.PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext()).getString("teme_preference", "2"));
            this.f17828q = 1;
            Resources resources2 = getResources();
            this.D = resources2.getInteger(R.integer.knob_x);
            this.E = resources2.getInteger(R.integer.knob_y);
            this.F = resources2.getInteger(getResources().getConfiguration().orientation == 2 ? R.integer.visina_y_land : R.integer.visina_y);
            Cfg.viewHeight = (int) TypedValue.applyDimension(1, this.F, getResources().getDisplayMetrics());
            this.f17830s = (int) TypedValue.applyDimension(1, this.D, getResources().getDisplayMetrics());
            this.f17831t = (int) TypedValue.applyDimension(1, this.E, getResources().getDisplayMetrics());
            int applyDimension = (int) TypedValue.applyDimension(1, this.F, getResources().getDisplayMetrics());
            this.f17832u = applyDimension;
            this.f17829r = applyDimension - this.C;
            Matrix matrix = new Matrix();
            this.f17834w = matrix;
            matrix.postTranslate(this.f17825n, this.f17829r);
            this.f17833v = new GestureDetector(getContext(), new c(this));
            int i9 = this.G;
            if (i9 == -1) {
                this.f17836y = BitmapFactory.decodeResource(getResources(), R.drawable.knob);
            } else if (i9 == 0) {
                this.f17836y = BitmapFactory.decodeResource(getResources(), R.drawable.knob_svitla);
                this.f17831t = (int) TypedValue.applyDimension(1, resources2.getInteger(R.integer.knob_y_svitla), getResources().getDisplayMetrics());
            } else if (i9 == 1) {
                this.f17836y = BitmapFactory.decodeResource(getResources(), R.drawable.knob_studio);
                this.f17830s -= (int) TypedValue.applyDimension(1, 4.0f, getResources().getDisplayMetrics());
            } else if (i9 == 2) {
                if (this.K) {
                    resources = getResources();
                    i8 = R.drawable.knob_flat;
                } else {
                    resources = getResources();
                    i8 = R.drawable.knob_flat_disabled;
                }
                this.f17836y = BitmapFactory.decodeResource(resources, i8);
                int applyDimension2 = (int) TypedValue.applyDimension(1, resources2.getInteger(R.integer.knob_y_svitla), getResources().getDisplayMetrics());
                this.f17831t = applyDimension2;
                this.J = applyDimension2;
                this.H.setColor(androidx.core.content.ContextCompat.getColor(getContext(), R.color.flat_zelena));
                this.H.setStrokeWidth(getWidth() / 18.0f);
                this.I.setColor(androidx.core.content.ContextCompat.getColor(getContext(), R.color.siva));
                this.I.setStrokeWidth(getWidth() / 18.0f);
            }
            this.f17835x = Bitmap.createScaledBitmap(this.f17836y, this.f17830s, this.f17831t, true);
        }
        super.onSizeChanged(i4, i5, i6, i7);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            new Handler().postDelayed(new a(), 50L);
        }
        return this.f17833v.onTouchEvent(motionEvent);
    }

    @Override // android.view.View
    public void setEnabled(boolean z3) {
        Resources resources;
        int i4;
        int i5;
        this.K = z3;
        if (z3) {
            resources = getResources();
            i4 = R.drawable.knob_flat;
        } else {
            resources = getResources();
            i4 = R.drawable.knob_flat_disabled;
        }
        this.f17836y = BitmapFactory.decodeResource(resources, i4);
        int i6 = this.f17830s;
        if (i6 > 0 && (i5 = this.f17831t) > 0) {
            this.f17835x = Bitmap.createScaledBitmap(this.f17836y, i6, i5, true);
        }
        invalidate();
    }

    public void setOnSeekBarChangeListener(d dVar) {
        this.A = dVar;
    }

    public void setProgress(int i4) {
        if (this.B != i4) {
            this.B = i4;
            d dVar = this.A;
            if (dVar != null) {
                dVar.a(this, i4, this.f17837z);
            }
            this.C = i4;
        }
    }
}
