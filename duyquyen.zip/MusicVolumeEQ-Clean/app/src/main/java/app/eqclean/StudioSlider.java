package app.eqclean;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Vertical slider, same behaviour as the original F14View / F14View_slider in Studio mode:
 * a track image (slider_studio, slider_studio_press while touched) with a knob bitmap (knob_studio) that follows
 * relative finger movement. progress = pixels above the bottom (0..travel), exactly like the original.
 */
public class StudioSlider extends View {
    public interface Listener { void onChange(StudioSlider s, int progress, boolean fromUser); }

    private final Bitmap track, trackPress, knob;
    private final int viewW, viewH, padH, padV, travel;
    private final boolean crop;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final RectF dst = new RectF();
    private float fprog;
    private int progress;
    private boolean pressed, dragging;
    private float lastY;
    private Listener listener;

    /**
     * @param padH/padV  padding of the track box (dp)
     * @param crop       true = centerCrop (volume slider), false = fitCenter (EQ bands)
     */
    public StudioSlider(Context c, int trackRes, int pressRes, int knobRes,
                        float wDp, float hDp, float padHDp, float padVDp, boolean crop,
                        float knobWDp, float knobHDp, float travelDp) {
        super(c);
        this.viewW = Studio.dp(c, wDp);
        this.viewH = Studio.dp(c, hDp);
        this.padH = Studio.dp(c, padHDp);
        this.padV = Studio.dp(c, padVDp);
        this.crop = crop;
        this.travel = Studio.dp(c, travelDp);
        this.track = BitmapFactory.decodeResource(c.getResources(), trackRes);
        this.trackPress = BitmapFactory.decodeResource(c.getResources(), pressRes);
        Bitmap k = BitmapFactory.decodeResource(c.getResources(), knobRes);
        this.knob = Bitmap.createScaledBitmap(k, Studio.dp(c, knobWDp), Studio.dp(c, knobHDp), true);
    }

    /** EQ band slider: 54x170dp, knob 42x53dp, travel 124dp (bar2_sirina / bar_visina / visina_y). */
    public static StudioSlider band(Context c) {
        return new StudioSlider(c, R.drawable.slider_studio, R.drawable.slider_studio_press, R.drawable.knob_studio,
                54, 170, 10, 0, false, 42, 53, 124);
    }

    /** Volume slider: 66x310dp, knob 65x80dp, travel 236dp (bar_sirina_slider / bar_visina_slider / visina_y_slider). */
    public static StudioSlider volume(Context c) {
        return new StudioSlider(c, R.drawable.slider_studio, R.drawable.slider_studio_press, R.drawable.knob_studio,
                66, 310, 9, 9, true, 65, 80, 236);
    }

    public int getTravel() { return travel; }
    public int getProgress() { return progress; }
    public boolean isDragging() { return dragging; }
    public void setListener(Listener l) { listener = l; }

    /** Programmatic set (does not call the listener). */
    public void setProgress(int p) {
        p = Math.max(0, Math.min(travel, p));
        if (p == progress && Math.abs(fprog - p) < 1f) return;
        progress = p;
        fprog = p;
        invalidate();
    }

    @Override protected void onMeasure(int ws, int hs) { setMeasuredDimension(viewW, viewH); }

    @Override protected void onDraw(Canvas canvas) {
        Bitmap t = pressed ? trackPress : track;
        float bl = padH, bt = padV, br = getWidth() - padH, bb = getHeight() - padV;
        float bw = br - bl, bh = bb - bt;
        float scale = crop ? Math.max(bw / t.getWidth(), bh / t.getHeight())
                           : Math.min(bw / t.getWidth(), bh / t.getHeight());
        float dw = t.getWidth() * scale, dh = t.getHeight() * scale;
        float cx = (bl + br) / 2f, cy = (bt + bb) / 2f;
        dst.set(cx - dw / 2f, cy - dh / 2f, cx + dw / 2f, cy + dh / 2f);
        canvas.save();
        canvas.clipRect(bl, bt, br, bb);
        canvas.drawBitmap(t, null, dst, paint);
        canvas.restore();
        canvas.drawBitmap(knob, (getWidth() - knob.getWidth()) / 2f, travel - progress, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastY = e.getY();
                dragging = true;
                pressed = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (!dragging) return true;
                float dy = e.getY() - lastY;
                lastY = e.getY();
                fprog = Math.max(0f, Math.min(travel, fprog - dy));
                int p = Math.round(fprog);
                if (p != progress) {
                    progress = p;
                    invalidate();
                    if (listener != null) listener.onChange(this, p, true);
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                pressed = false;
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
