package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** "MUSIC VOLUME EQ" drawn with a hand-made 5x7 block font. */
public class PixelTitleView extends View {
    private static final String TEXT = "MUSIC VOLUME EQ";
    private static final String GLYPHS = "MUSICVOLEQ";
    private static final String[][] G = {
            {"10001", "11011", "10101", "10101", "10001", "10001", "10001"},   // M
            {"10001", "10001", "10001", "10001", "10001", "10001", "01110"},   // U
            {"01111", "10000", "10000", "01110", "00001", "00001", "11110"},   // S
            {"11111", "00100", "00100", "00100", "00100", "00100", "11111"},   // I
            {"01110", "10001", "10000", "10000", "10000", "10001", "01110"},   // C
            {"10001", "10001", "10001", "10001", "10001", "01010", "00100"},   // V
            {"01110", "10001", "10001", "10001", "10001", "10001", "01110"},   // O
            {"10000", "10000", "10000", "10000", "10000", "10000", "11111"},   // L
            {"11111", "10000", "10000", "11110", "10000", "10000", "11111"},   // E
            {"01110", "10001", "10001", "10001", "10101", "10010", "01101"}};  // Q
    private final Paint fill = new Paint(), edge = new Paint();
    private final float d;
    public PixelTitleView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        fill.setColor(0xFFD2D2D2);
        edge.setColor(0xFF4A4C4F);
    }
    private int cols() {
        int n = 0;
        for (int i = 0; i < TEXT.length(); i++) n += (TEXT.charAt(i) == ' ' ? 3 : 5) + 1;
        return n - 1;
    }
    @Override protected void onDraw(Canvas c) {
        int total = cols();
        float cw = Math.min(getWidth() / (float) total, 2.4f * d);
        float ch = Math.min(getHeight() / 7f, cw * 0.78f);
        float x0 = (getWidth() - cw * total) / 2f, y0 = (getHeight() - ch * 7) / 2f;
        int col = 0;
        for (int i = 0; i < TEXT.length(); i++) {
            char ch0 = TEXT.charAt(i);
            if (ch0 == ' ') { col += 4; continue; }
            String[] g = G[GLYPHS.indexOf(ch0)];
            for (int r = 0; r < 7; r++)
                for (int k = 0; k < 5; k++)
                    if (g[r].charAt(k) == '1') {
                        float x = x0 + (col + k) * cw, y = y0 + r * ch;
                        c.drawRect(x, y, x + cw, y + ch, edge);
                        c.drawRect(x + cw * 0.12f, y + ch * 0.12f, x + cw * 0.88f, y + ch * 0.88f, fill);
                    }
            col += 6;
        }
    }
}
