package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Dark background with a faint square grid and small crosses at the intersections. */
public class GridBg extends View {
    private final Paint line = new Paint(), dot = new Paint();
    private final float d;
    public GridBg(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        line.setColor(0xFF131517); line.setStrokeWidth(Math.max(1f, d * 0.8f));
        dot.setColor(0xFF1E2124); dot.setStrokeWidth(Math.max(1f, d));
    }
    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF0B0C0D);
        float step = 26f * d;
        for (float x = 0; x < getWidth(); x += step) c.drawLine(x, 0, x, getHeight(), line);
        for (float y = 0; y < getHeight(); y += step) c.drawLine(0, y, getWidth(), y, line);
        float a = 2f * d;
        for (float x = 0; x < getWidth(); x += step)
            for (float y = 0; y < getHeight(); y += step) {
                c.drawLine(x - a, y, x + a, y, dot);
                c.drawLine(x, y - a, x, y + a, dot);
            }
    }
}
