package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Rotary knob 0..max: 270 degree arc, dot marks the value. Grey when inactive. */
public class KnobView extends View {
    public interface Listener { void onChange(int value); }
    private int max = 1000, value = 0;
    private boolean on = false;
    private Listener listener;
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float d;

    public KnobView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        arc.setStyle(Paint.Style.STROKE); arc.setStrokeWidth(3 * d); arc.setStrokeCap(Paint.Cap.ROUND);
        text.setTextSize(14 * d); text.setColor(0xFFCFCFCF);
    }
    public void setup(int max, int value, Listener l) { this.max = max; this.value = value; this.listener = l; invalidate(); }
    public void setActive(boolean a) { on = a; invalidate(); }
    public void setValue(int v) { value = Math.max(0, Math.min(max, v)); invalidate(); }
    public int getValue() { return value; }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float size = Math.min(w, h - 22 * d);
        float cx = w / 2f, r = size / 2f - 10 * d, cy = r + 12 * d;
        oval.set(cx - r, cy - r, cx + r, cy + r);
        arc.setColor(0xFF4A4A4F);
        c.drawArc(oval, 135, 270, false, arc);
        float sweep = 270f * value / max;
        if (on && sweep > 0) { arc.setColor(0xFFA5D6A7); c.drawArc(oval, 135, sweep, false, arc); }
        double a = Math.toRadians(135 + sweep);
        dot.setColor(on ? 0xFFA5D6A7 : 0xFF6B6B70);
        c.drawCircle((float) (cx + r * Math.cos(a)), (float) (cy + r * Math.sin(a)), 8 * d, dot);
        // MIN / MAX under the arc ends
        float ly = cy + r * 0.707f + 22 * d;
        text.setTextAlign(Paint.Align.LEFT);  c.drawText("MIN", cx - r * 0.707f - 18 * d, ly, text);
        text.setTextAlign(Paint.Align.RIGHT); c.drawText("MAX", cx + r * 0.707f + 18 * d, ly, text);
    }

    @Override protected void onMeasure(int ws, int hs) {
        int w = MeasureSpec.getSize(ws);
        setMeasuredDimension(w, (int) (Math.min(w, 150 * d) + 22 * d));
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_CANCEL || a == MotionEvent.ACTION_UP) return true;
        if (a != MotionEvent.ACTION_DOWN && a != MotionEvent.ACTION_MOVE) return false;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        float size = Math.min(getWidth(), getHeight() - 22 * d);
        float cx = getWidth() / 2f, cy = size / 2f + 2 * d;
        double ang = Math.toDegrees(Math.atan2(e.getY() - cy, e.getX() - cx));
        if (ang < 0) ang += 360;
        double rel = ang - 135;
        if (rel < 0) rel += 360;
        if (rel > 270) rel = (rel - 270) < (360 - rel) ? 270 : 0;   // dead zone -> nearest end
        int v = (int) Math.round(rel / 270.0 * max);
        if (v != value) { value = v; invalidate(); if (listener != null) listener.onChange(v); }
        return true;
    }
}
