package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/**
 * Left card: dB scale on the left, black LED panel (20 columns = 10 bands x 2), "VOLUME nn" text and the
 * EQ / BASS / VIRT tabs. In EQ mode touching sets band gain; in BASS / VIRT mode it sets the effect level.
 */
public class LedPanelView extends View {
    public interface Listener { void onMode(int mode); void onBand(int band, float db); void onLevel(int mode, int value); }

    public static final int CYAN = 0xFF5CC8F2;
    static final int[] SCALE = {38, 30, 20, 10, 7, 4, 2, 0, -2, -4, -7, -10, -20, -30, -38};
    static final String[] TABS = {"EQ", "BASS", "VIRT"};
    static final String[] FREQ = {"32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K"};
    static final int ROWS = 56, CENTER = 28, COLS = 20;

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final RectF[] tab = {new RectF(), new RectF(), new RectF()};
    private float labelW, panL, panT, panR, panB, ledL, ledR, ledT, ledB, textCy;
    private int mode = 0, vol = 0, touchBand = -1;
    private boolean lit = true, drag = false;
    private final float[] bands = new float[10];
    private final int[] level = new int[3];
    private Listener l;

    public LedPanelView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    public void setListener(Listener l) { this.l = l; }
    public void setMode(int m) { mode = m; invalidate(); }
    public void setBands(float[] b) { System.arraycopy(b, 0, bands, 0, 10); invalidate(); }
    public void setLevel(int m, int v) { level[m] = v; invalidate(); }
    public void setLit(boolean on) { lit = on; invalidate(); }
    public void setVolume(int v) { if (v != vol) { vol = v; invalidate(); } }

    /** Scale position (0..14, top to bottom) -> value. */
    static float posToVal(float pos) {
        pos = Math.max(0f, Math.min(14f, pos));
        int i = Math.min(13, (int) pos);
        float f = pos - i;
        return SCALE[i] + (SCALE[i + 1] - SCALE[i]) * f;
    }
    /** Value -> scale position. */
    static float valToPos(float v) {
        v = Math.max(-38f, Math.min(38f, v));
        for (int i = 0; i < 14; i++)
            if (v <= SCALE[i] && v >= SCALE[i + 1]) return i + (SCALE[i] - v) / (SCALE[i] - SCALE[i + 1]);
        return 7f;
    }
    static String dbText(float v) {
        int n = Math.round(v);
        return n > 0 ? "+" + n : String.valueOf(n);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        labelW = 45f * d;
        panL = labelW; panT = d; panR = w - d; panB = h - d;
        float pad = 12f * d;
        ledL = panL + pad; ledR = panR - pad; ledT = panT + pad;
        float tabH = 20f * d, tabTop = panB - 6f * d - tabH;
        float textRow = 18f * d, textBottom = tabTop - 4f * d;
        textCy = textBottom - textRow / 2f;
        ledB = textBottom - textRow - 5f * d;
        float gap = 6f * d, tw = (ledR - ledL - 2 * gap) / 3f;
        for (int i = 0; i < 3; i++) tab[i].set(ledL + i * (tw + gap), tabTop, ledL + i * (tw + gap) + tw, tabTop + tabH);
    }

    private float cy(float y, Paint pt) {
        Paint.FontMetrics fm = pt.getFontMetrics();
        return y - (fm.ascent + fm.descent) / 2f;
    }

    @Override protected void onDraw(Canvas c) {
        float ledH = ledB - ledT;
        // --- scale labels
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(14f * d);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(0xFFFFFFFF);
        for (int i = 0; i < 15; i++) {
            String t = mode == 0 ? dbText(SCALE[i]) : String.valueOf(Math.round(100f * (14 - i) / 14f));
            c.drawText(t, labelW - 13f * d, cy(ledT + ledH * i / 14f, p), p);
        }
        // --- panel
        r.set(panL, panT, panR, panB);
        p.setColor(0xFF000000);
        c.drawRoundRect(r, 14f * d, 14f * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f * d); p.setColor(0xFF3B3E42);
        c.drawRoundRect(r, 14f * d, 14f * d, p);
        p.setStyle(Paint.Style.FILL);
        // --- LEDs
        float pitch = ledH / ROWS, segH = pitch * 0.58f;
        float colP = (ledR - ledL) / COLS, colW = colP * 0.72f;
        int onCol = lit ? CYAN : 0xFF3B5561;
        for (int col = 0; col < COLS; col++) {
            float x0 = ledL + col * colP + (colP - colW) / 2f;
            int from, to;
            if (mode == 0) {
                int kv = Math.round(valToPos(bands[col / 2]) * 4f);
                from = Math.min(kv, CENTER); to = Math.max(kv, CENTER);
            } else {
                int v = level[mode];
                from = v <= 0 ? ROWS + 1 : Math.round(ROWS * (1f - v / 1000f)); to = ROWS;
            }
            for (int k = 0; k <= ROWS; k++) {
                float yc = ledT + k * pitch;
                boolean on = k >= from && k <= to;
                p.setColor(on ? onCol : (mode == 0 && k == CENTER ? 0xFF1C2A33 : 0xFF121416));
                c.drawRect(x0, yc - segH / 2f, x0 + colW, yc + segH / 2f, p);
            }
        }
        // --- volume text (right) and band readout (left)
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(15f * d);
        p.setTextAlign(Paint.Align.RIGHT);
        String num = String.format("%02d", vol);
        p.setColor(CYAN);
        c.drawText(num, ledR, cy(textCy, p), p);
        float nw = p.measureText(num + " ");
        p.setColor(0xFFFFFFFF);
        c.drawText("VOLUME", ledR - nw, cy(textCy, p), p);
        if (drag && mode == 0 && touchBand >= 0) {
            p.setTextAlign(Paint.Align.LEFT);
            p.setTextSize(13f * d);
            p.setColor(CYAN);
            c.drawText(FREQ[touchBand] + "  " + dbText(bands[touchBand]), ledL, cy(textCy, p), p);
        }
        // --- tabs
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(15f * d);
        for (int i = 0; i < 3; i++) {
            boolean sel = i == mode;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF050607);
            c.drawRoundRect(tab[i], 2f * d, 2f * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth((sel ? 1.6f : 1.2f) * d);
            p.setColor(sel ? CYAN : 0xFF3A3D40);
            c.drawRoundRect(tab[i], 2f * d, 2f * d, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(sel ? CYAN : 0xFFFFFFFF);
            c.drawText(TABS[i], tab[i].centerX(), cy(tab[i].centerY(), p), p);
        }
    }

    private float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    private void apply(float x, float y) {
        float fy = clamp((y - ledT) / (ledB - ledT), 0f, 1f);
        if (mode == 0) {
            int col = (int) clamp((x - ledL) / (ledR - ledL) * COLS, 0f, COLS - 1);
            int b = col / 2;
            float db = Math.round(posToVal(fy * 14f) * 2f) / 2f;
            bands[b] = db; touchBand = b;
            if (l != null) l.onBand(b, db);
        } else {
            int v = Math.round((1f - fy) * 1000f);
            level[mode] = v;
            if (l != null) l.onLevel(mode, v);
        }
        invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                for (int i = 0; i < 3; i++)
                    if (tab[i].contains(x, y)) { if (l != null) l.onMode(i); return true; }
                if (x < ledL - 6f * d || x > ledR + 6f * d || y < ledT - 8f * d || y > ledB + 8f * d) return false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                drag = true;
                apply(x, y);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (drag) apply(x, y);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                drag = false; touchBand = -1;
                invalidate();
                return true;
        }
        return true;
    }
}
