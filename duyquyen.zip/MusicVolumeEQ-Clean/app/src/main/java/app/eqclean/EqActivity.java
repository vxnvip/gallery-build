package app.eqclean;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Studio equalizer screens (eq_studio = 5 band, eq10_studio = 10 band) rebuilt in code.
 * Rows: [EQ on/off] EQUALIZER [5/10 band] | band panel | [BASS on/off] PRESET [VIRT on/off] | BASS knob, VU, VIRT knob.
 */
public class EqActivity extends Activity {
    private static final int BODY_W = 300;   // dp, width of the centred column
    private static final String[] PKEY = {"prefsEQ60", "prefsEQ230", "prefsEQ910", "prefsEQ3", "prefsEQ14"};
    private static final String[] FREQ5 = {"60 Hz", "230 Hz", "910 Hz", "3 kHz", "14 kHz"};
    private static final String[] NAMES5 = {"Default", "Flat", "Classical", "Dance", "Hiphop", "Latin", "Metal", "Pop", "Rock"};
    private static final int[] RES5 = {R.array.Default_array, R.array.Flat_array, R.array.Classical_array, R.array.Dance_array,
            R.array.Hiphop_array, R.array.Latin_array, R.array.Metal_array, R.array.Pop_array, R.array.Rock_array};
    private static final String[] NAMES10 = {"Flat", "Rock", "Pop", "Bass", "Treble", "Vocal"};
    private static final float[][] BUILTIN10 = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {5, 4, 3, 1, -1, -1, 1, 3, 4, 5},
            {-1, 1, 3, 4, 3, 0, -1, -1, -1, -1},
            {7, 6, 5, 3, 1, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 1, 3, 5, 6, 7},
            {-2, -3, -3, 1, 3, 3, 3, 1, 0, -1}};

    private EqService svc;
    private AudioManager am;
    private SharedPreferences pos, onPrefs, presets;
    private boolean mode10;
    private FrameLayout host;
    private ToggleButton tgEq, tgBass, tgVirt, tgBand10;
    private StudioCurve curve;
    private final StudioSlider[] sl = new StudioSlider[5];
    private final TextView[] vals = new TextView[5];
    private StudioKnob kBass, kVirt;
    private TextView presetTxt;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final Runnable save10 = () -> {
        StringBuilder sb = new StringBuilder();
        for (float f : Cfg.bands10) sb.append(f).append(",");
        getSharedPreferences("eq10_save_prefs", 0).edit().putString("eq10_save_prefs", sb.toString()).apply();
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().setStatusBarColor(Studio.BLACK);
        getWindow().setNavigationBarColor(Studio.BLACK);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        pos = getSharedPreferences("prefsEQPos", 0);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        presets = getSharedPreferences("prefsPresets", 0);
        mode10 = onPrefs.getBoolean("prefsBand10", true);
        load10();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Studio.background(this));

        LinearLayout bar = Studio.toolbar(this);
        IconView back = new IconView(this, IconView.BACK);
        back.setOnClickListener(v -> finish());
        bar.addView(back, 0, new LinearLayout.LayoutParams(Studio.dp(this, 44), Studio.dp(this, 48)));
        Studio.addAction(bar, new IconView(this, IconView.SPEAKER), v -> effectsDialog());
        root.addView(bar);
        root.addView(Studio.shadow(this));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        host = new FrameLayout(this);
        sv.addView(host, new ScrollView.LayoutParams(-1, -1));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        syncServiceMode();
        build();
        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onResume() {
        super.onResume();
        if (tgEq != null) {
            tgEq.setChecked(onPrefs.getBoolean("prefsEQOn1", true));
            tgBass.setChecked(onPrefs.getBoolean("prefsBASSOn1", false));
            tgVirt.setChecked(onPrefs.getBoolean("prefsVIRTOn1", false));
            applyEnabledLook();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        try { unbindService(conn); } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------------ layout
    private int dp(float v) { return Studio.dp(this, v); }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void build() {
        host.removeAllViews();
        Arrays5.clear(sl, vals);
        curve = null;

        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.addView(titleRow(), lp(-1, -2, 0, 3, 0, 0));
        b.addView(mode10 ? curvePanel() : bandsPanel(), lp(-1, -2, 0, 2, 0, 0));
        b.addView(presetRow(), lp(-1, -2, 20, 3, 20, 0));
        b.addView(knobRow(), lp(-1, -2, 20, 3, 20, 6));
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(BODY_W), -2, Gravity.CENTER_HORIZONTAL);
        host.addView(b, fp);

        applyEnabledLook();
        if (mode10) {
            curve.setBands(Cfg.bands10);
        } else {
            initBands5();
        }
    }

    private View titleRow() {
        FrameLayout f = new FrameLayout(this);
        tgEq = Studio.onOff(this);
        tgEq.setChecked(onPrefs.getBoolean("prefsEQOn1", true));
        tgEq.setOnClickListener(v -> {
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_EQ_TOGGLE));
            applyEnabledLook();
        });
        FrameLayout.LayoutParams a = new FrameLayout.LayoutParams(dp(Studio.ONOFF_W), dp(Studio.ONOFF_H), Gravity.START);
        a.leftMargin = dp(mode10 ? 5 : 0);
        f.addView(tgEq, a);

        TextView title = Studio.text(this, "EQUALIZER", Studio.TITLE_TEXT, Studio.WHITE);
        if (mode10) title.setTypeface(Typeface.DEFAULT_BOLD);
        f.addView(title, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        tgBand10 = Studio.band10Switch(this);
        tgBand10.setChecked(mode10);
        tgBand10.setOnClickListener(v -> switchMode(tgBand10.isChecked()));
        FrameLayout.LayoutParams c = new FrameLayout.LayoutParams(dp(Studio.ONOFF_W), dp(Studio.ONOFF_H), Gravity.END);
        c.rightMargin = dp(mode10 ? 5 : 0);
        f.addView(tgBand10, c);
        return f;
    }

    /** eq10_studio: black curve view inside the podlogaeq panel. */
    private View curvePanel() {
        LinearLayout p = new LinearLayout(this);
        p.setBackground(Studio.panel(this, Studio.PANEL));
        p.setPadding(dp(1), dp(1), dp(1), dp(1));
        curve = new StudioCurve(this);
        curve.setBackgroundColor(Studio.BLACK);
        curve.setListener((i, db, user) -> on10(i, db, user));
        p.addView(curve, new LinearLayout.LayoutParams(-1, dp(210)));
        return p;
    }

    /** eq_studio: dB scale + 5 sliders (60 Hz, 230 Hz, 910 Hz, 3 kHz, 14 kHz). */
    private View bandsPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.HORIZONTAL);
        p.setGravity(Gravity.CENTER);
        p.setBackground(Studio.panel(this, Studio.PANEL));
        p.setPadding(dp(1), dp(1), dp(1), dp(1));

        LinearLayout sc = Studio.scale(this, new String[]{"+15", " 0", "-15"}, new float[]{0.3f, 0.4f, 0.3f}, 20, 20);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -1);
        sp.leftMargin = dp(1);
        p.addView(sc, sp);

        for (int i = 0; i < 5; i++) {
            final int idx = i;
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);

            TextView f = Studio.text(this, FREQ5[i], Studio.EQBAR_TEXT, Studio.WHITE);
            f.setGravity(Gravity.CENTER);
            col.addView(f, new LinearLayout.LayoutParams(-2, dp(20)));

            sl[i] = StudioSlider.band(this);
            sl[i].setListener((s, prog, user) -> onBand5(idx, prog, user));
            col.addView(sl[i], new LinearLayout.LayoutParams(dp(54), dp(170)));

            vals[i] = Studio.text(this, "", Studio.EQ_TEXT, Studio.CYAN);
            vals[i].setGravity(Gravity.CENTER);
            vals[i].setSingleLine(true);
            col.addView(vals[i], new LinearLayout.LayoutParams(-2, dp(20)));
            p.addView(col, new LinearLayout.LayoutParams(-2, -2));
        }
        return p;
    }

    private View presetRow() {
        FrameLayout f = new FrameLayout(this);
        tgBass = Studio.onOff(this);
        tgBass.setChecked(onPrefs.getBoolean("prefsBASSOn1", false));
        tgBass.setOnClickListener(v -> {
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_BASS_TOGGLE));
            applyEnabledLook();
        });
        f.addView(tgBass, new FrameLayout.LayoutParams(dp(Studio.ONOFF_W), dp(Studio.ONOFF_H), Gravity.BOTTOM | Gravity.START));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        mid.addView(Studio.text(this, "PRESET", Studio.TITLE_TEXT, Studio.WHITE),
                new LinearLayout.LayoutParams(-2, -2));
        presetTxt = Studio.text(this, pos.getString("PresetName", "Custom"), Studio.EQBAR_TEXT, Studio.CYAN);
        presetTxt.setGravity(Gravity.CENTER);
        presetTxt.setSingleLine(true);
        presetTxt.setEllipsize(android.text.TextUtils.TruncateAt.END);
        presetTxt.setBackground(Studio.presetBox(this));
        presetTxt.setOnClickListener(v -> presetDialog());
        mid.addView(presetTxt, new LinearLayout.LayoutParams(dp(Studio.PRESET_W), dp(Studio.PRESET_H)));
        f.addView(mid, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        tgVirt = Studio.onOff(this);
        tgVirt.setChecked(onPrefs.getBoolean("prefsVIRTOn1", false));
        tgVirt.setOnClickListener(v -> {
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_VIRT_TOGGLE));
            applyEnabledLook();
        });
        f.addView(tgVirt, new FrameLayout.LayoutParams(dp(Studio.ONOFF_W), dp(Studio.ONOFF_H), Gravity.BOTTOM | Gravity.END));
        return f;
    }

    private View knobRow() {
        FrameLayout f = new FrameLayout(this);

        kBass = new StudioKnob(this);
        kBass.setProgress(pos.getInt("BassLevel", 0));
        kBass.setListener((p, user) -> {
            pos.edit().putInt("BassLevel", p).apply();
            if (svc != null) svc.setBass(p); else EqService.bassLevel = p;
        });
        f.addView(knobColumn(kBass, "BASS BOOST"), new FrameLayout.LayoutParams(-2, -2, Gravity.START));

        View vu = Studio.imageButton(this, R.drawable.botunvu_full_studio, R.drawable.botunvu_full_press_studio);
        vu.setOnClickListener(v -> vuDialog());
        f.addView(vu, new FrameLayout.LayoutParams(dp(Studio.FWDREV2), dp(Studio.FWDREV2), Gravity.CENTER));

        kVirt = new StudioKnob(this);
        kVirt.setProgress(pos.getInt("VirtLevel", 0));
        kVirt.setListener((p, user) -> {
            pos.edit().putInt("VirtLevel", p).apply();
            if (svc != null) svc.setVirt(p); else EqService.virtLevel = p;
        });
        f.addView(knobColumn(kVirt, "VIRTUALIZER"), new FrameLayout.LayoutParams(-2, -2, Gravity.END));
        return f;
    }

    private View knobColumn(StudioKnob k, String label) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(k, new LinearLayout.LayoutParams(dp(Studio.WHEEL), dp(Studio.WHEEL)));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.topMargin = dp(Studio.EQ_MARGIN_TOP);
        c.addView(Studio.text(this, label, Studio.TITLE_TEXT, Studio.WHITE), tp);
        return c;
    }

    /** dims things the way the original did for switched-off sections. */
    private void applyEnabledLook() {
        boolean eqOn = tgEq.isChecked();
        if (curve != null) curve.setActive(eqOn);
        for (StudioSlider s : sl) if (s != null) s.setAlpha(eqOn ? 1f : 0.4f);
        if (kBass != null) kBass.setActive(tgBass.isChecked());
        if (kVirt != null) kVirt.setActive(tgVirt.isChecked());
    }

    // ------------------------------------------------------------------ 10 band
    private void load10() {
        String saved = getSharedPreferences("eq10_save_prefs", 0).getString("eq10_save_prefs", "");
        if (saved.isEmpty()) return;
        String[] sp = saved.split(",");
        for (int i = 0; i < 10 && i < sp.length; i++) try { Cfg.bands10[i] = Float.parseFloat(sp[i]); } catch (Exception ignored) {}
    }

    private void on10(int i, float db, boolean user) {
        Cfg.bands10[i] = db;
        if (tgEq.isChecked() && svc != null) svc.dpEqApply(Cfg.bands10);
        ui.removeCallbacks(save10);
        ui.postDelayed(save10, 300);
        if (user) markCustom();
    }

    // ------------------------------------------------------------------ 5 band
    private int[] levelRange() {
        int mn = EqService.minLevel, mx = EqService.maxLevel;
        if (mx - mn == 0) { mn = -1500; mx = 1500; }
        return new int[]{mn, mx};
    }

    private float posToDb(int p, int travel) {
        int[] r = levelRange();
        return (p * (float) (r[1] - r[0]) / travel + r[0]) / 100f;
    }

    private int dbToPos(float db, int travel) {
        int[] r = levelRange();
        int p = Math.round((db * 100f - r[0]) / (float) (r[1] - r[0]) * travel);
        return Math.max(0, Math.min(travel, p));
    }

    private static String dbText(float db) {
        int v = Math.max(-15, Math.min(15, Math.round(db)));
        return v > 0 ? "+" + v : String.valueOf(v);
    }

    private static void setStatic(int band, int p) {
        switch (band) {
            case 0: EqService.pos60 = p; break;
            case 1: EqService.pos230 = p; break;
            case 2: EqService.pos910 = p; break;
            case 3: EqService.pos3k = p; break;
            default: EqService.pos14k = p;
        }
    }

    private void initBands5() {
        int travel = sl[0].getTravel();
        Cfg.viewHeight = travel;                        // original F14View does the same: scale = range / travel(px)
        for (int i = 0; i < 5; i++) {
            int p = Math.max(0, Math.min(travel, pos.getInt(PKEY[i], travel / 2)));
            sl[i].setProgress(p);
            setStatic(i, p);
            vals[i].setText(dbText(posToDb(p, travel)));
        }
        // the Equalizer effect is (re)created asynchronously by the service, so push the stored values a bit later
        ui.postDelayed(() -> {
            if (mode10 || sl[0] == null) return;
            for (int i = 0; i < 5; i++) {
                EqService.setBand(i, sl[i].getProgress());
                vals[i].setText(dbText(posToDb(sl[i].getProgress(), sl[i].getTravel())));
            }
        }, 400);
    }

    private void onBand5(int i, int p, boolean user) {
        setStatic(i, p);
        EqService.setBand(i, p);
        vals[i].setText(dbText(posToDb(p, sl[i].getTravel())));
        if (user) {
            pos.edit().putInt(PKEY[i], p).apply();
            markCustom();
        }
    }

    private void syncServiceMode() {
        if (mode10 == Cfg.tenBand) return;
        startService(new Intent(this, EqService.class)
                .setAction(mode10 ? EqService.ACTION_SET_EQ10 : EqService.ACTION_RELAISE_EQ10));
    }

    private void switchMode(boolean ten) {
        mode10 = ten;
        onPrefs.edit().putBoolean("prefsBand10", ten).apply();
        startService(new Intent(this, EqService.class)
                .setAction(ten ? EqService.ACTION_SET_EQ10 : EqService.ACTION_RELAISE_EQ10));
        build();
    }

    // ------------------------------------------------------------------ presets
    private void markCustom() {
        if (!"Custom".equals(presetTxt.getText().toString())) setPresetName("Custom");
    }

    private void setPresetName(String n) {
        presetTxt.setText(n);
        pos.edit().putString("PresetName", n).apply();
    }

    private String userPrefix() { return mode10 ? "u10_" : "u5_"; }

    private void applyPreset(float[] db) {
        if (mode10) {
            for (int i = 0; i < 10 && i < db.length; i++) {
                curve.setBand(i, db[i]);
                Cfg.bands10[i] = curve.getBand(i);
            }
            if (tgEq.isChecked() && svc != null) svc.dpEqApply(Cfg.bands10);
            ui.removeCallbacks(save10);
            ui.postDelayed(save10, 300);
        } else {
            for (int i = 0; i < 5 && i < db.length; i++) {
                int p = dbToPos(db[i], sl[i].getTravel());
                sl[i].setProgress(p);
                onBand5(i, p, true);
            }
        }
    }

    private float[] currentDb() {
        if (mode10) return curve.getBands();
        float[] v = new float[5];
        for (int i = 0; i < 5; i++) v[i] = posToDb(sl[i].getProgress(), sl[i].getTravel());
        return v;
    }

    private void presetDialog() {
        final List<String> names = new ArrayList<>();
        final List<float[]> data = new ArrayList<>();
        final List<String> keys = new ArrayList<>();            // non-null for user presets (deletable)
        if (mode10) {
            for (int i = 0; i < NAMES10.length; i++) { names.add(NAMES10[i]); data.add(BUILTIN10[i]); keys.add(null); }
        } else {
            for (int i = 0; i < NAMES5.length; i++) {
                int[] a = getResources().getIntArray(RES5[i]);
                float[] f = new float[a.length];
                for (int j = 0; j < a.length; j++) f[j] = a[j];
                names.add(NAMES5[i]); data.add(f); keys.add(null);
            }
        }
        for (Map.Entry<String, ?> e : presets.getAll().entrySet()) {
            if (!e.getKey().startsWith(userPrefix())) continue;
            try {
                String[] sp = String.valueOf(e.getValue()).split(",");
                float[] f = new float[sp.length];
                for (int i = 0; i < sp.length; i++) f[i] = Float.parseFloat(sp[i].trim());
                names.add(e.getKey().substring(userPrefix().length())); data.add(f); keys.add(e.getKey());
            } catch (Exception ignored) {}
        }
        names.add("+ Save current...");
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Preset")
                .setItems(names.toArray(new String[0]), (dd, which) -> {
                    if (which == names.size() - 1) { saveDialog(); return; }
                    applyPreset(data.get(which));
                    setPresetName(names.get(which));
                }).create();
        dlg.show();
        dlg.getListView().setOnItemLongClickListener((p, v, which, id) -> {
            if (which < keys.size() && keys.get(which) != null) {
                presets.edit().remove(keys.get(which)).apply();
                Toast.makeText(this, "Deleted " + names.get(which), Toast.LENGTH_SHORT).show();
                dlg.dismiss();
                return true;
            }
            return false;
        });
    }

    private void saveDialog() {
        final EditText in = new EditText(this);
        in.setSingleLine(true);
        in.setHint("Preset name");
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Save preset").setView(in)
                .setPositiveButton("Save", (dd, w) -> {
                    String n = in.getText().toString().trim().replace(",", " ");
                    if (n.isEmpty()) return;
                    StringBuilder sb = new StringBuilder();
                    for (float v : currentDb()) sb.append(v).append(",");
                    presets.edit().putString(userPrefix() + n, sb.toString()).apply();
                    setPresetName(n);
                })
                .setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ speaker icon: volume, lock, effects dialogs
    private void effectsDialog() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(20), dp(12), dp(20), dp(4));
        final TextView t = Studio.text(this, "", 18, Color.WHITE);
        SeekBar bar = new SeekBar(this);
        bar.setMax(am.getStreamMaxVolume(3));
        bar.setProgress(am.getStreamVolume(3));
        t.setText("VOLUME " + bar.getProgress());
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                am.setStreamVolume(3, p, 0);
                t.setText("VOLUME " + p);
                if (EqService.volumeLock) EqService.lockedVolume = p;
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        CheckBox lock = new CheckBox(this);
        lock.setText("Lock volume");
        lock.setTextColor(Color.WHITE);
        lock.setChecked(EqService.volumeLock);
        lock.setOnCheckedChangeListener((b, on) -> { if (svc != null) svc.setVolumeLock(on); });
        c.addView(t);
        c.addView(bar);
        c.addView(lock);
        Dialogs.Svc g = () -> svc;
        c.addView(menuButton("Preamp & Loudness", () -> Dialogs.preampLoudness(this, g)));
        c.addView(menuButton("Balance", () -> Dialogs.balance(this, g)));
        c.addView(menuButton("Limiter", () -> Dialogs.limiter(this, g)));
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setView(c).setPositiveButton("OK", null).show();
    }

    private Button menuButton(String text, Runnable r) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Studio.CYAN);
        b.setBackground(Studio.panel(this, 0xFF2A2A2C));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
        p.topMargin = dp(8);
        b.setLayoutParams(p);
        return b;
    }

    // ------------------------------------------------------------------ VU (Visualizer peak/RMS on the output mix)
    private void vuDialog() {
        final VuView vu = new VuView(this);
        vu.setPadding(dp(20), dp(8), dp(20), dp(8));
        Visualizer vis = null;
        try {
            vis = new Visualizer(Cfg.session);
            vis.setMeasurementMode(Visualizer.MEASUREMENT_MODE_PEAK_RMS);
            vis.setEnabled(true);
        } catch (Throwable e) {
            Toast.makeText(this, "VU needs the microphone permission (RECORD_AUDIO)", Toast.LENGTH_LONG).show();
            if (vis != null) try { vis.release(); } catch (Exception ignored) {}
            return;
        }
        final Visualizer v = vis;
        final Visualizer.MeasurementPeakRms m = new Visualizer.MeasurementPeakRms();
        final Runnable poll = new Runnable() {
            @Override public void run() {
                try {
                    v.getMeasurementPeakRms(m);
                    vu.set(clamp01((m.mPeak + 6000f) / 6000f), clamp01((m.mRms + 6000f) / 6000f));
                } catch (Exception ignored) {}
                ui.postDelayed(this, 50);
            }
        };
        ui.post(poll);
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle("VU").setView(vu)
                .setPositiveButton("Close", null).create();
        dlg.setOnDismissListener(x -> { ui.removeCallbacks(poll); try { v.setEnabled(false); v.release(); } catch (Exception ignored) {} });
        dlg.show();
    }

    private static float clamp01(float f) { return Math.max(0f, Math.min(1f, f)); }

    /** small helper: forget the old views when the layout is rebuilt. */
    private static final class Arrays5 {
        static void clear(StudioSlider[] s, TextView[] v) {
            for (int i = 0; i < s.length; i++) { s[i] = null; v[i] = null; }
        }
    }
}
