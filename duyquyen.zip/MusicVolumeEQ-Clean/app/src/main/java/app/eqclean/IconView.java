package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Tiny vector icons for the header: back arrow and speaker. */
public class IconView extends View {
    public static final int BACK = 0, SPEAKER = 1;
    private final int type;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public IconView(Context c, int type) {
        super(c);
        this.type = type;
        d = c.getResources().getDisplayMetrics().density;
        p.setColor(0xFFEDEDED); p.setStrokeWidth(2.6f * d); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, u = 11 * d;
        p.setStyle(Paint.Style.STROKE);
        if (type == BACK) {
            c.drawLine(cx - u, cy, cx + u, cy, p);
            c.drawLine(cx - u, cy, cx - u * 0.1f, cy - u * 0.9f, p);
            c.drawLine(cx - u, cy, cx - u * 0.1f, cy + u * 0.9f, p);
        } else {
            p.setStyle(Paint.Style.FILL);
            Path s = new Path();
            s.moveTo(cx - u, cy - u * 0.4f); s.lineTo(cx - u * 0.4f, cy - u * 0.4f);
            s.lineTo(cx + u * 0.3f, cy - u); s.lineTo(cx + u * 0.3f, cy + u);
            s.lineTo(cx - u * 0.4f, cy + u * 0.4f); s.lineTo(cx - u, cy + u * 0.4f); s.close();
            c.drawPath(s, p);
            p.setStyle(Paint.Style.STROKE);
            c.drawArc(cx - u * 0.2f, cy - u * 0.6f, cx + u * 0.9f, cy + u * 0.6f, -55, 110, false, p);
            c.drawArc(cx - u * 0.2f, cy - u * 1.0f, cx + u * 1.4f, cy + u * 1.0f, -55, 110, false, p);
        }
    }
}
