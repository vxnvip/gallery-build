package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Header icons drawn by hand: hamburger, fullscreen brackets, vertical dots. */
public class IconView extends View {
    public static final int MENU = 0, FULLSCREEN = 1, DOTS = 2;
    private final int type;
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    public IconView(Context c, int type) {
        super(c);
        this.type = type;
        d = c.getResources().getDisplayMetrics().density;
        p.setColor(0xFFFFFFFF);
    }
    @Override protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        p.setStyle(Paint.Style.FILL);
        if (type == MENU) {
            float w = 19f * d, h = 2.4f * d, gap = 6.6f * d;
            for (int i = -1; i <= 1; i++) c.drawRect(cx - w / 2, cy + i * gap - h / 2, cx + w / 2, cy + i * gap + h / 2, p);
        } else if (type == DOTS) {
            float r = 2.2f * d;
            for (int i = -1; i <= 1; i++) c.drawCircle(cx, cy + i * 6.4f * d, r, p);
        } else {
            float s = 9.5f * d, l = 6f * d, t = 2.4f * d;
            for (int sx = -1; sx <= 1; sx += 2)
                for (int sy = -1; sy <= 1; sy += 2) {
                    float x = cx + sx * s, y = cy + sy * s;
                    float hx0 = sx < 0 ? x - t / 2 : x - l + t / 2, hx1 = sx < 0 ? x + l - t / 2 : x + t / 2;
                    float vy0 = sy < 0 ? y - t / 2 : y - l + t / 2, vy1 = sy < 0 ? y + l - t / 2 : y + t / 2;
                    c.drawRect(hx0, y - t / 2, hx1, y + t / 2, p);
                    c.drawRect(x - t / 2, vy0, x + t / 2, vy1, p);
                }
        }
    }
}
