package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Segmented spectrum bars (green at the bottom fading to white at the top), fed from Visualizer FFT data. */
public class SpectrumView extends View {
    public static final int BARS = 24, ROWS = 44;
    private final float[] levels = new float[BARS];
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public SpectrumView(Context c) { super(c); d = c.getResources().getDisplayMetrics().density; }

    /** Called from the Visualizer capture thread. fft = Visualizer FFT bytes, sr = sampling rate in milliHertz. */
    public void pushFft(byte[] fft, int sr) {
        int n = fft.length;
        float binHz = (sr / 1000f) / n;
        if (binHz <= 0) return;
        float maxHz = Math.min(16000f, sr / 2000f);
        for (int b = 0; b < BARS; b++) {
            float lo = 40f * (float) Math.pow(maxHz / 40f, (float) b / BARS);
            float hi = 40f * (float) Math.pow(maxHz / 40f, (float) (b + 1) / BARS);
            int k0 = Math.max(1, Math.round(lo / binHz)), k1 = Math.max(k0 + 1, Math.round(hi / binHz));
            float mag = 0;
            for (int k = k0; k < k1 && 2 * k + 1 < n; k++) mag = Math.max(mag, (float) Math.hypot(fft[2 * k], fft[2 * k + 1]));
            float db = 20f * (float) Math.log10(mag + 1f);
            float v = Math.max(0f, Math.min(1f, (db - 4f) / 38f));
            levels[b] = v > levels[b] ? v : levels[b] * 0.88f + v * 0.12f;
        }
        postInvalidate();
    }

    /** Let bars fall when no audio data is coming. */
    public void decay() {
        boolean any = false;
        for (int i = 0; i < BARS; i++) { levels[i] *= 0.85f; if (levels[i] > 0.003f) any = true; else levels[i] = 0; }
        if (any) postInvalidate();
    }

    private static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float padX = 14 * d, padT = 4 * d, padB = 4 * d;
        float gap = 1.6f * d;
        float bw = (w - 2 * padX) / BARS;
        float rh = (h - padT - padB) / ROWS;
        for (int b = 0; b < BARS; b++) {
            int lit = Math.round(levels[b] * ROWS);
            float x0 = padX + b * bw + gap / 2f, x1 = padX + (b + 1) * bw - gap / 2f;
            for (int r = 0; r < lit; r++) {
                float frac = (float) r / ROWS;
                p.setColor(lerp(0xFFA5D6A7, 0xFFFFFFFF, Math.max(0f, Math.min(1f, (frac - 0.45f) / 0.4f))));
                float yb = h - padB - r * rh;
                c.drawRect(x0, yb - rh + 1f, x1, yb, p);
            }
        }
    }
}
