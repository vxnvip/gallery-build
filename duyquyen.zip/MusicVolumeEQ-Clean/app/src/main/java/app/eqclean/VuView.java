package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Two segmented bars (PEAK / RMS), values 0..1. */
public class VuView extends View {
    private float peak, rms;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    public VuView(Context c) { super(c); d = c.getResources().getDisplayMetrics().density; p.setTextSize(13 * d); }
    public void set(float peak, float rms) { this.peak = peak; this.rms = rms; invalidate(); }

    @Override protected void onMeasure(int ws, int hs) { setMeasuredDimension(MeasureSpec.getSize(ws), (int) (90 * d)); }

    private void bar(Canvas c, String name, float v, float y) {
        int segs = 24;
        float x0 = 46 * d, sw = (getWidth() - x0) / segs, h = 22 * d;
        p.setColor(0xFFB0B0B0); p.setStyle(Paint.Style.FILL);
        c.drawText(name, 0, y + h * 0.75f, p);
        for (int i = 0; i < segs; i++) {
            boolean lit = i < Math.round(v * segs);
            int col = i > segs * 0.85f ? 0xFFEF5350 : (i > segs * 0.65f ? 0xFFFFCA28 : 0xFFA5D6A7);
            p.setColor(lit ? col : 0xFF333336);
            c.drawRect(x0 + i * sw + 1.5f * d, y, x0 + (i + 1) * sw - 1.5f * d, y + h, p);
        }
    }
    @Override protected void onDraw(Canvas c) { bar(c, "PEAK", peak, 6 * d); bar(c, "RMS", rms, 46 * d); }
}
