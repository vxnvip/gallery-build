package app.eqclean;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.audiofx.BassBoost;
import android.media.audiofx.DynamicsProcessing;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.Virtualizer;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Audio engine. Ported from hr.podlanica.MusicVolumeEQ (v7.0).
 * 1:1 = same effects, same math, same prefs keys. Parts marked [RECONSTRUCTED] / [INFERRED]
 * were NOT recoverable from the decompile (see README).
 */
@SuppressLint("NewApi")
public class EqService extends Service {
    public static final String ACTION_EQ_TOGGLE = "hr.podlanica.action.ACTION_EQ_TOGGLE";
    public static final String ACTION_BASS_TOGGLE = "hr.podlanica.action.ACTION_BASS_TOGGLE";
    public static final String ACTION_VIRT_TOGGLE = "hr.podlanica.action.ACTION_VIRT_TOGGLE";
    public static final String ACTION_SET_EQ10 = "hr.podlanica.action.ACTION_SET_EQ10";
    public static final String ACTION_RELAISE_EQ10 = "hr.podlanica.action.ACTION_RELAISE_EQ10";
    static final int[] DP_CUTOFFS = {32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000}; // f17981z

    public static volatile boolean running = false;
    // effects (U, V, W)
    public static Equalizer eq;
    public static BassBoost bass;
    public static Virtualizer virt;
    // flags (X, Y, Z)
    public static boolean eqOn, bassOn, virtOn;
    // 5-band slider positions (f17960a0 .. f17964e0): 60Hz=band0, 230=band1, 910=band2, 3k=band3, 14k=band4
    public static int pos60, pos230, pos910, pos3k, pos14k;
    public static int bassLevel, virtLevel;            // f17965f0, f17966g0 (0..1000)
    public static short minLevel, maxLevel;            // f17967h0, f17968i0

    private DynamicsProcessing dp;
    private DynamicsProcessing.Limiter limiter;
    private DynamicsProcessing.Mbc mbc;
    private DynamicsProcessing.Eq dpEq;
    private LoudnessEnhancer loudnessEnhancer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;
    private AudioManager audioManager;
    private AudioDeviceCallback deviceCallback;
    private AudioSessionReceiver sessionReceiver;
    private String deviceType = Cfg.DEVICE_KEYS[0];
    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder { public EqService get() { return EqService.this; } }

    public static void start(Context c) {
        Intent i = new Intent(c, EqService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    // ---------- effect creation (J, K, M) ----------
    private static Equalizer ensureEq() {
        if (eq == null) { eq = new Equalizer(Cfg.PRIORITY, Cfg.session); eq.setEnabled(true); }
        return eq;
    }
    public static synchronized BassBoost ensureBass() {
        if (bass == null) { bass = new BassBoost(Cfg.PRIORITY, Cfg.session); bass.setEnabled(true); }
        return bass;
    }
    public static synchronized Virtualizer ensureVirt() {
        if (virt == null) { virt = new Virtualizer(Cfg.PRIORITY, Cfg.session); virt.setEnabled(true); }
        return virt;
    }
    public static void eqStart() { try { ensureEq(); minLevel = eq.getBandLevelRange()[0]; maxLevel = eq.getBandLevelRange()[1]; } catch (Exception ignored) {} } // s()
    public static void eqRelease() { if (eq != null) { eq.setEnabled(false); eq.release(); eq = null; } }                    // r()
    public static void bassStart() { try { ensureBass(); } catch (Exception ignored) {} }                                    // f()
    public static void bassRelease() { if (bass != null) { bass.setEnabled(false); bass.release(); bass = null; } }          // e()
    public static void virtStart() { try { ensureVirt(); } catch (Exception ignored) {} }                                    // y()
    public static void virtRelease() { if (virt != null) { virt.setEnabled(false); virt.release(); virt = null; } }          // x()

    // ---------- 5-band (i,k,m,o,q + h,j,l,n,p) ----------
    /** scaled = pos * (range / viewHeight); level = scaled + min, clamped to max-1. Identical math to original. */
    public static void setBand(int band, int pos) {
        if (!eqOn) return;
        int range = maxLevel - minLevel;
        if (range == 0) range = 3000;
        double scaled = pos * ((double) range / Cfg.viewHeight);
        double level = scaled + minLevel;
        if (level >= maxLevel) level = maxLevel - 1;
        try { eq.setBandLevel((short) band, (short) level); } catch (Exception ignored) {}
    }
    /** dB label shown in original UI: (scaled+min)/95, capped at 15, "+" prefix when > 0. */
    public static String bandLabel(int pos) {
        int range = maxLevel - minLevel;
        if (range == 0) range = 3000;
        double scaled = pos * ((double) range / Cfg.viewHeight);
        int v = (((int) scaled) + minLevel) / 95;
        if (v > 15) v = 15;
        return v > 0 ? "+" + v : String.valueOf(v);
    }
    public void set60(int p)  { pos60 = p;  setBand(0, p); }
    public void set230(int p) { pos230 = p; setBand(1, p); }
    public void set910(int p) { pos910 = p; setBand(2, p); }
    public void set3k(int p)  { pos3k = p;  setBand(3, p); }
    public void set14k(int p) { pos14k = p; setBand(4, p); }

    public void setBass(int v) { bassLevel = v; if (bassOn) try { bass.setStrength((short) v); } catch (Exception ignored) {} }  // g()
    public void setVirt(int v) { virtLevel = v; if (virtOn) try { virt.setStrength((short) v); } catch (Exception ignored) {} } // z()

    // ---------- loudness (L, t, u, v) ----------
    public synchronized LoudnessEnhancer loudness() {
        if (loudnessEnhancer == null && Cfg.loudness > 0) {
            loudnessEnhancer = new LoudnessEnhancer(Cfg.session);
            loudnessEnhancer.setEnabled(true);
        }
        return loudnessEnhancer;
    }
    public void setLoudness(int mB) {                       // t(i)
        if (loudnessEnhancer == null) { try { loudness(); } catch (Exception ignored) {} }
        try {
            if (loudnessEnhancer != null) loudnessEnhancer.setTargetGain(mB); else Cfg.loudness = 0;
        } catch (Exception e) { System.out.println("GOTCHA EX " + e); }
    }
    public void loudnessOff() {                              // u()
        if (loudnessEnhancer != null) { loudnessEnhancer.setEnabled(false); loudnessEnhancer.release(); loudnessEnhancer = null; }
    }
    public void loudnessOn() { try { loudness(); } catch (Exception ignored) {} }   // v()

    // ---------- DynamicsProcessing (O, P, U, Y, Z, a0, c0, d0) ----------
    private void dpInit() {                                  // O()
        if (Build.VERSION.SDK_INT < 28 || dp != null) return;
        try {
            DynamicsProcessing.Config.Builder b = new DynamicsProcessing.Config.Builder(0, 2, true, 10, true, 10, false, 10, true);
            b.setPreferredFrameDuration(10.0f);
            DynamicsProcessing.Config cfg = b.build();
            if (limiter == null) limiter = new DynamicsProcessing.Limiter(Cfg.limEnabled, Cfg.limInUse, Cfg.limLinkGroup,
                    Cfg.limAttack, Cfg.limRelease, Cfg.limRatio, Cfg.limThreshold, Cfg.limPostGain);
            if (!limiter.isEnabled()) limiter.setEnabled(true);
            if (dp == null) dp = new DynamicsProcessing(Integer.MAX_VALUE, Cfg.session, cfg);
            if (!dp.getEnabled()) dp.setEnabled(true);
        } catch (Exception e) { System.out.println(e.getMessage()); }
        try { dp.setLimiterAllChannelsTo(limiter); } catch (Exception e) { System.out.println(e.getMessage()); }
    }
    private void dpEqInit() {                                // P()
        if (dpEq == null && Build.VERSION.SDK_INT >= 28 && Cfg.tenBand) {
            dpEq = new DynamicsProcessing.Eq(true, true, Cfg.DP_BANDS);
            dpEq.setEnabled(true);
            for (int i = 0; i < Cfg.DP_BANDS; i++) {
                try { dpEq.getBand(i).setCutoffFrequency(DP_CUTOFFS[i]); } catch (Exception e) { e.printStackTrace(); }
            }
            dpEqApply(Cfg.bands10);
        }
    }
    public void dpEqApply(float[] gains) {                   // a0()
        if (Build.VERSION.SDK_INT < 28 || !Cfg.tenBand) return;
        if (dpEq == null) dpEqInit();
        if (dp == null) dpInit();
        if (dpEq == null || dp == null) return;
        for (int i = 0; i < Cfg.DP_BANDS; i++) {
            try {
                DynamicsProcessing.EqBand band = dpEq.getBand(i);
                band.setEnabled(true);
                band.setGain(gains[i]);
                dp.setPreEqBandAllChannelsTo(i, band);
            } catch (UnsupportedOperationException e) { e.printStackTrace(); return; }
        }
    }
    private void dpRelease() {                               // U()
        try {
            if (dp != null) { dp.setEnabled(false); dp.release(); dp = null; }
            if (limiter != null) { limiter.setEnabled(false); limiter = null; }
        } catch (Exception ignored) {}
    }
    public void applyBalance() {                             // Y()
        if (Build.VERSION.SDK_INT < 28) return;
        if (dp == null) dpInit();
        float f5 = Cfg.balance, left = 0f, right = 0f;
        if (f5 > 50f) left = -(f5 - 50f); else if (f5 < 50f) right = -(50f - f5);
        try { dp.setInputGainbyChannel(0, left); dp.setInputGainbyChannel(1, right); } catch (Exception e) { System.out.println(e.getMessage()); }
    }
    public void applyPreamp() {                              // d0()
        if (dp == null) dpInit();
        int i = Cfg.preamp;
        try { dp.setInputGainAllChannelsTo(i < 20 ? 0.0f - (20.0f - i) : 0.0f + (20.0f - (40.0f - i))); } catch (Exception e) { e.printStackTrace(); }
    }
    public void applyLimiter() {                             // c0()
        if (Build.VERSION.SDK_INT < 28) return;
        if (dp == null) dpInit();
        try {
            if (limiter == null) limiter = new DynamicsProcessing.Limiter(Cfg.limEnabled, Cfg.limInUse, Cfg.limLinkGroup,
                    Cfg.limAttack, Cfg.limRelease, Cfg.limRatio, Cfg.limThreshold, Cfg.limPostGain);
            if (!limiter.isEnabled()) { limiter.setEnabled(true); if (!dp.getEnabled()) { dp.setEnabled(true); dp.setLimiterAllChannelsTo(limiter); } }
        } catch (Exception e) { System.out.println(e.getMessage()); }
        try {
            if (limiter == null || !limiter.isEnabled()) return;
            limiter.setAttackTime(Cfg.limAttack);
            limiter.setReleaseTime(Cfg.limRelease);
            limiter.setRatio(Cfg.limRatio);
            limiter.setThreshold(Cfg.limThreshold);
            limiter.setPostGain(Cfg.limPostGain);
            dp.setLimiterAllChannelsTo(limiter);
        } catch (Exception e) { System.out.println(e.getMessage()); }
    }
    /** Z() - MBC setup. [INFERRED] setter order: Android API wrapper bodies were stripped by the decompiler. Original never calls it from recoverable code. */
    public void setupMbc() {
        if (Build.VERSION.SDK_INT < 28) return;
        if (dp == null) dpInit();
        try {
            if (mbc == null) mbc = new DynamicsProcessing.Mbc(true, true, Cfg.DP_BANDS);
            if (!mbc.isEnabled()) { mbc.setEnabled(true); if (!dp.getEnabled()) { dp.setEnabled(true); dp.setMbcAllChannelsTo(mbc); } }
        } catch (Exception e) { System.out.println(e.getMessage()); }
        try {
            if (mbc == null || !mbc.isEnabled()) return;
            for (int i = 0; i < Cfg.DP_BANDS; i++) {
                try {
                    DynamicsProcessing.MbcBand b = mbc.getBand(i);
                    b.setEnabled(true); b.setAttackTime(3.0f); b.setReleaseTime(80.0f); b.setRatio(1.0f);
                    b.setThreshold(-45.0f); b.setKneeWidth(0.0f); b.setPostGain(10.0f);   // [INFERRED]
                    b.setNoiseGateThreshold(-90.0f); b.setExpanderRatio(1.0f);
                } catch (UnsupportedOperationException e) { e.printStackTrace(); }
            }
            dp.setMbcAllChannelsTo(mbc);
        } catch (Exception e) { System.out.println(e.getMessage()); }
    }

    // ---------- toggles (R, S, T) ----------
    private SharedPreferences on() { return getSharedPreferences("prefsEQOn", 0); }
    private void toggleBass() {
        bassOn = on().getBoolean("prefsBASSOn1", false);
        if (bassOn) { bassOn = false; bassRelease(); on().edit().putBoolean("prefsBASSOn1", false).apply(); }
        else { bassOn = true; bassStart(); on().edit().putBoolean("prefsBASSOn1", true).apply(); }
    }
    private void toggleEq() {
        eqOn = on().getBoolean("prefsEQOn1", true);
        if (eqOn) { eqOn = false; eqRelease(); on().edit().putBoolean("prefsEQOn1", false).apply(); }
        else { eqOn = true; eqStart(); on().edit().putBoolean("prefsEQOn1", true).apply(); }
    }
    private void toggleVirt() {
        virtOn = on().getBoolean("prefsVIRTOn1", false);
        if (virtOn) { virtOn = false; virtRelease(); on().edit().putBoolean("prefsVIRTOn1", false).apply(); }
        else { virtOn = true; virtStart(); on().edit().putBoolean("prefsVIRTOn1", true).apply(); }
    }

    // ---------- apply everything (b0) ----------
    private void applyAll() {
        SharedPreferences p = getSharedPreferences("prefsLoudness", 0);
        Cfg.loudness = p.getInt("prefsLoudnessValue", 0);
        if (Cfg.loudness == 0) loudnessOff();
        else { loudnessOn(); handler.postDelayed(() -> { setLoudness(0); setLoudness(Cfg.loudness); }, 500L); }
        setBass(bassLevel); setVirt(virtLevel);
        set3k(pos3k); set14k(pos14k); set60(pos60); set230(pos230); set910(pos910);
        if (Build.VERSION.SDK_INT >= 28 && Cfg.preamp != 20) applyPreamp();
        if (Build.VERSION.SDK_INT >= 28 && Cfg.balance != 50f) applyBalance();
    }

    // ---------- output device detection (I(), callback b) ----------
    private void detectDevice(AudioDeviceInfo[] devices) {
        deviceType = Cfg.DEVICE_KEYS[0];
        for (AudioDeviceInfo d : devices) {
            int t = d.getType();
            if (t == 2 || t == 24 || t == 27) { Cfg.deviceName = "Speaker"; deviceType = Cfg.DEVICE_KEYS[0]; }
            else if (t == 8 || t == 7) { Cfg.deviceName = String.valueOf(d.getProductName()); deviceType = Cfg.DEVICE_KEYS[2]; }
            else if (t == 4 || t == 3) { Cfg.deviceName = "Headphones"; deviceType = Cfg.DEVICE_KEYS[1]; }
            else if (t == 22 || t == 26 || t == 11) { Cfg.deviceName = String.valueOf(d.getProductName()); deviceType = Cfg.DEVICE_KEYS[3]; }
        }
        showNotification();
        // [NOT PORTED] original also looked up a per-headphone preset in its SQLite DB (X(), W()) and applied it.
    }

    // ---------- lifecycle ----------
    @Override public IBinder onBind(Intent i) { return binder; }

    @Override public void onCreate() {
        super.onCreate();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) wakeLock = pm.newWakeLock(1, "Music Volume EQ::WakelockTag");
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        SharedPreferences sp = getSharedPreferences("prefsEQPos", 0);
        int mid = Cfg.viewHeight / 2;
        pos60 = sp.getInt("prefsEQ60", mid); pos14k = sp.getInt("prefsEQ14", mid); pos3k = sp.getInt("prefsEQ3", mid);
        pos230 = sp.getInt("prefsEQ230", mid); pos910 = sp.getInt("prefsEQ910", mid);
        bassLevel = sp.getInt("BassLevel", 0); virtLevel = sp.getInt("VirtLevel", 0);
        // [RECONSTRUCTED] flags + effect creation (done in the lost part of onStartCommand originally)
        eqOn = on().getBoolean("prefsEQOn1", true); bassOn = on().getBoolean("prefsBASSOn1", false); virtOn = on().getBoolean("prefsVIRTOn1", false);
        try { if (eqOn) eqStart(); if (bassOn) bassStart(); if (virtOn) virtStart(); } catch (Exception ignored) {}
        applyAll();
        if (Build.VERSION.SDK_INT >= 23) {
            audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            detectDevice(audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS));
            deviceCallback = new AudioDeviceCallback() {
                @Override public void onAudioDevicesAdded(AudioDeviceInfo[] d) { detectDevice(d); }
                @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] d) { detectDevice(audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)); }
            };
            audioManager.registerAudioDeviceCallback(deviceCallback, null);
        }
    }

    /** [RECONSTRUCTED] original onStartCommand body was lost in decompile; rebuilt from its callers/actions. */
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        running = true;
        if (intent != null && intent.getBooleanExtra("STOP", false)) { stopSelf(); return START_NOT_STICKY; }
        showNotification();
        if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
        if (sessionReceiver == null) {
            sessionReceiver = new AudioSessionReceiver();
            IntentFilter f = new IntentFilter();
            f.addAction("android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION");
            f.addAction("android.media.action.CLOSE_AUDIO_EFFECT_CONTROL_SESSION");
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(sessionReceiver, f, Context.RECEIVER_EXPORTED);
            else registerReceiver(sessionReceiver, f);
        }
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_EQ_TOGGLE.equals(a)) toggleEq();
        else if (ACTION_BASS_TOGGLE.equals(a)) toggleBass();
        else if (ACTION_VIRT_TOGGLE.equals(a)) toggleVirt();
        else if (ACTION_SET_EQ10.equals(a)) { Cfg.tenBand = true; dpEqApply(Cfg.bands10); }
        else if (ACTION_RELAISE_EQ10.equals(a)) { Cfg.tenBand = false; dpRelease(); dpEq = null; mbc = null; }
        applyAll();
        return START_STICKY;
    }

    @Override public void onDestroy() {                      // V()
        super.onDestroy();
        running = false;
        eqRelease(); bassRelease(); virtRelease(); loudnessOff();
        if (Build.VERSION.SDK_INT >= 28 && dp != null) dpRelease();
        nm.cancel(Cfg.NOTIF_ID); stopForeground(true);
        handler.removeCallbacksAndMessages(null);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (sessionReceiver != null) { try { unregisterReceiver(sessionReceiver); } catch (Exception e) { e.printStackTrace(); } sessionReceiver = null; }
        if (Build.VERSION.SDK_INT >= 23 && audioManager != null && deviceCallback != null) {
            try { audioManager.unregisterAudioDeviceCallback(deviceCallback); } catch (Exception ignored) {}
        }
    }

    // ---------- notification (simplified e0) ----------
    private void showNotification() {
        String ch = "";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("EqChannel", getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c); ch = "EqChannel";
        }
        Intent stop = new Intent(this, EqService.class); stop.putExtra("STOP", true);
        int fl = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent stopPi = PendingIntent.getService(this, 5, stop, fl);
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), fl);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        Notification n = b.setContentTitle(getString(R.string.app_name)).setContentText(Cfg.deviceName)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off).setOngoing(true)
                .setContentIntent(open).addAction(new Notification.Action.Builder(0, "Stop", stopPi).build()).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(Cfg.NOTIF_ID, n, 2); else startForeground(Cfg.NOTIF_ID, n);
        } catch (Exception e) { e.printStackTrace(); }
    }
}
