package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Right card: 100..0 scale, framed vertical slider with ticks and a black thumb with a cyan line, "VOLUME" caption. */
public class VolSliderView extends View {
    public interface Listener { void onValue(int pct); }

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float panL, panR, panT, panB, trackT, trackB, cx;
    private int value = 0;
    private boolean drag = false;
    private Listener l;

    public VolSliderView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    public void setListener(Listener l) { this.l = l; }
    public boolean isDragging() { return drag; }
    public void setValue(int v) { v = Math.max(0, Math.min(100, v)); if (v != value) { value = v; invalidate(); } }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        panL = 36f * d; panR = w - d; panT = d; panB = h - 38f * d;
        cx = (panL + panR) / 2f;
        trackT = panT + 25f * d; trackB = panB - 25f * d;
    }

    @Override protected void onDraw(Canvas c) {
        float panH = panB - panT;
        // scale labels
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(14f * d);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(0xFFFFFFFF);
        for (int i = 0; i <= 5; i++) {
            float y = panT + panH * 0.1f + panH * 0.8f * i / 5f;
            Paint.FontMetrics fm = p.getFontMetrics();
            c.drawText(String.valueOf(100 - i * 20), 22f * d, y - (fm.ascent + fm.descent) / 2f, p);
        }
        // panel
        r.set(panL, panT, panR, panB);
        p.setColor(0xFF161718);
        c.drawRoundRect(r, 12f * d, 12f * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f * d); p.setColor(0xFF3B3E42);
        c.drawRoundRect(r, 12f * d, 12f * d, p);
        // ticks (17, major every 4th)
        p.setStrokeWidth(1.2f * d); p.setColor(0xFF8E9093);
        for (int i = 0; i <= 16; i++) {
            float y = trackT + (trackB - trackT) * i / 16f;
            float half = (i % 4 == 0 ? 21f : 14.5f) * d;
            c.drawLine(cx - half, y, cx + half, y, p);
        }
        // track
        r.set(cx - 6.5f * d, trackT, cx + 6.5f * d, trackB);
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF050505);
        c.drawRoundRect(r, 6f * d, 6f * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f * d); p.setColor(0xFFB5B5B5);
        c.drawRoundRect(r, 6f * d, 6f * d, p);
        // thumb
        float ty = trackB - (value / 100f) * (trackB - trackT);
        r.set(cx - 23.5f * d, ty - 32f * d, cx + 23.5f * d, ty + 32f * d);
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF000000);
        c.drawRoundRect(r, 8f * d, 8f * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f * d); p.setColor(0xFFD0D0D0);
        c.drawRoundRect(r, 8f * d, 8f * d, p);
        p.setStyle(Paint.Style.FILL); p.setColor(LedPanelView.CYAN);
        c.drawRect(cx - 22f * d, ty - 1f * d, cx + 22f * d, ty + 1f * d, p);
        // caption
        p.setColor(0xFFFFFFFF);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(17f * d);
        p.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = p.getFontMetrics();
        c.drawText("VOLUME", cx, panB + 22f * d - (fm.ascent + fm.descent) / 2f, p);
    }

    private void update(float y) {
        float f = 1f - (y - trackT) / (trackB - trackT);
        int v = Math.round(Math.max(0f, Math.min(1f, f)) * 100f);
        value = v;
        if (l != null) l.onValue(v);
        invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (e.getX() < panL - 8f * d) return false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                drag = true; update(e.getY()); return true;
            case MotionEvent.ACTION_MOVE:
                if (drag) update(e.getY());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                drag = false; invalidate(); return true;
        }
        return true;
    }
}
