package app.eqclean;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

/**
 * Home screen (like the original): spectrum analyzer card with EQ / BASS / VIRT toggles, vertical volume slider,
 * and an EQ button that opens the equalizer page (EqActivity).
 */
public class MainActivity extends Activity {
    private static final int GREEN = 0xFFA5D6A7, BG = 0xFF121212, CARD = 0xFF1E1E1E;

    private EqService svc;
    private AudioManager am;
    private SharedPreferences onPrefs;
    private SpectrumView spec;
    private VolumeSliderView vol;
    private TextView volText;
    private final TextView[] tabs = new TextView[3];
    private final boolean[] tabOn = new boolean[3];
    private Visualizer vis;
    private boolean fullscreen = false;
    private float d;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long lastFft = 0;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    /** keeps the volume slider in sync with hardware keys and lets spectrum bars fall when audio stops. */
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!vol.isDragging()) refreshVolume();
            if (System.currentTimeMillis() - lastFft > 200) spec.decay();
            ui.postDelayed(this, 100);
        }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        if (s == null && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        d = getResources().getDisplayMetrics().density;
        tabOn[0] = onPrefs.getBoolean("prefsEQOn1", true);
        tabOn[1] = onPrefs.getBoolean("prefsBASSOn1", false);
        tabOn[2] = onPrefs.getBoolean("prefsVIRTOn1", false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GridDrawable());
        root.setPadding(dp(12), dp(8), dp(12), dp(12));
        root.addView(header());

        // ---- main row: dB scale | spectrum card | volume
        LinearLayout row = new LinearLayout(this);
        row.addView(new ScaleView(this, 16, 104), new LinearLayout.LayoutParams(dp(46), -1));
        row.addView(spectrumCard(), new LinearLayout.LayoutParams(0, -1, 1));
        row.addView(volumeColumn(), lp(dp(150), -1, 0, 6, 0));
        root.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));

        // ---- EQ button
        TextView eq = label("EQ", 30, Color.WHITE, false);
        eq.setBackground(new HexDrawable());
        eq.setOnClickListener(v -> startActivity(new Intent(this, EqActivity.class)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(dp(88), dp(78));
        ep.gravity = Gravity.CENTER_HORIZONTAL; ep.topMargin = dp(14);
        root.addView(eq, ep);
        setContentView(root);

        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onResume() {
        super.onResume();
        tabOn[0] = onPrefs.getBoolean("prefsEQOn1", true);   // EqActivity may have changed them
        tabOn[1] = onPrefs.getBoolean("prefsBASSOn1", false);
        tabOn[2] = onPrefs.getBoolean("prefsVIRTOn1", false);
        for (int i = 0; i < 3; i++) tabs[i].setTextColor(tabOn[i] ? GREEN : Color.WHITE);
        refreshVolume();
        startVis();
        ui.post(tick);
    }
    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(tick); stopVis(); }
    @Override protected void onDestroy() { super.onDestroy(); try { unbindService(conn); } catch (Exception ignored) {} }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        startVis();
    }

    // ---------------------------------------------------------------- helpers
    private int dp(float v) { return (int) (v * d + 0.5f); }
    private LinearLayout.LayoutParams lp(int w, int h, float weight, int mx, int my) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(mx), dp(my), dp(mx), dp(my));
        return p;
    }
    private GradientDrawable outlined(int color, float radiusDp, int stroke, int width) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp)); g.setStroke(Math.max(1,width), stroke);
        return g;
    }

    private final class GridDrawable extends Drawable {
        private final Paint p = new Paint(1);
        @Override public void draw(Canvas c) {
            c.drawColor(0xFF070909);
            float step = dp(32);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(0.6f)); p.setColor(0xFF111819);
            for (float x=0; x<getBounds().width(); x+=step) c.drawLine(x,0,x,getBounds().height(),p);
            for (float y=0; y<getBounds().height(); y+=step) c.drawLine(0,y,getBounds().width(),y,p);
            p.setColor(0xFF0D1719); p.setStrokeWidth(dp(0.7f));
            for (float x=-getBounds().height(); x<getBounds().width(); x+=step*4) c.drawLine(x,0,x+getBounds().height(),getBounds().height(),p);
        }
        @Override public void setAlpha(int a) {} @Override public void setColorFilter(android.graphics.ColorFilter f) {} @Override public int getOpacity(){return android.graphics.PixelFormat.OPAQUE;}
    }

    private final class HexDrawable extends Drawable {
        private final Paint p = new Paint(1);
        @Override public void draw(Canvas c) {
            android.graphics.Rect b=getBounds(); float w=b.width(), h=b.height();
            Path path=new Path(); path.moveTo(w*.5f, h*.03f); path.lineTo(w*.95f,h*.25f); path.lineTo(w*.95f,h*.75f); path.lineTo(w*.5f,h*.97f); path.lineTo(w*.05f,h*.75f); path.lineTo(w*.05f,h*.25f); path.close();
            p.setColor(0xFF080909); p.setStyle(Paint.Style.FILL); c.drawPath(path,p);
            p.setColor(0xFFD0D0D0); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); c.drawPath(path,p);
        }
        @Override public void setAlpha(int a) {} @Override public void setColorFilter(android.graphics.ColorFilter f) {} @Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp));
        return g;
    }
    private TextView label(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    // ---------------------------------------------------------------- layout
    private View header() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        IconView menu = new IconView(this, IconView.MENU);
        menu.setOnClickListener(v -> effectsMenu(v));
        TextView title = label("MUSIC VOLUME EQ", 18, 0xFF5E5E62, true);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setLetterSpacing(0.06f);
        title.setSingleLine(true);
        IconView full = new IconView(this, IconView.FULLSCREEN);
        full.setOnClickListener(v -> toggleFullscreen());
        IconView more = new IconView(this, IconView.DOTS);
        more.setOnClickListener(v -> moreMenu(v));
        h.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(52)));
        h.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        h.addView(full, new LinearLayout.LayoutParams(dp(48), dp(52)));
        h.addView(more, new LinearLayout.LayoutParams(dp(40), dp(52)));
        return h;
    }

    private View spectrumCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(outlined(CARD, 10, 0xFF38383A, dp(1.5f)));
        card.setPadding(0, dp(12), 0, 0);
        spec = new SpectrumView(this);
        card.addView(spec, new LinearLayout.LayoutParams(-1, 0, 1));

        volText = label("", 19, Color.WHITE, true);
        volText.setGravity(Gravity.END);
        volText.setPadding(0, 0, dp(18), dp(4));
        card.addView(volText, new LinearLayout.LayoutParams(-1, dp(40)));

        LinearLayout t = new LinearLayout(this);
        t.setGravity(Gravity.CENTER);
        String[] names = {"EQ", "BASS", "VIRT"};
        String[] actions = {EqService.ACTION_EQ_TOGGLE, EqService.ACTION_BASS_TOGGLE, EqService.ACTION_VIRT_TOGGLE};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView b = label(names[i], 19, tabOn[i] ? GREEN : Color.WHITE, true);
            tabs[i] = b;
            b.setOnClickListener(v -> {
                startService(new Intent(this, EqService.class).setAction(actions[idx]));
                tabOn[idx] = !tabOn[idx];
                b.setTextColor(tabOn[idx] ? GREEN : Color.WHITE);
            });
            t.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
        }
        card.addView(t, new LinearLayout.LayoutParams(-1, dp(56)));
        return card;
    }

    private View volumeColumn() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        vol = new VolumeSliderView(this);
        vol.setListener(f -> {
            int max = am.getStreamMaxVolume(3);
            int v = Math.round(f * max);
            am.setStreamVolume(3, v, 0);
            if (EqService.volumeLock) EqService.lockedVolume = v;
            setVolText(v);
        });
        c.addView(vol, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView t = label("VOLUME", 22, Color.WHITE, true);
        c.addView(t, new LinearLayout.LayoutParams(-2, dp(56)));
        return c;
    }

    // ---------------------------------------------------------------- volume
    private void refreshVolume() {
        int max = Math.max(1, am.getStreamMaxVolume(3)), v = am.getStreamVolume(3);
        vol.setFraction((float) v / max);
        setVolText(v);
    }
    private void setVolText(int v) {
        SpannableString s = new SpannableString(String.format("VOLUME %02d", v));
        s.setSpan(new ForegroundColorSpan(GREEN), 7, s.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        volText.setText(s);
    }

    // ---------------------------------------------------------------- menus
    private void effectsMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Preamp & Loudness");
        m.getMenu().add(0, 2, 1, "Balance");
        m.getMenu().add(0, 3, 2, "Limiter");
        m.setOnMenuItemClickListener(it -> {
            Dialogs.Svc g = () -> svc;
            if (it.getItemId() == 1) Dialogs.preampLoudness(this, g);
            else if (it.getItemId() == 2) Dialogs.balance(this, g);
            else Dialogs.limiter(this, g);
            return true;
        });
        m.show();
    }

    private void moreMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        MenuItem lock = m.getMenu().add(0, 1, 0, "Lock volume");
        lock.setCheckable(true); lock.setChecked(EqService.volumeLock);
        m.getMenu().add(0, 2, 1, "Stop & exit");
        m.setOnMenuItemClickListener(it -> {
            if (it.getItemId() == 1) { if (svc != null) svc.setVolumeLock(!EqService.volumeLock); }
            else {
                startService(new Intent(this, EqService.class).putExtra("STOP", true));
                finishAndRemoveTask();
            }
            return true;
        });
        m.show();
    }

    @SuppressWarnings("deprecation")
    private void toggleFullscreen() {
        fullscreen = !fullscreen;
        getWindow().getDecorView().setSystemUiVisibility(fullscreen
                ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                : View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ---------------------------------------------------------------- spectrum (Visualizer FFT on the output mix)
    private void startVis() {
        if (vis != null) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        try {
            Visualizer v = new Visualizer(Cfg.session);
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
            v.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override public void onWaveFormDataCapture(Visualizer x, byte[] w, int sr) {}
                @Override public void onFftDataCapture(Visualizer x, byte[] fft, int sr) { lastFft = System.currentTimeMillis(); spec.pushFft(fft, sr); }
            }, Visualizer.getMaxCaptureRate() / 2, false, true);
            v.setEnabled(true);
            vis = v;
        } catch (Throwable t) { vis = null; }
    }
    private void stopVis() {
        if (vis == null) return;
        try { vis.setEnabled(false); vis.release(); } catch (Throwable ignored) {}
        vis = null;
    }
}
