package app.eqclean;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.drawerlayout.widget.DrawerLayout;

import java.util.Arrays;

/**
 * Studio "booster" screen (activity_booster_studio) rebuilt in code:
 * toolbar | left dB scale + black screen (spectrum, VOLUME n, EQ/BASS/VIRT toggles) + right scale + volume slider | EQ button,
 * plus the left drawer (logo + list).
 */
public class MainActivity extends Activity {
    private static final String[] DB_SCALE = {"+38 ", "+30 ", "+20 ", "+10 ", "+7 ", "+4 ", "+2 ", "  0", " -2", " -4", " -7", "-10", "-20", "-30", "-38"};
    private static final String[] VOL_SCALE = {"100", " 80", " 60", " 40", " 20", "  0"};
    private static final float[] VOL_W = {0.3f, 0.4f, 0.3f, 0.3f, 0.4f, 0.3f};

    private EqService svc;
    private AudioManager am;
    private SharedPreferences onPrefs;
    private SpectrumView spec;
    private StudioSlider vol;
    private TextView volText;
    private DrawerLayout drawer;
    private final ToggleButton[] tg = new ToggleButton[3];
    private Visualizer vis;
    private boolean fullscreen;
    private long lastFft;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    /** keeps the slider in sync with hardware keys and lets the spectrum fall when audio stops. */
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!vol.isDragging()) refreshVolume();
            if (System.currentTimeMillis() - lastFft > 200) spec.decay();
            ui.postDelayed(this, 100);
        }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        if (s == null && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
        getWindow().setStatusBarColor(Studio.BLACK);
        getWindow().setNavigationBarColor(Studio.BLACK);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        onPrefs = getSharedPreferences("prefsEQOn", 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Studio.background(this));

        LinearLayout bar = Studio.toolbar(this);
        IconView menu = new IconView(this, IconView.MENU);
        menu.setOnClickListener(v -> drawer.openDrawer(Gravity.START));
        bar.addView(menu, 0, new LinearLayout.LayoutParams(Studio.dp(this, 44), Studio.dp(this, 48)));
        Studio.addAction(bar, new IconView(this, IconView.FULLSCREEN), v -> toggleFullscreen());
        Studio.addAction(bar, new IconView(this, IconView.DOTS), this::moreMenu);
        root.addView(bar);
        root.addView(Studio.shadow(this));

        drawer = new DrawerLayout(this);
        drawer.addView(body(), new DrawerLayout.LayoutParams(-1, -1));
        DrawerLayout.LayoutParams dlp = new DrawerLayout.LayoutParams(Studio.dp(this, 240), -1);
        dlp.gravity = Gravity.START;
        drawer.addView(drawerPanel(), dlp);
        root.addView(drawer, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onResume() {
        super.onResume();
        syncToggles();
        refreshVolume();
        startVis();
        ui.post(tick);
    }

    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(tick); stopVis(); }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unbindService(conn); } catch (Exception ignored) {}
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        startVis();
    }

    // ------------------------------------------------------------------ layout
    private View body() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, Studio.dp(this, 5), 0, 0);

        // main row: dB scale | screen | volume scale | slider
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(Studio.dp(this, 10), Studio.dp(this, 10), Studio.dp(this, 10), 0);

        float[] w = new float[DB_SCALE.length];
        Arrays.fill(w, 0.3f);
        LinearLayout left = Studio.scale(this, DB_SCALE, w, 0, 40);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-2, Studio.dp(this, 310));
        llp.leftMargin = Studio.dp(this, 1);
        row.addView(left, llp);

        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(Studio.dp(this, 180), Studio.dp(this, 310));
        ep.rightMargin = Studio.dp(this, 10);
        row.addView(screen(), ep);

        LinearLayout right = Studio.scale(this, VOL_SCALE, VOL_W, 0, 0);
        right.getChildAt(0).setPadding(0, Studio.dp(this, 20), 0, 0);
        right.getChildAt(VOL_SCALE.length - 1).setPadding(0, 0, 0, Studio.dp(this, 20));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-2, Studio.dp(this, 310));
        rlp.leftMargin = Studio.dp(this, 1);
        row.addView(right, rlp);

        FrameLayout sliderBox = new FrameLayout(this);
        sliderBox.setBackground(Studio.panel(this, Studio.PANEL));
        vol = StudioSlider.volume(this);
        vol.setListener((sl, p, user) -> {
            if (!user) return;
            int max = Math.max(1, am.getStreamMaxVolume(3));
            int v = Math.round(p * max / (float) sl.getTravel());
            if (v != am.getStreamVolume(3)) am.setStreamVolume(3, v, 0);
            if (EqService.volumeLock) EqService.lockedVolume = v;
            volText.setText(String.valueOf(v));
        });
        sliderBox.addView(vol, new FrameLayout.LayoutParams(Studio.dp(this, 66), Studio.dp(this, 310), Gravity.CENTER));
        row.addView(sliderBox, new LinearLayout.LayoutParams(Studio.dp(this, 72), Studio.dp(this, 310)));
        col.addView(row, new LinearLayout.LayoutParams(-2, -2));

        // "VOLUME" caption under the slider (right aligned)
        TextView cap = Studio.text(this, "VOLUME", Studio.TITLE_TEXT, Studio.WHITE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.gravity = Gravity.END;
        cp.rightMargin = Studio.dp(this, 33);
        col.addView(cap, cp);

        // EQ button
        View eq = Studio.imageButton(this, R.drawable.botuneq_studio, R.drawable.botuneq_press_studio);
        eq.setOnClickListener(v -> startActivity(new Intent(this, EqActivity.class)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Studio.dp(this, Studio.FWDREV2), Studio.dp(this, Studio.FWDREV2));
        bp.gravity = Gravity.CENTER_HORIZONTAL;
        bp.topMargin = Studio.dp(this, 5);
        col.addView(eq, bp);
        return col;
    }

    /** "ekran": black rounded panel with the spectrum, the VOLUME n line and the three toggles. */
    private View screen() {
        LinearLayout ekran = new LinearLayout(this);
        ekran.setOrientation(LinearLayout.VERTICAL);
        ekran.setBackground(Studio.panel(this, Studio.BLACK));

        FrameLayout holder = new FrameLayout(this);
        holder.setBackgroundColor(Studio.BLACK);
        spec = new SpectrumView(this);
        spec.setColors(Studio.CYAN, Studio.WHITE);
        holder.addView(spec, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 0, 0.7f);
        hp.setMargins(Studio.dp(this, 10), Studio.dp(this, 10), Studio.dp(this, 10), Studio.dp(this, 5));
        ekran.addView(holder, hp);

        // "VOLUME n", right aligned
        LinearLayout doli = new LinearLayout(this);
        doli.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        doli.addView(Studio.text(this, "VOLUME", Studio.BUTTON_TEXT, Studio.WHITE));
        volText = Studio.text(this, "15", Studio.BUTTON_TEXT, Studio.CYAN);
        volText.setSingleLine(true);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-2, -2);
        vp.leftMargin = Studio.dp(this, 3);
        doli.addView(volText, vp);
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(-1, -2);
        dp1.setMargins(Studio.dp(this, 10), 0, Studio.dp(this, 10), Studio.dp(this, 5));
        ekran.addView(doli, dp1);

        // EQ | BASS | VIRT
        LinearLayout doli2 = new LinearLayout(this);
        doli2.setGravity(Gravity.CENTER_VERTICAL);
        String[] names = {"EQ", "BASS", "VIRT"};
        final String[] actions = {EqService.ACTION_EQ_TOGGLE, EqService.ACTION_BASS_TOGGLE, EqService.ACTION_VIRT_TOGGLE};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            ToggleButton t = Studio.textToggle(this, names[i]);
            t.setOnClickListener(v -> startService(new Intent(this, EqService.class).setAction(actions[idx])));
            tg[i] = t;
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(Studio.dp(this, 40), Studio.dp(this, 15));
            if (i > 0) tp.leftMargin = Studio.dp(this, 5);
            doli2.addView(t, tp);
        }
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(-1, -2);
        dp2.setMargins(Studio.dp(this, 10), 0, Studio.dp(this, 10), Studio.dp(this, 5));
        ekran.addView(doli2, dp2);
        return ekran;
    }

    private View drawerPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(Studio.BLACK);
        p.setClickable(true);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_drawer_studio);
        logo.setAdjustViewBounds(true);
        p.addView(logo, new LinearLayout.LayoutParams(-1, -2));
        p.addView(Studio.shadow(this));

        final String[] items = {"Equalizer", "Settings", "Share the app", "Rate this app", "About"};
        ListView list = new ListView(this);
        list.setDivider(null);
        list.setSelector(new ColorDrawable(0x956DE5FF));
        list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                TextView t = (TextView) super.getView(pos, cv, parent);
                t.setTextColor(Studio.WHITE);
                t.setTextSize(16);
                t.setPadding(Studio.dp(MainActivity.this, 16), Studio.dp(MainActivity.this, 12), Studio.dp(MainActivity.this, 16), Studio.dp(MainActivity.this, 12));
                return t;
            }
        });
        list.setOnItemClickListener((a, v, pos, id) -> {
            drawer.closeDrawers();
            switch (pos) {
                case 0: startActivity(new Intent(this, EqActivity.class)); break;
                case 2: share(); break;
                case 4: about(); break;
                default: Toast.makeText(this, items[pos] + " is not ported yet", Toast.LENGTH_SHORT).show();
            }
        });
        p.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        return p;
    }

    // ------------------------------------------------------------------ state
    private void syncToggles() {
        tg[0].setChecked(onPrefs.getBoolean("prefsEQOn1", true));
        tg[1].setChecked(onPrefs.getBoolean("prefsBASSOn1", false));
        tg[2].setChecked(onPrefs.getBoolean("prefsVIRTOn1", false));
    }

    private void refreshVolume() {
        int max = Math.max(1, am.getStreamMaxVolume(3)), v = am.getStreamVolume(3);
        vol.setProgress(Math.round(v * vol.getTravel() / (float) max));
        volText.setText(String.valueOf(v));
    }

    // ------------------------------------------------------------------ menus
    private void moreMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Preamp & Loudness");
        m.getMenu().add(0, 2, 1, "Balance");
        m.getMenu().add(0, 3, 2, "Limiter");
        MenuItem lock = m.getMenu().add(0, 4, 3, "Lock volume");
        lock.setCheckable(true);
        lock.setChecked(EqService.volumeLock);
        m.getMenu().add(0, 5, 4, "Quit");
        m.setOnMenuItemClickListener(it -> {
            Dialogs.Svc g = () -> svc;
            switch (it.getItemId()) {
                case 1: Dialogs.preampLoudness(this, g); break;
                case 2: Dialogs.balance(this, g); break;
                case 3: Dialogs.limiter(this, g); break;
                case 4: if (svc != null) svc.setVolumeLock(!EqService.volumeLock); break;
                default:
                    startService(new Intent(this, EqService.class).putExtra("STOP", true));
                    finishAndRemoveTask();
            }
            return true;
        });
        m.show();
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, "Music Volume EQ");
        startActivity(Intent.createChooser(i, "Share the app"));
    }

    private void about() {
        String ver = "";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            ver = pi.versionName;
        } catch (Exception ignored) {}
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Music Volume EQ").setMessage("Version " + ver).setPositiveButton("OK", null).show();
    }

    @SuppressWarnings("deprecation")
    private void toggleFullscreen() {
        fullscreen = !fullscreen;
        getWindow().getDecorView().setSystemUiVisibility(fullscreen
                ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                : View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ------------------------------------------------------------------ spectrum (Visualizer FFT on the output mix)
    private void startVis() {
        if (vis != null) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        try {
            Visualizer v = new Visualizer(Cfg.session);
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
            v.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override public void onWaveFormDataCapture(Visualizer x, byte[] w, int sr) {}
                @Override public void onFftDataCapture(Visualizer x, byte[] fft, int sr) { lastFft = System.currentTimeMillis(); spec.pushFft(fft, sr); }
            }, Visualizer.getMaxCaptureRate() / 2, false, true);
            v.setEnabled(true);
            vis = v;
        } catch (Throwable t) { vis = null; }
    }

    private void stopVis() {
        if (vis == null) return;
        try { vis.setEnabled(false); vis.release(); } catch (Throwable ignored) {}
        vis = null;
    }
}
