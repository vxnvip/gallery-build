package app.eqclean;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Simple programmatic UI - replace freely. Only talks to EqService via its public methods. */
public class MainActivity extends Activity {
    private EqService svc;
    private LinearLayout root;
    private SharedPreferences pos;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        if (Build.VERSION.SDK_INT >= 23) {
            String[] perms = Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO};
            requestPermissions(perms, 1);
        }
        pos = getSharedPreferences("prefsEQPos", 0);
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad * 2, pad, pad);
        sv.addView(root);
        setContentView(sv);

        sw("EQ", "prefsEQOn1", true, EqService.ACTION_EQ_TOGGLE);
        sw("Bass boost", "prefsBASSOn1", false, EqService.ACTION_BASS_TOGGLE);
        sw("Virtualizer", "prefsVIRTOn1", false, EqService.ACTION_VIRT_TOGGLE);

        int h = Cfg.viewHeight;
        bar("60 Hz", h, pos.getInt("prefsEQ60", h / 2), "prefsEQ60", v -> svc.set60(v));
        bar("230 Hz", h, pos.getInt("prefsEQ230", h / 2), "prefsEQ230", v -> svc.set230(v));
        bar("910 Hz", h, pos.getInt("prefsEQ910", h / 2), "prefsEQ910", v -> svc.set910(v));
        bar("3 kHz", h, pos.getInt("prefsEQ3", h / 2), "prefsEQ3", v -> svc.set3k(v));
        bar("14 kHz", h, pos.getInt("prefsEQ14", h / 2), "prefsEQ14", v -> svc.set14k(v));
        bar("Bass level", 1000, pos.getInt("BassLevel", 0), "BassLevel", v -> svc.setBass(v));
        bar("Virtualizer level", 1000, pos.getInt("VirtLevel", 0), "VirtLevel", v -> svc.setVirt(v));
        SharedPreferences lp = getSharedPreferences("prefsLoudness", 0);
        bar("Loudness (mB)", 1000, lp.getInt("prefsLoudnessValue", 0), null, v -> {
            lp.edit().putInt("prefsLoudnessValue", v).apply();
            Cfg.loudness = v;
            if (v == 0) svc.loudnessOff(); else { svc.loudnessOn(); svc.setLoudness(v); }
        });
        bar("Preamp (20 = 0 dB)", 40, Cfg.preamp, null, v -> { Cfg.preamp = v; svc.applyPreamp(); });
        bar("Balance (50 = centre)", 100, (int) Cfg.balance, null, v -> { Cfg.balance = v; svc.applyBalance(); });

        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onDestroy() { super.onDestroy(); try { unbindService(conn); } catch (Exception ignored) {} }

    private void sw(String label, String key, boolean def, String action) {
        Switch w = new Switch(this);
        w.setText(label);
        w.setChecked(getSharedPreferences("prefsEQOn", 0).getBoolean(key, def));
        w.setOnCheckedChangeListener((CompoundButton b, boolean on) -> {
            if (on == getSharedPreferences("prefsEQOn", 0).getBoolean(key, def)) return;
            startService(new Intent(this, EqService.class).setAction(action));
        });
        root.addView(w);
    }

    private interface IntCb { void on(int v); }

    private void bar(String label, int max, int value, String prefKey, IntCb cb) {
        TextView t = new TextView(this);
        t.setText(label);
        SeekBar b = new SeekBar(this);
        b.setMax(max);
        b.setProgress(value);
        b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                if (!user || svc == null) return;
                cb.on(p);
                if (prefKey != null) pos.edit().putInt(prefKey, p).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        root.addView(t);
        root.addView(b);
    }
}
