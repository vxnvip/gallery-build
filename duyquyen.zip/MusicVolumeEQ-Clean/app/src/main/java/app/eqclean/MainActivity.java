package app.eqclean;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Dark "LED" layout: header, EQ/BASS/VIRT LED panel + volume slider, hexagon power button. */
public class MainActivity extends Activity {
    private static final String[] BUILTIN_NAMES = {"Flat", "Rock", "Pop", "Bass", "Treble", "Vocal"};
    private static final float[][] BUILTIN = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {5, 4, 3, 1, -1, -1, 1, 3, 4, 5},
            {-1, 1, 3, 4, 3, 0, -1, -1, -1, -1},
            {7, 6, 5, 3, 1, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 1, 3, 5, 6, 7},
            {-2, -3, -3, 1, 3, 3, 3, 1, 0, -1}};
    private static final String[] MODE_NAMES = {"EQ", "BASS", "VIRT"};

    private EqService svc;
    private SharedPreferences pos, onPrefs, presets;
    private LedPanelView panel;
    private VolSliderView slider;
    private HexButton hex;
    private AudioManager am;
    private float d;
    private int mode = 0;
    private boolean full = false;
    private final boolean[] on = new boolean[3];
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable save10 = () -> {
        StringBuilder sb = new StringBuilder();
        for (float f : Cfg.bands10) sb.append(f).append(",");
        getSharedPreferences("eq10_save_prefs", 0).edit().putString("eq10_save_prefs", sb.toString()).apply();
    };
    private final Runnable poll = new Runnable() {
        @Override public void run() { syncVolume(); ui.postDelayed(this, 300); }
    };
    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        if (s == null && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        pos = getSharedPreferences("prefsEQPos", 0);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        presets = getSharedPreferences("prefsPresets", 0);
        d = getResources().getDisplayMetrics().density;
        Cfg.tenBand = true;
        load10();
        loadOn();

        FrameLayout root = new FrameLayout(this);
        root.addView(new GridBg(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(header(), new LinearLayout.LayoutParams(-1, dp(56)));

        int rowH = Math.max(dp(300), (int) (0.45f * Math.max(getResources().getDisplayMetrics().heightPixels,
                getResources().getDisplayMetrics().widthPixels)));
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, 0, dp(10), 0);

        panel = new LedPanelView(this);
        panel.setBands(Cfg.bands10);
        panel.setLevel(1, pos.getInt("BassLevel", 0));
        panel.setLevel(2, pos.getInt("VirtLevel", 0));
        panel.setListener(new LedPanelView.Listener() {
            @Override public void onMode(int m) { mode = m; refresh(); }
            @Override public void onBand(int i, float db) {
                Cfg.bands10[i] = db;
                if (svc != null && on[0]) svc.dpEqApply(Cfg.bands10);
                ui.removeCallbacks(save10);
                ui.postDelayed(save10, 300);
            }
            @Override public void onLevel(int m, int v) {
                if (m == 1) { pos.edit().putInt("BassLevel", v).apply(); if (svc != null) svc.setBass(v); }
                else { pos.edit().putInt("VirtLevel", v).apply(); if (svc != null) svc.setVirt(v); }
            }
        });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, rowH, 1f);
        pl.gravity = Gravity.TOP;
        row.addView(panel, pl);

        slider = new VolSliderView(this);
        slider.setListener(pct -> {
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            int idx = Math.round(pct * max / 100f);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0);
            panel.setVolume(idx);
            if (EqService.volumeLock) EqService.lockedVolume = idx;
        });
        row.addView(slider, new LinearLayout.LayoutParams(dp(112), rowH + dp(38)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, rowH + dp(38));
        rp.topMargin = dp(14);
        col.addView(row, rp);

        hex = new HexButton(this);
        hex.setOnClickListener(v -> {
            String act = mode == 0 ? EqService.ACTION_EQ_TOGGLE : mode == 1 ? EqService.ACTION_BASS_TOGGLE : EqService.ACTION_VIRT_TOGGLE;
            startService(new Intent(this, EqService.class).setAction(act));
            on[mode] = !on[mode];
            refresh();
        });
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(64), dp(74));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.topMargin = dp(2);
        hp.bottomMargin = dp(24);
        col.addView(hex, hp);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(col);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        refresh();
        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onResume() { super.onResume(); loadOn(); refresh(); ui.post(poll); }
    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(poll); }
    @Override protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        try { unbindService(conn); } catch (Exception ignored) {}
    }

    private int dp(float v) { return (int) (v * d + 0.5f); }

    private View header() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        IconView menu = new IconView(this, IconView.MENU);
        menu.setOnClickListener(v -> presetDialog());
        IconView fs = new IconView(this, IconView.FULLSCREEN);
        fs.setOnClickListener(v -> toggleFull());
        IconView dots = new IconView(this, IconView.DOTS);
        dots.setOnClickListener(v -> moreDialog());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(56), -1);
        mp.leftMargin = dp(6);
        h.addView(menu, mp);
        h.addView(new PixelTitleView(this), new LinearLayout.LayoutParams(0, dp(14), 1f));
        h.addView(fs, new LinearLayout.LayoutParams(dp(48), -1));
        h.addView(dots, new LinearLayout.LayoutParams(dp(44), -1));
        return h;
    }

    private void toggleFull() {
        full = !full;
        getWindow().getDecorView().setSystemUiVisibility(full
                ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                  | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                : View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ---------------------------------------------------------------- state
    private void loadOn() {
        on[0] = onPrefs.getBoolean("prefsEQOn1", true);
        on[1] = onPrefs.getBoolean("prefsBASSOn1", false);
        on[2] = onPrefs.getBoolean("prefsVIRTOn1", false);
    }

    private void refresh() {
        if (panel == null) return;
        panel.setMode(mode);
        panel.setLit(on[mode]);
        hex.set(MODE_NAMES[mode], on[mode]);
    }

    private void syncVolume() {
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        panel.setVolume(cur);
        if (!slider.isDragging()) slider.setValue(Math.round(cur * 100f / max));
    }

    private void load10() {
        String saved = getSharedPreferences("eq10_save_prefs", 0).getString("eq10_save_prefs", "");
        if (!saved.isEmpty()) {
            String[] sp = saved.split(",");
            for (int i = 0; i < 10 && i < sp.length; i++)
                try { Cfg.bands10[i] = Math.max(-38f, Math.min(38f, Float.parseFloat(sp[i]))); } catch (Exception ignored) {}
        }
    }

    // ---------------------------------------------------------------- presets (hamburger)
    private void applyBands(float[] db) {
        for (int i = 0; i < 10 && i < db.length; i++) Cfg.bands10[i] = Math.max(-38f, Math.min(38f, db[i]));
        panel.setBands(Cfg.bands10);
        if (svc != null && on[0]) svc.dpEqApply(Cfg.bands10);
        ui.removeCallbacks(save10);
        ui.postDelayed(save10, 300);
    }

    private void presetDialog() {
        final List<String> names = new ArrayList<>();
        final List<float[]> vals = new ArrayList<>();
        final List<String> keys = new ArrayList<>();
        for (int i = 0; i < BUILTIN.length; i++) { names.add(BUILTIN_NAMES[i]); vals.add(BUILTIN[i]); keys.add(null); }
        for (Map.Entry<String, ?> e : presets.getAll().entrySet()) {
            if (!e.getKey().startsWith("p10_")) continue;
            try {
                String[] sp = String.valueOf(e.getValue()).split(",");
                float[] v = new float[sp.length];
                for (int i = 0; i < sp.length; i++) v[i] = Float.parseFloat(sp[i].trim());
                names.add(e.getKey().substring(4)); vals.add(v); keys.add(e.getKey());
            } catch (Exception ignored) {}
        }
        names.add("+ Save current...");
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Preset")
                .setItems(names.toArray(new String[0]), (dd, which) -> {
                    if (which == names.size() - 1) { saveDialog(); return; }
                    mode = 0; refresh();
                    applyBands(vals.get(which));
                }).create();
        dlg.show();
        dlg.getListView().setOnItemLongClickListener((p, v, which, id) -> {
            if (which < keys.size() && keys.get(which) != null) {
                presets.edit().remove(keys.get(which)).apply();
                Toast.makeText(this, "Deleted " + names.get(which), Toast.LENGTH_SHORT).show();
                dlg.dismiss();
                return true;
            }
            return false;
        });
    }

    private void saveDialog() {
        final EditText in = new EditText(this);
        in.setSingleLine(true); in.setHint("Preset name");
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Save preset").setView(in)
                .setPositiveButton("Save", (dd, w) -> {
                    String n = in.getText().toString().trim().replace(",", " ");
                    if (n.isEmpty()) return;
                    StringBuilder sb = new StringBuilder();
                    for (float v : Cfg.bands10) sb.append(v).append(",");
                    presets.edit().putString("p10_" + n, sb.toString()).apply();
                })
                .setNegativeButton("Cancel", null).show();
    }

    // ---------------------------------------------------------------- more (3 dots)
    private void moreDialog() {
        final Dialogs.Svc g = () -> svc;
        final String[] items = {"Preamp & Loudness", "Balance", "Limiter", "VU meter",
                EqService.volumeLock ? "Unlock volume" : "Lock volume", "Reset EQ"};
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setItems(items, (dd, which) -> {
                    switch (which) {
                        case 0: Dialogs.preampLoudness(this, g); break;
                        case 1: Dialogs.balance(this, g); break;
                        case 2: Dialogs.limiter(this, g); break;
                        case 3: vuDialog(); break;
                        case 4:
                            if (svc != null) svc.setVolumeLock(!EqService.volumeLock);
                            break;
                        default: applyBands(new float[10]); break;
                    }
                }).show();
    }

    // ---------------------------------------------------------------- VU meter
    private void vuDialog() {
        final VuView vu = new VuView(this);
        vu.setPadding(dp(20), dp(8), dp(20), dp(8));
        Visualizer vis = null;
        try {
            vis = new Visualizer(Cfg.session);
            vis.setMeasurementMode(Visualizer.MEASUREMENT_MODE_PEAK_RMS);
            vis.setEnabled(true);
        } catch (Throwable e) {
            Toast.makeText(this, "VU needs the microphone permission (RECORD_AUDIO)", Toast.LENGTH_LONG).show();
            if (vis != null) try { vis.release(); } catch (Exception ignored) {}
            return;
        }
        final Visualizer v = vis;
        final Visualizer.MeasurementPeakRms m = new Visualizer.MeasurementPeakRms();
        final Runnable vuPoll = new Runnable() {
            @Override public void run() {
                try {
                    v.getMeasurementPeakRms(m);
                    vu.set(clamp01((m.mPeak + 6000f) / 6000f), clamp01((m.mRms + 6000f) / 6000f));
                } catch (Exception ignored) {}
                ui.postDelayed(this, 50);
            }
        };
        ui.post(vuPoll);
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle("VU").setView(vu)
                .setPositiveButton("Close", null).create();
        dlg.setOnDismissListener(x -> { ui.removeCallbacks(vuPoll); try { v.setEnabled(false); v.release(); } catch (Exception ignored) {} });
        dlg.show();
    }
    private static float clamp01(float f) { return Math.max(0f, Math.min(1f, f)); }
}
