package app.eqclean;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * UI (replace freely). Layout: header + overflow "Audio Effects" menu, 5 band sliders + bass + virt,
 * EQ/BASS/VIRT toggles, vertical volume slider with lock, 10-band mode.
 * All audio goes through EqService.
 */
public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(165, 214, 167);
    private EqService svc;
    private SharedPreferences pos, onPrefs;
    private LinearLayout panel5, panel10;
    private Button tabEq, tabBass, tabVirt, mode10;
    private VerticalSeekBar volBar;
    private TextView volText;
    private AudioManager am;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        pos = getSharedPreferences("prefsEQPos", 0);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        float d = getResources().getDisplayMetrics().density;
        Cfg.viewHeight = (int) (155 * d);                       // original: 155dp slider height (scale = range / height)
        Cfg.tenBand = false;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 18, 18));
        root.setPadding((int) (12 * d), (int) (28 * d), (int) (12 * d), (int) (12 * d));

        // header
        LinearLayout head = new LinearLayout(this);
        TextView title = new TextView(this);
        title.setText("MUSIC VOLUME EQ"); title.setTextColor(Color.GRAY); title.setTextSize(20);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        Button more = new Button(this);
        more.setText("⋮"); more.setBackgroundColor(Color.TRANSPARENT); more.setTextColor(Color.WHITE);
        more.setOnClickListener(v -> {
            PopupMenu m = new PopupMenu(this, v);
            m.getMenu().add(0, 1, 0, "Preamp & Loudness");
            m.getMenu().add(0, 2, 1, "Balance");
            m.getMenu().add(0, 3, 2, "Limiter");
            m.setOnMenuItemClickListener(it -> {
                Dialogs.Svc g = () -> svc;
                if (it.getItemId() == 1) Dialogs.preampLoudness(this, g);
                else if (it.getItemId() == 2) Dialogs.balance(this, g);
                else Dialogs.limiter(this, g);
                return true;
            });
            m.show();
        });
        head.addView(title); head.addView(more);
        root.addView(head);

        // main row: EQ panel (left) + volume (right)
        LinearLayout row = new LinearLayout(this);
        row.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1));
        FrameHolder left = new FrameHolder(this);
        left.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1));
        panel5 = band5Panel(d);
        panel10 = band10Panel(d);
        panel10.setVisibility(View.GONE);
        left.addView(panel5); left.addView(panel10);
        row.addView(left);
        row.addView(volumePanel(d));
        root.addView(row);

        // tabs EQ / BASS / VIRT (toggle + colour like original), 10-band mode
        LinearLayout tabs = new LinearLayout(this);
        tabs.setGravity(Gravity.CENTER);
        tabEq = tab("EQ", EqService.ACTION_EQ_TOGGLE, "prefsEQOn1", true);
        tabBass = tab("BASS", EqService.ACTION_BASS_TOGGLE, "prefsBASSOn1", false);
        tabVirt = tab("VIRT", EqService.ACTION_VIRT_TOGGLE, "prefsVIRTOn1", false);
        mode10 = new Button(this);
        mode10.setText(Build.VERSION.SDK_INT >= 28 ? "10-band: OFF" : "10-band (Android 9+)");
        mode10.setEnabled(Build.VERSION.SDK_INT >= 28);
        mode10.setOnClickListener(v -> toggle10());
        tabs.addView(tabEq); tabs.addView(tabBass); tabs.addView(tabVirt); tabs.addView(mode10);
        root.addView(tabs);
        setContentView(root);

        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onResume() { super.onResume(); refreshVolume(); }
    @Override protected void onDestroy() { super.onDestroy(); try { unbindService(conn); } catch (Exception ignored) {} }

    // small FrameLayout alias so imports stay short
    static class FrameHolder extends android.widget.FrameLayout { FrameHolder(Context c) { super(c); } }

    private Button tab(String label, String action, String key, boolean def) {
        Button b = new Button(this);
        b.setText(label); b.setBackgroundColor(Color.TRANSPARENT);
        b.setTextColor(onPrefs.getBoolean(key, def) ? GREEN : Color.WHITE);
        b.setOnClickListener(v -> {
            startService(new Intent(this, EqService.class).setAction(action));
            boolean now = !onPrefs.getBoolean(key, def);      // service flips the same pref
            b.setTextColor(now ? GREEN : Color.WHITE);
        });
        return b;
    }

    // ----- 5-band + bass + virt -----
    private LinearLayout band5Panel(float d) {
        LinearLayout p = new LinearLayout(this);
        p.setGravity(Gravity.CENTER);
        int h = Cfg.viewHeight;
        p.addView(col("60Hz", h, pos.getInt("prefsEQ60", h / 2), "prefsEQ60", true, v -> { if (svc != null) svc.set60(v); }));
        p.addView(col("230Hz", h, pos.getInt("prefsEQ230", h / 2), "prefsEQ230", true, v -> { if (svc != null) svc.set230(v); }));
        p.addView(col("910Hz", h, pos.getInt("prefsEQ910", h / 2), "prefsEQ910", true, v -> { if (svc != null) svc.set910(v); }));
        p.addView(col("3kHz", h, pos.getInt("prefsEQ3", h / 2), "prefsEQ3", true, v -> { if (svc != null) svc.set3k(v); }));
        p.addView(col("14kHz", h, pos.getInt("prefsEQ14", h / 2), "prefsEQ14", true, v -> { if (svc != null) svc.set14k(v); }));
        p.addView(col("BASS", 1000, pos.getInt("BassLevel", 0), "BassLevel", false, v -> { if (svc != null) svc.setBass(v); }));
        p.addView(col("VIRT", 1000, pos.getInt("VirtLevel", 0), "VirtLevel", false, v -> { if (svc != null) svc.setVirt(v); }));
        return p;
    }
    private interface IntCb { void on(int v); }

    private LinearLayout col(String name, int max, int value, String key, boolean showDb, IntCb cb) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1));
        TextView val = new TextView(this); val.setTextColor(GREEN); val.setGravity(Gravity.CENTER);
        TextView nm = new TextView(this); nm.setText(name); nm.setTextColor(Color.WHITE); nm.setTextSize(11); nm.setGravity(Gravity.CENTER);
        VerticalSeekBar b = new VerticalSeekBar(this);
        b.setMax(max); b.setProgress(value);
        val.setText(showDb ? EqService.bandLabel(value) : String.valueOf(value));
        b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                cb.on(p); pos.edit().putInt(key, p).apply();
                val.setText(showDb ? EqService.bandLabel(p) : String.valueOf(p));
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        c.addView(val);
        c.addView(b, new LinearLayout.LayoutParams(-2, 0, 1));
        c.addView(nm);
        return c;
    }

    // ----- 10-band (DynamicsProcessing). Range -15..+15 dB, 0.1 dB steps. [range INFERRED] -----
    private LinearLayout band10Panel(float d) {
        LinearLayout p = new LinearLayout(this);
        p.setGravity(Gravity.CENTER);
        String[] names = {"32", "64", "125", "250", "500", "1k", "2k", "4k", "8k", "16k"};
        String saved = getSharedPreferences("eq10_save_prefs", 0).getString("eq10_save_prefs", "");
        if (!saved.isEmpty()) {
            String[] sp = saved.split(",");
            for (int i = 0; i < 10 && i < sp.length; i++) try { Cfg.bands10[i] = Float.parseFloat(sp[i]); } catch (Exception ignored) {}
        }
        for (int i = 0; i < 10; i++) {
            final int idx = i;
            int prog = Math.round(Cfg.bands10[i] * 10f) + 150;
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
            c.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1));
            TextView val = new TextView(this); val.setTextColor(GREEN); val.setTextSize(10); val.setGravity(Gravity.CENTER);
            val.setText(String.format("%.1f", Cfg.bands10[i]));
            TextView nm = new TextView(this); nm.setText(names[i]); nm.setTextColor(Color.WHITE); nm.setTextSize(10); nm.setGravity(Gravity.CENTER);
            VerticalSeekBar b = new VerticalSeekBar(this);
            b.setMax(300); b.setProgress(prog);
            b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int pr, boolean u) {
                    Cfg.bands10[idx] = (pr - 150) / 10f;
                    val.setText(String.format("%.1f", Cfg.bands10[idx]));
                    if (svc != null) svc.dpEqApply(Cfg.bands10);
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {
                    StringBuilder sb = new StringBuilder();
                    for (float f : Cfg.bands10) sb.append(f).append(",");
                    getSharedPreferences("eq10_save_prefs", 0).edit().putString("eq10_save_prefs", sb.toString()).apply();
                }
            });
            c.addView(val); c.addView(b, new LinearLayout.LayoutParams(-2, 0, 1)); c.addView(nm);
            p.addView(c);
        }
        return p;
    }

    private void toggle10() {
        boolean on = !Cfg.tenBand;
        Cfg.tenBand = on;                                       // set first so the service sees it
        startService(new Intent(this, EqService.class).setAction(on ? EqService.ACTION_SET_EQ10 : EqService.ACTION_RELAISE_EQ10));
        panel5.setVisibility(on ? View.GONE : View.VISIBLE);
        panel10.setVisibility(on ? View.VISIBLE : View.GONE);
        mode10.setText(on ? "10-band: ON" : "10-band: OFF");
    }

    // ----- volume (vertical slider + lock) -----
    private LinearLayout volumePanel(float d) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setLayoutParams(new LinearLayout.LayoutParams((int) (90 * d), -1));
        volText = new TextView(this); volText.setTextColor(Color.WHITE); volText.setGravity(Gravity.CENTER);
        volBar = new VerticalSeekBar(this);
        volBar.setMax(am.getStreamMaxVolume(3));
        volBar.setProgress(am.getStreamVolume(3));
        volBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                am.setStreamVolume(3, p, 0);
                volText.setText(String.format("VOLUME %02d", p));
                if (EqService.volumeLock) EqService.lockedVolume = p;
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        CheckBox lock = new CheckBox(this);
        lock.setText("Lock"); lock.setTextColor(Color.WHITE);
        lock.setOnCheckedChangeListener((b, on) -> { if (svc != null) svc.setVolumeLock(on); });
        v.addView(volText); v.addView(volBar, new LinearLayout.LayoutParams(-2, 0, 1)); v.addView(lock);
        refreshVolume();
        return v;
    }
    private void refreshVolume() {
        if (volBar == null) return;
        volBar.setProgress(am.getStreamVolume(3));
        volText.setText(String.format("VOLUME %02d", am.getStreamVolume(3)));
    }
}
