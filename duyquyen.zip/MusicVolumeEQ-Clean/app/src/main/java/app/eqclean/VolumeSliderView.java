package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Vertical volume slider: rounded card, ticks both sides, big green thumb, 0..100 labels on the left. */
public class VolumeSliderView extends View {
    public interface Listener { void onFraction(float f); }
    private float frac = 0f;
    private boolean dragging = false;
    private Listener listener;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d;

    public VolumeSliderView(Context c) { super(c); d = c.getResources().getDisplayMetrics().density; }
    public void setListener(Listener l) { listener = l; }
    public boolean isDragging() { return dragging; }
    public void setFraction(float f) { frac = Math.max(0f, Math.min(1f, f)); invalidate(); }

    private float cardLeft() { return getWidth() - 92 * d; }
    private float top() { return 40 * d; }
    private float bottom() { return getHeight() - 40 * d; }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cl = cardLeft(), cx = cl + 46 * d, tp = top(), bt = bottom();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1E1E1E);
        rf.set(cl, 0, w, h);
        c.drawRoundRect(rf, 28 * d, 28 * d, p);
        // track
        p.setColor(0xFF2B2B2D);
        rf.set(cx - 7 * d, tp - 14 * d, cx + 7 * d, bt + 14 * d);
        c.drawRoundRect(rf, 7 * d, 7 * d, p);
        // ticks + labels
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(0xFF77777A); t.setStrokeWidth(2f * d);
        Paint tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        tx.setColor(0xFF9A9A9A); tx.setTextSize(16 * d); tx.setFakeBoldText(true); tx.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i <= 20; i++) {
            float y = bt - (bt - tp) * i / 20f;
            boolean major = i % 5 == 0, mid = i % 10 == 0 || major;
            float len = major ? 27 * d : 11 * d;
            c.drawLine(cx - 12 * d - len, y, cx - 12 * d, y, t);
            c.drawLine(cx + 12 * d, y, cx + 12 * d + len, y, t);
            if (i % 4 == 0) c.drawText(String.valueOf(i * 5), cl / 2f, y + 6 * d, tx);
        }
        // thumb
        float ty = bt - (bt - tp) * frac;
        p.setColor(0x33000000); c.drawCircle(cx, ty + 3 * d, 19 * d, p);
        p.setColor(0xFFA5D6A7); c.drawCircle(cx, ty, 19 * d, p);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: dragging = true; if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            case MotionEvent.ACTION_MOVE: {
                float f = (bottom() - e.getY()) / (bottom() - top());
                frac = Math.max(0f, Math.min(1f, f));
                invalidate();
                if (listener != null) listener.onFraction(frac);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: dragging = false; return true;
        }
        return super.onTouchEvent(e);
    }
}
