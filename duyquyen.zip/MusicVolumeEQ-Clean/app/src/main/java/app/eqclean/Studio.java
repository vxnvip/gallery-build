package app.eqclean;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

/**
 * "Studio" theme built entirely in code. Every number below comes from the original Studio resources
 * (colors.xml / dimens.xml / *_studio.xml drawables). Only the bitmap artwork (png) is still loaded from res/drawable.
 */
final class Studio {
    static final int CYAN = 0xFF6DE5FF;      // plava_studio
    static final int WHITE = 0xFFFFFFFF;     // bijela
    static final int BLACK = 0xFF000000;
    static final int PANEL = 0xFF191C1B;     // podlogaeq inner fill
    static final int RING = 0xFF5D5D5D;      // circle_color of the knobs

    // dimens.xml (portrait)
    static final float EQ_TEXT = 9f;         // eq_text
    static final float EQBAR_TEXT = 12f;     // eqbar_text
    static final float TITLE_TEXT = 12f;     // eqnaslov_text
    static final float BUTTON_TEXT = 11f;    // button_text
    static final float ONOFF_W = 64f, ONOFF_H = 29f;
    static final float FWDREV2 = 60f;
    static final float WHEEL = 88f;
    static final float PRESET_W = 98f, PRESET_H = 28f;
    static final float EQ_MARGIN_TOP = 3f;

    private Studio() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------ backgrounds
    /** back_studio.xml: bg_studio.png tiled. */
    static Drawable background(Context c) {
        Bitmap b = BitmapFactory.decodeResource(c.getResources(), R.drawable.bg_studio);
        BitmapDrawable d = new BitmapDrawable(c.getResources(), b);
        d.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        d.setDither(true);
        return d;
    }

    /** sjena.xml: transparent (bottom) -> black (top), 3dp under the toolbar. */
    static View shadow(Context c) {
        View v = new View(c);
        v.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0x00000000, 0x80000000, 0xFF000000}));
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(c, 3)));
        return v;
    }

    /** podloga.xml / podlogaeq.xml: flat rounded panel. */
    static Drawable panel(Context c, int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, 5));
        return g;
    }

    /** podloga_preset_studio.xml: black box, 0.5dp white stroke, radius 3dp. */
    static Drawable presetBox(Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(BLACK);
        g.setStroke(Math.max(1, dp(c, 0.5f)), WHITE);
        g.setCornerRadius(dp(c, 3));
        return g;
    }

    // ------------------------------------------------------------------ toolbar
    /** 48dp black bar with the Studio logo on the left; callers add icons (see addAction). */
    static LinearLayout toolbar(Context c) {
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(BLACK);
        bar.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(c, 48)));
        ImageView logo = new ImageView(c);
        logo.setImageResource(R.drawable.logo_toolbar_studio);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(c, 8);
        bar.addView(logo, lp);
        bar.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 1));
        return bar;
    }

    static void addAction(LinearLayout bar, View icon, View.OnClickListener l) {
        icon.setOnClickListener(l);
        bar.addView(icon, new LinearLayout.LayoutParams(dp(bar.getContext(), 44), dp(bar.getContext(), 48)));
    }

    // ------------------------------------------------------------------ text
    static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    /** Column of labels that share the height by weight (dB / volume scales). */
    static LinearLayout scale(Context c, String[] labels, float[] weights, int padTopDp, int padBottomDp) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(c, padTopDp), 0, dp(c, padBottomDp));
        for (int i = 0; i < labels.length; i++) {
            TextView t = text(c, labels[i], EQ_TEXT, WHITE);
            t.setGravity(Gravity.CENTER);
            t.setIncludeFontPadding(false);
            col.addView(t, new LinearLayout.LayoutParams(-2, 0, weights[i]));
        }
        return col;
    }

    // ------------------------------------------------------------------ buttons
    /** onoff_studio.xml: png switch (on_studio when pressed/checked, off_studio otherwise). */
    static ToggleButton imageSwitch(Context c, int onRes, int offRes) {
        ToggleButton t = new ToggleButton(c);
        t.setTextOn("");
        t.setTextOff("");
        t.setText("");
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, c.getDrawable(onRes));
        s.addState(new int[]{android.R.attr.state_checked}, c.getDrawable(onRes));
        s.addState(new int[]{}, c.getDrawable(offRes));
        t.setBackground(s);
        t.setStateListAnimator(null);
        return t;
    }

    static ToggleButton onOff(Context c) { return imageSwitch(c, R.drawable.on_studio, R.drawable.off_studio); }
    static ToggleButton band10Switch(Context c) { return imageSwitch(c, R.drawable.eq_on10_studio, R.drawable.eq_on5_studio); }

    /** buttonxml_studio.xml + toggle_color_studio.xml: small outlined text toggle. */
    static ToggleButton textToggle(Context c, String label) {
        ToggleButton t = new ToggleButton(c);
        t.setTextOn(label);
        t.setTextOff(label);
        t.setText(label);
        t.setAllCaps(false);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, BUTTON_TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, 0);
        t.setMinWidth(0);
        t.setMinimumWidth(0);
        t.setMinHeight(0);
        t.setMinimumHeight(0);
        t.setIncludeFontPadding(false);
        t.setStateListAnimator(null);
        t.setTextColor(new ColorStateList(
                new int[][]{{android.R.attr.state_pressed}, {android.R.attr.state_checked}, {}},
                new int[]{BLACK, CYAN, WHITE}));
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, box(c, CYAN, WHITE, 1f));
        s.addState(new int[]{android.R.attr.state_checked}, box(c, BLACK, CYAN, 0.5f));
        s.addState(new int[]{}, box(c, 0x00000000, 0xFF232424, 1f));
        t.setBackground(s);
        return t;
    }

    private static Drawable box(Context c, int fill, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        g.setCornerRadius(dp(c, 1));
        return g;
    }

    /** botuneqxml_studio.xml / botunvuxml_studio.xml: round png button with a pressed image. */
    static View imageButton(Context c, int normalRes, int pressedRes) {
        View v = new View(c);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, c.getDrawable(pressedRes));
        s.addState(new int[]{}, c.getDrawable(normalRes));
        v.setBackground(s);
        v.setClickable(true);
        return v;
    }
}
