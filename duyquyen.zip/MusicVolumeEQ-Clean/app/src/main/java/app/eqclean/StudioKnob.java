package app.eqclean;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Bass / Virtualizer knob. Layout numbers are the Studio ones: 88dp frame, roundknob_studio face with 3dp margin
 * (roundknob_press_studio while touched), arc from 130deg sweeping 279deg (end_angle 409), stroke 10, dashed 3/2,
 * track #5d5d5d, progress #ffffff, max 1000.
 */
public class StudioKnob extends View {
    public interface Listener { void onChange(int progress, boolean fromUser); }

    private static final float START = 130f, SWEEP = 279f;

    private final int size, faceSize;
    private final Bitmap face, facePress;
    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringFg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arc = new RectF();
    private final float radius;
    private int max = 1000, progress;
    private boolean pressed;
    private Listener listener;

    public StudioKnob(Context c) {
        super(c);
        size = Studio.dp(c, Studio.WHEEL);
        faceSize = Studio.dp(c, Studio.WHEEL - 6);
        face = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(c.getResources(), R.drawable.roundknob_studio), faceSize, faceSize, true);
        facePress = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(c.getResources(), R.drawable.roundknob_press_studio), faceSize, faceSize, true);
        radius = faceSize * 0.2927f;   // sits on the two inner arcs printed on the face art
        float stroke = Studio.dp(c, 10);
        for (Paint p : new Paint[]{ringBg, ringFg}) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(stroke);
            p.setPathEffect(new DashPathEffect(new float[]{3f, 2f}, 0f));
        }
        ringBg.setColor(Studio.RING);
        ringFg.setColor(Studio.WHITE);
    }

    public void setListener(Listener l) { listener = l; }
    public int getProgress() { return progress; }
    public void setMax(int m) { max = m; }

    /** Programmatic set (does not call the listener). */
    public void setProgress(int p) {
        p = Math.max(0, Math.min(max, p));
        if (p == progress) return;
        progress = p;
        invalidate();
    }

    /** Dimmed when the effect is switched off. */
    public void setActive(boolean on) { setAlpha(on ? 1f : 0.5f); }

    @Override protected void onMeasure(int ws, int hs) { setMeasuredDimension(size, size); }

    @Override protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        Bitmap f = pressed ? facePress : face;
        canvas.drawBitmap(f, cx - f.getWidth() / 2f, cy - f.getHeight() / 2f, bitmapPaint);
        arc.set(cx - radius, cy - radius, cx + radius, cy + radius);
        canvas.drawArc(arc, START, SWEEP, false, ringBg);
        float sw = SWEEP * progress / (float) max;
        if (sw > 0.1f) canvas.drawArc(arc, START, sw, false, ringFg);
    }

    private void touch(MotionEvent e) {
        float dx = e.getX() - getWidth() / 2f, dy = e.getY() - getHeight() / 2f;
        if (dx * dx + dy * dy < Studio.dp(getContext(), 6) * Studio.dp(getContext(), 6)) return;   // dead centre
        float ang = (float) Math.toDegrees(Math.atan2(dy, dx));
        if (ang < 0) ang += 360f;
        float rel = ang - START;
        if (rel < 0) rel += 360f;
        int p;
        if (rel <= SWEEP) p = Math.round(rel / SWEEP * max);
        else p = (rel - SWEEP) < (360f - SWEEP) / 2f ? max : 0;   // gap at the bottom snaps to the nearer end
        if (p != progress) {
            progress = p;
            invalidate();
            if (listener != null) listener.onChange(p, true);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pressed = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                touch(e);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                touch(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pressed = false;
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
