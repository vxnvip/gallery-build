package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.View;

/** Hexagon power button showing the current mode name. */
public class HexButton extends View {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float d;
    private String label = "EQ";
    private boolean on = true;
    public HexButton(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(2f * d);
        line.setPathEffect(new CornerPathEffect(3f * d));
        txt.setTextAlign(Paint.Align.CENTER); txt.setTypeface(Typeface.DEFAULT); txt.setTextSize(30f * d);
    }
    public void set(String label, boolean on) { this.label = label; this.on = on; invalidate(); }
    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), m = 2f * d;
        float l = m, r = w - m, t = m, b = h - m, cx = w / 2f;
        path.reset();
        path.moveTo(cx, t);
        path.lineTo(r, t + (b - t) * 0.25f);
        path.lineTo(r, t + (b - t) * 0.75f);
        path.lineTo(cx, b);
        path.lineTo(l, t + (b - t) * 0.75f);
        path.lineTo(l, t + (b - t) * 0.25f);
        path.close();
        int col = on ? 0xFFFFFFFF : 0xFF5A5D61;
        line.setColor(col); txt.setColor(col);
        c.drawPath(path, line);
        Paint.FontMetrics fm = txt.getFontMetrics();
        c.drawText(label, cx, h / 2f - (fm.ascent + fm.descent) / 2f, txt);
    }
}
