package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** 10-band curve (32 Hz .. 16 kHz, -15..+15 dB) in the Studio palette. Drag a point vertically. */
public class StudioCurve extends View {
    public interface Listener { void onBand(int index, float db, boolean fromUser); }

    public static final int BANDS = 10;
    public static final float RANGE = 15f;
    private static final String[] FREQ = {"32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K"};

    private final float[] db = new float[BANDS];
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint zero = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint guide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint value = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float d;
    private float left, right, top, bottom;
    private int active = -1;
    private Listener listener;

    public StudioCurve(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        grid.setColor(0xFF2A2D2C); grid.setStrokeWidth(1f);
        zero.setColor(0xFF5D5D5D); zero.setStrokeWidth(Math.max(1f, d));
        guide.setColor(0xFF1F2322); guide.setStrokeWidth(1f);
        line.setColor(Studio.CYAN); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(2f * d);
        line.setStrokeJoin(Paint.Join.ROUND); line.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        dot.setColor(Studio.CYAN);
        ring.setColor(Studio.WHITE); ring.setStyle(Paint.Style.STROKE); ring.setStrokeWidth(1.5f * d);
        label.setColor(Studio.WHITE); label.setTextSize(9f * d); label.setTextAlign(Paint.Align.CENTER);
        value.setColor(Studio.CYAN); value.setTextSize(9f * d); value.setTextAlign(Paint.Align.CENTER);
    }

    public void setListener(Listener l) { listener = l; }
    public float getBand(int i) { return db[i]; }
    public float[] getBands() { return db.clone(); }

    public void setBands(float[] v) {
        for (int i = 0; i < BANDS && i < v.length; i++) db[i] = clamp(v[i]);
        invalidate();
    }

    public void setBand(int i, float v) { db[i] = clamp(v); invalidate(); }

    public void setActive(boolean on) { setAlpha(on ? 1f : 0.4f); }

    private static float clamp(float v) { return Math.max(-RANGE, Math.min(RANGE, v)); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        left = 30f * d; right = w - 12f * d; top = 16f * d; bottom = h - 20f * d;
        fill.setShader(new LinearGradient(0, top, 0, bottom, 0x556DE5FF, 0x006DE5FF, Shader.TileMode.CLAMP));
    }

    private float xOf(int i) { return left + (i + 0.5f) * (right - left) / BANDS; }
    private float yOf(float v) { return top + (RANGE - v) / (2f * RANGE) * (bottom - top); }

    @Override protected void onDraw(Canvas c) {
        // dB grid + labels
        for (int g = -15; g <= 15; g += 5) {
            float y = yOf(g);
            c.drawLine(left, y, right, y, g == 0 ? zero : grid);
            label.setTextAlign(Paint.Align.RIGHT);
            c.drawText(g > 0 ? "+" + g : String.valueOf(g), left - 5f * d, y + 3f * d, label);
        }
        label.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < BANDS; i++) {
            c.drawLine(xOf(i), top, xOf(i), bottom, guide);
            c.drawText(FREQ[i], xOf(i), getHeight() - 6f * d, label);
        }
        // smooth curve
        path.reset();
        path.moveTo(xOf(0), yOf(db[0]));
        for (int i = 1; i < BANDS; i++) {
            float x0 = xOf(i - 1), y0 = yOf(db[i - 1]), x1 = xOf(i), y1 = yOf(db[i]);
            float mx = (x0 + x1) / 2f;
            path.cubicTo(mx, y0, mx, y1, x1, y1);
        }
        Path area = new Path(path);
        area.lineTo(xOf(BANDS - 1), bottom);
        area.lineTo(xOf(0), bottom);
        area.close();
        c.drawPath(area, fill);
        c.drawPath(path, line);
        // points + values
        for (int i = 0; i < BANDS; i++) {
            float x = xOf(i), y = yOf(db[i]);
            c.drawCircle(x, y, (i == active ? 8f : 6f) * d, dot);
            if (i == active) c.drawCircle(x, y, 10f * d, ring);
            int r = Math.round(db[i]);
            String s = r > 0 ? "+" + r : String.valueOf(r);
            float ty = y - 12f * d < top ? y + 20f * d : y - 12f * d;
            c.drawText(s, x, ty, value);
        }
    }

    private void drag(MotionEvent e) {
        if (active < 0) return;
        float v = RANGE - (e.getY() - top) / (bottom - top) * 2f * RANGE;
        v = Math.round(clamp(v) * 2f) / 2f;                 // 0.5 dB steps
        if (v != db[active]) {
            db[active] = v;
            invalidate();
            if (listener != null) listener.onBand(active, v, true);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                float colW = (right - left) / BANDS;
                int i = (int) ((e.getX() - left) / colW);
                if (i < 0 || i >= BANDS) return false;
                active = i;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                drag(e);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                drag(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                active = -1;
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
