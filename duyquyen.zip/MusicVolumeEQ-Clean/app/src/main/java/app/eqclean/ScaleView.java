package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** dB scale labels shown to the left of the spectrum card (decorative, evenly spaced like the original). */
public class ScaleView extends View {
    private static final String[] L = {"+38", "+30", "+20", "+10", "+7", "+4", "+2", "0", "-2", "-4", "-7", "-10", "-20", "-30", "-38"};
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d, top, bottom;
    public ScaleView(Context c, float topDp, float bottomDp) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        top = topDp * d; bottom = bottomDp * d;
        p.setColor(0xFF9A9A9A); p.setTextSize(15 * d); p.setFakeBoldText(true); p.setTextAlign(Paint.Align.CENTER);
    }
    @Override protected void onDraw(Canvas c) {
        float h = getHeight() - top - bottom;
        for (int i = 0; i < L.length; i++) c.drawText(L[i], getWidth() / 2f, top + h * i / (L.length - 1) + 5 * d, p);
    }
}
