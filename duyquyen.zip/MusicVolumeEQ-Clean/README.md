# Music Volume EQ - clean project

Clean Gradle project. UI is programmatic (`MainActivity` + custom views `EqView`, `KnobView`, `PillSwitch`, `IconView`, `VuView`), two screens. Home (`MainActivity`): spectrum analyzer + EQ/BASS/VIRT toggles + vertical volume slider + EQ button. EQ page (`EqActivity`), laid out like the reference screenshot: EQUALIZER card with curve + `10 EQ` pill, PRESET card with BASS BOOST / VIRTUALIZER knobs and a VU button; the speaker icon opens volume/lock + Preamp/Balance/Limiter; the audio engine is `EqService` (port of `hr.podlanica.MusicVolumeEQ` 7.0).

## Build
Push to GitHub; Actions (`.github/workflows/build.yml`) produces `app-debug.apk`. Locally: JDK 17 + Android SDK 34, `gradle assembleDebug`.

## Audio port status
1:1 (same effects/params/math/prefs keys): Equalizer BassBoost, Virtualizer, LoudnessEnhancer (+500 ms re-apply),
DynamicsProcessing (10-band pre-EQ @ 32..16000 Hz, limiter, balance, preamp), device-type detection, session receiver.

NOT recoverable from the decompile - verify against the original APK on a device:
- `onStartCommand` body (decompiler failed) -> rebuilt from callers: STOP extra, EQ/BASS/VIRT toggle actions, SET/RELAISE_EQ10, START_STICKY.
- MBC band setter order (`setupMbc`): API wrapper classes were stripped; values assigned by type/value. Original never reached it from recoverable code.
- Per-headphone preset DB (SQLite `presets10`, AutoEQ) and volume-lock handler: not ported.
- Notification layout simplified.

## Stage 1 (original UI import) - status
Imported from the original 7.0 APK (apktool res + smali-recovered Java):
- res/: layouts, drawables, colors, dimens, integers, arrays, strings (app_strings.xml), styles of all 4 themes (Classic/Material/Studio/Flat). AdView tags removed.
- hr/podlanica views: EqualizerView, F14View, F14View_slider, F14View_c, F3View, F60View, F230View, F910View, BassView, VirtView, CircularSeekBar, CircularSeekBarBass, CircularSeekBarDialog.
  jadx failed on CircularSeekBarBass.f/g/onTouchEvent, CircularSeekBar.onTouchEvent and onSizeChanged of F3/F60/F230/F910/F14_c/Bass/Virt -> rebuilt by hand from smali.
- hr/podlanica/MusicVolumeEQ.java: shim forwarding the views' static hooks to EqService.
NOT done yet: activities (EqActivity/MainActivity still use the old programmatic UI), theme chooser, Preferences. Not compiled locally (no SDK in sandbox).

## Studio theme rebuilt in code (stage 2)
`MainActivity` and `EqActivity` no longer inflate XML. The Studio theme (activity_booster_studio, eq_studio, eq10_studio) is built
in Java with the same dp/sp/colour values: `Studio` (colours, drawables, toolbar, toggles, scales), `StudioSlider` (volume + 5 band sliders,
replaces F14View/F14View_slider), `StudioKnob` (bass/virtualizer, replaces CircularSeekBarBass), `StudioCurve` (10 band, replaces EqualizerView).
Only the png artwork (knob_studio, slider_studio, on/off_studio, botuneq/botunvu, logo, bg_studio ...) is still loaded from res/drawable.
The stage-1 XML layouts and hr.podlanica views are untouched and unused by the activities.

Inferred (not recoverable from the decompile): what the booster "screen" draws (spectrum bars from Visualizer FFT are used), the exact knob ring radius,
press-image timing, preset/VU dialogs, drawer actions (Settings / Rate are stubs). Portrait only. Not compiled here (no Android SDK): syntax checked with javac only.
