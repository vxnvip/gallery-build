/*
 * Copyright (c) 2019 EKA2L1 Team.
 * 
 * This file is part of EKA2L1 project.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SETTING
#define SETTING(name, variable, default_var)
#endif

SETTING(fps, fps, 60)
SETTING(time-delay, time_delay, 0)
SETTING(should-child-inherit-setting, child_inherit_setting, true)
SETTING(screen-rotation, screen_rotation, 0)
SETTING(screen-mode, screen_mode, -1)
SETTING(screen-upscale, screen_upscale, -1.0f)
SETTING(screen-upscale-method, screen_upscale_method, 0)
SETTING(filter-shader-path, filter_shader_path, "")
SETTING(t9-bypass-hack, t9_bypass_hack, false)

#ifdef SETTING
#undef SETTING
#endif