/*
 * Copyright (c) 2019 EKA2L1 Team
 * 
 * This file is part of EKA2L1 project.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <services/window/classes/dsa.h>
#include <services/window/classes/winbase.h>
#include <services/window/classes/wingroup.h>
#include <services/window/classes/winuser.h>
#include <services/window/screen.h>
#include <services/window/window.h>

#include <common/rgb.h>
#include <common/time.h>
#include <config/app_settings.h>
#include <config/config.h>
#include <drivers/itc.h>

#include <kernel/kernel.h>
#include <kernel/timing.h>
#include <thread>

namespace eka2l1::epoc {
    struct window_drawer_walker : public window_tree_walker {
        drivers::graphics_command_builder &builder_;
        std::uint32_t total_redrawed_;
        canvas_base *streaming_window_ = nullptr;
        bitmap_cache *bitmap_cache_ = nullptr;

        explicit window_drawer_walker(drivers::graphics_command_builder &builder)
            : builder_(builder)
            , total_redrawed_(0) {
        }

        bool do_it(window *win) {
            if (win->type != window_kind::client) {
                return false;
            }

            epoc::canvas_base *cv = reinterpret_cast<epoc::canvas_base*>(win);
            bitmap_cache_ = cv->client->get_ws().get_bitmap_cache();

            if (cv->can_be_physically_seen() && cv->surface_streaming()) {
                streaming_window_ = cv;
            }

            if (cv->draw(builder_))
                total_redrawed_++;

            return false;
        }
    };

    struct window_dsa_abort_walker: public window_tree_walker {
        std::int32_t reason_;

        explicit window_dsa_abort_walker(const std::int32_t reason)
            : reason_(reason) {
        }

        bool do_it(window *win) {
            if (win->type == window_kind::client) {
                canvas_base *user = reinterpret_cast<canvas_base*>(win);
                if (user->is_dsa_active()) {
                    std::vector<dsa*> dsa_residents = user->directs_;

                    for (std::size_t i = 0; i < dsa_residents.size(); i++) {
                        dsa_residents[i]->abort(reason_);
                    }
                }
            }

            return false;
        }
    };

    struct window_dsa_region_walker : public window_tree_walker {
        common::region region_;

        bool do_it(window *win) override {
            if (win->type == window_kind::client) {
                canvas_base *user = reinterpret_cast<canvas_base *>(win);
                if (user->is_dsa_active()) {
                    region_.add_region(user->visible_region);
                }
            }

            return false;
        }
    };

    bool focus_callback_free_check_func(screen::focus_change_callback &data) {
        return !data.second;
    }

    void focus_callback_free_func(screen::focus_change_callback &data) {
        data.second = nullptr;
    }

    bool screen_redraw_callback_free_check_func(screen::screen_redraw_callback &data) {
        return !data.second;
    }

    void screen_redraw_callback_free_func(screen::screen_redraw_callback &data) {
        data.second = nullptr;
    }

    bool screen_mode_change_callback_free_check_func(screen::screen_mode_change_callback &data) {
        return !data.second;
    }

    void screen_mode_change_callback_free_func(screen::screen_mode_change_callback &data) {
        data.second = nullptr;
    }

    screen::screen(const int number, epoc::config::screen &scr_conf, bool reserve_host_focus)
        : number(number)
        , ui_rotation(0)
        , refresh_rate(60)
        , display_scale_factor(1.0f)
        , logic_scale_factor_x(1.0f)
        , logic_scale_factor_y(1.0f)
        , requested_ui_scale_factor(-1.0f)
        , screen_texture(0)
        , dsa_texture(0)
        , disp_mode(display_mode::color16ma)
        , dsa_disp_mode(display_mode::color16ma)
        , dsa_disp_mode_initial(display_mode::color16ma)
        , last_vsync(0)
        , last_fps_check(0)
        , last_fps(0)
        , frame_passed_per_sec(0)
        , scr_config(scr_conf)
        , crr_mode(0)
        , physical_mode(0)
        , focus(nullptr)
        , default_owning_group(nullptr)
        , next(nullptr)
        , screen_buffer_chunk(nullptr)
        , flags_(FLAG_ORIENTATION_LOCK)
        , focus_callbacks(focus_callback_free_check_func, focus_callback_free_func)
        , screen_redraw_callbacks(screen_redraw_callback_free_check_func, screen_redraw_callback_free_func)
        , screen_mode_change_callbacks(screen_mode_change_callback_free_check_func, screen_mode_change_callback_free_func) {
        root = std::make_unique<epoc::window>(nullptr, this, nullptr);
        if (reserve_host_focus) {
            // The host launcher replaces the guest shell at normal priority. A group
            // sent to the back must stay behind it until the app brings itself forward.
            auto launcher = std::make_unique<window_group>(nullptr, this, root.get(), 0);
            launcher->set_receive_focus(true);
            host_launcher_group = std::move(launcher);
        }
        disp_mode = current_mode().disp_mode;
        dsa_disp_mode = current_mode().dsa_disp_mode;
        dsa_disp_mode_initial = current_mode().dsa_disp_mode;

        // A wsini can list several unrotated modes (P900 has 208x320 and 208x208); the
        // first one is the physical panel, the rest are alternative layouts.
        for (std::size_t i = 0; i < scr_config.modes.size(); i++) {
            if (scr_config.modes[i].rotation == 0) {
                physical_mode = static_cast<std::uint8_t>(i);
                break;
            }
        }

        if (scr_conf.auto_clear) {
            flags_ |= FLAG_AUTO_CLEAR_BACKGROUND;
        }
    }

    static void flip_screen_image(std::uint8_t *buffer, const std::uint32_t line_pitch, const std::uint32_t line_count) {
        std::uint8_t *pitcher = new std::uint8_t[line_pitch];

        for (std::size_t y = 0; y < line_count / 2; y++) {
            std::memcpy(pitcher, buffer + y * line_pitch, line_pitch);
            std::memmove(buffer + y * line_pitch, buffer + (line_count - y - 1) * line_pitch, line_pitch);
            std::memmove(buffer + (line_count - y - 1) * line_pitch, pitcher, line_pitch);
        }

        delete pitcher;
    }

    void screen::reset_dsa_depth_guess() {
        dsa_disp_mode = dsa_disp_mode_initial;
        if (!screen_buffer_chunk) {
            return;
        }

        if (dsa_disp_mode != disp_mode) {
            const eka2l1::vec2 buffer_size = current_mode().size;
            const std::size_t narrow_bytes = epoc::get_byte_width(buffer_size.x,
                epoc::get_bpp_from_display_mode(dsa_disp_mode)) * buffer_size.y;
            const std::size_t wide_bytes = epoc::get_byte_width(buffer_size.x,
                epoc::get_bpp_from_display_mode(disp_mode)) * buffer_size.y;
            if (wide_bytes > narrow_bytes) {
                std::fill(screen_buffer_ptr() + narrow_bytes, screen_buffer_ptr() + wide_bytes,
                    SCREEN_BUFFER_UNTOUCHED_FILL);
            }
        }
        if (direct_framebuffer_mapped) {
            direct_framebuffer.reset(screen_buffer_ptr(), screen_buffer_byte_width(dsa_disp_mode), current_mode().size.y);
        }
    }

    void screen::mark_direct_framebuffer_mapped() {
        if (direct_framebuffer_mapped || !screen_buffer_chunk) {
            return;
        }

        direct_framebuffer_mapped = true;

        direct_framebuffer.reset(screen_buffer_ptr(), screen_buffer_byte_width(dsa_disp_mode), current_mode().size.y);
    }

    bool screen::update_direct_framebuffer() {
        return screen_buffer_chunk && direct_framebuffer.update(screen_buffer_ptr(),
            screen_buffer_byte_width(dsa_disp_mode), current_mode().size.y);
    }

    void screen::present_framebuffer(drivers::graphics_driver *driver, kernel_system *kern,
        const eka2l1::rect *symbian_rects, const std::uint32_t rect_count) {
        // Update the DSA screen texture
        const epoc::config::screen_mode &mode_info = current_mode();
        const eka2l1::vec2 screen_size = mode_info.size;

        const char *data_ptr = reinterpret_cast<const char *>(screen_buffer_ptr());

        // WINDOWMODE tells us what WSERV composes in, not what a direct screen
        // access client writes into the panel buffer. Most EKA1 guests take the
        // reported mode and write that many bytes per pixel, but a few hardcode
        // 16-bit pixels and would be shredded by a 32-bit upload. The two cases
        // are distinguishable: at 16 bits the guest only ever fills the first
        // half of the (always 32-bit sized) buffer. Start narrow and widen the
        // moment anything lands in the upper half.
        const bool dsa_depth_changed = promote_dsa_depth_if_deep_pixels_written();

        // Every writer lays its rows out at the pitch the screen reports, so read
        // it back with that one. Only a 32-bit framebuffer is ever padded.
        const std::uint32_t bits_per_pixel = epoc::get_bpp_from_display_mode(dsa_disp_mode);
        const std::size_t tight_screen_pitch = mode_info.size.x * sizeof(std::uint32_t);
        const std::size_t framebuffer_pitch = screen_buffer_byte_width(dsa_disp_mode);
        const std::size_t screen_pitch = common::max(framebuffer_pitch, tight_screen_pitch);
        const std::size_t buffer_size = screen_pitch * mode_info.size.y;
        const std::size_t pixels_per_line = (screen_pitch != tight_screen_pitch)
            ? screen_pitch / sizeof(std::uint32_t)
            : 0;

        std::unique_lock<std::mutex> guard(screen_mutex);

        if (dsa_depth_changed && dsa_texture) {
            // The transfer texture was made for the old depth; drop it and let the
            // block below build one that matches.
            drivers::graphics_command_builder discard_builder;
            discard_builder.destroy_bitmap(dsa_texture);

            drivers::command_list discard_list = discard_builder.retrieve_command_list();
            driver->submit_command_list(discard_list);

            dsa_texture = 0;
        }

        if (!dsa_texture) {
            const int max_square_width = common::max<int>(screen_size.x, screen_size.y);

            kern->unlock();
            guard.unlock();

            drivers::handle bitmap_handle = drivers::create_bitmap(driver, eka2l1::vec2(max_square_width, max_square_width), bits_per_pixel);

            kern->lock();
            guard.lock();

            dsa_texture = bitmap_handle;
        }

        if (!screen_texture) {
            set_screen_mode(nullptr, driver, crr_mode);
        }

        eka2l1::drivers::filter_option filter = (kern->get_config()->nearest_neighbor_filtering ? eka2l1::drivers::filter_option::nearest : eka2l1::drivers::filter_option::linear);
        drivers::graphics_command_builder builder;

        // Only one rectangle for now!
        builder.update_bitmap(dsa_texture, data_ptr, buffer_size, { 0, 0 }, screen_size,
            pixels_per_line);

        // NOTE: This is a hack for some apps that dont fill alpha
        // TODO: Figure out why or better solution (maybe the display mode is not really correct?)
        switch (dsa_disp_mode) {
        case epoc::display_mode::color16m:
        case epoc::display_mode::color16mu:
        case epoc::display_mode::color16ma:
            builder.set_swizzle(dsa_texture, drivers::channel_swizzle::red, drivers::channel_swizzle::green,
                drivers::channel_swizzle::blue, drivers::channel_swizzle::one);

            break;

        default:
            break;
        }

        const float rotation_draw = is_framebuffer_upside_down() ? 180.0f : 0.0f;

        builder.bind_bitmap(screen_texture);
        builder.set_feature(drivers::graphics_feature::clipping, false);
        builder.set_texture_filter(dsa_texture, true, filter);
        builder.set_texture_filter(dsa_texture, false, filter);

        auto draw_area = [&](const eka2l1::rect &source_rect) {
            eka2l1::rect dest_rect = source_rect;
            if (rotation_draw != 0.0f) {
                dest_rect.top = screen_size - source_rect.top;
            }
            dest_rect.scale(display_scale_factor);
            builder.draw_bitmap(dsa_texture, 0, dest_rect, source_rect, eka2l1::vec2(0, 0), rotation_draw, 0);
        };

        auto draw_rows = [&](int first, int end) {
            draw_area(eka2l1::rect(eka2l1::vec2(0, first), eka2l1::vec2(screen_size.x, end - first)));
        };

        if (direct_framebuffer_mapped) {
            const auto &rows = direct_framebuffer.written_rows();
            for (int y = 0; y < static_cast<int>(rows.size());) {
                if (!rows[y]) {
                    ++y;
                    continue;
                }
                const int first = y++;
                while (y < static_cast<int>(rows.size()) && rows[y]) {
                    ++y;
                }
                draw_rows(first, y);
            }
        } else if (symbian_rects && rect_count) {
            // A DSA client only writes inside its region; elsewhere the buffer holds stale pixels
            // that must not cover the windows now on top of it.
            std::vector<eka2l1::rect> clip_rects;
            if (active_dsa_count_ > 0) {
                window_dsa_region_walker dsa_walker;
                root->walk_tree(&dsa_walker, epoc::window_tree_walk_style::bonjour_children);
                clip_rects = std::move(dsa_walker.region_.rects_);
            } else {
                clip_rects.push_back(eka2l1::rect(eka2l1::vec2(0, 0), screen_size));
            }

            for (std::uint32_t i = 0; i < rect_count; i++) {
                eka2l1::rect area = symbian_rects[i];
                area.transform_from_symbian_rectangle();

                for (const eka2l1::rect &clip : clip_rects) {
                    const eka2l1::rect clipped = area.intersect(clip);
                    if (clipped.valid()) {
                        draw_area(clipped);
                    }
                }
            }
        } else {
            draw_rows(0, screen_size.y);
        }
        builder.bind_bitmap(0);

        drivers::command_list retrieved = builder.retrieve_command_list();
        driver->submit_command_list(retrieved);

        if (((flags_ & epoc::screen::FLAG_SCREEN_UPSCALE_FACTOR_LOCK) == 0) && sync_screen_buffer) {
            // The app/game updates normally, try to avoid upscaling it
            // Sometimes UI are mixed in, and these syncs need to sync UI's data too!
            // Automatically flag and save this settings
            if (focus) {
                focus->saved_setting.screen_upscale_method = 1;
                restore_from_config(driver, focus->saved_setting, nullptr);
                try_change_display_rescale(driver, display_scale_factor);
            }
        }

        fire_screen_redraw_callbacks(true);
    }

    bool screen::promote_dsa_depth_if_deep_pixels_written() {
        if (dsa_disp_mode == disp_mode) {
            return false;
        }

        if (!screen_buffer_chunk) {
            return false;
        }

        // The buffer is always allocated for the composed mode, so a guest writing at the
        // narrower depth leaves the tail of every frame untouched. Anything in there can
        // only have come from the guest: the WSERV write-back honours dsa_disp_mode too.
        const eka2l1::vec2 buffer_size = current_mode().size;
        const std::size_t narrow_bytes = epoc::get_byte_width(buffer_size.x,
            epoc::get_bpp_from_display_mode(dsa_disp_mode)) * buffer_size.y;
        const std::size_t wide_bytes = epoc::get_byte_width(buffer_size.x,
            epoc::get_bpp_from_display_mode(disp_mode)) * buffer_size.y;

        if (wide_bytes <= narrow_bytes) {
            dsa_disp_mode = disp_mode;
            return true;
        }

        const std::uint8_t *tail = screen_buffer_ptr() + narrow_bytes;
        const std::size_t tail_size = wide_bytes - narrow_bytes;

        for (std::size_t i = 0; i < tail_size; i++) {
            if (tail[i] != SCREEN_BUFFER_UNTOUCHED_FILL) {
                LOG_INFO(SERVICE_WINDOW, "Direct screen access writes {} bit pixels, switching the framebuffer format",
                    epoc::get_bpp_from_display_mode(disp_mode));

                dsa_disp_mode = disp_mode;
                return true;
            }
        }

        return false;
    }

    void screen::sync_screen_buffer_data(drivers::graphics_driver *driver) {
        std::uint8_t *buffer_ptr = screen_buffer_ptr();
        const config::screen_mode &crrmode = current_mode();
        const std::uint32_t bits_per_pixel = epoc::get_bpp_from_display_mode(dsa_disp_mode);
        const std::uint32_t tight_pitch = epoc::get_byte_width(crrmode.size.x, bits_per_pixel);
        const std::uint32_t framebuffer_pitch = screen_buffer_byte_width(dsa_disp_mode);

        if (framebuffer_pitch == tight_pitch) {
            drivers::read_bitmap(driver, screen_texture, eka2l1::point(0, 0), eka2l1::object_size(crrmode.size),
                bits_per_pixel, buffer_ptr);

            if (is_framebuffer_upside_down()) {
                flip_screen_image(buffer_ptr, tight_pitch, crrmode.size.y);
            }
            if (direct_framebuffer_mapped) {
                direct_framebuffer.acknowledge(buffer_ptr);
            }
            return;
        }

        std::vector<std::uint8_t> tight_buffer(tight_pitch * crrmode.size.y);
        drivers::read_bitmap(driver, screen_texture, eka2l1::point(0, 0), eka2l1::object_size(crrmode.size),
            bits_per_pixel, tight_buffer.data());

        if (is_framebuffer_upside_down()) {
            flip_screen_image(tight_buffer.data(), tight_pitch, crrmode.size.y);
        }

        for (std::int32_t y = 0; y < crrmode.size.y; y++) {
            std::memcpy(buffer_ptr + y * framebuffer_pitch, tight_buffer.data() + y * tight_pitch, tight_pitch);
        }
        if (direct_framebuffer_mapped) {
            direct_framebuffer.acknowledge(buffer_ptr);
        }
    }

    bool screen::redraw(drivers::graphics_command_builder &builder, const bool need_bind) {
        if (need_update_visible_regions()) {
            recalculate_visible_regions();
        }

        if (need_bind) {
            builder.bind_bitmap(screen_texture);
        }

        builder.set_feature(eka2l1::drivers::graphics_feature::cull, false);
        builder.set_feature(eka2l1::drivers::graphics_feature::depth_test, false);
        builder.set_feature(eka2l1::drivers::graphics_feature::blend, false);
        builder.set_feature(eka2l1::drivers::graphics_feature::clipping, false);
        builder.set_feature(eka2l1::drivers::graphics_feature::stencil_test, false);

        const bool full_redraw = flags_ & FLAG_SERVER_REDRAW_PENDING;
        region_redraw_active_ = !full_redraw && !server_redraw_region_.empty();
        if (region_redraw_active_) {
            // Windows replay their stores over what is on screen, clipped to the region.
            flags_ |= FLAG_SERVER_REDRAW_PENDING;
        }

        builder.clear(eka2l1::vecx<float, 6>({ 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 }), drivers::draw_buffer_bit_depth_buffer
            | drivers::draw_buffer_bit_stencil_buffer | (full_redraw ? drivers::draw_buffer_bit_color_buffer : 0));

        builder.blend_formula(drivers::blend_equation::add, drivers::blend_equation::add,
            drivers::blend_factor::frag_out_alpha, drivers::blend_factor::one_minus_frag_out_alpha,
            drivers::blend_factor::one, drivers::blend_factor::one);

        // Walk through the window tree in recursive order, and do draw
        // We dont care about visible regions. Nowadays, detect visible region to reduce pixel plotting is
        // just not really worth the time, since GPU draws so fast. Symbian code still has it though.
        window_drawer_walker adrawwalker(builder);
        root->walk_tree_back_to_front(&adrawwalker);

        if (adrawwalker.bitmap_cache_) {
            adrawwalker.bitmap_cache_->flush_retired(builder);
        }

        // Done! Unbind and submit this to the driver
        builder.bind_bitmap(0);

        // Remove pending draw flags...
        flags_ &= ~(FLAG_SERVER_REDRAW_PENDING | FLAG_CLIENT_REDRAW_PENDING);
        server_redraw_region_.make_empty();
        region_redraw_active_ = false;

        // Keep consuming visible decoder mailboxes at display boundaries.
        if (adrawwalker.streaming_window_) {
            adrawwalker.streaming_window_->canvas_base::try_update(nullptr);
        }

        return adrawwalker.total_redrawed_;
    }

    void screen::redraw(drivers::graphics_driver *driver) {
        if (!screen_texture) {
            set_screen_mode(nullptr, driver, crr_mode);
        }

        // Make command list first, and bind our screen bitmap
        drivers::graphics_command_builder builder;
        const bool performed = redraw(builder, true);
    
        eka2l1::drivers::command_list retrieved = builder.retrieve_command_list();
        driver->submit_command_list(retrieved);

        if (performed && sync_screen_buffer && (display_scale_factor == 1.0f)) {
            sync_screen_buffer_data(driver);
        }

        fire_screen_redraw_callbacks(false);
    }

    void screen::deinit(drivers::graphics_driver *driver) {
        // Make command list first, and bind our screen bitmap
        if (driver) {
            drivers::graphics_command_builder builder;

            if (dsa_texture) {
                builder.destroy_bitmap(dsa_texture);
            }

            if (screen_texture) {
                builder.destroy_bitmap(screen_texture);
            }

            eka2l1::drivers::command_list retrieved = builder.retrieve_command_list();
            driver->submit_command_list(retrieved);
        }
    }

    const void screen::get_max_num_colors(int &colors, int &greys) const {
        greys = 0;
        colors = get_num_colors_from_display_mode(disp_mode);
        if (!is_display_mode_color(disp_mode)) {
            greys = colors;
            colors = 0;
        }
    }

    void screen::resize(drivers::graphics_driver *driver, const eka2l1::vec2 &new_size) {
        // Make command list first, and bind our screen bitmap
        drivers::graphics_command_builder builder;
        bool need_bind = true;

        eka2l1::vec2 screen_size_scaled = current_mode().size * display_scale_factor;

        if (!screen_texture) {
            // Create new one! Its content is undefined until something draws over it, and a
            // fullscreen app that leaves part of the screen alone (the control pane area, for
            // instance) would present that leftover memory as garbage. Ask for a clearing redraw.
            screen_texture = drivers::create_bitmap(driver, screen_size_scaled, 32);
            flags_ |= FLAG_SERVER_REDRAW_PENDING;
        } else {
            builder.bind_bitmap(screen_texture);
            builder.resize_bitmap(screen_texture, screen_size_scaled);

            need_bind = false;
        }

        const bool performed = redraw(builder, need_bind);

        eka2l1::drivers::command_list retrieved = builder.retrieve_command_list();
        driver->submit_command_list(retrieved);

        if (performed && sync_screen_buffer) {
            sync_screen_buffer_data(driver);
        }
    }

    static epoc::window_group *find_group_to_focus(epoc::window *root) {
        epoc::window_group *next_to_focus = reinterpret_cast<epoc::window_group *>(root->child);

        while (next_to_focus != nullptr) {
            assert(next_to_focus->type == window_kind::group && "The window kind of lvl1 root's child must be window group");
            if (next_to_focus->can_receive_focus())
                break;

            next_to_focus = reinterpret_cast<epoc::window_group *>(next_to_focus->sibling);
        }

        return next_to_focus && next_to_focus->client ? next_to_focus : nullptr;
    }

    void screen::restore_from_config(drivers::graphics_driver *driver,
        const eka2l1::config::app_setting &setting, window_server *winserv) {
        if (winserv && (setting.screen_mode >= 0) && (setting.screen_mode < total_screen_mode())
            && (setting.screen_mode != crr_mode)) {
            set_screen_mode(winserv, driver, setting.screen_mode);
        }

        refresh_rate = static_cast<std::uint8_t>(setting.fps);
        flags_ &= ~FLAG_SCREEN_UPSCALE_FACTOR_LOCK;

        if (setting.screen_upscale_method != 0) {
            flags_ |= FLAG_SCREEN_UPSCALE_FACTOR_LOCK;

            // Assigning the factor alone would leave the screen bitmap at the old size, uncomposited.
            if (driver) {
                try_change_display_rescale(driver, 1.0f);
            } else {
                display_scale_factor = 1.0f;
            }
        }

        requested_ui_scale_factor = setting.screen_upscale;

        if (driver) {
            driver->set_upscale_shader(setting.filter_shader_path);
        }
    }

    void screen::store_to_config(drivers::graphics_driver *driver, eka2l1::config::app_setting &setting) {
        setting.fps = refresh_rate;
        setting.screen_mode = crr_mode;

        if (flags_ & FLAG_SCREEN_UPSCALE_FACTOR_LOCK) {
            setting.screen_upscale_method = 1;
        } else {
            setting.screen_upscale_method = 0;
        }

        setting.screen_upscale = requested_ui_scale_factor;

        if (driver) {
            setting.filter_shader_path = driver->get_active_upscale_shader();
        }
    }

    epoc::window_group *screen::update_focus(window_server *serv, epoc::window_group *closing_group) {
        epoc::window_group *old_focus = focus;

        // Iterate through root's childs.
        focus = find_group_to_focus(root.get());
        const bool is_me_currently_focus = (serv->get_current_focus_screen() == this);

        epoc::window_group *alternative_focus = nullptr;
        screen *new_focus_screen = nullptr;

        if (is_me_currently_focus && !focus) {
            // Don't give up hope! There must be one group to be focused, and it may be present
            // in other screen.
            // iterate through all screen
            new_focus_screen = serv->get_screens();

            while (new_focus_screen != nullptr) {
                if (new_focus_screen != this) {
                    // Try finding out a new group
                    alternative_focus = find_group_to_focus(new_focus_screen->root.get());
                }

                if (alternative_focus) {
                    break;
                }

                new_focus_screen = new_focus_screen->next;
            }

            if (!alternative_focus) {
                new_focus_screen = nullptr;
            }
        }

        if (old_focus != focus || new_focus_screen) {
            if (old_focus && (old_focus != closing_group) && is_me_currently_focus) {
                if (focus)
                    focus->scr->store_to_config(serv->get_graphics_driver(), old_focus->saved_setting);

                old_focus->lost_focus();

                // Remove the screen native upscale lock
                flags_ &= ~FLAG_SCREEN_UPSCALE_FACTOR_LOCK;
            }

            if (new_focus_screen) {
                serv->set_focus_screen(new_focus_screen);

                alternative_focus->gain_focus();

                serv->send_focus_group_change_events(new_focus_screen);
                new_focus_screen->fire_focus_change_callbacks(focus_change_target);

                new_focus_screen->restore_from_config(serv->get_graphics_driver(),
                    alternative_focus->saved_setting, serv);
            } else if (focus && is_me_currently_focus) {
                focus->gain_focus();

                serv->send_focus_group_change_events(this);
                fire_focus_change_callbacks(focus_change_target);

                restore_from_config(serv->get_graphics_driver(), focus->saved_setting, serv);
            }
        }

        return (new_focus_screen ? alternative_focus : focus);
    }

    epoc::window_group *screen::get_group_chain() {
        return reinterpret_cast<epoc::window_group *>(root->child);
    }

    void screen::fire_focus_change_callbacks(const focus_change_property property) {
        const std::lock_guard<std::mutex> guard(focus_callback_mutex);

        for (auto &callback : focus_callbacks) {
            if (callback.second)
                callback.second(callback.first, focus, property);
        }
    }

    void screen::fire_screen_redraw_callbacks(const bool is_dsa) {
        const std::lock_guard<std::mutex> guard(screen_redraw_callback_mutex);

        for (auto &callback : screen_redraw_callbacks) {
            if (callback.second)
                callback.second(callback.first, this, is_dsa);
        }
    }

    void screen::fire_screen_mode_change_callbacks(const int old_mode) {
        const std::lock_guard<std::mutex> guard(screen_mode_change_callback_mutex);

        for (auto &callback : screen_mode_change_callbacks) {
            if (callback.second)
                callback.second(callback.first, this, old_mode);
        }
    }

    std::size_t screen::add_focus_change_callback(void *userdata, focus_change_callback_handler handler) {
        const std::lock_guard<std::mutex> guard(focus_callback_mutex);

        focus_change_callback callback_pair = { userdata, handler };
        return focus_callbacks.add(callback_pair);
    }

    bool screen::remove_focus_change_callback(const std::size_t cb) {
        const std::lock_guard<std::mutex> guard(focus_callback_mutex);
        return focus_callbacks.remove(cb);
    }

    std::size_t screen::add_screen_redraw_callback(void *userdata, screen_redraw_callback_handler handler) {
        const std::lock_guard<std::mutex> guard(screen_redraw_callback_mutex);

        screen_redraw_callback callback_pair = { userdata, handler };
        return screen_redraw_callbacks.add(callback_pair);
    }

    bool screen::remove_screen_redraw_callback(const std::size_t cb) {
        const std::lock_guard<std::mutex> guard(screen_redraw_callback_mutex);
        return screen_redraw_callbacks.remove(cb);
    }

    std::size_t screen::add_screen_mode_change_callback(void *userdata, screen_mode_change_callback_handler handler) {
        const std::lock_guard<std::mutex> guard(screen_mode_change_callback_mutex);

        screen_mode_change_callback callback_pair = { userdata, handler };
        return screen_mode_change_callbacks.add(callback_pair);
    }

    bool screen::remove_screen_mode_change_callback(const std::size_t cb) {
        const std::lock_guard<std::mutex> guard(screen_mode_change_callback_mutex);
        return screen_mode_change_callbacks.remove(cb);
    }

    void screen::abort_all_dsas(const std::int32_t reason) {
        window_dsa_abort_walker walker(reason);
        root->walk_tree(&walker, epoc::window_tree_walk_style::bonjour_children_and_previous_siblings);
    }

    void screen::set_screen_mode(window_server *winserv, drivers::graphics_driver *drv, const int mode) {
        const auto *new_mode = mode_info(mode);
        if (!new_mode) {
            return;
        }

        const int old_mode = crr_mode;
        const bool display_mode_changed = disp_mode != new_mode->disp_mode;
        bool really_changed = false;

        if (crr_mode != mode) {
            LOG_TRACE(SERVICE_WINDOW, "Screen mode changed to {}", mode);
            really_changed = true;
        }

        if (display_mode_changed) {
            abort_all_dsas(dsa_terminate_screen_display_mode_change);
        }

        crr_mode = mode;
        if (really_changed) {
            disp_mode = new_mode->disp_mode;
            dsa_disp_mode_initial = new_mode->dsa_disp_mode;
            reset_dsa_depth_guess();

            if (dsa_texture) {
                drivers::graphics_command_builder builder;
                builder.destroy_bitmap(dsa_texture);
                auto commands = builder.retrieve_command_list();
                drv->submit_command_list(commands);
                dsa_texture = 0;
            }
        }

        resize(drv, new_mode->size);

        if (really_changed) {
            fire_screen_mode_change_callbacks(old_mode);

            if (winserv)
                winserv->send_screen_change_events(this);

            const epoc::config::screen_mode *modeinfo_o = mode_info(old_mode);
            const epoc::config::screen_mode *modeinfo_n = mode_info(crr_mode);

            if (modeinfo_o && modeinfo_n) {
                if ((modeinfo_o->size != modeinfo_n->size) || display_mode_changed) {
                    if (!display_mode_changed) {
                        abort_all_dsas(dsa_terminate_rotation_change);
                    }
                    
                    // Do it right now (when are we gonna redraw again to calculate the visible region clueless)
                    need_update_visible_regions(true);
                    recalculate_visible_regions();
                }
            }
        }
    }

    void screen::vsync(ntimer *timing, std::uint64_t &next_vsync_us) {
        const std::uint64_t tnow = common::get_current_utc_time_in_microseconds_since_epoch();

        std::uint64_t delta = tnow - last_vsync;

        const std::uint64_t microsecs_a_frame = 1000000 / refresh_rate;

        if (delta < microsecs_a_frame) {
            next_vsync_us = microsecs_a_frame - delta;
        } else {
            next_vsync_us = 0;
        }

        // Skip last vsync to next frame
        last_vsync = ((tnow + microsecs_a_frame - 1) / microsecs_a_frame) * microsecs_a_frame;

        const std::uint64_t delta_fps = tnow - last_fps_check;
        if (delta_fps >= common::microsecs_per_sec) {
            last_fps = frame_passed_per_sec;
            last_fps_check = tnow;

            frame_passed_per_sec = 0;
        }

        frame_passed_per_sec++;
    }

    const epoc::config::screen_mode *screen::mode_info(const int number) const {
        if (number < scr_config.modes.size()) {
            return &scr_config.modes[number];
        }

        return nullptr;
    }

    const epoc::config::screen_mode &screen::current_mode() const {
        return *mode_info(crr_mode);
    }

    eka2l1::vec2 screen::size() const {
        return mode_info(physical_mode)->size;
    }

    const int screen::total_screen_mode() const {
        return static_cast<int>(scr_config.modes.size());
    }

    void screen::set_rotation(window_server *winserv, drivers::graphics_driver *drv, const int rot) {
        if (orientation_lock()) {
            // Feel like we are at home
            ui_rotation = rot;
        } else {
            // We need to confirm this rotation exists
            for (std::size_t i = 0; i < scr_config.modes.size(); i++) {
                if (scr_config.modes[i].rotation == rot) {
                    // Reset the UI rotation
                    ui_rotation = 0;
                    set_screen_mode(winserv, drv, static_cast<int>(i));
                    break;
                }
            }
        }
    }

    void screen::set_orientation_lock(drivers::graphics_driver *drv, const bool lock) {
        if (orientation_lock() == lock) {
            return;
        }

        if (orientation_lock() && !lock) {
            // Transitioning to wild mode
            orientation_lock(false);
            return;
        }

        // Abadon our UI rotation
        ui_rotation = 0;
        orientation_lock(true);
    }

    std::uint8_t *screen::screen_buffer_ptr() {
        return reinterpret_cast<std::uint8_t *>(screen_buffer_chunk->host_base()) + sizeof(std::uint16_t) * WORD_PALETTE_ENTRIES_COUNT;
    }

    bool screen::is_framebuffer_upside_down() const {
        // A panel framebuffer reads 270 as the standard landscape, so 90 and 180 arrive flipped.
        // A ScreenPlay framebuffer is a surface already turned to the device orientation.
        if (is_screenplay_architecture()) {
            return false;
        }

        const int rotation = current_mode().rotation;
        return (rotation == 90) || (rotation == 180);
    }

    std::uint32_t screen::screen_buffer_byte_width() const {
        return screen_buffer_byte_width(disp_mode);
    }

    std::uint32_t screen::screen_buffer_byte_width(const epoc::display_mode mode) const {
        const std::uint32_t bits_per_pixel = epoc::get_bpp_from_display_mode(mode);

        // The buffer is laid out for the mode currently displayed, not for the panel's
        // native orientation, so a rotated mode gets its own row length.
        const std::uint32_t tight_pitch = epoc::get_byte_width(current_mode().size.x, bits_per_pixel);

        // ScreenPlay phones expose their 32-bit display framebuffer with a
        // 64-byte-aligned pitch. Keep older bitmap-screen architectures on
        // their word-aligned layout.
        if (is_screenplay_architecture() && (bits_per_pixel == 32)) {
            return (tight_pitch + 63) & ~63U;
        }

        return tight_pitch;
    }

    struct window_visible_region_calc_walker: public window_tree_walker {
        common::region visible_left_region_;
        bool trigger_redraw_;

        explicit window_visible_region_calc_walker(const common::region &master_region, bool trigger_redraw = true)
            : visible_left_region_(master_region)
            , trigger_redraw_(trigger_redraw) {
        }

        bool do_it(epoc::window *win) override {
            if (win->type == epoc::window_kind::client) {
                epoc::canvas_base *winuser = reinterpret_cast<epoc::canvas_base*>(win);
                common::region previous_region = winuser->visible_region;

                winuser->visible_region.make_empty();

                if ((winuser->win_type != epoc::window_type::blank) || (!winuser->scr->scr_config.blt_offscreen)) {
                    if (!visible_left_region_.empty() && winuser->is_visible()) {
                        if (winuser->flags & epoc::window::flag_shape_region) {
                            winuser->visible_region = winuser->shape_region;
                        } else {
                            winuser->visible_region.add_rect(winuser->abs_rect);
                        }

                        // The region that window can render is the region intersects with the current available left region
                        // Eliminating the intersected region that is reserved for this window, we got the next region left to go on.
                        winuser->visible_region = winuser->visible_region.intersect(visible_left_region_);
                        visible_left_region_.eliminate(winuser->visible_region);
                    }
                }

                if (!previous_region.identical(winuser->visible_region)) {
                    if (winuser->is_dsa_active()) {
                        std::vector<dsa*> dsa_residents = winuser->directs_;

                        for (std::size_t i = 0; i < dsa_residents.size(); i++) {
                            dsa_residents[i]->visible_region_changed(winuser->visible_region);
                        }
                    }

                    winuser->report_visiblity_change();

                    if (trigger_redraw_) {
                        winuser->scr->flags_ |= screen::FLAG_SERVER_REDRAW_PENDING;
                    }
                }
            }

            return false;
        }
    };

    void screen::recalculate_visible_regions(bool dont_trigger_redraw) {
        common::region master_region;
        eka2l1::rect master_rect{ eka2l1::vec2(0, 0), current_mode().size };

        master_region.add_rect(master_rect);
        window_visible_region_calc_walker walker(master_region, !dont_trigger_redraw);

        root->walk_tree(&walker, epoc::window_tree_walk_style::bonjour_children);
        need_update_visible_regions(false);
    }

    void screen::ref_dsa_usage() {
        if (active_dsa_count_ == 0) {
            reset_dsa_depth_guess();
        }

        active_dsa_count_++;

        if (need_update_visible_regions()) {
            recalculate_visible_regions(true);
        }
    }

    void screen::deref_dsa_usage() {
        active_dsa_count_--;
    }

    void screen::need_update_visible_regions(const bool value) {
        if (value) {
            flags_ |= FLAG_NEED_RECALC_VISIBLE;

            if (active_dsa_count_) {
                recalculate_visible_regions(true);
            }
        } else {
            flags_ &= ~FLAG_NEED_RECALC_VISIBLE;
        }
    }

    void screen::try_change_display_rescale(drivers::graphics_driver *driver, const float new_scale_factor) {
        if (new_scale_factor != display_scale_factor) {
            // Resize the screen bitmap
            if (screen_texture) {
                eka2l1::vec2 screen_size_scaled = current_mode().size * new_scale_factor;
                drivers::graphics_command_builder cmd_builder;

                cmd_builder.resize_bitmap(screen_texture, screen_size_scaled);
                drivers::command_list retrieved = cmd_builder.retrieve_command_list();
                driver->submit_command_list(retrieved);

                // Wholeheartedly need a redraw pls
                flags_ |= FLAG_SERVER_REDRAW_PENDING;
            }

            display_scale_factor = new_scale_factor;
        }
    }

    void screen::set_native_scale_factor(drivers::graphics_driver *driver, const float new_scale_factor_x,
        const float new_scale_factor_y) {
        if (logic_scale_factor_x != new_scale_factor_x) {
            logic_scale_factor_x = new_scale_factor_x;
        }

        if (logic_scale_factor_y != new_scale_factor_y) {
            logic_scale_factor_y = new_scale_factor_y;
        }

        float correct_display_scale_factor = 1.0f;

        // We want to keep the original display size in case it's downscale.
        if ((flags_ & FLAG_SCREEN_UPSCALE_FACTOR_LOCK) == 0) {
            correct_display_scale_factor = common::min(logic_scale_factor_x, logic_scale_factor_y);

            if (correct_display_scale_factor < 1.0f) {
                correct_display_scale_factor = 1.0f;
            }
        }

        try_change_display_rescale(driver, correct_display_scale_factor);
    }
}
