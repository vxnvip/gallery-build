/*
* Copyright (c) 2019 EKA2L1 Team.
*
* This file is part of EKA2L1 project
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include <common/cvt.h>
#include <common/log.h>

#include <services/fbs/adapter/freetype_font_adapter.h>
#include <cstring>
#include <memory>

#include <freetype/tttables.h>

namespace eka2l1::epoc::adapter {
    struct freetype_lib_raii {
        FT_Library lib_{};

        explicit freetype_lib_raii() {
            auto err = FT_Init_FreeType(&lib_);
            if (err) {
                LOG_ERROR(SERVICE_FBS, "Failed to initialize FreeType library, error: {}", FT_Error_String(err));
            }
        }

        ~freetype_lib_raii() {
            FT_Done_FreeType(lib_);
        }
    };

    std::unique_ptr<freetype_lib_raii> ft_lib_raii_;

    // Thank you very much Anson!
    // Source: https://lists.gnu.org/archive/html/freetype/2005-06/msg00033.html
    // Don't know if Symbian dev made this code, or they copy it
    // Symbian Source: https://github.com/SymbianSource/oss.FCL.sf.os.textandloc/blob/59666d6704fee305b0fdd74974f7b4f42659c6a6/fontservices/freetypefontrasteriser/src/FTRAST2.CPP#L934
    static int derive_design_height_from_max_height(const FT_Face& aFace, int aMaxHeightInPixel)
    {
        const int boundingBoxHeightInFontUnit = aFace->bbox.yMax - aFace->bbox.yMin;
        int designHeightInPixels = ( ( aMaxHeightInPixel *
                                        aFace->units_per_EM ) / boundingBoxHeightInFontUnit );

        const int maxHeightInFontUnit = aMaxHeightInPixel << 6;
        FT_Set_Pixel_Sizes( aFace, designHeightInPixels, designHeightInPixels );
        int currentMaxHeightInFontUnit = FT_MulFix(
            boundingBoxHeightInFontUnit, aFace->size->metrics.y_scale );
        while ( currentMaxHeightInFontUnit < maxHeightInFontUnit )
        {
            designHeightInPixels++;
            FT_Set_Pixel_Sizes( aFace, designHeightInPixels, designHeightInPixels );
            currentMaxHeightInFontUnit = FT_MulFix(
                boundingBoxHeightInFontUnit, aFace->size->metrics.y_scale );
        }
        // The lower bound is ours, not Symbian's: FT_Set_Pixel_Sizes fails at
        // zero, which leaves currentMaxHeightInFontUnit unchanged and spins
        // this loop forever. A caller asking for an unusably small height is
        // enough to reach that.
        while ( ( currentMaxHeightInFontUnit > maxHeightInFontUnit ) && ( designHeightInPixels > 1 ) )
        {
            designHeightInPixels--;
            FT_Set_Pixel_Sizes( aFace, designHeightInPixels, designHeightInPixels );
            currentMaxHeightInFontUnit = FT_MulFix(
                boundingBoxHeightInFontUnit, aFace->size->metrics.y_scale );
        }
        return designHeightInPixels;
    }

    inline float ft_convention_to_float(FT_Pos val) {
        if (0 > val) {
            val = static_cast<FT_Pos>(-val);
        }

        return static_cast<float>(val) / 64.0f;
    }

    inline short ft_convention_to_int_pixel(FT_Pos val) {
        return static_cast<short>((val + 32) >> 6);
    }

    FT_Library get_ft_lib() {
        return ft_lib_raii_->lib_;
    }

    freetype_font_adapter::freetype_font_adapter(std::vector<std::uint8_t> &data)
        : data_(data)
        , is_valid_(false) {
        if (!ft_lib_raii_) {
            ft_lib_raii_ = std::make_unique<freetype_lib_raii>();
        }

        FT_Face query_face;
        auto err = FT_New_Memory_Face(get_ft_lib(), data_.data(), static_cast<FT_Long>(data_.size()), -1, &query_face);

        if (err) {
            LOG_ERROR(SERVICE_FBS, "FreeType failed to query face count from memory, error: {}", FT_Error_String(err));
            return;
        }

        for (auto i = 0; i < query_face->num_faces; i++) {
            FT_Face face;
            err = FT_New_Memory_Face(get_ft_lib(), data_.data(), static_cast<FT_Long>(data_.size()), i, &face);
            if (err) {
                LOG_ERROR(SERVICE_FBS, "FreeType failed to read face from memory, error: {}", FT_Error_String(err));
                continue;
            }
            faces_.push_back(face);
        }

        if (!faces_.empty()) {
            is_valid_ = true;

            current_font_sizes_.resize(faces_.size());
            std::fill(current_font_sizes_.begin(), current_font_sizes_.end(), 0);
        }
    }

    bool freetype_font_adapter::set_font_size(const std::size_t index, const std::uint32_t size) {
        if (index >= faces_.size()) {
            return false;
        }

        if (current_font_sizes_[index] != 0 && current_font_sizes_[index] == size) {
            return true;
        }

        auto face = faces_[index];
        auto err = FT_Set_Pixel_Sizes(face, 0, size);

        if (err) {
            LOG_ERROR(SERVICE_FBS, "Failed to set character size for face, error: {}", FT_Error_String(err));
            return false;
        }

        current_font_sizes_[index] = size;
        return true;
    }

    freetype_font_adapter::~freetype_font_adapter() {
        for (auto face : faces_) {
            FT_Done_Face(face);
        }
    }

    std::uint32_t freetype_font_adapter::line_gap(const std::size_t idx, const std::uint32_t metric_identifier) {
        if (idx >= faces_.size()) {
            return 0;
        }

        if (!set_font_size(idx, metric_identifier)) {
            return 0;
        }

        return faces_[idx]->size->metrics.height - faces_[idx]->size->metrics.ascender + faces_[idx]->size->metrics.descender;
    }

    bool freetype_font_adapter::get_face_attrib(const std::size_t idx, open_font_face_attrib &face_attrib) {
        if (idx >= faces_.size()) {
            return false;
        }

        auto face = faces_[idx];

        auto fam_name = common::utf8_to_ucs2(face->family_name);
        auto name = fam_name + u" " + common::utf8_to_ucs2(face->style_name);

        face_attrib.fam_name.assign(nullptr, fam_name);
        face_attrib.name.assign(nullptr, name);
        face_attrib.local_full_fam_name.assign(nullptr, fam_name);
        face_attrib.local_full_name.assign(nullptr, name);
        face_attrib.style = 0;

        if (face->style_flags & FT_STYLE_FLAG_BOLD) {
            face_attrib.style |= open_font_face_attrib::bold;
        }

        if (face->style_flags & FT_STYLE_FLAG_ITALIC) {
            face_attrib.style |= open_font_face_attrib::italic;
        }

        if (face->face_flags & FT_FACE_FLAG_FIXED_WIDTH) {
            face_attrib.style |= open_font_face_attrib::mono_width;
        }

        auto header = reinterpret_cast<TT_Header*>(FT_Get_Sfnt_Table(face, FT_SFNT_HEAD));

        if (header) {
            face_attrib.min_size_in_pixels = header->Lowest_Rec_PPEM;
        }

        auto os2 = reinterpret_cast<TT_OS2*>(FT_Get_Sfnt_Table(face, FT_SFNT_OS2));

        if (os2) {
            face_attrib.coverage[0] = os2->ulUnicodeRange1;
            face_attrib.coverage[1] = os2->ulUnicodeRange2;
            face_attrib.coverage[2] = os2->ulUnicodeRange3;
            face_attrib.coverage[3] = os2->ulUnicodeRange4;

            if (((os2->panose[1] >= 2) && (os2->panose[1] <= 10)) || (os2->panose[1] >= 14)) {
                face_attrib.style |= open_font_face_attrib::serif;
            }
        }

        return true;
    }

    std::uint8_t *freetype_font_adapter::get_glyph_bitmap(const std::size_t idx, std::uint32_t code, const std::uint32_t metric_identifier,
        int *rasterized_width, int *rasterized_height, std::uint32_t &total_size, epoc::glyph_bitmap_type *bmp_type,
        open_font_character_metric &character_metric) {
        if (idx >= faces_.size()) {
            return nullptr;
        }

        auto face = faces_[idx];
        auto glyph_index = code;

        if (glyph_index & 0x80000000) {
            glyph_index &= ~0x80000000;
        } else {
            glyph_index = FT_Get_Char_Index(face, code);
        }

        if (!set_font_size(idx, metric_identifier)) {
            return nullptr;
        }

        // A caller backing a monochrome face asks for that format; FreeType's
        // own monochrome rasteriser, hinted, is far kinder to small CJK glyphs
        // than thresholding a grey one would be.
        const bool want_monochrome = bmp_type && (*bmp_type == glyph_bitmap_type::monochrome_glyph_bitmap);

        auto err = FT_Load_Glyph(face, glyph_index, FT_LOAD_RENDER | (want_monochrome ? FT_LOAD_TARGET_MONO : 0));
        if (err) {
            LOG_ERROR(SERVICE_FBS, "Failed to load glyph for face to get glyph bitmap, error: {}", FT_Error_String(err));
            return nullptr;
        }

        auto glyph = face->glyph;
        auto bitmap = glyph->bitmap;

        if (rasterized_width) {
            *rasterized_width = static_cast<int>(bitmap.width);
        }

        if (rasterized_height) {
            *rasterized_height = static_cast<int>(bitmap.rows);
        }

        const glyph_bitmap_type produced = (bitmap.pixel_mode == FT_PIXEL_MODE_MONO)
            ? glyph_bitmap_type::monochrome_glyph_bitmap
            : glyph_bitmap_type::antialised_glyph_bitmap;

        total_size = bitmap.width * bitmap.rows;

        if (bmp_type) {
            *bmp_type = produced;
        }

        character_metric.width = ft_convention_to_int_pixel(glyph->metrics.width);
        character_metric.height = ft_convention_to_int_pixel(glyph->metrics.height);
        character_metric.horizontal_bearing_x = ft_convention_to_int_pixel(glyph->metrics.horiBearingX);
        character_metric.horizontal_bearing_y = ft_convention_to_int_pixel(glyph->metrics.horiBearingY);
        character_metric.horizontal_advance = ft_convention_to_int_pixel(glyph->metrics.horiAdvance);
        character_metric.vertical_bearing_x = ft_convention_to_int_pixel(glyph->metrics.vertBearingX);
        character_metric.vertical_bearing_y = ft_convention_to_int_pixel(glyph->metrics.vertBearingY);
        character_metric.vertical_advance = ft_convention_to_int_pixel(glyph->metrics.vertAdvance);
        character_metric.bitmap_type = produced;

        const std::int32_t width = static_cast<std::int32_t>(bitmap.width);
        const std::int32_t height = static_cast<std::int32_t>(bitmap.rows);

        // Clients read the glyph data using these metrics, so report the grid-fitted
        // bitmap rather than the outline, as Symbian's FreeType rasteriser does.
        character_metric.width = static_cast<std::int16_t>(width);
        character_metric.height = static_cast<std::int16_t>(height);
        character_metric.horizontal_bearing_x = static_cast<std::int16_t>(glyph->bitmap_left);
        character_metric.horizontal_bearing_y = static_cast<std::int16_t>(glyph->bitmap_top);

        if (produced != glyph_bitmap_type::monochrome_glyph_bitmap) {
            // Antialiased glyph data is read as tightly packed rows.
            if (bitmap.pitch > width) {
                for (std::int32_t y = 1; y < height; y++) {
                    std::memmove(bitmap.buffer + static_cast<std::ptrdiff_t>(y) * width,
                        bitmap.buffer + static_cast<std::ptrdiff_t>(y) * bitmap.pitch, width);
                }
            }
            return bitmap.buffer;
        }

        // FreeType packs a monochrome row most significant bit first and pads
        // it to whole bytes; a Symbian glyph is one run of bits, least
        // significant first, run-length encoded from there.

        std::vector<std::uint32_t> bits((static_cast<std::size_t>(width) * height + 31) >> 5, 0);

        for (std::int32_t y = 0; y < height; y++) {
            const std::uint8_t *row = bitmap.buffer + static_cast<std::ptrdiff_t>(y) * bitmap.pitch;

            for (std::int32_t x = 0; x < width; x++) {
                if (row[x >> 3] & (0x80 >> (x & 7))) {
                    const std::int32_t index = y * width + x;
                    bits[index >> 5] |= (1u << (index & 31));
                }
            }
        }

        const std::size_t word_count = monochrome_glyph_word_count(width, height);
        std::uint32_t *compressed = new std::uint32_t[word_count];
        std::fill(compressed, compressed + word_count, 0);

        total_size = ((compress_monochrome_glyph(bits.data(), width, height, compressed) + 31) >> 5) * 4;

        std::uint8_t *result = reinterpret_cast<std::uint8_t *>(compressed);
        owned_monochrome_bitmaps_.push_back(result);

        return result;
    }

    void freetype_font_adapter::free_glyph_bitmap(std::uint8_t *data) {
        // Antialiased glyphs live in FreeType's own slot and are replaced by
        // the next load; only the monochrome ones are ours to release.
        auto owned = std::find(owned_monochrome_bitmaps_.begin(), owned_monochrome_bitmaps_.end(), data);

        if (owned != owned_monochrome_bitmaps_.end()) {
            owned_monochrome_bitmaps_.erase(owned);
            delete[] reinterpret_cast<std::uint32_t *>(data);
        }
    }

    bool freetype_font_adapter::measure_atlas_glyphs(const std::size_t idx, const int *codes, const std::size_t count,
        const std::uint32_t metric_identifier, eka2l1::vec2 *sizes) {
        if (idx >= faces_.size()) {
            return false;
        }

        auto face = faces_[idx];

        if (!set_font_size(idx, metric_identifier)) {
            return false;
        }

        for (std::size_t i = 0; i < count; i++) {
            auto err = FT_Load_Char(face, static_cast<FT_ULong>(codes[i]), FT_LOAD_BITMAP_METRICS_ONLY);

            if (err) {
                LOG_WARN(SERVICE_FBS, "Failed to load character code 0x{:X} for face to measure glyph atlas, error: {}",
                    codes[i], FT_Error_String(err));

                sizes[i] = eka2l1::vec2(0, 0);
                continue;
            }

            // Metrics-only loading reports the plain (non-LCD) bitmap, while
            // rendering goes through the LCD filter and is averaged back down
            // by three. The two agree to within the filter's couple of pixels,
            // which the caller's padding absorbs.
            sizes[i] = eka2l1::vec2(static_cast<int>(face->glyph->bitmap.width),
                static_cast<int>(face->glyph->bitmap.rows));
        }

        return true;
    }

    bool freetype_font_adapter::render_atlas_glyphs(const std::size_t idx, const int *codes, const std::size_t count,
        const std::uint32_t metric_identifier, std::uint8_t *atlas, const eka2l1::vec2 atlas_size,
        const eka2l1::vec2 *positions, character_info *info) {
        if (idx >= faces_.size()) {
            return false;
        }

        auto face = faces_[idx];

        if (!set_font_size(idx, metric_identifier)) {
            return false;
        }

        for (std::size_t i = 0; i < count; i++) {
            auto err = FT_Load_Char(face, static_cast<FT_ULong>(codes[i]), FT_LOAD_DEFAULT);

            if (!err) {
                err = FT_Render_Glyph(face->glyph, FT_RENDER_MODE_LCD);
            }

            if (err) {
                LOG_WARN(SERVICE_FBS, "Failed to render character code 0x{:X} for face to get glyph atlas, error: {}",
                    codes[i], FT_Error_String(err));

                info[i] = character_info{};
                continue;
            }

            auto glyph = face->glyph;
            auto bitmap = glyph->bitmap;

            std::uint8_t *dest = atlas + positions[i].x * 4 + positions[i].y * atlas_size.x * 4;

            for (std::uint32_t y = 0; y < bitmap.rows; y++) {
                for (std::uint32_t x = 0; x < bitmap.width / 3; x++) {
                    auto average = static_cast<float>(bitmap.buffer[x * 3 + y * bitmap.pitch] +
                        bitmap.buffer[x * 3 + y * bitmap.pitch + 1] +
                        bitmap.buffer[x * 3 + y * bitmap.pitch + 2]) / 3.0f;

                    eka2l1::vec4 color(bitmap.buffer[x * 3 + y * bitmap.pitch], bitmap.buffer[x * 3 + y * bitmap.pitch + 1],
                       bitmap.buffer[x * 3 + y * bitmap.pitch + 2], static_cast<std::uint8_t>(average));

                    float max = (static_cast<float>(std::max({ color.x, color.y, color.z })) / 255.0f);
                    int min = std::min({ color.x, color.y, color.z });

                    color = color * max + eka2l1::vec4(color.x, color.y, color.z, min) * (1.0f - max);

                    dest[x * 4 + y * atlas_size.x * 4 + 0] = color.x;
                    dest[x * 4 + y * atlas_size.x * 4 + 1] = color.y;
                    dest[x * 4 + y * atlas_size.x * 4 + 2] = color.z;
                    dest[x * 4 + y * atlas_size.x * 4 + 3] = color.w;
                }
            }

            info[i].x0 = static_cast<std::uint16_t>(positions[i].x);
            info[i].y0 = static_cast<std::uint16_t>(positions[i].y);
            info[i].x1 = static_cast<std::uint16_t>(positions[i].x + bitmap.width / 3);
            info[i].y1 = static_cast<std::uint16_t>(positions[i].y + bitmap.rows);
            info[i].xadv = ft_convention_to_float(glyph->metrics.horiAdvance);
            info[i].xoff = static_cast<float>(glyph->bitmap_left);
            info[i].yoff = static_cast<float>(-glyph->bitmap_top);
            info[i].xoff2 = info[i].xoff + static_cast<float>(bitmap.width / 3);
            info[i].yoff2 = info[i].yoff + static_cast<float>(bitmap.rows);
        }

        return true;
    }


    bool freetype_font_adapter::does_glyph_exist(std::size_t idx, std::uint32_t code, const std::uint32_t metric_identifier) {
        if (idx >= faces_.size()) {
            return false;
        }

        auto face = faces_[idx];

        if (code & 0x80000000) {
            return ((code & ~0x80000000) < face->num_glyphs);
        }

        return FT_Get_Char_Index(face, code) != 0;
    }

    std::size_t freetype_font_adapter::count() {
        return faces_.size();
    }

    bool freetype_font_adapter::has_character(const std::size_t face_index, const std::int32_t codepoint, const std::uint32_t metric_identifier) {
        if (face_index >= faces_.size()) {
            return false;
        }

        auto face = faces_[face_index];
        auto glyph_index = FT_Get_Char_Index(face, codepoint);

        return glyph_index != 0;
    }

    bool freetype_font_adapter::get_table_content(const std::size_t face_index, const std::uint32_t tag4, std::uint8_t *dest, uint32_t &dest_size) {
        auto face = faces_[face_index];

        FT_ULong dest_size_temp = !dest ? 0 : dest_size;
        auto table = FT_Load_Sfnt_Table(face, tag4, 0, dest, &dest_size_temp);

        if (!table) {
            return false;
        }

        dest_size = static_cast<std::uint32_t>(dest_size_temp);
        return true;
    }

    static constexpr float DESIGN_SIZE_SCALE = 9.0f / 10.0f;

    std::optional<open_font_metrics> freetype_font_adapter::get_nearest_supported_metric(const std::size_t face_index, const std::uint16_t targeted_font_size, std::uint32_t *metric_identifier,
        bool is_design_font_size) {
        if (face_index >= faces_.size()) {
            return std::nullopt;
        }

        auto face = faces_[face_index];
        auto adjusted_font_size = is_design_font_size ? (static_cast<int>(static_cast<float>(targeted_font_size) * DESIGN_SIZE_SCALE)) :
            derive_design_height_from_max_height(face, targeted_font_size);

        auto fake_design_height = is_design_font_size ? targeted_font_size : adjusted_font_size;

        if (!set_font_size(face_index, adjusted_font_size)) {
            return std::nullopt;
        }

        // TODO: Filling max depth?
        open_font_metrics metrics{};
        metrics.ascent = ft_convention_to_int_pixel(face->size->metrics.ascender);
        // FreeType's descender is negative; Symbian metrics store the descent as a positive distance.
        metrics.descent = ft_convention_to_int_pixel(-face->size->metrics.descender);
        metrics.max_height = ft_convention_to_int_pixel(face->size->metrics.height);
        metrics.max_width = ft_convention_to_int_pixel(face->size->metrics.max_advance);
        metrics.max_depth = 0;
        metrics.baseline_correction = 0;
        metrics.design_height = static_cast<std::int16_t>(fake_design_height);

        if (metric_identifier) {
            *metric_identifier = adjusted_font_size;
        }

        return metrics;
    }

    std::uint32_t freetype_font_adapter::get_glyph_advance(const std::size_t face_index, const std::uint32_t codepoint, const std::uint32_t metric_identifier, const bool vertical) {
        auto face = faces_[face_index];
        if (!face) {
            return 0;
        }

        auto glyph_index = codepoint;
        if (glyph_index & 0x80000000) {
            glyph_index &= ~0x80000000;
        } else {
            glyph_index = FT_Get_Char_Index(face, codepoint);
        }

        if (!set_font_size(face_index, metric_identifier)) {
            return 0;
        }

        auto err = FT_Load_Glyph(face, glyph_index, FT_LOAD_ADVANCE_ONLY);
        if (err) {
            LOG_ERROR(SERVICE_FBS, "Failed to load glyph for face to get glyph advance, error: {}", FT_Error_String(err));
            return 0;
        }

        auto glyph = face->glyph;

        return vertical ? ft_convention_to_int_pixel(glyph->metrics.vertAdvance) :
                          ft_convention_to_int_pixel(glyph->metrics.horiAdvance);
    }
}
