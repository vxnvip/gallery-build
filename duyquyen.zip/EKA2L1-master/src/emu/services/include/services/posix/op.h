/*
 * Copyright (c) 2018 EKA2L1 Team
 *
 * This file is part of EKA2L1 project
 * (see bentokun.github.com/EKA2L1).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

namespace eka2l1 {
    enum TPosixMessage {
        PMread,
        PMwrite,
        PMfSync,
        PMsendto,
        PMrecvfrom,
        PMconnect,
        PMshutdown,
        PMaccept,
        PMioctl,
        PMioctlN,
        PMwaitpid,
        PMdup,
        PMdup2,
        PMopen,
        PMclose,
        PMlseek,
        PMfstat,
        PMgetcwd,
        PMchdir,
        PMmkdir,
        PMrmdir,
        PMchmod,
        PMunlink,
        PMstat,
        PMrename,
        PMResolvePath,
        PMsocket,
        PMbind,
        PMlisten,
        PMsockname,
        PMgetsockopt,
        PMsetsockopt,
        PMioctlcomplete,
        PMcancel,
        PMterminateprocess,
        PMgetenv,
        PMsetenv,
        PMunsetenv,
        PMpopen3,
        // Inter process operations
        PMisparent,
        PMrendezvous,
        PMpipewrite,
        PMpiperead,
        PMpipeioctl,
        PMpipeclose,
        PMpipecancel
    };
}
