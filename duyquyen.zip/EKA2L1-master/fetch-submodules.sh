#!/usr/bin/env bash
# Zip tải từ GitHub không chứa submodule (src/external/* rỗng).
# Script này tự tải các submodule còn thiếu từ repo gốc EKA2L1 (đúng commit đã pin).
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

missing=()
while read -r p; do
  [ -z "$p" ] && continue
  if [ -z "$(ls -A "$p" 2>/dev/null)" ]; then missing+=("$p"); fi
done < <(grep -E '^[[:space:]]*path[[:space:]]*=' .gitmodules | sed -E 's/^[^=]*=[[:space:]]*//')

if [ ${#missing[@]} -eq 0 ]; then
  echo "[fetch-submodules] Da du submodule."
  exit 0
fi

echo "[fetch-submodules] Thieu ${#missing[@]} submodule, dang tai..."
TMP="$(mktemp -d)"
git clone --depth 1 --recurse-submodules --shallow-submodules -j8 \
  https://github.com/EKA2L1/EKA2L1 "$TMP/up"

for p in "${missing[@]}"; do
  if [ ! -d "$TMP/up/$p" ]; then echo "[fetch-submodules] Khong thay $p"; exit 1; fi
  mkdir -p "$p"
  cp -a "$TMP/up/$p/." "$p/"
  find "$p" -name .git -exec rm -rf {} + 2>/dev/null || true
done
rm -rf "$TMP"
echo "[fetch-submodules] Xong."
