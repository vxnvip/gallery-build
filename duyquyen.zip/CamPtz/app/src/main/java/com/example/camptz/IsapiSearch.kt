package com.example.camptz

import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * Liệt kê từng file ghi hình trên thẻ nhớ qua ISAPI (Hikvision / Hik-OEM / một số EZVIZ).
 * POST /ISAPI/ContentMgmt/search  (Digest auth, tự xử lý 401).
 * Blocking -> gọi trong io.execute { }.
 */
class IsapiSearch(
    private val host: String,
    private val port: Int,
    private val user: String,
    private val pass: String,
) {
    data class RecFile(
        val start: String,
        val end: String,
        val type: String,
        val size: String,
        val uri: String,
    )

    /**
     * @param daysBack tìm lùi bao nhiêu ngày
     * @param trackId  101 = kênh 1 main stream, 102 = sub stream; 103 = ảnh chụp
     */
    fun listFiles(daysBack: Int = 7, trackId: Int = 101, max: Int = 200): List<RecFile> {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
        val now = System.currentTimeMillis()
        val from = fmt.format(Date(now - daysBack * 86_400_000L))
        val to = fmt.format(Date(now))
        val searchId = UUID.randomUUID().toString().uppercase()

        val result = mutableListOf<RecFile>()
        var pos = 0
        while (result.size < max) {
            val body = """<?xml version="1.0" encoding="utf-8"?>
<CMSearchDescription>
  <searchID>$searchId</searchID>
  <trackIDList><trackID>$trackId</trackID></trackIDList>
  <timeSpanList><timeSpan><startTime>$from</startTime><endTime>$to</endTime></timeSpan></timeSpanList>
  <maxResults>40</maxResults>
  <searchResultPostion>$pos</searchResultPostion>
  <metadataList><metadataDescriptor>//recordType.meta.std-cgi.com</metadataDescriptor></metadataList>
</CMSearchDescription>"""
            val xml = post("/ISAPI/ContentMgmt/search", body)

            val items = Regex("<searchMatchItem>(.*?)</searchMatchItem>", RegexOption.DOT_MATCHES_ALL)
                .findAll(xml).map { it.groupValues[1] }.toList()
            for (b in items) {
                fun tag(t: String) = Regex("<$t>(.*?)</$t>", RegexOption.DOT_MATCHES_ALL)
                    .find(b)?.groupValues?.get(1)?.trim()?.replace("&amp;", "&") ?: ""
                val uri = tag("playbackURI")
                val size = Regex("[?&]size=(\\d+)").find(uri)?.groupValues?.get(1) ?: ""
                result += RecFile(
                    start = tag("startTime"),
                    end = tag("endTime"),
                    type = tag("metadata").ifEmpty { Regex("<recordType>(.*?)</").find(b)?.groupValues?.get(1) ?: "" },
                    size = size,
                    uri = uri,
                )
            }
            val more = xml.contains("<responseStatusStrg>MORE</responseStatusStrg>")
            if (!more || items.isEmpty()) break
            pos += items.size
        }
        return result
    }

    /** Báo cáo dạng text để hiện lên màn hình. */
    fun report(daysBack: Int = 7): String {
        val files = listFiles(daysBack)
        if (files.isEmpty()) return "Không tìm thấy file nào trong $daysBack ngày qua."
        val sb = StringBuilder("== ${files.size} FILE TRÊN THẺ NHỚ ==\n")
        files.forEachIndexed { i, f ->
            val mb = f.size.toLongOrNull()?.let { "%.1f MB".format(it / 1048576.0) } ?: "?"
            sb.appendLine("${i + 1}. ${f.start} → ${f.end}  [$mb] ${f.type}")
            sb.appendLine("   ${f.uri}")
        }
        return sb.toString()
    }

    // ---------- HTTP + Digest ----------

    private fun post(path: String, body: String): String {
        val url = "http://$host:$port$path"
        val first = send(url, body, null)
        if (first.first != 401) return check(first)
        val auth = buildAuth(first.third ?: error("401 nhưng không có WWW-Authenticate"), "POST", path)
        return check(send(url, body, auth))
    }

    private fun check(r: Triple<Int, String, String?>): String {
        if (r.first !in 200..299) error("ISAPI ${r.first}: ${r.second.take(300)}")
        return r.second
    }

    private fun send(url: String, body: String, auth: String?): Triple<Int, String, String?> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 4000
            c.readTimeout = 10000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/xml; charset=utf-8")
            if (auth != null) c.setRequestProperty("Authorization", auth)
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.readText().orEmpty()
            return Triple(code, text, c.getHeaderField("WWW-Authenticate"))
        } finally {
            c.disconnect()
        }
    }

    private fun md5(s: String) =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun buildAuth(header: String, method: String, uri: String): String {
        if (header.startsWith("Basic", true)) {
            val b = android.util.Base64.encodeToString("$user:$pass".toByteArray(), android.util.Base64.NO_WRAP)
            return "Basic $b"
        }
        fun p(k: String) = Regex("""$k="?([^",]+)"?""").find(header)?.groupValues?.get(1)
        val realm = p("realm") ?: ""
        val nonce = p("nonce") ?: ""
        val opaque = p("opaque")
        val qop = p("qop")?.split(",")?.map { it.trim() }?.firstOrNull { it == "auth" }
        val ha1 = md5("$user:$realm:$pass")
        val ha2 = md5("$method:$uri")
        val nc = "00000001"
        val cnonce = ByteArray(8).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        val resp = if (qop != null) md5("$ha1:$nonce:$nc:$cnonce:$qop:$ha2") else md5("$ha1:$nonce:$ha2")
        return buildString {
            append("""Digest username="$user", realm="$realm", nonce="$nonce", uri="$uri", response="$resp"""")
            if (qop != null) append(""", qop=$qop, nc=$nc, cnonce="$cnonce"""")
            if (opaque != null) append(""", opaque="$opaque"""")
        }
    }
}
