package com.example.camptz

import com.sun.jna.Library
import com.sun.jna.Memory
import com.sun.jna.Native
import com.sun.jna.Pointer
import com.sun.jna.Structure
import com.sun.jna.ptr.IntByReference
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Binding JNA tới libhcnetsdk.so (HCNetSDK của Hikvision, bản đi kèm app EZVIZ). */
interface HcNet : Library {
    fun NET_DVR_Init(): Boolean
    fun NET_DVR_Cleanup(): Boolean
    fun NET_DVR_SetConnectTime(dwWaitTime: Int, dwTryTimes: Int): Boolean
    fun NET_DVR_GetLastError(): Int
    fun NET_DVR_Login_V40(pLoginInfo: LoginInfo, lpDeviceInfo: Pointer): Int
    fun NET_DVR_Logout(lUserID: Int): Boolean
    fun NET_DVR_GetDVRConfig(
        lUserID: Int, dwCommand: Int, lChannel: Int,
        lpOutBuffer: Pointer, dwOutBufferSize: Int, lpBytesReturned: IntByReference
    ): Boolean
    fun NET_DVR_FindFile_V30(lUserID: Int, lpFindCond: FileCond): Int
    fun NET_DVR_FindNextFile_V30(lFindHandle: Int, lpFindData: FindData): Int
    fun NET_DVR_FindClose_V30(lFindHandle: Int): Boolean
    fun NET_DVR_GetFileByName(lUserID: Int, sDVRFileName: String, sSavedFileName: String): Int
    fun NET_DVR_PlayBackControl(lPlayHandle: Int, dwControlCode: Int, dwInValue: Int, lpOutValue: IntByReference?): Boolean
    fun NET_DVR_GetDownloadPos(lFileHandle: Int): Int
    fun NET_DVR_StopGetFile(lFileHandle: Int): Boolean
}

@Structure.FieldOrder(
    "sDeviceAddress", "byUseTransport", "wPort", "sUserName", "sPassword",
    "cbLoginResult", "pUser", "bUseAsynLogin", "byProxyType", "byUseUTCTime",
    "byLoginMode", "byHttps", "iProxyID", "byVerifyMode", "byRes3"
)
class LoginInfo : Structure() {
    @JvmField var sDeviceAddress = ByteArray(129)
    @JvmField var byUseTransport: Byte = 0
    @JvmField var wPort: Short = 0
    @JvmField var sUserName = ByteArray(64)
    @JvmField var sPassword = ByteArray(64)
    @JvmField var cbLoginResult: Pointer? = null
    @JvmField var pUser: Pointer? = null
    @JvmField var bUseAsynLogin: Int = 0
    @JvmField var byProxyType: Byte = 0
    @JvmField var byUseUTCTime: Byte = 0
    @JvmField var byLoginMode: Byte = 0
    @JvmField var byHttps: Byte = 0
    @JvmField var iProxyID: Int = 0
    @JvmField var byVerifyMode: Byte = 0
    @JvmField var byRes3 = ByteArray(119)
}

@Structure.FieldOrder("dwYear", "dwMonth", "dwDay", "dwHour", "dwMinute", "dwSecond")
class NetTime : Structure() {
    @JvmField var dwYear: Int = 0
    @JvmField var dwMonth: Int = 0
    @JvmField var dwDay: Int = 0
    @JvmField var dwHour: Int = 0
    @JvmField var dwMinute: Int = 0
    @JvmField var dwSecond: Int = 0

    fun set(y: Int, mo: Int, d: Int, h: Int, mi: Int, s: Int) {
        dwYear = y; dwMonth = mo; dwDay = d; dwHour = h; dwMinute = mi; dwSecond = s
    }
    fun toArray() = intArrayOf(dwYear, dwMonth, dwDay, dwHour, dwMinute, dwSecond)
}

@Structure.FieldOrder("lChannel", "dwFileType", "dwIsLocked", "dwUseCardNo", "sCardNumber", "struStartTime", "struStopTime")
class FileCond : Structure() {
    @JvmField var lChannel: Int = 1
    @JvmField var dwFileType: Int = 0xff
    @JvmField var dwIsLocked: Int = 0xff
    @JvmField var dwUseCardNo: Int = 0
    @JvmField var sCardNumber = ByteArray(32)
    @JvmField var struStartTime = NetTime()
    @JvmField var struStopTime = NetTime()
}

@Structure.FieldOrder("sFileName", "struStartTime", "struStopTime", "dwFileSize", "sCardNum", "byLocked", "byFileType", "byRes")
class FindData : Structure() {
    @JvmField var sFileName = ByteArray(100)
    @JvmField var struStartTime = NetTime()
    @JvmField var struStopTime = NetTime()
    @JvmField var dwFileSize: Int = 0
    @JvmField var sCardNum = ByteArray(32)
    @JvmField var byLocked: Byte = 0
    @JvmField var byFileType: Byte = 0
    @JvmField var byRes = ByteArray(2)
}

internal object HikSdk {
    val api: HcNet by lazy {
        for (n in listOf("hpr", "crypto", "ssl", "HCCore", "HCCoreDevCfg")) {
            try { System.loadLibrary(n) } catch (_: Throwable) { }
        }
        val a = Native.load("hcnetsdk", HcNet::class.java)
        a.NET_DVR_Init()
        a.NET_DVR_SetConnectTime(5000, 1)
        a
    }
}

/** Một đoạn ghi hình trên thẻ nhớ. Giờ s/e là giờ địa phương của camera: [năm, tháng, ngày, giờ, phút, giây]. */
class RecFile(val name: String, val s: IntArray, val e: IntArray, val size: Long, val type: Int) {
    fun startText() = "%02d:%02d:%02d".format(s[3], s[4], s[5])
    fun endText() = "%02d:%02d:%02d".format(e[3], e[4], e[5])
    fun sizeText() = "%.1f MB".format(size / 1048576.0)
    fun typeText() = when (type) {
        0 -> "liên tục"; 1 -> "chuyển động"; 2 -> "báo động"; 6 -> "thủ công"; else -> "loại $type"
    }
}

/** Phiên đăng nhập SDK vào camera (cổng 8000). Mọi hàm là blocking -> gọi từ thread nền. */
class HikSession {
    private val api = HikSdk.api
    private var uid = -1
    private var host = ""
    var channel = 1; private set
    var serial = ""; private set
    var offsetMs = 0L; private set               // giờ camera - UTC
    var todayY = 0; private set
    var todayM = 0; private set
    var todayD = 0; private set

    /** Trả về null nếu thành công, ngược lại là thông báo lỗi. */
    fun login(host: String, port: Int, user: String, pass: String): String? {
        this.host = host
        val li = LoginInfo()
        fill(li.sDeviceAddress, host); fill(li.sUserName, user); fill(li.sPassword, pass)
        li.wPort = port.toShort()
        li.byLoginMode = 0
        val dev = Memory(1024).also { it.clear() }
        uid = api.NET_DVR_Login_V40(li, dev)
        if (uid < 0) {
            val err = api.NET_DVR_GetLastError()
            return "đăng nhập cổng $port lỗi $err — " + when (err) {
                1 -> "sai mã xác minh"
                7 -> "không kết nối được (cổng có mở không?)"
                10 -> "hết thời gian chờ"
                47 -> "user không tồn tại"
                else -> "xem mã lỗi HCNetSDK"
            }
        }
        serial = String(dev.getByteArray(0, 48), Charsets.US_ASCII).substringBefore('\u0000')
        channel = (dev.getByte(53).toInt() and 0xff).let { if (it == 0) 1 else it }
        readDeviceTime()
        return null
    }

    private fun readDeviceTime() {
        val now = System.currentTimeMillis()
        val mem = Memory(24).also { it.clear() }
        val ok = try { api.NET_DVR_GetDVRConfig(uid, 118, 1, mem, 24, IntByReference()) } catch (_: Throwable) { false }
        val t = IntArray(6) { mem.getInt(it * 4L) }
        if (ok && t[0] in 2000..2100) {
            val asUtc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear(); set(t[0], t[1] - 1, t[2], t[3], t[4], t[5])
            }.timeInMillis
            offsetMs = Math.round((asUtc - now) / 900000.0) * 900000L
            todayY = t[0]; todayM = t[1]; todayD = t[2]
        } else {
            offsetMs = TimeZone.getDefault().getOffset(now).toLong()
            val c = Calendar.getInstance()
            todayY = c.get(Calendar.YEAR); todayM = c.get(Calendar.MONTH) + 1; todayD = c.get(Calendar.DAY_OF_MONTH)
        }
    }

    fun logout() {
        if (uid >= 0) { try { api.NET_DVR_Logout(uid) } catch (_: Throwable) { } }
        uid = -1
    }

    /** Liệt kê các đoạn ghi trong một ngày (giờ camera). */
    fun list(y: Int, m: Int, d: Int): List<RecFile> {
        check(uid >= 0) { "chưa đăng nhập SDK" }
        val cond = FileCond()
        cond.lChannel = channel
        cond.struStartTime.set(y, m, d, 0, 0, 0)
        cond.struStopTime.set(y, m, d, 23, 59, 59)
        val h = api.NET_DVR_FindFile_V30(uid, cond)
        if (h < 0) error("FindFile lỗi ${api.NET_DVR_GetLastError()}")
        val out = ArrayList<RecFile>()
        try {
            var spins = 0
            while (out.size < 3000) {
                val fd = FindData()
                val r = api.NET_DVR_FindNextFile_V30(h, fd)
                if (r == 1000) {
                    out += RecFile(
                        String(fd.sFileName, Charsets.UTF_8).substringBefore('\u0000'),
                        fd.struStartTime.toArray(), fd.struStopTime.toArray(),
                        fd.dwFileSize.toLong() and 0xffffffffL, fd.byFileType.toInt()
                    )
                } else if (r == 1002) {
                    if (++spins > 300) break
                    Thread.sleep(100)
                } else break          // 1001 không có, 1003 hết, 1004 lỗi
            }
        } finally {
            api.NET_DVR_FindClose_V30(h)
        }
        return out
    }

    /** URL phát lại RTSP kiểu Hikvision, giờ đã đổi sang UTC theo múi giờ của camera. */
    fun rtspUrl(r: RecFile): String {
        fun utc(t: IntArray): String {
            val ms = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear(); set(t[0], t[1] - 1, t[2], t[3], t[4], t[5])
            }.timeInMillis - offsetMs
            return SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(ms))
        }
        return "rtsp://$host:554/Streaming/tracks/${channel * 100 + 1}?starttime=${utc(r.s)}&endtime=${utc(r.e)}"
    }

    /** Tải một đoạn ghi về file. Trả về null nếu xong, ngược lại là lỗi. */
    fun download(r: RecFile, dest: File, onPos: (Int) -> Unit): String? {
        check(uid >= 0) { "chưa đăng nhập SDK" }
        val h = api.NET_DVR_GetFileByName(uid, r.name, dest.absolutePath)
        if (h < 0) return "GetFileByName lỗi ${api.NET_DVR_GetLastError()}"
        try {
            if (!api.NET_DVR_PlayBackControl(h, 1, 0, null)) return "không bắt đầu tải được (lỗi ${api.NET_DVR_GetLastError()})"
            while (true) {
                val pos = api.NET_DVR_GetDownloadPos(h)
                if (pos < 0 || pos >= 200) return "mất kết nối khi tải (mã $pos)"
                onPos(pos)
                if (pos == 100) return null
                Thread.sleep(500)
            }
        } finally {
            api.NET_DVR_StopGetFile(h)
        }
    }

    private fun fill(dst: ByteArray, s: String) {
        val b = s.toByteArray(Charsets.UTF_8)
        System.arraycopy(b, 0, dst, 0, minOf(b.size, dst.size - 1))
    }
}
