package com.example.camptz

import com.sun.jna.Library
import com.sun.jna.Memory
import com.sun.jna.Native
import com.sun.jna.Pointer
import com.sun.jna.Structure
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * Liệt kê file trên thẻ nhớ camera EZVIZ bằng HCNetSDK (libhcnetsdk.so) qua cổng 8000.
 * Giống cách app EZVIZ làm ở chế độ LAN: user "admin", mật khẩu = mã xác minh.
 * Blocking -> gọi trong io.execute { }.
 */
interface HcNet : Library {
    fun NET_DVR_Init(): Boolean
    fun NET_DVR_Cleanup(): Boolean
    fun NET_DVR_SetConnectTime(dwWaitTime: Int, dwTryTimes: Int): Boolean
    fun NET_DVR_GetLastError(): Int
    fun NET_DVR_Login_V40(pLoginInfo: LoginInfo, lpDeviceInfo: Pointer): Int
    fun NET_DVR_Logout(lUserID: Int): Boolean
    fun NET_DVR_FindFile_V30(lUserID: Int, lpFindCond: FileCond): Int
    fun NET_DVR_FindNextFile_V30(lFindHandle: Int, lpFindData: FindData): Int
    fun NET_DVR_FindClose_V30(lFindHandle: Int): Boolean
}

@Structure.FieldOrder(
    "sDeviceAddress", "byUseTransport", "wPort", "sUserName", "sPassword",
    "cbLoginResult", "pUser", "bUseAsynLogin", "byProxyType", "byUseUTCTime",
    "byLoginMode", "byHttps", "iProxyID", "byVerifyMode", "byRes3"
)
class LoginInfo : Structure() {
    @JvmField var sDeviceAddress = ByteArray(129)
    @JvmField var byUseTransport: Byte = 0
    @JvmField var wPort: Short = 0
    @JvmField var sUserName = ByteArray(64)
    @JvmField var sPassword = ByteArray(64)
    @JvmField var cbLoginResult: Pointer? = null
    @JvmField var pUser: Pointer? = null
    @JvmField var bUseAsynLogin: Int = 0
    @JvmField var byProxyType: Byte = 0
    @JvmField var byUseUTCTime: Byte = 0
    @JvmField var byLoginMode: Byte = 0   // 0 = giao thức riêng của SDK (cổng 8000)
    @JvmField var byHttps: Byte = 0
    @JvmField var iProxyID: Int = 0
    @JvmField var byVerifyMode: Byte = 0
    @JvmField var byRes3 = ByteArray(119)
}

@Structure.FieldOrder("dwYear", "dwMonth", "dwDay", "dwHour", "dwMinute", "dwSecond")
class NetTime : Structure() {
    @JvmField var dwYear: Int = 0
    @JvmField var dwMonth: Int = 0
    @JvmField var dwDay: Int = 0
    @JvmField var dwHour: Int = 0
    @JvmField var dwMinute: Int = 0
    @JvmField var dwSecond: Int = 0
}

@Structure.FieldOrder(
    "lChannel", "dwFileType", "dwIsLocked", "dwUseCardNo",
    "sCardNumber", "struStartTime", "struStopTime"
)
class FileCond : Structure() {
    @JvmField var lChannel: Int = 1
    @JvmField var dwFileType: Int = 0xff   // 0xff = tất cả
    @JvmField var dwIsLocked: Int = 0xff   // 0xff = tất cả
    @JvmField var dwUseCardNo: Int = 0
    @JvmField var sCardNumber = ByteArray(32)
    @JvmField var struStartTime = NetTime()
    @JvmField var struStopTime = NetTime()
}

@Structure.FieldOrder(
    "sFileName", "struStartTime", "struStopTime", "dwFileSize",
    "sCardNum", "byLocked", "byFileType", "byRes"
)
class FindData : Structure() {
    @JvmField var sFileName = ByteArray(100)
    @JvmField var struStartTime = NetTime()
    @JvmField var struStopTime = NetTime()
    @JvmField var dwFileSize: Int = 0
    @JvmField var sCardNum = ByteArray(32)
    @JvmField var byLocked: Byte = 0
    @JvmField var byFileType: Byte = 0
    @JvmField var byRes = ByteArray(2)
}

private object HikSdk {
    val api: HcNet by lazy {
        // Nạp trước các thư viện phụ thuộc; cái nào thiếu thì bỏ qua.
        for (n in listOf("hpr", "crypto", "ssl", "HCCore", "HCCoreDevCfg")) {
            try { System.loadLibrary(n) } catch (_: Throwable) { }
        }
        val a = Native.load("hcnetsdk", HcNet::class.java)
        a.NET_DVR_Init()
        a.NET_DVR_SetConnectTime(5000, 1)
        a
    }
}

class HikFileSearch(
    private val host: String,
    private val port: Int,
    private val user: String,
    private val pass: String,
) {
    private class Rec(val s: NetTime, val e: NetTime, val size: Int, val name: String)

    fun report(daysBack: Int = 7): String {
        val api = try { HikSdk.api } catch (t: Throwable) {
            return "Không nạp được libhcnetsdk.so: ${t.message}\n" +
                "(máy phải là arm64, và các file .so phải nằm trong jniLibs/arm64-v8a)"
        }

        val li = LoginInfo().apply {
            fillStr(sDeviceAddress, host)
            fillStr(sUserName, user)
            fillStr(sPassword, pass)
            wPort = port.toShort()
            byLoginMode = 0
        }
        val devInfo = Memory(1024).also { it.clear() }
        val uid = api.NET_DVR_Login_V40(li, devInfo)
        if (uid < 0) {
            val err = api.NET_DVR_GetLastError()
            return "Đăng nhập SDK thất bại (cổng $port): mã lỗi $err — ${errText(err)}"
        }

        val sb = StringBuilder()
        try {
            val serial = String(devInfo.getByteArray(0, 48), Charsets.US_ASCII).substringBefore('\u0000')
            val startChan = (devInfo.getByte(53).toInt() and 0xff).let { if (it == 0) 1 else it }
            sb.appendLine("== SDK ĐÃ ĐĂNG NHẬP ==")
            sb.appendLine("Serial: $serial   Kênh bắt đầu: $startChan")

            val all = mutableListOf<Rec>()
            val errs = mutableListOf<String>()
            for (d in 0 until daysBack) {
                if (all.size >= 500) break
                val day = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -d) }
                val cond = FileCond().apply {
                    lChannel = startChan
                    struStartTime = timeOf(day, 0, 0, 0)
                    struStopTime = timeOf(day, 23, 59, 59)
                }
                val h = api.NET_DVR_FindFile_V30(uid, cond)
                if (h < 0) {
                    errs += "ngày -$d: lỗi ${api.NET_DVR_GetLastError()}"
                    continue
                }
                try {
                    var guard = 0
                    while (all.size < 500 && guard++ < 5000) {
                        val fd = FindData()
                        when (api.NET_DVR_FindNextFile_V30(h, fd)) {
                            1000 -> all += Rec(
                                fd.struStartTime, fd.struStopTime, fd.dwFileSize,
                                String(fd.sFileName, Charsets.UTF_8).substringBefore('\u0000')
                            )
                            1002 -> Thread.sleep(100)          // đang tìm
                            else -> break                       // 1001 không có, 1003 hết, 1004 lỗi
                        }
                    }
                } finally {
                    api.NET_DVR_FindClose_V30(h)
                }
            }

            all.sortBy { stamp(it.s) }
            sb.appendLine("Tìm thấy ${all.size} file trong $daysBack ngày qua.")
            if (errs.isNotEmpty()) sb.appendLine("Lỗi tìm: ${errs.joinToString("; ")}")
            all.forEachIndexed { i, r ->
                val mb = "%.1f MB".format(r.size.toLong().and(0xffffffffL) / 1048576.0)
                sb.appendLine("${i + 1}. ${stamp(r.s)} → ${stamp(r.e).substring(11)}  [$mb]")
                sb.appendLine("   ${r.name}")
                sb.appendLine("   ${rtspUrl(r)}")
            }
        } finally {
            api.NET_DVR_Logout(uid)
        }
        return sb.toString()
    }

    // ---------- tiện ích ----------

    private fun fillStr(dst: ByteArray, s: String) {
        val b = s.toByteArray(Charsets.UTF_8)
        System.arraycopy(b, 0, dst, 0, minOf(b.size, dst.size - 1))
    }

    private fun timeOf(c: Calendar, h: Int, m: Int, s: Int) = NetTime().apply {
        dwYear = c.get(Calendar.YEAR); dwMonth = c.get(Calendar.MONTH) + 1; dwDay = c.get(Calendar.DAY_OF_MONTH)
        dwHour = h; dwMinute = m; dwSecond = s
    }

    private fun stamp(t: NetTime) = "%04d-%02d-%02d %02d:%02d:%02d"
        .format(t.dwYear, t.dwMonth, t.dwDay, t.dwHour, t.dwMinute, t.dwSecond)

    /** URL phát lại RTSP kiểu Hikvision; giờ camera được coi là cùng múi giờ với điện thoại. */
    private fun rtspUrl(r: Rec): String {
        fun utc(t: NetTime): String {
            val c = Calendar.getInstance().apply {
                clear(); set(t.dwYear, t.dwMonth - 1, t.dwDay, t.dwHour, t.dwMinute, t.dwSecond)
            }
            return SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(c.time)
        }
        return "rtsp://$host:554/Streaming/tracks/101?starttime=${utc(r.s)}&endtime=${utc(r.e)}"
    }

    private fun errText(e: Int) = when (e) {
        1 -> "sai user hoặc mật khẩu / mã xác minh"
        2 -> "không đủ quyền"
        3 -> "SDK chưa khởi tạo"
        7 -> "không kết nối được tới camera (cổng $port có mở không?)"
        8, 9 -> "lỗi gửi/nhận dữ liệu"
        10 -> "hết thời gian chờ phản hồi"
        47 -> "user không tồn tại"
        else -> "xem bảng mã lỗi của HCNetSDK"
    }
}
