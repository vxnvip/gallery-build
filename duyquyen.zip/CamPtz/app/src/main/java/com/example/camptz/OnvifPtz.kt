package com.example.camptz

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Điều khiển PTZ qua ONVIF (SOAP + WS-UsernameToken digest).
 * LƯU Ý: mọi hàm là blocking -> gọi trong thread nền / coroutine (Dispatchers.IO).
 *
 * Dùng:
 *   val cam = OnvifPtz("192.168.43.99", 80, "admin", "MA_XAC_MINH")
 *   cam.init()              // đồng bộ giờ, lấy địa chỉ dịch vụ + profile
 *   cam.move(-0.5f, 0f)     // quay trái
 *   cam.move(0.5f, 0f)      // quay phải
 *   cam.stop()              // dừng (gọi khi nhả nút)
 *
 * Manifest cần: <uses-permission android:name="android.permission.INTERNET"/>
 *               <application android:usesCleartextTraffic="true" ...>
 */
class OnvifPtz(
    private val host: String,
    private val port: Int,
    private val user: String,
    private val pass: String,
) {
    private val deviceUrl = "http://$host:$port/onvif/device_service"
    private var ptzUrl = ""
    private var mediaUrl = ""
    private var profileToken = ""
    private var timeOffsetMs = 0L

    /** Gọi 1 lần trước khi điều khiển. */
    fun init() {
        syncTime()
        val caps = soap(
            deviceUrl,
            """<tds:GetCapabilities xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
                 <tds:Category>All</tds:Category></tds:GetCapabilities>"""
        )
        ptzUrl = xaddr(caps, "PTZ") ?: error("Camera không báo dịch vụ PTZ")
        mediaUrl = xaddr(caps, "Media") ?: error("Camera không báo dịch vụ Media")

        val profiles = soap(
            mediaUrl,
            """<trt:GetProfiles xmlns:trt="http://www.onvif.org/ver10/media/wsdl"/>"""
        )
        profileToken = Regex("""Profiles[^>]*token="([^"]+)"""")
            .find(profiles)?.groupValues?.get(1) ?: error("Không lấy được profile")
    }

    /** x: trái(-1)..phải(+1), y: xuống(-1)..lên(+1). Tốc độ 0..1. */
    fun move(x: Float, y: Float = 0f) {
        soap(
            ptzUrl,
            """<tptz:ContinuousMove xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl"
                    xmlns:tt="http://www.onvif.org/ver10/schema">
                 <tptz:ProfileToken>$profileToken</tptz:ProfileToken>
                 <tptz:Velocity>
                   <tt:PanTilt x="$x" y="$y"/>
                 </tptz:Velocity>
               </tptz:ContinuousMove>"""
        )
    }

    fun stop() {
        soap(
            ptzUrl,
            """<tptz:Stop xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl">
                 <tptz:ProfileToken>$profileToken</tptz:ProfileToken>
                 <tptz:PanTilt>true</tptz:PanTilt>
                 <tptz:Zoom>true</tptz:Zoom>
               </tptz:Stop>"""
        )
    }

    /**
     * Dò xem camera có cho quản lý / phát lại thẻ nhớ qua ONVIF Profile G không,
     * và thử vài đường ISAPI. Trả về văn bản báo cáo để hiển thị.
     */
    fun probeStorage(): String {
        val out = StringBuilder()
        val services = try {
            soap(
                deviceUrl,
                """<tds:GetServices xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
                     <tds:IncludeCapability>false</tds:IncludeCapability></tds:GetServices>"""
            )
        } catch (e: Exception) {
            return "GetServices lỗi: ${e.message}"
        }
        val map = Regex("""Namespace>(.*?)</\w*:?Namespace>\s*<\w*:?XAddr>(.*?)</""", RegexOption.DOT_MATCHES_ALL)
            .findAll(services).associate { it.groupValues[1].trim() to it.groupValues[2].trim() }
        fun svc(key: String) = map.entries.firstOrNull { it.key.contains(key) }?.value
        val rec = svc("/recording/")
        val search = svc("/search/")
        val replay = svc("/replay/")
        out.appendLine("== ONVIF ==")
        out.appendLine("Recording: ${rec ?: "KHÔNG có"}")
        out.appendLine("Search:    ${search ?: "KHÔNG có"}")
        out.appendLine("Replay:    ${replay ?: "KHÔNG có"}")

        if (search != null) {
            try {
                val r = soap(search, """<tse:GetRecordingSummary xmlns:tse="http://www.onvif.org/ver10/search/wsdl"/>""")
                fun v(tag: String) = Regex("""<\w*:?$tag>(.*?)</""").find(r)?.groupValues?.get(1)
                out.appendLine("Số bản ghi: ${v("NumberRecordings")}")
                out.appendLine("Từ: ${v("DataFrom")}")
                out.appendLine("Đến: ${v("DataUntil")}")
            } catch (e: Exception) {
                out.appendLine("GetRecordingSummary lỗi: ${e.message?.take(200)}")
            }
        }
        if (rec != null) {
            try {
                val r = soap(rec, """<trc:GetRecordings xmlns:trc="http://www.onvif.org/ver10/recording/wsdl"/>""")
                val tokens = Regex("""<\w*:?RecordingToken>(.*?)</""").findAll(r)
                    .map { it.groupValues[1] }.distinct().toList()
                out.appendLine("Recording token: ${tokens.size} (${tokens.take(3)})")
                if (replay != null && tokens.isNotEmpty()) {
                    val u = soap(
                        replay,
                        """<trp:GetReplayUri xmlns:trp="http://www.onvif.org/ver10/replay/wsdl"
                                xmlns:tt="http://www.onvif.org/ver10/schema">
                             <trp:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream>
                               <tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trp:StreamSetup>
                             <trp:RecordingToken>${tokens[0]}</trp:RecordingToken>
                           </trp:GetReplayUri>"""
                    )
                    out.appendLine("Replay URI: ${Regex("""Uri>(.*?)</""").find(u)?.groupValues?.get(1)}")
                }
            } catch (e: Exception) {
                out.appendLine("GetRecordings/Replay lỗi: ${e.message?.take(200)}")
            }
        }

        out.appendLine()
        out.appendLine("== ISAPI (401 = có tồn tại, 404 = không) ==")
        for (path in listOf("/ISAPI/System/deviceInfo", "/ISAPI/ContentMgmt/Storage", "/ISAPI/ContentMgmt/search")) {
            out.appendLine(httpCode(path))
        }
        return out.toString()
    }

    private fun httpCode(path: String): String = try {
        val c = URL("http://$host:$port$path").openConnection() as HttpURLConnection
        c.connectTimeout = 3000
        c.readTimeout = 3000
        val code = c.responseCode
        c.disconnect()
        "$path -> $code"
    } catch (e: Exception) {
        "$path -> lỗi ${e.message?.take(80)}"
    }

    /** RTSP xem trực tiếp (ONVIF GetStreamUri). */
    fun liveUri(): String {
        val r = soap(
            mediaUrl,
            """<trt:GetStreamUri xmlns:trt="http://www.onvif.org/ver10/media/wsdl"
                    xmlns:tt="http://www.onvif.org/ver10/schema">
                 <trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream>
                   <tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup>
                 <trt:ProfileToken>$profileToken</trt:ProfileToken>
               </trt:GetStreamUri>"""
        )
        return unescape(Regex("""<\w*:?Uri>(.*?)</""").find(r)?.groupValues?.get(1) ?: error("Không có Uri"))
    }

    /** URI phát lại theo ONVIF (có thể cần header Require: onvif-replay). */
    fun replayUri(token: String = "OnvifRecordingToken_1"): String {
        val replay = serviceUrl("/replay/") ?: error("Không có dịch vụ Replay")
        val u = soap(
            replay,
            """<trp:GetReplayUri xmlns:trp="http://www.onvif.org/ver10/replay/wsdl"
                    xmlns:tt="http://www.onvif.org/ver10/schema">
                 <trp:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream>
                   <tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trp:StreamSetup>
                 <trp:RecordingToken>$token</trp:RecordingToken>
               </trp:GetReplayUri>"""
        )
        return unescape(Regex("""<\w*:?Uri>(.*?)</""").find(u)?.groupValues?.get(1) ?: error("Không có Uri"))
    }

    /** Thử FindRecordings + FindEvents (7 ngày gần nhất), trả báo cáo thô (rút gọn). */
    fun listRecordings(): String {
        val search = serviceUrl("/search/") ?: return "Camera không có dịch vụ Search"
        val ns = "http://www.onvif.org/ver10/search/wsdl"
        val out = StringBuilder()

        out.appendLine("== FindRecordings ==")
        try {
            val f = soap(search, """<tse:FindRecordings xmlns:tse="$ns"><tse:Scope/>
                <tse:KeepAliveTime>PT10S</tse:KeepAliveTime></tse:FindRecordings>""")
            val tok = Regex("""SearchToken>(.*?)</""").find(f)?.groupValues?.get(1)
            if (tok == null) out.appendLine(squash(f)) else {
                val r = soap(search, """<tse:GetRecordingSearchResults xmlns:tse="$ns">
                    <tse:SearchToken>$tok</tse:SearchToken><tse:MinResults>1</tse:MinResults>
                    <tse:MaxResults>50</tse:MaxResults><tse:WaitTime>PT5S</tse:WaitTime>
                    </tse:GetRecordingSearchResults>""")
                out.appendLine(squash(r))
            }
        } catch (e: Exception) { out.appendLine("lỗi: ${e.message?.take(300)}") }

        out.appendLine()
        out.appendLine("== FindEvents (7 ngày) ==")
        try {
            val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }
            val now = System.currentTimeMillis() + timeOffsetMs
            val start = iso.format(Date(now - 7 * 86_400_000L))
            val end = iso.format(Date(now))
            val f = soap(search, """<tse:FindEvents xmlns:tse="$ns">
                <tse:StartPoint>$start</tse:StartPoint><tse:EndPoint>$end</tse:EndPoint>
                <tse:Scope/><tse:SearchFilter/><tse:IncludeStartState>false</tse:IncludeStartState>
                <tse:KeepAliveTime>PT10S</tse:KeepAliveTime></tse:FindEvents>""")
            val tok = Regex("""SearchToken>(.*?)</""").find(f)?.groupValues?.get(1)
            if (tok == null) out.appendLine(squash(f)) else {
                val r = soap(search, """<tse:GetEventSearchResults xmlns:tse="$ns">
                    <tse:SearchToken>$tok</tse:SearchToken><tse:MinResults>1</tse:MinResults>
                    <tse:MaxResults>50</tse:MaxResults><tse:WaitTime>PT5S</tse:WaitTime>
                    </tse:GetEventSearchResults>""")
                out.appendLine(squash(r))
            }
        } catch (e: Exception) { out.appendLine("lỗi: ${e.message?.take(300)}") }
        return out.toString()
    }

    private var svcCache: Map<String, String>? = null

    private fun serviceUrl(key: String): String? {
        val m = svcCache ?: run {
            val xml = soap(
                deviceUrl,
                """<tds:GetServices xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
                     <tds:IncludeCapability>false</tds:IncludeCapability></tds:GetServices>"""
            )
            Regex("""Namespace>(.*?)</\w*:?Namespace>\s*<\w*:?XAddr>(.*?)</""", RegexOption.DOT_MATCHES_ALL)
                .findAll(xml).associate { it.groupValues[1].trim() to it.groupValues[2].trim() }
                .also { svcCache = it }
        }
        return m.entries.firstOrNull { it.key.contains(key) }?.value
    }

    private fun unescape(s: String) = s.replace("&amp;", "&").trim()

    private fun squash(xml: String, max: Int = 1800) =
        xml.replace(Regex("""\sxmlns(:\w+)?="[^"]*""""), "")
            .replace(Regex("""<(/?)[\w-]+:"""), "<$1")
            .replace(Regex("""\s+"""), " ")
            .take(max)

    // ---------- nội bộ ----------

    /** Camera hay lệch giờ -> lấy giờ UTC của camera để tính digest cho đúng. */
    private fun syncTime() {
        try {
            val r = soap(
                deviceUrl,
                """<tds:GetSystemDateAndTime xmlns:tds="http://www.onvif.org/ver10/device/wsdl"/>""",
                auth = false
            )
            val utc = Regex("""UTCDateTime>(.*?)</""", RegexOption.DOT_MATCHES_ALL)
                .find(r)?.groupValues?.get(1) ?: return
            fun n(tag: String) = Regex("""<\w*:?$tag>(\d+)<""").find(utc)!!.groupValues[1].toInt()
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                set(n("Year"), n("Month") - 1, n("Day"), n("Hour"), n("Minute"), n("Second"))
            }
            timeOffsetMs = cal.timeInMillis - System.currentTimeMillis()
        } catch (_: Exception) { /* bỏ qua, dùng giờ máy */ }
    }

    private fun xaddr(xml: String, service: String): String? =
        Regex("""<\w*:?$service>\s*<\w*:?XAddr>(.*?)</""", RegexOption.DOT_MATCHES_ALL)
            .find(xml)?.groupValues?.get(1)?.trim()

    private fun securityHeader(): String {
        val nonce = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val created = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .format(Date(System.currentTimeMillis() + timeOffsetMs))
        val sha1 = MessageDigest.getInstance("SHA-1").apply {
            update(nonce); update(created.toByteArray()); update(pass.toByteArray())
        }.digest()
        val digest = Base64.encodeToString(sha1, Base64.NO_WRAP)
        val nonceB64 = Base64.encodeToString(nonce, Base64.NO_WRAP)
        return """<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
                    xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
              <wsse:UsernameToken>
                <wsse:Username>$user</wsse:Username>
                <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">$digest</wsse:Password>
                <wsse:Nonce>$nonceB64</wsse:Nonce>
                <wsu:Created>$created</wsu:Created>
              </wsse:UsernameToken></wsse:Security>"""
    }

    private fun soap(url: String, body: String, auth: Boolean = true): String {
        val envelope = """<?xml version="1.0" encoding="UTF-8"?>
            <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
              <s:Header>${if (auth) securityHeader() else ""}</s:Header>
              <s:Body>$body</s:Body>
            </s:Envelope>"""
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 4000
            c.readTimeout = 6000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
            c.outputStream.use { it.write(envelope.toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.readText().orEmpty()
            if (c.responseCode !in 200..299) error("ONVIF ${c.responseCode}: ${text.take(300)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
