package com.example.camptz

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Điều khiển PTZ qua ONVIF (SOAP + WS-UsernameToken digest).
 * LƯU Ý: mọi hàm là blocking -> gọi trong thread nền / coroutine (Dispatchers.IO).
 *
 * Dùng:
 *   val cam = OnvifPtz("192.168.43.99", 80, "admin", "MA_XAC_MINH")
 *   cam.init()              // đồng bộ giờ, lấy địa chỉ dịch vụ + profile
 *   cam.move(-0.5f, 0f)     // quay trái
 *   cam.move(0.5f, 0f)      // quay phải
 *   cam.stop()              // dừng (gọi khi nhả nút)
 *
 * Manifest cần: <uses-permission android:name="android.permission.INTERNET"/>
 *               <application android:usesCleartextTraffic="true" ...>
 */
class OnvifPtz(
    private val host: String,
    private val port: Int,
    private val user: String,
    private val pass: String,
) {
    private val deviceUrl = "http://$host:$port/onvif/device_service"
    private var ptzUrl = ""
    private var mediaUrl = ""
    private var profileToken = ""
    private var timeOffsetMs = 0L

    /** Gọi 1 lần trước khi điều khiển. */
    fun init() {
        syncTime()
        val caps = soap(
            deviceUrl,
            """<tds:GetCapabilities xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
                 <tds:Category>All</tds:Category></tds:GetCapabilities>"""
        )
        ptzUrl = xaddr(caps, "PTZ") ?: error("Camera không báo dịch vụ PTZ")
        mediaUrl = xaddr(caps, "Media") ?: error("Camera không báo dịch vụ Media")

        val profiles = soap(
            mediaUrl,
            """<trt:GetProfiles xmlns:trt="http://www.onvif.org/ver10/media/wsdl"/>"""
        )
        profileToken = Regex("""Profiles[^>]*token="([^"]+)"""")
            .find(profiles)?.groupValues?.get(1) ?: error("Không lấy được profile")
    }

    /** x: trái(-1)..phải(+1), y: xuống(-1)..lên(+1). Tốc độ 0..1. */
    fun move(x: Float, y: Float = 0f) {
        soap(
            ptzUrl,
            """<tptz:ContinuousMove xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl"
                    xmlns:tt="http://www.onvif.org/ver10/schema">
                 <tptz:ProfileToken>$profileToken</tptz:ProfileToken>
                 <tptz:Velocity>
                   <tt:PanTilt x="$x" y="$y"/>
                 </tptz:Velocity>
               </tptz:ContinuousMove>"""
        )
    }

    fun stop() {
        soap(
            ptzUrl,
            """<tptz:Stop xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl">
                 <tptz:ProfileToken>$profileToken</tptz:ProfileToken>
                 <tptz:PanTilt>true</tptz:PanTilt>
                 <tptz:Zoom>true</tptz:Zoom>
               </tptz:Stop>"""
        )
    }

    // ---------- nội bộ ----------

    /** Camera hay lệch giờ -> lấy giờ UTC của camera để tính digest cho đúng. */
    private fun syncTime() {
        try {
            val r = soap(
                deviceUrl,
                """<tds:GetSystemDateAndTime xmlns:tds="http://www.onvif.org/ver10/device/wsdl"/>""",
                auth = false
            )
            val utc = Regex("""UTCDateTime>(.*?)</""", RegexOption.DOT_MATCHES_ALL)
                .find(r)?.groupValues?.get(1) ?: return
            fun n(tag: String) = Regex("""<\w*:?$tag>(\d+)<""").find(utc)!!.groupValues[1].toInt()
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                set(n("Year"), n("Month") - 1, n("Day"), n("Hour"), n("Minute"), n("Second"))
            }
            timeOffsetMs = cal.timeInMillis - System.currentTimeMillis()
        } catch (_: Exception) { /* bỏ qua, dùng giờ máy */ }
    }

    private fun xaddr(xml: String, service: String): String? =
        Regex("""<\w*:?$service>\s*<\w*:?XAddr>(.*?)</""", RegexOption.DOT_MATCHES_ALL)
            .find(xml)?.groupValues?.get(1)?.trim()

    private fun securityHeader(): String {
        val nonce = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val created = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .format(Date(System.currentTimeMillis() + timeOffsetMs))
        val sha1 = MessageDigest.getInstance("SHA-1").apply {
            update(nonce); update(created.toByteArray()); update(pass.toByteArray())
        }.digest()
        val digest = Base64.encodeToString(sha1, Base64.NO_WRAP)
        val nonceB64 = Base64.encodeToString(nonce, Base64.NO_WRAP)
        return """<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
                    xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
              <wsse:UsernameToken>
                <wsse:Username>$user</wsse:Username>
                <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">$digest</wsse:Password>
                <wsse:Nonce>$nonceB64</wsse:Nonce>
                <wsu:Created>$created</wsu:Created>
              </wsse:UsernameToken></wsse:Security>"""
    }

    private fun soap(url: String, body: String, auth: Boolean = true): String {
        val envelope = """<?xml version="1.0" encoding="UTF-8"?>
            <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
              <s:Header>${if (auth) securityHeader() else ""}</s:Header>
              <s:Body>$body</s:Body>
            </s:Envelope>"""
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 4000
            c.readTimeout = 6000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
            c.outputStream.use { it.write(envelope.toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.readText().orEmpty()
            if (c.responseCode !in 200..299) error("ONVIF ${c.responseCode}: ${text.take(300)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
