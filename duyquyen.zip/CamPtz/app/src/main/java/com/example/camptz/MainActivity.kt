package com.example.camptz

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import java.io.File
import java.util.Calendar
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()      // ONVIF: PTZ, live
    private val sdkIo = Executors.newSingleThreadExecutor()   // HCNetSDK: danh sách, tải
    @Volatile private var cam: OnvifPtz? = null
    @Volatile private var hik: HikSession? = null
    @Volatile private var downloading = false
    @Volatile private var formatting = false

    private lateinit var status: TextView
    private lateinit var surface: SurfaceView
    private lateinit var info: TextView
    private lateinit var dayTv: TextView
    private lateinit var countTv: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var panels: List<View>

    private var player: ExoPlayer? = null
    private var playingRec = false
    private var curUser = ""
    private var curPass = ""
    private var selY = 0
    private var selM = 0
    private var selD = 0
    private var listLoaded = false
    private var selectedRow: View? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- dựng giao diện ----------

    private fun field(hint: String, value: String, numeric: Boolean = false, secret: Boolean = false) =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine()
            inputType = when {
                secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                numeric -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT
            }
        }

    private fun wbtn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    private fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f) }

    private fun padBtn(label: String, x: Float, y: Float) = Button(this).apply {
        text = label
        textSize = 24f
        layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; drive(x, y); true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; halt(); true }
                else -> true
            }
        }
    }

    private fun vbox(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(8), dp(12), dp(8))
        views.forEach { addView(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        // ---- khung hình + trạng thái ----
        surface = SurfaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
        }
        status = TextView(this).apply {
            text = "Chưa kết nối"
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        // ---- tab Kết nối ----
        val etHost = field("IP camera", prefs.getString("host", "192.168.43.99")!!)
        val etPort = field("Port ONVIF (PTZ/live)", prefs.getString("port", "80")!!, numeric = true)
        val etSdkPort = field("Port SDK Hikvision (thẻ nhớ)", prefs.getString("sdkport", "8000")!!, numeric = true)
        val etUser = field("User", prefs.getString("user", "admin")!!)
        val etPass = field("Mã xác minh", prefs.getString("pass", "")!!, secret = true)
        info = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(8), 0, dp(8))
        }
        val btnConnect = Button(this).apply {
            text = "Kết nối"
            setOnClickListener {
                val host = etHost.text.toString().trim()
                val port = etPort.text.toString().trim().toIntOrNull() ?: 80
                val sdkPort = etSdkPort.text.toString().trim().toIntOrNull() ?: 8000
                val user = etUser.text.toString().trim()
                val pass = etPass.text.toString()
                curUser = user; curPass = pass
                prefs.edit().putString("host", host).putString("port", port.toString())
                    .putString("sdkport", sdkPort.toString()).putString("user", user)
                    .putString("pass", pass).apply()
                info.text = ""
                listLoaded = false
                ui("Đang kết nối...")
                io.execute {
                    try {
                        val c = OnvifPtz(host, port, user, pass)
                        c.init()
                        cam = c
                        step("ONVIF: OK (PTZ + live)")
                    } catch (e: Exception) {
                        cam = null
                        step("ONVIF lỗi: ${e.message}")
                    }
                }
                sdkIo.execute {
                    hik?.logout(); hik = null
                    try {
                        val s = HikSession()
                        val err = s.login(host, sdkPort, user, pass)
                        if (err == null) {
                            hik = s
                            selY = s.todayY; selM = s.todayM; selD = s.todayD
                            step("SDK: OK, serial ${s.serial}, kênh ${s.channel}")
                            runOnUiThread { dayTv.text = dayLabel() }
                        } else step("SDK: $err")
                    } catch (t: Throwable) {
                        step("SDK: không nạp được thư viện: ${t.message}")
                    }
                }
            }
        }
        val connectPanel = vbox(etHost, etPort, etSdkPort, etUser, etPass, btnConnect, info)

        // ---- tab Live + PTZ ----
        val s = SPEED
        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(spacer(), padBtn("▲", 0f, s), spacer()))
            addView(row(padBtn("◀", -s, 0f), padBtn("■", 0f, 0f), padBtn("▶", s, 0f)))
            addView(row(spacer(), padBtn("▼", 0f, -s), spacer()))
        }
        val livePanel = vbox(
            row(
                wbtn("Xem live") { startLive() },
                wbtn("Dừng hình") { stopPlayer(); ui("Đã dừng hình") }
            ),
            pad
        )

        // ---- tab Thẻ nhớ ----
        dayTv = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            text = "--/--/----"
        }
        countTv = TextView(this).apply {
            setPadding(0, dp(8), 0, dp(4))
            text = "Bấm \"Tải danh sách\""
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cardPanel = vbox(
            row(
                Button(this).apply { text = "◀"; setOnClickListener { shiftDay(-1) } },
                dayTv,
                Button(this).apply { text = "▶"; setOnClickListener { shiftDay(1) } }
            ),
            row(
                wbtn("Tải danh sách") { loadList() },
                wbtn("Dừng hình") { stopPlayer(); ui("Đã dừng hình") }
            ),
            row(
                Button(this).apply {
                    text = "Định dạng thẻ nhớ"
                    setTextColor(Color.RED)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener { confirmFormat() }
                }
            ),
            countTv,
            listBox
        )

        panels = listOf(connectPanel, livePanel, cardPanel)
        val content = FrameLayoutCompat(panels)
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(content)
        }

        val tabs = row(
            wbtn("Kết nối") { showPanel(0) },
            wbtn("Live / PTZ") { showPanel(1) },
            wbtn("Thẻ nhớ") {
                showPanel(2)
                if (hik != null && !listLoaded) loadList()
            }
        )

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            addView(surface)
            addView(status)
            addView(tabs)
            addView(scroll)
        })
        showPanel(0)
    }

    /** Chứa nhiều panel chồng lên nhau, mỗi lúc chỉ hiện một cái. */
    private fun FrameLayoutCompat(views: List<View>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        views.forEach { addView(it) }
    }

    private fun showPanel(i: Int) {
        panels.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
    }

    // ---------- live ----------

    private fun startLive() {
        val h = hik ?: return ui("Hãy kết nối trước (cần đăng nhập SDK)")
        if (formatting) return ui("Đang định dạng thẻ, chưa xem live được")
        stopPlayer()
        playingRec = false
        ui("Đang mở live...")
        val holder = surface.holder
        sdkIo.execute {
            val err = try { h.startLive(holder) } catch (t: Throwable) { t.message }
            if (err == null) { ui("Đang phát live ✔"); return@execute }
            // dự phòng: RTSP qua ONVIF
            val c = cam
            if (c != null) {
                try {
                    val u = withAuth(c.liveUri())
                    runOnUiThread { playingRec = false; play(u) }
                    return@execute
                } catch (_: Exception) { }
            }
            ui("Live lỗi: $err")
        }
    }

    // ---------- thẻ nhớ ----------

    private fun dayLabel() = "%02d/%02d/%04d".format(selD, selM, selY)

    private fun shiftDay(delta: Int) {
        if (selY == 0) return ui("Hãy kết nối trước")
        val c = Calendar.getInstance().apply { clear(); set(selY, selM - 1, selD); add(Calendar.DAY_OF_MONTH, delta) }
        selY = c.get(Calendar.YEAR); selM = c.get(Calendar.MONTH) + 1; selD = c.get(Calendar.DAY_OF_MONTH)
        dayTv.text = dayLabel()
        loadList()
    }

    private fun loadList() {
        val h = hik ?: return ui("Chưa đăng nhập SDK (xem tab Kết nối)")
        listLoaded = true
        countTv.text = "Đang tìm ngày ${dayLabel()}..."
        listBox.removeAllViews()
        val y = selY; val m = selM; val d = selD
        sdkIo.execute {
            try {
                val recs = h.list(y, m, d)
                runOnUiThread { showList(recs) }
            } catch (e: Throwable) {
                runOnUiThread { countTv.text = "Lỗi: ${e.message}" }
            }
        }
    }

    private fun showList(recs: List<RecFile>) {
        listBox.removeAllViews()
        selectedRow = null
        countTv.text = if (recs.isEmpty()) "Không có bản ghi ngày ${dayLabel()}"
        else "${recs.size} bản ghi ngày ${dayLabel()} (bấm để phát, ⬇ để tải)"
        for (r in recs) {
            val rowV = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = "${r.startText()} → ${r.endText()}\n${r.sizeText()} · ${r.typeText()}"
                textSize = 15f
                setPadding(dp(8), dp(10), dp(8), dp(10))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val bPlay = Button(this).apply { text = "▶" }
            val bDl = Button(this).apply { text = "⬇" }
            val doPlay = { selectRow(rowV); playRec(r) }
            tv.setOnClickListener { doPlay() }
            bPlay.setOnClickListener { doPlay() }
            bDl.setOnClickListener { downloadRec(r) }
            rowV.addView(tv); rowV.addView(bPlay); rowV.addView(bDl)
            listBox.addView(rowV)
        }
    }


    private fun confirmFormat() {
        if (hik == null) return ui("Chưa đăng nhập SDK (xem tab Kết nối)")
        if (formatting) return ui("Đang định dạng, đợi chút")
        if (downloading) return ui("Đang tải file, đợi tải xong rồi hãy định dạng")
        AlertDialog.Builder(this)
            .setTitle("Định dạng thẻ nhớ?")
            .setMessage("TOÀN BỘ bản ghi trên thẻ sẽ bị xóa vĩnh viễn và không khôi phục được. Camera sẽ ngừng ghi trong lúc format.")
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Xóa hết") { _, _ -> formatCard() }
            .show()
    }

    private fun formatCard() {
        val h = hik ?: return ui("Chưa đăng nhập SDK")
        formatting = true
        stopPlayer()
        listBox.removeAllViews()
        selectedRow = null
        countTv.text = "Đang định dạng thẻ nhớ, không tắt app..."
        ui("Bắt đầu định dạng...")
        sdkIo.execute {
            val err = try { h.formatDisk { p -> ui("Đang định dạng $p%") } } catch (e: Throwable) { e.message }
            formatting = false
            runOnUiThread {
                if (err == null) {
                    status.text = "Đã định dạng xong thẻ nhớ"
                    countTv.text = "Thẻ nhớ đã được xóa sạch"
                } else {
                    status.text = "Định dạng lỗi: $err"
                    countTv.text = "Định dạng lỗi: $err"
                }
            }
        }
    }

    private fun selectRow(v: View) {
        selectedRow?.setBackgroundColor(Color.TRANSPARENT)
        v.setBackgroundColor(Color.parseColor("#334488FF"))
        selectedRow = v
    }

    private fun playRec(r: RecFile) {
        val h = hik ?: return ui("Chưa đăng nhập SDK")
        if (formatting) return ui("Đang định dạng thẻ, chưa phát được")
        stopPlayer()
        playingRec = true
        ui("Đang mở bản ghi ${r.startText()}...")
        val holder = surface.holder
        sdkIo.execute {
            val err = try { h.startPlayback(r, holder) } catch (t: Throwable) { t.message }
            ui(if (err == null) "Đang phát ✔ ${r.startText()}" else "Không phát được: $err")
        }
    }

    private fun downloadRec(r: RecFile) {
        val h = hik ?: return ui("Chưa đăng nhập SDK")
        if (formatting) return ui("Đang định dạng thẻ, không tải được")
        if (downloading) return ui("Đang tải file khác, đợi chút")
        downloading = true
        val dir = File(getExternalFilesDir(null), "recordings").apply { mkdirs() }
        val dest = File(dir, r.name.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".mp4")
        ui("Bắt đầu tải...")
        sdkIo.execute {
            try { h.stopPlayback() } catch (_: Throwable) { }
            val err = try { h.download(r, dest) { p -> ui("Đang tải $p%") } } catch (e: Throwable) { e.message }
            downloading = false
            ui(if (err == null) "Đã tải xong: ${dest.absolutePath}" else "Tải lỗi: $err")
        }
    }

    // ---------- video ----------

    private fun play(url: String) {
        stopPlayer()
        val p = ExoPlayer.Builder(this).build()
        p.setVideoSurfaceView(surface)
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                ui(
                    if (playingRec) "Không phát lại được (${error.errorCodeName}). Thử nút ⬇ để tải file."
                    else "Lỗi phát: ${error.errorCodeName}"
                )
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) ui("Đang phát ✔")
            }
        })
        val src = RtspMediaSource.Factory()
            .setForceUseRtpTcp(true)
            .createMediaSource(MediaItem.fromUri(url))
        p.setMediaSource(src)
        p.prepare()
        p.playWhenReady = true
        player = p
        ui("Đang mở luồng...")
    }

    private fun stopPlayer() {
        player?.release()
        player = null
        hik?.let { sess -> try { sdkIo.execute { sess.stopPlayback() } } catch (_: Exception) { } }
    }

    /** Gắn user:pass vào URL rtsp nếu chưa có. */
    private fun withAuth(raw: String): String {
        val u = Uri.parse(raw.replace("&amp;", "&"))
        if (u.userInfo != null) return u.toString()
        val ui = "${Uri.encode(curUser)}:${Uri.encode(curPass)}"
        return u.buildUpon().encodedAuthority("$ui@${u.encodedAuthority}").build().toString()
    }

    // ---------- PTZ ----------

    private fun drive(x: Float, y: Float) {
        val c = cam ?: return ui("Chưa kết nối")
        io.execute {
            try { if (x == 0f && y == 0f) c.stop() else c.move(x, y) }
            catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun halt() {
        val c = cam ?: return
        io.execute {
            try { c.stop() } catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    // ---------- tiện ích ----------

    private fun ui(msg: String) = runOnUiThread { status.text = msg }

    private fun step(msg: String) = runOnUiThread {
        status.text = msg
        info.append(msg + "\n")
    }

    override fun onStop() {
        super.onStop()
        halt()
        stopPlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        sdkIo.execute { hik?.logout(); hik = null }
        sdkIo.shutdown()
        io.shutdown()
    }

    companion object {
        private const val SPEED = 0.5f
    }
}
