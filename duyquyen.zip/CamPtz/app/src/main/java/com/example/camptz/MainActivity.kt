package com.example.camptz

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    // 1 luồng duy nhất -> lệnh move/stop luôn đúng thứ tự
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var cam: OnvifPtz? = null
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        fun field(hint: String, value: String, numeric: Boolean = false, secret: Boolean = false) =
            EditText(this).apply {
                this.hint = hint
                setText(value)
                setSingleLine()
                inputType = when {
                    secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    numeric -> InputType.TYPE_CLASS_NUMBER
                    else -> InputType.TYPE_CLASS_TEXT
                }
            }

        val etHost = field("IP camera", prefs.getString("host", "192.168.43.99")!!)
        val etPort = field("Port ONVIF", prefs.getString("port", "80")!!, numeric = true)
        val etUser = field("User", prefs.getString("user", "admin")!!)
        val etPass = field("Mật khẩu / mã xác minh", prefs.getString("pass", "")!!, secret = true)

        val btnConnect = Button(this).apply { text = "Kết nối" }
        status = TextView(this).apply {
            text = "Chưa kết nối"
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }

        fun padBtn(label: String, x: Float, y: Float) = Button(this).apply {
            text = label
            textSize = 24f
            layoutParams = LinearLayout.LayoutParams(0, dp(80), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { v.isPressed = true; drive(x, y); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; halt(); true }
                    else -> true
                }
            }
        }
        fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(80), 1f) }
        fun row(vararg views: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach { addView(it) }
        }

        val s = SPEED
        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(spacer(), padBtn("▲", 0f, s), spacer()))
            addView(row(padBtn("◀", -s, 0f), padBtn("■", 0f, 0f), padBtn("▶", s, 0f)))
            addView(row(spacer(), padBtn("▼", 0f, -s), spacer()))
        }

        btnConnect.setOnClickListener {
            val host = etHost.text.toString().trim()
            val port = etPort.text.toString().trim().toIntOrNull() ?: 80
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString()
            prefs.edit().putString("host", host).putString("port", port.toString())
                .putString("user", user).putString("pass", pass).apply()
            ui("Đang kết nối...")
            io.execute {
                try {
                    val c = OnvifPtz(host, port, user, pass)
                    c.init()
                    cam = c
                    ui("Đã kết nối ✔  Giữ nút để quay, nhả để dừng")
                } catch (e: Exception) {
                    cam = null
                    ui("Lỗi kết nối: ${e.message}")
                }
            }
        }

        val btnProbe = Button(this).apply { text = "Dò thẻ nhớ (SD)" }
        val probeOut = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, dp(8), 0, dp(8))
        }
        btnProbe.setOnClickListener {
            val c = cam ?: return@setOnClickListener ui("Hãy kết nối trước")
            probeOut.text = "Đang dò..."
            io.execute {
                val rep = try { c.probeStorage() } catch (e: Exception) { "Lỗi: ${e.message}" }
                runOnUiThread { probeOut.text = rep }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(etHost); addView(etPort); addView(etUser); addView(etPass)
            addView(btnConnect)
            addView(status)
            addView(pad)
            addView(btnProbe)
            addView(probeOut)
        }
        setContentView(ScrollView(this).apply {
            fitsSystemWindows = true
            addView(root)
        })
    }

    private fun drive(x: Float, y: Float) {
        val c = cam ?: return ui("Chưa kết nối")
        io.execute {
            try { if (x == 0f && y == 0f) c.stop() else c.move(x, y) }
            catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun halt() {
        val c = cam ?: return
        io.execute {
            try { c.stop() } catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun ui(msg: String) = runOnUiThread { status.text = msg }

    override fun onStop() {
        super.onStop()
        halt() // rời app là dừng camera
    }

    companion object {
        private const val SPEED = 0.5f
    }
}
