package com.example.camptz

import android.app.Activity
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class MainActivity : Activity() {

    // 1 luồng duy nhất -> lệnh move/stop luôn đúng thứ tự
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var cam: OnvifPtz? = null
    private lateinit var status: TextView
    private lateinit var urlEt: EditText
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var libVlc: LibVLC
    private lateinit var mp: MediaPlayer
    private var viewsAttached = false

    private var curHost = ""
    private var curUser = ""
    private var curPass = ""

    private var candidates: List<String> = emptyList()
    private var candIdx = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        libVlc = LibVLC(this, arrayListOf("--rtsp-tcp", "--network-caching=600"))
        mp = MediaPlayer(libVlc)
        mp.setEventListener(object : MediaPlayer.EventListener {
            override fun onEvent(event: MediaPlayer.Event) {
                when (event.type) {
                    MediaPlayer.Event.Playing -> ui("Đang phát ✔  (${mask(currentUrl())})")
                    MediaPlayer.Event.EncounteredError -> runOnUiThread { onPlayError() }
                }
            }
        })

        fun field(hint: String, value: String, numeric: Boolean = false, secret: Boolean = false) =
            EditText(this).apply {
                this.hint = hint
                setText(value)
                setSingleLine()
                inputType = when {
                    secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    numeric -> InputType.TYPE_CLASS_NUMBER
                    else -> InputType.TYPE_CLASS_TEXT
                }
            }

        val etHost = field("IP camera", prefs.getString("host", "192.168.43.99")!!)
        val etPort = field("Port ONVIF", prefs.getString("port", "80")!!, numeric = true)
        val etUser = field("User", prefs.getString("user", "admin")!!)
        val etPass = field("Mật khẩu / mã xác minh", prefs.getString("pass", "")!!, secret = true)

        val btnConnect = Button(this).apply { text = "Kết nối" }
        status = TextView(this).apply {
            text = "Chưa kết nối"
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            setTextIsSelectable(true)
        }

        fun wbtn(label: String) = Button(this).apply {
            text = label
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        fun padBtn(label: String, x: Float, y: Float) = Button(this).apply {
            text = label
            textSize = 24f
            layoutParams = LinearLayout.LayoutParams(0, dp(80), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { v.isPressed = true; drive(x, y); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; halt(); true }
                    else -> true
                }
            }
        }
        fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(80), 1f) }
        fun row(vararg views: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach { addView(it) }
        }

        // ---- video (libVLC) ----
        videoLayout = VLCVideoLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220))
            setBackgroundColor(0xFF000000.toInt())
        }
        urlEt = EditText(this).apply {
            hint = "RTSP phát lại (sửa giờ rồi bấm Phát URL)"
            textSize = 12f
        }
        val btnLive = wbtn("Live")
        val btnPlay = wbtn("Phát URL")
        val btnStop = wbtn("Dừng hình")

        // ---- PTZ ----
        val s = SPEED
        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(spacer(), padBtn("▲", 0f, s), spacer()))
            addView(row(padBtn("◀", -s, 0f), padBtn("■", 0f, 0f), padBtn("▶", s, 0f)))
            addView(row(spacer(), padBtn("▼", 0f, -s), spacer()))
        }

        // ---- thẻ nhớ ----
        val btnProbe = wbtn("Dò thẻ nhớ")
        val btnList = wbtn("Liệt kê bản ghi")
        val probeOut = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(8), 0, dp(8))
        }

        btnConnect.setOnClickListener {
            val host = etHost.text.toString().trim()
            val port = etPort.text.toString().trim().toIntOrNull() ?: 80
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString()
            curHost = host; curUser = user; curPass = pass
            prefs.edit().putString("host", host).putString("port", port.toString())
                .putString("user", user).putString("pass", pass).apply()
            ui("Đang kết nối...")
            io.execute {
                try {
                    val c = OnvifPtz(host, port, user, pass)
                    c.init()
                    cam = c
                    ui("Đã kết nối ✔  Giữ nút để quay, nhả để dừng")
                    runOnUiThread { urlEt.setText(sampleReplayUrl(host)) }
                } catch (e: Exception) {
                    cam = null
                    ui("Lỗi kết nối: ${e.message}")
                }
            }
        }

        btnLive.setOnClickListener {
            val c = cam
            io.execute {
                val list = ArrayList<String>()
                try { if (c != null) list += c.liveUri() } catch (_: Exception) { }
                list += "rtsp://$curHost:554/Streaming/Channels/101"
                list += "rtsp://$curHost:554/h264_stream"
                list += "rtsp://$curHost:554/Streaming/Channels/102"
                runOnUiThread { playList(list.map { withAuth(it) }) }
            }
        }
        btnPlay.setOnClickListener {
            val u = urlEt.text.toString().trim()
            if (u.isEmpty()) return@setOnClickListener ui("Chưa có URL")
            playList(listOf(withAuth(u)))
        }
        btnStop.setOnClickListener { stopPlayer(); ui("Đã dừng hình") }

        btnProbe.setOnClickListener {
            val c = cam ?: return@setOnClickListener ui("Hãy kết nối trước")
            probeOut.text = "Đang dò..."
            io.execute {
                val rep = try { c.probeStorage() } catch (e: Exception) { "Lỗi: ${e.message}" }
                runOnUiThread { probeOut.text = rep }
            }
        }
        btnList.setOnClickListener {
            val c = cam ?: return@setOnClickListener ui("Hãy kết nối trước")
            probeOut.text = "Đang liệt kê..."
            io.execute {
                val rep = try { c.listRecordings() } catch (e: Exception) { "Lỗi: ${e.message}" }
                runOnUiThread { probeOut.text = rep }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(etHost); addView(etPort); addView(etUser); addView(etPass)
            addView(btnConnect)
            addView(status)
            addView(videoLayout)
            addView(row(btnLive, btnPlay, btnStop))
            addView(urlEt)
            addView(pad)
            addView(row(btnProbe, btnList))
            addView(probeOut)
        }
        setContentView(ScrollView(this).apply {
            fitsSystemWindows = true
            addView(root)
        })
    }

    // ---------- video ----------

    override fun onStart() {
        super.onStart()
        if (!viewsAttached) {
            mp.attachViews(videoLayout, null, false, false)
            viewsAttached = true
        }
    }

    private fun currentUrl() = candidates.getOrNull(candIdx) ?: ""

    private fun playList(urls: List<String>) {
        if (urls.isEmpty()) return
        candidates = urls
        candIdx = 0
        startCandidate()
    }

    private fun startCandidate() {
        val url = currentUrl()
        mp.stop()
        val media = Media(libVlc, Uri.parse(url))
        media.setHWDecoderEnabled(true, false)
        media.addOption(":network-caching=600")
        mp.media = media
        media.release()
        mp.play()
        ui("Mở (${candIdx + 1}/${candidates.size}): ${mask(url)}")
    }

    private fun onPlayError() {
        if (candIdx + 1 < candidates.size) {
            candIdx++
            startCandidate()
        } else {
            ui("Không phát được: ${mask(currentUrl())}")
        }
    }

    private fun stopPlayer() {
        candidates = emptyList()
        candIdx = 0
        mp.stop()
    }

    /** Gắn user:pass vào URL rtsp nếu chưa có. */
    private fun withAuth(raw: String): String {
        val u = Uri.parse(raw.replace("&amp;", "&"))
        if (u.userInfo != null) return u.toString()
        val ui = "${Uri.encode(curUser)}:${Uri.encode(curPass)}"
        return u.buildUpon().encodedAuthority("$ui@${u.encodedAuthority}").build().toString()
    }

    private fun mask(url: String) = url.replace(Regex("""//[^/@]*@"""), "//***@")

    /** URL mẫu kiểu Hikvision: phát lại đoạn 30–20 phút trước (giờ UTC của điện thoại). */
    private fun sampleReplayUrl(host: String): String {
        val f = SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val now = System.currentTimeMillis()
        val st = f.format(Date(now - 30 * 60_000L))
        val en = f.format(Date(now - 20 * 60_000L))
        return "rtsp://$host:554/Streaming/tracks/101?starttime=$st&endtime=$en"
    }

    // ---------- PTZ ----------

    private fun drive(x: Float, y: Float) {
        val c = cam ?: return ui("Chưa kết nối")
        io.execute {
            try { if (x == 0f && y == 0f) c.stop() else c.move(x, y) }
            catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun halt() {
        val c = cam ?: return
        io.execute {
            try { c.stop() } catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun ui(msg: String) = runOnUiThread { status.text = msg }

    override fun onStop() {
        super.onStop()
        halt()
        stopPlayer()
        if (viewsAttached) {
            mp.detachViews()
            viewsAttached = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mp.release()
        libVlc.release()
    }

    companion object {
        private const val SPEED = 0.5f
    }
}
