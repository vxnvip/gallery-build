package com.example.camptz

import android.app.Activity
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class MainActivity : Activity() {

    // 1 luồng duy nhất -> lệnh move/stop luôn đúng thứ tự
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var cam: OnvifPtz? = null
    private lateinit var status: TextView
    private lateinit var surface: SurfaceView
    private lateinit var urlEt: EditText
    private var player: ExoPlayer? = null
    private var curUser = ""
    private var curPass = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        fun field(hint: String, value: String, numeric: Boolean = false, secret: Boolean = false) =
            EditText(this).apply {
                this.hint = hint
                setText(value)
                setSingleLine()
                inputType = when {
                    secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    numeric -> InputType.TYPE_CLASS_NUMBER
                    else -> InputType.TYPE_CLASS_TEXT
                }
            }

        val etHost = field("IP camera", prefs.getString("host", "192.168.43.99")!!)
        val etPort = field("Port ONVIF", prefs.getString("port", "80")!!, numeric = true)
        val etSdkPort = field("Port SDK Hikvision (thường 8000)", prefs.getString("sdkport", "8000")!!, numeric = true)
        val etUser = field("User", prefs.getString("user", "admin")!!)
        val etPass = field("Mật khẩu / mã xác minh", prefs.getString("pass", "")!!, secret = true)

        val btnConnect = Button(this).apply { text = "Kết nối" }
        status = TextView(this).apply {
            text = "Chưa kết nối"
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }

        fun wbtn(label: String) = Button(this).apply {
            text = label
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        fun padBtn(label: String, x: Float, y: Float) = Button(this).apply {
            text = label
            textSize = 24f
            layoutParams = LinearLayout.LayoutParams(0, dp(80), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { v.isPressed = true; drive(x, y); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; halt(); true }
                    else -> true
                }
            }
        }
        fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(80), 1f) }
        fun row(vararg views: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach { addView(it) }
        }

        // ---- video ----
        surface = SurfaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220))
        }
        urlEt = EditText(this).apply {
            hint = "RTSP phát lại (sửa giờ rồi bấm Phát URL)"
            textSize = 12f
        }
        val btnLive = wbtn("Live")
        val btnPlay = wbtn("Phát URL")
        val btnStop = wbtn("Dừng hình")

        // ---- PTZ ----
        val s = SPEED
        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(spacer(), padBtn("▲", 0f, s), spacer()))
            addView(row(padBtn("◀", -s, 0f), padBtn("■", 0f, 0f), padBtn("▶", s, 0f)))
            addView(row(spacer(), padBtn("▼", 0f, -s), spacer()))
        }

        // ---- thẻ nhớ ----
        val btnProbe = wbtn("Dò thẻ nhớ")
        val btnList = wbtn("Liệt kê bản ghi")
        val btnFiles = wbtn("Liệt kê file SD")
        val probeOut = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(8), 0, dp(8))
        }

        btnConnect.setOnClickListener {
            val host = etHost.text.toString().trim()
            val port = etPort.text.toString().trim().toIntOrNull() ?: 80
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString()
            curUser = user; curPass = pass
            prefs.edit().putString("host", host).putString("port", port.toString())
                .putString("user", user).putString("pass", pass).apply()
            ui("Đang kết nối...")
            io.execute {
                try {
                    val c = OnvifPtz(host, port, user, pass)
                    c.init()
                    cam = c
                    ui("Đã kết nối ✔  Giữ nút để quay, nhả để dừng")
                    runOnUiThread { urlEt.setText(sampleReplayUrl(host)) }
                } catch (e: Exception) {
                    cam = null
                    ui("Lỗi kết nối: ${e.message}")
                }
            }
        }

        btnLive.setOnClickListener {
            val c = cam ?: return@setOnClickListener ui("Hãy kết nối trước")
            io.execute {
                try {
                    val u = withAuth(c.liveUri())
                    runOnUiThread { play(u) }
                } catch (e: Exception) { ui("Lỗi live: ${e.message}") }
            }
        }
        btnPlay.setOnClickListener {
            val u = urlEt.text.toString().trim()
            if (u.isEmpty()) return@setOnClickListener ui("Chưa có URL")
            play(withAuth(u))
        }
        btnStop.setOnClickListener { stopPlayer(); ui("Đã dừng hình") }

        btnProbe.setOnClickListener {
            val c = cam ?: return@setOnClickListener ui("Hãy kết nối trước")
            probeOut.text = "Đang dò..."
            io.execute {
                val rep = try { c.probeStorage() } catch (e: Exception) { "Lỗi: ${e.message}" }
                runOnUiThread { probeOut.text = rep }
            }
        }
        btnList.setOnClickListener {
            val c = cam ?: return@setOnClickListener ui("Hãy kết nối trước")
            probeOut.text = "Đang liệt kê..."
            io.execute {
                val rep = try { c.listRecordings() } catch (e: Exception) { "Lỗi: ${e.message}" }
                runOnUiThread { probeOut.text = rep }
            }
        }

        btnFiles.setOnClickListener {
            val host = etHost.text.toString().trim()
            val sdkPort = etSdkPort.text.toString().trim().toIntOrNull() ?: 8000
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString()
            prefs.edit().putString("sdkport", sdkPort.toString()).apply()
            probeOut.text = "Đang đăng nhập SDK và tìm file..."
            io.execute {
                val rep = try { HikFileSearch(host, sdkPort, user, pass).report(7) }
                          catch (e: Throwable) { "Lỗi: ${e.message}" }
                runOnUiThread { probeOut.text = rep }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(etHost); addView(etPort); addView(etSdkPort); addView(etUser); addView(etPass)
            addView(btnConnect)
            addView(status)
            addView(surface)
            addView(row(btnLive, btnPlay, btnStop))
            addView(urlEt)
            addView(pad)
            addView(row(btnProbe, btnList, btnFiles))
            addView(probeOut)
        }
        setContentView(ScrollView(this).apply {
            fitsSystemWindows = true
            addView(root)
        })
    }

    // ---------- video ----------

    private fun play(url: String) {
        stopPlayer()
        val p = ExoPlayer.Builder(this).build()
        p.setVideoSurfaceView(surface)
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                ui("Lỗi phát: ${error.errorCodeName}")
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) ui("Đang phát ✔")
            }
        })
        val src = RtspMediaSource.Factory()
            .setForceUseRtpTcp(true)
            .createMediaSource(MediaItem.fromUri(url))
        p.setMediaSource(src)
        p.prepare()
        p.playWhenReady = true
        player = p
        ui("Đang mở luồng...")
    }

    private fun stopPlayer() {
        player?.release()
        player = null
    }

    /** Gắn user:pass vào URL rtsp nếu chưa có. */
    private fun withAuth(raw: String): String {
        val u = Uri.parse(raw.replace("&amp;", "&"))
        if (u.userInfo != null) return u.toString()
        val ui = "${Uri.encode(curUser)}:${Uri.encode(curPass)}"
        return u.buildUpon().encodedAuthority("$ui@${u.encodedAuthority}").build().toString()
    }

    /** URL mẫu kiểu Hikvision: phát lại đoạn 30–20 phút trước (giờ UTC của điện thoại). */
    private fun sampleReplayUrl(host: String): String {
        val f = SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val now = System.currentTimeMillis()
        val st = f.format(Date(now - 30 * 60_000L))
        val en = f.format(Date(now - 20 * 60_000L))
        return "rtsp://$host:554/Streaming/tracks/101?starttime=$st&endtime=$en"
    }

    // ---------- PTZ ----------

    private fun drive(x: Float, y: Float) {
        val c = cam ?: return ui("Chưa kết nối")
        io.execute {
            try { if (x == 0f && y == 0f) c.stop() else c.move(x, y) }
            catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun halt() {
        val c = cam ?: return
        io.execute {
            try { c.stop() } catch (e: Exception) { ui("Lỗi: ${e.message}") }
        }
    }

    private fun ui(msg: String) = runOnUiThread { status.text = msg }

    override fun onStop() {
        super.onStop()
        halt()
        stopPlayer()
    }

    companion object {
        private const val SPEED = 0.5f
    }
}
