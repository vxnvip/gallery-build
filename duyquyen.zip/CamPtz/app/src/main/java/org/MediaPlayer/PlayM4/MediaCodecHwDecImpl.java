package org.MediaPlayer.PlayM4;

import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.util.Log;
import android.util.Range;

/** Native gọi qua JNI để dò khả năng giải mã phần cứng. */
public class MediaCodecHwDecImpl {
    private final String TAG = "PlayerSDK";
    private int nMaxHeight = 0, nMaxWeight = 0, nMinHeight = 0, nMinWeight = 0;

    private MediaCodecInfo chooseCodec(String mime, boolean encoder) {
        int n = MediaCodecList.getCodecCount();
        for (int i = 0; i < n; i++) {
            MediaCodecInfo info = MediaCodecList.getCodecInfoAt(i);
            for (String t : info.getSupportedTypes()) {
                if (t.equalsIgnoreCase(mime)) {
                    if (encoder && info.isEncoder()) return info;
                    if (!encoder && !info.isEncoder()) return info;
                }
            }
        }
        return null;
    }

    public int GetMaxHeight() { return nMaxHeight; }
    public int GetMaxWeight() { return nMaxWeight; }
    public int GetMinHeight() { return nMinHeight; }
    public int GetMinWeight() { return nMinWeight; }

    public int Init(int type, boolean encoder) {
        if (type < 0) return 0x8003;
        String mime;
        switch (type) {
            case 0: mime = "video/avc"; break;
            case 1: mime = "video/hevc"; break;
            case 2: mime = "video/mp4v-es"; break;
            case 3: mime = "video/mjpeg"; break;
            default: Log.i(TAG, "other type is not support set mime null"); mime = ""; break;
        }
        if (mime.isEmpty()) return 0x8101;
        MediaCodecInfo info = chooseCodec(mime, encoder);
        if (info == null) return 0x8103;
        try {
            MediaCodecInfo.CodecCapabilities caps = info.getCapabilitiesForType(mime);
            if (caps != null) {
                MediaCodecInfo.VideoCapabilities vc = caps.getVideoCapabilities();
                if (vc != null) {
                    Range<Integer> h = vc.getSupportedHeights();
                    Range<Integer> w = vc.getSupportedWidths();
                    if (h != null && w != null) {
                        nMaxHeight = h.getUpper(); nMinHeight = h.getLower();
                        nMaxWeight = w.getUpper(); nMinWeight = w.getLower();
                    }
                }
            }
            return 0;
        } catch (Exception e) {
            Log.e(TAG, "MEDIACODEC_TRY_CATCH_ERR createDecoderByType mime: " + mime);
            e.printStackTrace();
            return 0x8004;
        }
    }
}
