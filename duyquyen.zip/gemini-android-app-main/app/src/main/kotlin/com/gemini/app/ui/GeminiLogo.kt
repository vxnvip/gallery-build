package com.gemini.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Logo ">_ Gemini" vẽ hoàn toàn bằng code (không dùng ảnh).
 *
 * - Chữ "Gemini": đường viền vector của font Poppins Medium, nhúng sẵn dưới dạng
 *   path (không cần file font). Tô gradient xanh -> tím -> hồng.
 * - ">" và "_": vẽ bằng nét bo tròn. ">" cao đúng bằng chữ G.
 *
 * Toạ độ nội bộ tính theo đơn vị font (1000 đơn vị = 1 em), gốc y nằm ở đường
 * baseline, trục y hướng xuống. [height] là chiều cao vùng chữ (từ chấm chữ "i"
 * tới đáy), chiều rộng tự tính theo tỉ lệ.
 */
@Composable
fun GeminiLogo(
    modifier: Modifier = Modifier,
    height: Dp = 22.dp,
    contentDescription: String = "Gemini"
) {
    val glyphs = remember { parseGlyphPath(GLYPH_DATA) }
    val chevron = remember {
        Path().apply {
            moveTo(CHEV_LEFT, CHEV_TOP)
            lineTo(CHEV_RIGHT, CHEV_MID)
            lineTo(CHEV_LEFT, CHEV_BOTTOM)
        }
    }
    val underscore = remember {
        Path().apply {
            moveTo(UNDERSCORE_LEFT, UNDERSCORE_Y)
            lineTo(UNDERSCORE_RIGHT, UNDERSCORE_Y)
        }
    }
    val textBrush = remember {
        Brush.horizontalGradient(
            colorStops = arrayOf(
                0.00f to Color(0xFF3988FC),
                0.23f to Color(0xFF4891FA),
                0.41f to Color(0xFF848EF5),
                0.51f to Color(0xFFA48CF3),
                0.59f to Color(0xFFB682D7),
                0.73f to Color(0xFFD072A6),
                0.86f to Color(0xFFE46687),
                1.00f to Color(0xFFEB627E)
            ),
            startX = GRADIENT_START,
            endX = LOGO_WIDTH
        )
    }
    val chevronBrush = remember { SolidColor(Color(0xFF2F7EFE)) }
    val underscoreBrush = remember { SolidColor(Color(0xFF3484FD)) }
    val stroke = remember { Stroke(width = STROKE_WIDTH, cap = StrokeCap.Round, join = StrokeJoin.Round) }

    Canvas(
        modifier = modifier
            .height(height)
            .aspectRatio(LOGO_WIDTH / LOGO_HEIGHT)
            .semantics { this.contentDescription = contentDescription }
    ) {
        val s = size.height / LOGO_HEIGHT
        withTransform({
            scale(s, s, Offset.Zero)
            translate(0f, -LOGO_TOP)
        }) {
            drawPath(glyphs, textBrush)
            drawPath(chevron, chevronBrush, style = stroke)
            drawPath(underscore, underscoreBrush, style = stroke)
        }
    }
}

// ---- Kích thước (đơn vị font) ------------------------------------------------
private const val LOGO_TOP = -770f      // đỉnh chấm chữ "i"
private const val LOGO_BOTTOM = 9f   // đáy chữ "e"
private const val LOGO_HEIGHT = LOGO_BOTTOM - LOGO_TOP
private const val LOGO_WIDTH = 4581f
private const val GRADIENT_START = 1071f   // gradient bắt đầu từ mép trái chữ G
private const val STROKE_WIDTH = 96f

private const val CHEV_LEFT = 48f
private const val CHEV_RIGHT = 381f
private const val CHEV_TOP = -656f
private const val CHEV_MID = -349f
private const val CHEV_BOTTOM = -42f

private const val UNDERSCORE_LEFT = 561f
private const val UNDERSCORE_RIGHT = 816f
private const val UNDERSCORE_Y = -42f

// ---- Parser path (chỉ hỗ trợ M L Q C Z tuyệt đối) ---------------------------
private val PATH_TOKEN = Regex("[MLQCZ]|-?\\d+(?:\\.\\d+)?")

private fun parseGlyphPath(data: String): Path {
    val tokens = PATH_TOKEN.findAll(data).map { it.value }.toList()
    val path = Path()
    var i = 0
    fun next(): Float = tokens[i++].toFloat()
    while (i < tokens.size) {
        when (tokens[i++]) {
            "M" -> path.moveTo(next(), next())
            "L" -> path.lineTo(next(), next())
            "Q" -> path.quadraticBezierTo(next(), next(), next(), next())
            "C" -> path.cubicTo(next(), next(), next(), next(), next(), next())
            "Z" -> path.close()
        }
    }
    return path
}

// Đường viền các chữ G e m i n i (Poppins Medium), đã dời sẵn theo vị trí.
private const val GLYPH_DATA = """
            M1612 -495Q1585 -547 1537 -573.5Q1489 -600 1426 -600Q1357 -600 1303 -569Q1249 -538 1218.5 -481Q1188 -424 1188 -349Q1188 -274 1218.5 -216.5Q1249 -159 1303 -128Q1357 -97 1426 -97Q1519 -97 1577 -149Q1635 -201 1648 -290L1387 -290L1387 -381L1770 -381L1770 -292Q1759 -211 1712.5 -143Q1666 -75 1591.5 -34.5Q1517 6 1426 6Q1328 6 1247 -39.5Q1166 -85 1118.5 -166Q1071 -247 1071 -349Q1071 -451 1118.5 -532Q1166 -613 1247.5 -658.5Q1329 -704 1426 -704Q1537 -704 1623.5 -649.5Q1710 -595 1749 -495Z
            M2383 -233L1962 -233Q1967 -167 2011 -127Q2055 -87 2119 -87Q2211 -87 2249 -164L2372 -164Q2347 -88 2281.5 -39.5Q2216 9 2119 9Q2040 9 1977.5 -26.5Q1915 -62 1879.5 -126.5Q1844 -191 1844 -276Q1844 -361 1878.5 -425.5Q1913 -490 1975.5 -525Q2038 -560 2119 -560Q2197 -560 2258 -526Q2319 -492 2353 -430.5Q2387 -369 2387 -289Q2387 -258 2383 -233Z
            M2268 -325Q2267 -388 2223 -426Q2179 -464 2114 -464Q2055 -464 2013 -426.5Q1971 -389 1963 -325Z
            M3393 -325L3393 0L3280 0L3280 -308Q3280 -382 3243 -421.5Q3206 -461 3142 -461Q3078 -461 3040.5 -421.5Q3003 -382 3003 -308L3003 0L2890 0L2890 -308Q2890 -382 2853 -421.5Q2816 -461 2752 -461Q2688 -461 2650.5 -421.5Q2613 -382 2613 -308L2613 0L2499 0L2499 -551L2613 -551L2613 -488Q2641 -522 2684 -541Q2727 -560 2776 -560Q2842 -560 2894 -532Q2946 -504 2974 -451Q2999 -501 3052 -530.5Q3105 -560 3166 -560Q3231 -560 3282.5 -533Q3334 -506 3363.5 -453Q3393 -400 3393 -325Z
            M3523 -697Q3523 -728 3544 -749Q3565 -770 3596 -770Q3626 -770 3647 -749Q3668 -728 3668 -697Q3668 -666 3647 -645Q3626 -624 3596 -624Q3565 -624 3544 -645Q3523 -666 3523 -697Z
            M3652 -551L3652 0L3538 0L3538 -551Z
            M4306 -325L4306 0L4193 0L4193 -308Q4193 -382 4156 -421.5Q4119 -461 4055 -461Q3991 -461 3953.5 -421.5Q3916 -382 3916 -308L3916 0L3802 0L3802 -551L3916 -551L3916 -488Q3944 -522 3987.5 -541Q4031 -560 4080 -560Q4145 -560 4196.5 -533Q4248 -506 4277 -453Q4306 -400 4306 -325Z
            M4436 -697Q4436 -728 4457 -749Q4478 -770 4509 -770Q4539 -770 4560 -749Q4581 -728 4581 -697Q4581 -666 4560 -645Q4539 -624 4509 -624Q4478 -624 4457 -645Q4436 -666 4436 -697Z
            M4565 -551L4565 0L4451 0L4451 -551Z
        """
