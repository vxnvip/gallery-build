package com.gemini.app.ui.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

internal data class QuickAction(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val description: String
)

private data class ActionGroup(val title: String, val items: List<QuickAction>)

private val groups = listOf(
    ActionGroup(
        "Phản hồi",
        listOf(
            QuickAction("copy", "Sao chép", Icons.Default.ContentCopy, "Phản hồi cuối → bộ nhớ tạm"),
            QuickAction("share", "Chia sẻ", Icons.Default.Share, "Chia sẻ phản hồi cuối"),
            QuickAction("history", "Lịch sử", Icons.Default.History, "Câu hỏi gần đây"),
        )
    ),
    ActionGroup(
        "Phiên",
        listOf(
            QuickAction("compress", "Nén", Icons.Default.Compress, "Tóm tắt & bắt đầu lại"),
            QuickAction("reset", "Đặt lại", Icons.Default.Refresh, "Xóa ngữ cảnh"),
            QuickAction("clearui", "Xóa màn hình", Icons.Default.Delete, "Chỉ xóa phần hiển thị"),
            QuickAction("chats", "Lịch sử chat", Icons.Default.Save, "Lưu / mở lại"),
            QuickAction("stats", "Thống kê", Icons.Default.Info, "Thông tin phiên"),
        )
    ),
    ActionGroup(
        "Dự án",
        listOf(
            QuickAction("memory", "Bộ nhớ", Icons.Default.Memory, "Đọc GEMINI.md"),
            QuickAction("init", "Khởi tạo", Icons.Default.NoteAdd, "Tạo GEMINI.md"),
            QuickAction("shell", "Thử shell", Icons.Default.Terminal, "Chạy thử qua Termux"),
        )
    ),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickActionsSheet(
    viewModel: ChatViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var dialog by remember { mutableStateOf<DialogContent?>(null) }
    var showChats by remember { mutableStateOf(false) }
    val expanded = remember { mutableStateOf(emptySet<String>()) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 600.dp)
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                "Thao tác nhanh",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                "Lối tắt cho cuộc trò chuyện. Cài đặt, tài khoản và trợ giúp nằm trong menu bên (☰).",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            groups.forEach { group ->
                AccordionSection(
                    title = group.title,
                    expanded = group.title in expanded.value,
                    onToggle = {
                        expanded.value = if (group.title in expanded.value)
                            expanded.value - group.title else expanded.value + group.title
                    }
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 320.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(group.items) { action ->
                            ActionTile(action) {
                                handleAction(
                                    action.id, viewModel, context,
                                    onShowDialog = { dialog = it },
                                    onShowChats = { showChats = true },
                                    onDismiss = onDismiss
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    dialog?.let { d ->
        AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = {
                TextButton(onClick = { dialog = null }) { Text("Đóng") }
            },
            title = { Text(d.title) },
            text = {
                Column {
                    d.lines.forEach { line ->
                        Text(
                            line,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = if (d.mono) FontFamily.Monospace else null
                            )
                        )
                    }
                }
            }
        )
    }

    if (showChats) {
        ChatsDialog(
            viewModel = viewModel,
            onDismiss = { showChats = false },
            onResumed = {
                showChats = false
                onDismiss()
            }
        )
    }
}

private fun handleAction(
    id: String,
    viewModel: ChatViewModel,
    context: Context,
    onShowDialog: (DialogContent) -> Unit,
    onShowChats: () -> Unit,
    onDismiss: () -> Unit
) {
    when (id) {
        "stats" -> onShowDialog(statsDialog(viewModel))
        "history" -> onShowDialog(historyDialog(viewModel))
        "copy" -> {
            val text = viewModel.lastAssistantText()
            if (text.isNullOrBlank()) toast(context, "Chưa có phản hồi nào")
            else {
                copyToClipboard(context, "gemini-reply", text)
                toast(context, "Đã sao chép")
            }
        }
        "share" -> {
            val text = viewModel.lastAssistantText()
            if (text.isNullOrBlank()) toast(context, "Chưa có phản hồi nào")
            else shareText(context, text)
        }
        "compress" -> { viewModel.compressSession(); onDismiss() }
        "memory" -> {
            viewModel.sendMessage(
                "Open GEMINI.md in the workspace with read_file. " +
                    "If it does not exist, create it with write_file containing: " +
                    "\"# Gemini memory\\n\". Then tell me what it contains."
            )
            onDismiss()
        }
        "init" -> {
            viewModel.sendMessage(
                "Create GEMINI.md in the workspace using write_file with this " +
                    "content:\n# Gemini memory\n\n- Project style & commands\n" +
                    "- Key decisions\n- Known gotchas\n\nThen confirm."
            )
            onDismiss()
        }
        "reset" -> { viewModel.resetSession(); onDismiss() }
        "clearui" -> { viewModel.clearMessages(); onDismiss() }
        "shell" -> {
            viewModel.sendMessage(
                "Use run_shell_command to execute: echo hello from termux && uname -a"
            )
            onDismiss()
        }
        "chats" -> onShowChats()
    }
}

@Composable
private fun AccordionSection(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.medium,
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "Thu gọn" else "Mở rộng",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    content()
                }
            }
        }
    }
}

@Composable
fun ChatsDialog(
    viewModel: ChatViewModel,
    onDismiss: () -> Unit,
    onResumed: () -> Unit
) {
    val context = LocalContext.current
    var entries by remember { mutableStateOf(viewModel.listSavedChats()) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<com.gemini.bridge.storage.ChatStore.Entry?>(null) }
    var renameText by remember { mutableStateOf("") }
    val groups = remember(entries) { groupByRecency(entries) }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp, top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại")
                    }
                    Text(
                        "Lịch sử trò chuyện",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        viewModel.saveCurrentChat()
                        entries = viewModel.listSavedChats()
                        toast(context, "Đã lưu")
                    }) {
                        Icon(Icons.Default.Save, contentDescription = "Lưu cuộc trò chuyện hiện tại")
                    }
                }
                if (entries.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            "Chưa có cuộc trò chuyện nào",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        groups.forEach { (label, items) ->
                            item(key = "h-$label") {
                                Text(
                                    label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 4.dp)
                                )
                            }
                            items(items, key = { it.name }) { entry ->
                                var rowHeightPx by remember { mutableStateOf(0) }
                                var touch by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
                                val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
                                val density = androidx.compose.ui.platform.LocalDensity.current
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .onSizeChanged { rowHeightPx = it.height }
                                            .pointerInput(entry.name) {
                                                detectTapGestures(
                                                    onTap = {
                                                        viewModel.resumeChat(entry.name)
                                                        onResumed()
                                                    },
                                                    onLongPress = { pos ->
                                                        touch = pos
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        menuFor = entry.name
                                                    }
                                                )
                                            }
                                            .padding(horizontal = 20.dp, vertical = 14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (entry.pinned) {
                                            Icon(
                                                Icons.Default.PushPin, null,
                                                modifier = Modifier.size(18.dp),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(Modifier.width(12.dp))
                                        }
                                        Text(
                                            entry.title,
                                            style = MaterialTheme.typography.bodyLarge,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    // Menu pops up right under the finger.
                                    DropdownMenu(
                                        expanded = menuFor == entry.name,
                                        onDismissRequest = { menuFor = null },
                                        offset = with(density) {
                                            DpOffset(touch.x.toDp(), (touch.y - rowHeightPx).toDp())
                                        }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text(if (entry.pinned) "Bỏ ghim" else "Ghim") },
                                            leadingIcon = { Icon(Icons.Default.PushPin, null) },
                                            onClick = {
                                                menuFor = null
                                                viewModel.pinChat(entry.name, !entry.pinned)
                                                entries = viewModel.listSavedChats()
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Đổi tên") },
                                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                                            onClick = {
                                                menuFor = null
                                                renameText = entry.title
                                                renaming = entry
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Xóa", color = MaterialTheme.colorScheme.error) },
                                            leadingIcon = {
                                                Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                                            },
                                            onClick = {
                                                menuFor = null
                                                viewModel.deleteChat(entry.name)
                                                entries = viewModel.listSavedChats()
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    renaming?.let { target ->
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Đổi tên cuộc trò chuyện") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    enabled = renameText.isNotBlank(),
                    onClick = {
                        viewModel.renameChat(target.name, renameText)
                        entries = viewModel.listSavedChats()
                        renaming = null
                    }
                ) { Text("Lưu") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Hủy") } }
        )
    }
}

private fun groupByRecency(
    entries: List<com.gemini.bridge.storage.ChatStore.Entry>
): List<Pair<String, List<com.gemini.bridge.storage.ChatStore.Entry>>> {
    val pinned = entries.filter { it.pinned }
    val rest = entries.filter { !it.pinned }
    return buildList {
        if (pinned.isNotEmpty()) add("Đã ghim" to pinned)
        if (rest.isNotEmpty()) add("Gần đây" to rest)
    }
}

@Composable
private fun ActionTile(action: QuickAction, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(56.dp),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.secondaryContainer
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    action.icon,
                    contentDescription = action.label,
                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(action.label, style = MaterialTheme.typography.labelMedium)
        Text(
            action.description,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

internal data class DialogContent(val title: String, val lines: List<String>, val mono: Boolean = false)

internal fun statsDialog(vm: ChatViewModel): DialogContent {
    val s = vm.stats()
    return DialogContent(
        title = "Thống kê phiên",
        lines = listOf(
            "Mô hình: ${vm.model.value}",
            "Thư mục dự án: ${vm.workspaceLabel.value}",
            "Tin nhắn: ${s.userMessages + s.modelMessages}",
            "  · người dùng: ${s.userMessages}",
            "  · mô hình: ${s.modelMessages}",
            "Lượt gọi công cụ: ${s.toolEvents}",
            "Tổng ký tự: ${s.totalChars}"
        ),
        mono = true
    )
}

internal fun historyDialog(vm: ChatViewModel): DialogContent {
    val prompts = vm.messages.filter { it.isUser }.takeLast(10).map { it.text }
    val lines = if (prompts.isEmpty()) listOf("(chưa có câu hỏi nào)")
        else prompts.mapIndexed { i, p -> "${i + 1}. ${p.take(80)}" }
    return DialogContent(title = "Câu hỏi gần đây", lines = lines)
}

internal fun copyToClipboard(context: Context, label: String, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
}

internal fun shareText(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(
        Intent.createChooser(send, "Chia sẻ").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

internal fun toast(context: Context, text: String) {
    Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
}
