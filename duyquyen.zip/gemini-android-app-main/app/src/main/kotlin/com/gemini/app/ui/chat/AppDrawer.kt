package com.gemini.app.ui.chat

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.gemini.app.R

@Composable
fun AppDrawer(
    viewModel: ChatViewModel,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenChats: () -> Unit,
    onOpenAbout: () -> Unit
) {
    val context = LocalContext.current
    val workspaceLabel by viewModel.workspaceLabel.collectAsState()
    val model by viewModel.model.collectAsState()

    val folderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) viewModel.setProjectFolder(uri.toString())
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.mipmap.ic_launcher_foreground),
                    contentDescription = null,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.width(12.dp))
                Image(
                    painter = painterResource(id = R.drawable.logo_gemini),
                    contentDescription = "Gemini",
                    modifier = Modifier.height(24.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                model,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                workspaceLabel,
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        SectionLabel("Cuộc trò chuyện")
        DrawerItem(Icons.Default.Edit, "New chat") {
            onClose(); viewModel.newChat()
        }
        DrawerItem(Icons.Default.History, "Lịch sử") {
            onClose(); onOpenChats()
        }
        DrawerItem(Icons.Default.FileDownload, "Xuất ra Markdown") {
            onClose(); shareMarkdown(context, viewModel.exportAsMarkdown())
        }
        DrawerItem(Icons.Default.Folder, "Chọn thư mục dự án") {
            onClose(); folderLauncher.launch(null)
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        SectionLabel("Công cụ & dòng lệnh")
        DrawerItem(Icons.Default.Terminal, "Mở Termux") {
            onClose(); openTermux(context)
        }
        DrawerItem(Icons.Default.Code, "Mã nguồn") {
            onClose(); openUrl(context, "https://github.com/aciderix/gemini-android-app")
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        SectionLabel("Ứng dụng")
        DrawerItem(Icons.Default.Settings, "Cài đặt") {
            onClose(); onOpenSettings()
        }
        DrawerItem(Icons.Default.HelpOutline, "Trợ giúp") {
            onClose(); openUrl(context, "https://ai.google.dev/gemini-api/docs")
        }
        DrawerItem(Icons.Default.Article, "Tài liệu") {
            onClose(); openUrl(context, "https://ai.google.dev/gemini-api/docs")
        }
        DrawerItem(Icons.Default.BugReport, "Báo lỗi") {
            onClose(); openUrl(context, "https://github.com/aciderix/gemini-android-app/issues/new")
        }
        DrawerItem(Icons.Default.PrivacyTip, "Quyền riêng tư") {
            onClose(); openUrl(context, "https://policies.google.com/privacy")
        }
        DrawerItem(Icons.Default.Info, "Giới thiệu") {
            onClose(); onOpenAbout()
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        SectionLabel("Tài khoản")
        DrawerItem(Icons.Default.Logout, "Đăng xuất / đổi khóa API") {
            onClose(); viewModel.signOut()
        }
        DrawerItem(Icons.Default.ExitToApp, "Thoát") {
            onClose()
            (context as? android.app.Activity)?.finish()
        }
    }
}

@Composable
private fun DrawerItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    NavigationDrawerItem(
        icon = { Icon(icon, contentDescription = null) },
        label = { Text(label) },
        selected = false,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp),
        colors = NavigationDrawerItemDefaults.colors(
            unselectedContainerColor = androidx.compose.ui.graphics.Color.Transparent
        )
    )
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 24.dp, top = 12.dp, bottom = 4.dp)
    )
}

@Composable
fun AboutDialog(viewModel: ChatViewModel, onDismiss: () -> Unit) {
    val model by viewModel.model.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } },
        title = { Text("Gemini cho Android") },
        text = {
            Column {
                Text(
                    "Ứng dụng Android gốc cho Gemini, hỗ trợ gọi công cụ (function calling).",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
                Text("Mô hình: $model", style = MaterialTheme.typography.labelMedium)
                Text(
                    "Đã cài Termux: ${if (viewModel.termuxInstalled) "có" else "không"}",
                    style = MaterialTheme.typography.labelMedium
                )
                Text(
                    "Số công cụ: ${viewModel.availableTools.size}",
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "github.com/aciderix/gemini-android-app",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    )
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

private fun shareMarkdown(context: Context, markdown: String) {
    val intent = Intent(Intent.ACTION_SEND)
        .setType("text/markdown")
        .putExtra(Intent.EXTRA_TEXT, markdown)
        .putExtra(Intent.EXTRA_SUBJECT, "Cuộc trò chuyện Gemini")
    runCatching {
        context.startActivity(
            Intent.createChooser(intent, "Xuất cuộc trò chuyện")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

private fun openTermux(context: Context) {
    val launch = context.packageManager.getLaunchIntentForPackage("com.termux")
    if (launch != null) {
        try {
            context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (_: ActivityNotFoundException) {
        }
    }
    openUrl(context, "https://f-droid.org/packages/com.termux/")
}
