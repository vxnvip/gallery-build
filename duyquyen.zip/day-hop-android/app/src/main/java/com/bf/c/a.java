package com.bf.c;

import java.io.IOException;
import java.io.InputStream;
import javax.microedition.media.Manager;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;
import javax.microedition.media.control.VolumeControl;

/* loaded from: classes.dex */
public final class a {
    private static String[] a;
    private static Player[] b;
    private static int[] c = {60};
    private static int[] d = {-1};

    static {
        String[] strArr = {"bg.mid"};
        a = strArr;
        b = new Player[strArr.length];
    }

    public static int a(int i) {
        if (b[i] != null) {
            return b[i].getState();
        }
        return -1;
    }

    private synchronized InputStream b(int i) {
        return com.bf.c.a.class.getResourceAsStream(new StringBuffer().append("/sound/").append(a[i]).toString());
    }

    private synchronized void b() {
        for (int i = 0; i < b.length; i++) {
            try {
                if (b[i] != null) {
                    b[i].stop();
                    b[i].deallocate();
                    if (com.bf.d.a.b) {
                        b[i] = null;
                    }
                }
            } catch (MediaException e) {
                e.printStackTrace();
                System.gc();
            }
        }
        System.gc();
    }

    private synchronized void c(int i) {
        String str;
        com.a.a.a.Base.a("AudioPlay.java createSound()");
        switch (i) {
            case 0:
                str = "audio/midi";
                break;
            default:
                str = "audio/midi";
                break;
        }
        try {
            try {
                InputStream b2 = b(i);
                if (b2 != null) {
                    b[i] = Manager.createPlayer(b2, str);
                    b[i].realize();
                    b[i].prefetch();
                    b[i].setLoopCount(d[i]);
                    VolumeControl control = (VolumeControl) b[i].getControl("VolumeControl");
                    if (control != null) {
                        control.setLevel(c[i]);
                    }
                } else {
                    com.a.a.a.Base.a(new StringBuffer().append("AudioPlay.java createSound() [ Error ] : music ").append(i).append(" is NULL").toString());
                }
            } catch (MediaException e) {
                e.printStackTrace();
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public final synchronized void a() {
        b();
    }

    public final synchronized void a(int i, int i2) {
        com.a.a.a.Base.a(new StringBuffer().append("AudioPlay.java playSound(").append(i).append(",").append(i2).append(")").toString());
        if (i2 > 0) {
            c[i] = i2 >= 100 ? 100 : i2;
            try {
                if (b[i] == null) {
                    c(i);
                }
                if (com.bf.d.a.c) {
                    b[i].setMediaTime(0L);
                }
                b[i].start();
            } catch (MediaException e) {
                com.a.a.a.Base.a(new StringBuffer().append("AudioPlay.java playSound() [ Error ] : ").append(e.getMessage()).toString());
            }
        }
    }
}
