package com.bf.d;

/* loaded from: classes.dex */
public final class a {
    public static boolean a = true;
    public static boolean b = true;
    public static boolean c = true;
    public static boolean d = true;
    public static int e = 1;
    public static boolean f = true;
    public static int g = 0;
    public static int h = 1000;
    public static int i = 2000;
    public static int j = 208;
}
