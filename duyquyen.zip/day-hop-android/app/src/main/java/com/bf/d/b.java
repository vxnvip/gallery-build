package com.bf.d;

/* loaded from: classes.dex */
public final class b {
    public static final int[] a = new int[0];
    public static final String[] b = new String[0];
    public static boolean c = false;
    public static int d = 176;
    public static int e = 208;
    public static int f = com.bf.d.a.j;
    public static int g = 1;
    public static boolean h = false;
}
