package com.bf.midlet;

/* loaded from: classes.dex */
final class b implements Runnable {
    private final BF_MIDlet a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(BF_MIDlet bF_MIDlet) {
        this.a = bF_MIDlet;
    }

    @Override // java.lang.Runnable
    public final void run() {
        BF_MIDlet.a(this.a);
        this.a.e = false;
    }
}
