package com.bf.midlet;

import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Image;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/* loaded from: classes.dex */
public class BF_MIDlet extends MIDlet {
    public static BF_MIDlet a;
    private static Thread l;
    private static Thread m;
    public com.bf.a.a b;
    public com.bf.a.b c;
    public com.bf.a.d d;
    public boolean f;
    private com.bf.a.c g;
    private boolean k;
    public boolean e = false;
    private Runnable h = new a(this);
    private Runnable i = new b(this);
    private Runnable j = new c(this);

    public BF_MIDlet() {
        new d(this);
        this.k = false;
        this.f = false;
        if (com.bf.d.a.e != 1) {
            com.bf.d.b.g = com.bf.d.a.e;
        }
        if (com.bf.d.b.g != -1) {
            com.a.a.a.a.b.b.a = com.bf.d.b.g;
        }
        com.a.a.a.Base.g = false;
        com.a.a.a.b.a.b = new Image[78];
        com.a.a.a.b.a.a = com.bf.d.b.a;
        if (!com.bf.d.a.f) {
            com.bf.d.b.h = com.bf.d.a.f;
        }
        com.a.a.a.a.b.b.a(com.bf.d.b.d, com.bf.d.b.f, com.bf.d.b.g, com.bf.d.b.h);
        com.a.a.a.a.b.b.a();
        com.a.a.a.a.b.b.a(this);
        com.a.a.a.a.b.b.a(15);
        a = this;
        if (this.g == null) {
            a.g = new com.bf.a.c();
        }
        if (a.d == null) {
            a.d = new com.bf.a.d();
        }
        if (a.c == null) {
            a.c = new com.bf.a.b();
        }
        if (a.b == null) {
            a.b = new com.bf.a.a();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(BF_MIDlet bF_MIDlet) {
        int i = com.bf.a.c.f;
        com.a.a.a.Base.f.b();
        if (i != 2) {
            com.bf.a.d.k();
            a.c.h();
        }
        if (i != 3) {
            a.b.k();
        }
        switch (i) {
            case 1:
            default:
                return;
            case 2:
                a.d.j();
                a.c.g();
                return;
            case 3:
                a.b.j();
                return;
        }
    }

    public static void c() {
        try {
            a.destroyApp(true);
        } catch (MIDletStateChangeException e) {
            e.printStackTrace();
        }
    }

    private static void e() {
        a.g.a();
    }

    public final void a() {
        this.e = true;
        com.bf.a.c.f = 2;
        e();
        new Thread(a.i).start();
    }

    public final void b() {
        this.e = true;
        com.bf.a.c.f = 3;
        e();
        new Thread(a.j).start();
    }

    public final void d() {
        Thread thread = new Thread(new e(this));
        l = thread;
        thread.start();
        Thread thread2 = new Thread(new f(this));
        m = thread2;
        thread2.start();
    }

    protected void destroyApp(boolean z) throws MIDletStateChangeException {
        Display.getDisplay(a).setCurrent((Displayable) null);
        notifyDestroyed();
    }

    protected void pauseApp() {
        this.k = true;
        a.b.l();
    }

    protected void startApp() {
        if (this.k) {
            return;
        }
        this.e = true;
        com.bf.a.c.f = 1;
        e();
        new Thread(a.h).start();
    }
}
