package com.bf.a;

import com.bf.midlet.BF_MIDlet;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;

/* loaded from: classes.dex */
public final class b extends com.a.a.a.a.a {
    private Vector f = new Vector();
    private int[] g = {6};
    private int h;
    private int i;
    private int j;

    private void b(int i) {
        do {
            this.h += i;
            if (this.h > 6) {
                this.h = 0;
            } else if (this.h < 0) {
                this.h = 6;
            }
            if (this.h == 1 && !com.bf.b.a.a().c()) {
                b(i);
            }
            if (this.h == 3) {
                b(i);
            }
            if (com.bf.d.a.d) {
                return;
            }
        } while (this.h == 2);
    }

    @Override // com.a.a.a.a.a
    public final void a(Graphics graphics) {
        com.a.a.a.Base.a(graphics);
        switch (this.i) {
            case 0:
            case 1:
            case 2:
            case 6:
                break;
            case 3:
                com.bf.e.b.a(graphics, 0);
                break;
            case 4:
            case 5:
                graphics.setColor(255, 125, 55);
                graphics.drawRect((com.a.a.a.a.a.a / 2) - 85, (com.a.a.a.a.a.b / 2) - 85, 168, 170);
                break;
            default:
                com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[6], com.a.a.a.a.a.a / 2, com.a.a.a.a.a.b / 2, 3);
                if (this.h != 2) {
                    com.a.a.a.Base.e.a(graphics, com.bf.e.c.d[this.h], (com.a.a.a.a.a.a / 2) - 27, (com.a.a.a.a.a.b / 2) + 70, 320, 320, com.bf.e.a.a, com.bf.e.a.b, 2, 1);
                    break;
                } else {
                    com.a.a.a.Base.e.a(graphics, com.bf.e.c.d[this.h], (com.a.a.a.a.a.a / 2) - 27, (com.a.a.a.a.a.b / 2) + 70, 320, 320, com.bf.e.a.c, com.bf.e.a.d, 2, 1);
                    break;
                }
        }
        switch (this.i) {
            case 4:
                com.a.a.a.Base.e.a(graphics, "Thao tác: Phím 2/mũi tên lên để di chuyển lên trên; phím 4/mũi tên trái để di chuyển sang trái; phím 6/mũi tên phải để di chuyển sang phải; phím 8/mũi tên xuống để di chuyển xuống dưới; phím mềm trái để xem lại, phím mềm phải về trình đơn chính.", (com.a.a.a.a.a.a / 2) - 80, (com.a.a.a.a.a.b / 2) - 70, 160, 160, com.bf.e.c.b, com.bf.e.c.c, 3, 0);
                break;
            case 5:
                com.a.a.a.Base.e.a(graphics, "Việt hóa bởi skypeaful*Email:*skypeaful@yahoo.com.vn*Website:www.Zing4u.us", (com.a.a.a.a.a.a / 2) - 80, (com.a.a.a.a.a.b / 2) - 70, 160, 160, com.bf.e.c.b, com.bf.e.c.c, 3, 0);
                break;
        }
        switch (this.i) {
            case 4:
            case 5:
                com.a.a.a.Base.e.a(graphics, com.bf.e.c.d[this.h], (com.a.a.a.a.a.a / 2) - 30, (com.a.a.a.a.a.b / 2) - 95, 80, 80, com.bf.e.a.a, com.bf.e.a.b, 2, 1);
                com.a.a.a.Base.e.a(graphics, com.bf.e.c.a[2], (com.a.a.a.a.a.a / 2) + 55, (com.a.a.a.a.a.b / 2) + 80, 320, 320, com.bf.e.a.a, com.bf.e.a.b, 2, 1);
                break;
        }
        switch (this.j) {
            case 0:
                com.bf.e.b.a(graphics);
                com.bf.e.b.a(graphics, 3);
                return;
            case 1:
                com.bf.e.b.a(graphics);
                com.bf.e.b.a(graphics, 1);
                return;
            case 2:
                com.a.a.a.Base.a(graphics);
                com.a.b.a.e.a(graphics, com.bf.a.d.m, com.a.a.a.a.a.a / 2, com.a.a.a.a.a.b / 2, 3);
                com.a.a.a.Base.f.a(graphics, "Xác định", com.a.a.a.a.a.d + 10, (com.a.a.a.a.a.e + com.bf.d.b.e) - 10, 36, com.bf.e.a.f, com.bf.e.a.e);
                com.a.a.a.Base.f.a(graphics, "Thoát", (com.a.a.a.a.a.d + com.a.a.a.a.a.c) - 10, (com.a.a.a.a.a.e + com.bf.d.b.e) - 10, 40, com.bf.e.a.f, com.bf.e.a.e);
                return;
            default:
                return;
        }
    }

    @Override // com.a.a.a.a.a
    public final void b() {
        switch (this.j) {
            case 0:
                if (!com.a.a.a.a.b.b.b(32768)) {
                    if (com.a.a.a.a.b.b.b(65536)) {
                        this.j = -1;
                        return;
                    }
                    return;
                }
                com.bf.b.a.a().b();
                com.bf.e.a.h = com.bf.b.a.a().d();
                BF_MIDlet.a.b.m();
                BF_MIDlet.a.b.n();
                BF_MIDlet.a.b.i();
                BF_MIDlet.a.b.g();
                BF_MIDlet.a.b();
                return;
            case 1:
                if (com.a.a.a.a.b.b.b(32768)) {
                    this.j = 2;
                    return;
                } else if (com.a.a.a.a.b.b.b(65536)) {
                    this.j = -1;
                    return;
                } else {
                    return;
                }
            case 2:
                if (com.a.a.a.a.a.a(32768)) {
                    BF_MIDlet.a.d();
                    return;
                } else if (com.a.a.a.a.a.a(65536)) {
                    BF_MIDlet.c();
                    return;
                } else {
                    return;
                }
            default:
                switch (this.i) {
                    case 0:
                        if (com.bf.b.a.a().c()) {
                            this.i = -1;
                            this.j = 0;
                            return;
                        }
                        BF_MIDlet.a.b.n();
                        BF_MIDlet.a.b.i();
                        BF_MIDlet.a.b.g();
                        BF_MIDlet.a.b();
                        return;
                    case 1:
                        BF_MIDlet.a.b.n();
                        BF_MIDlet.a.b.h();
                        BF_MIDlet.a.b();
                        return;
                    case 2:
                    default:
                        if (com.a.a.a.a.b.b.b(4096) || com.a.a.a.a.b.b.b(1024) || com.a.a.a.a.b.b.b(4) || com.a.a.a.a.b.b.b(16)) {
                            b(-1);
                            return;
                        } else if (com.a.a.a.a.b.b.b(8192) || com.a.a.a.a.b.b.b(2048) || com.a.a.a.a.b.b.b(256) || com.a.a.a.a.b.b.b(64)) {
                            b(1);
                            return;
                        } else if (com.a.a.a.a.b.b.b(16384) || com.a.a.a.a.b.b.b(32)) {
                            switch (this.h) {
                                case 2:
                                    BF_MIDlet.a.d();
                                    return;
                                default:
                                    this.i = this.h;
                                    if (this.i == 6) {
                                        this.i = -1;
                                        this.j = 1;
                                        return;
                                    }
                                    return;
                            }
                        } else {
                            return;
                        }
                    case 3:
                        if (com.a.a.a.a.a.a(32768)) {
                            com.bf.d.b.c = true;
                            this.i = -1;
                            return;
                        } else if (com.a.a.a.a.a.a(65536)) {
                            com.bf.d.b.c = false;
                            this.i = -1;
                            return;
                        } else {
                            return;
                        }
                    case 4:
                    case 5:
                        if (com.a.a.a.a.b.b.b(65536)) {
                            this.i = -1;
                            return;
                        } else if (com.a.a.a.a.b.b.b(1024) || com.a.a.a.a.b.b.b(4)) {
                            com.a.a.a.Base.e.a(0, -1);
                            return;
                        } else if (com.a.a.a.a.b.b.b(2048) || com.a.a.a.a.b.b.b(256)) {
                            com.a.a.a.Base.e.a(0, 1);
                            return;
                        } else {
                            return;
                        }
                    case 6:
                        return;
                }
        }
    }

    @Override // com.a.a.a.a.a
    public final void c() {
    }

    @Override // com.a.a.a.a.a
    public final void d() {
    }

    public final void g() {
        if (this.f.size() != this.g.length) {
            this.f.removeAllElements();
            for (int i = 0; i < this.g.length; i++) {
                this.f.addElement(new Integer(this.g[i]));
            }
        }
        com.a.a.a.b.a.a(this.f);
        if (com.bf.b.a.a().c()) {
            this.h = 1;
        } else {
            this.h = 0;
        }
        this.i = -1;
        this.j = -1;
    }

    public final void h() {
        com.a.a.a.b.a.b(this.f);
    }
}
