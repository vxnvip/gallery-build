package com.bf.a;

/* loaded from: classes.dex */
final class e implements Runnable {
    private final d a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(d dVar) {
        this.a = dVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            if (this.a.g) {
                Thread.sleep(2000L);
                d.b(1);
                this.a.g = false;
                this.a.h = true;
            } else {
                Thread.sleep(com.bf.d.a.i);
                d.b(2);
            }
            while (this.a.h) {
                Thread.sleep(200L);
            }
            while (this.a.f) {
                if (d.l() && d.k == 0) {
                    this.a.h();
                }
                if (d.a(this.a) == 128) {
                    if (this.a.i == 0) {
                        this.a.i = System.currentTimeMillis();
                    } else {
                        Thread.sleep(1000L);
                    }
                    d.k++;
                } else {
                    Thread.sleep(this.a.l[d.k][6]);
                    d.k++;
                    if (this.a.i != 0) {
                        long currentTimeMillis = System.currentTimeMillis() - this.a.i;
                        if (currentTimeMillis < d.j) {
                            Thread.sleep(d.j - currentTimeMillis);
                        }
                    }
                    this.a.i = System.currentTimeMillis();
                    if (d.k >= this.a.l.length) {
                        this.a.f = false;
                    }
                }
            }
        } catch (Exception e) {
        } finally {
            this.a.g();
            this.a.i();
        }
    }
}
