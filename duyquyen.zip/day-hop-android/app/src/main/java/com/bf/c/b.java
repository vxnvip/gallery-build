package com.bf.c;

/* loaded from: classes.dex */
public final class b {
    private static b e;
    private c a;
    private Thread b;
    private c c = new c();
    private Thread d = new Thread(this.c);

    private b() {
        this.d.start();
        this.a = new c();
        this.b = new Thread(this.a);
        this.b.start();
    }

    public static b a() {
        if (e == null) {
            e = new b();
        }
        return e;
    }

    public final c b() {
        return this.c;
    }
}
