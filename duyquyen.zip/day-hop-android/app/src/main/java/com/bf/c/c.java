package com.bf.c;

/* loaded from: classes.dex */
public final class c implements Runnable {
    private boolean a;
    private int c;
    private boolean b = false;
    private int e = 0;
    private a d = new a();

    public c() {
        this.a = false;
        this.a = true;
    }

    public final synchronized void a() {
        this.b = false;
        this.d.a();
    }

    public final synchronized void a(int i, int i2) {
        this.e = 100;
        this.c = 0;
        this.b = true;
    }

    public final int b() {
        return com.bf.c.a.a(this.c);
    }

    @Override // java.lang.Runnable
    public final void run() {
        while (this.a) {
            long currentTimeMillis = System.currentTimeMillis();
            if (this.b) {
                try {
                    this.d.a(this.c, this.e);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                this.b = false;
            }
            long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
            if (currentTimeMillis2 < 50) {
                try {
                    Thread.sleep(50 - currentTimeMillis2);
                } catch (InterruptedException e2) {
                }
            }
        }
    }
}
