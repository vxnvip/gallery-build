package com.bf.a;

import com.bf.midlet.BF_MIDlet;
import java.lang.reflect.Array;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/* loaded from: classes.dex */
public final class a extends com.a.a.a.a.a {
    private boolean h;
    private int i;
    private int j;
    private int k;
    private int l;
    private long o;
    private int p;
    private int q;
    private int r;
    private boolean u;
    private int x;
    private int y;
    private int z;
    private Vector f = new Vector();
    private int[] g = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    private long m = 1000;
    private long n = 0;
    private int[][] s = (int[][]) Array.newInstance(Integer.TYPE, 20, 2);
    private int[][][] t = (int[][][]) Array.newInstance(Integer.TYPE, 20, 12, 2);
    private int[] v = {0, -1, -2, -3};
    private int[] w = {-135, -100, -30, -10, 0, 10, 20, 15, 10, 5, 0, -5, 0};

    public a() {
        int[] iArr = {0, 0, 0, 0};
        m();
        i();
    }

    private void a(int i, boolean z) {
        this.i = i;
        switch (this.i) {
            case 5:
                this.k = 1;
                this.l = 0;
                return;
            case 6:
            case 7:
            default:
                return;
            case 8:
                this.k = 1;
                this.l = 0;
                return;
        }
    }

    private void a(Graphics graphics, int i) {
        char c;
        if (this.v[0] >= 0) {
            switch (this.i) {
                case 6:
                    c = 0;
                    break;
                default:
                    c = 1;
                    break;
            }
            com.a.a.a.Base.e.a(graphics, com.bf.e.c.i[c], (com.a.a.a.a.a.a / 2) - 30, ((com.a.a.a.a.a.b / 2) + this.w[this.v[0]]) - 10, 100, 80, com.bf.e.a.c, com.bf.e.a.d, 2, 1);
        }
        if (com.a.a.a.Base.b - this.n >= 100) {
            this.n = com.a.a.a.Base.b;
            int[] iArr = this.v;
            iArr[0] = iArr[0] + 1;
            if (this.v[0] >= this.w.length) {
                this.v[0] = this.w.length - 1;
            }
        }
    }

    private void o() {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        boolean z8;
        switch (this.q) {
            case 0:
                for (int i = 0; i < this.t[com.bf.e.a.h].length; i++) {
                    if (this.t[com.bf.e.a.h][i][0] != -1 && this.t[com.bf.e.a.h][i][1] != -1) {
                        int i2 = 0;
                        while (true) {
                            if (i2 >= this.t[com.bf.e.a.h].length) {
                                z4 = true;
                                break;
                            } else if (this.t[com.bf.e.a.h][i][0] == -1 || this.t[com.bf.e.a.h][i][1] == -1 || this.t[com.bf.e.a.h][i][1] - 1 != this.t[com.bf.e.a.h][i2][1] || this.t[com.bf.e.a.h][i][0] != this.t[com.bf.e.a.h][i2][0]) {
                                i2++;
                            } else {
                                z4 = false;
                                break;
                            }
                        }
                        if (z4 && this.t[com.bf.e.a.h][i][0] == this.s[com.bf.e.a.h][0] && this.t[com.bf.e.a.h][i][1] + 1 == this.s[com.bf.e.a.h][1] && com.bf.e.a.g[com.bf.e.a.h][this.t[com.bf.e.a.h][i][1] - 1][this.t[com.bf.e.a.h][i][0]] != 1) {
                            int[] iArr = this.t[com.bf.e.a.h][i];
                            iArr[1] = iArr[1] - 1;
                        }
                    }
                }
                break;
            case 1:
                for (int i3 = 0; i3 < this.t[com.bf.e.a.h].length; i3++) {
                    if (this.t[com.bf.e.a.h][i3][0] != -1 && this.t[com.bf.e.a.h][i3][1] != -1) {
                        int i4 = 0;
                        while (true) {
                            if (i4 >= this.t[com.bf.e.a.h].length) {
                                z3 = true;
                                break;
                            } else if (this.t[com.bf.e.a.h][i3][0] == -1 || this.t[com.bf.e.a.h][i3][1] == -1 || this.t[com.bf.e.a.h][i3][1] + 1 != this.t[com.bf.e.a.h][i4][1] || this.t[com.bf.e.a.h][i3][0] != this.t[com.bf.e.a.h][i4][0]) {
                                i4++;
                            } else {
                                z3 = false;
                                break;
                            }
                        }
                        if (z3 && this.t[com.bf.e.a.h][i3][0] == this.s[com.bf.e.a.h][0] && this.t[com.bf.e.a.h][i3][1] - 1 == this.s[com.bf.e.a.h][1] && com.bf.e.a.g[com.bf.e.a.h][this.t[com.bf.e.a.h][i3][1] + 1][this.t[com.bf.e.a.h][i3][0]] != 1) {
                            int[] iArr2 = this.t[com.bf.e.a.h][i3];
                            iArr2[1] = iArr2[1] + 1;
                        }
                    }
                }
                break;
            case 2:
                for (int i5 = 0; i5 < this.t[com.bf.e.a.h].length; i5++) {
                    if (this.t[com.bf.e.a.h][i5][0] != -1 && this.t[com.bf.e.a.h][i5][1] != -1) {
                        int i6 = 0;
                        while (true) {
                            if (i6 >= this.t[com.bf.e.a.h].length) {
                                z2 = true;
                                break;
                            } else if (this.t[com.bf.e.a.h][i5][0] == -1 || this.t[com.bf.e.a.h][i5][1] == -1 || this.t[com.bf.e.a.h][i5][0] - 1 != this.t[com.bf.e.a.h][i6][0] || this.t[com.bf.e.a.h][i5][1] != this.t[com.bf.e.a.h][i6][1]) {
                                i6++;
                            } else {
                                z2 = false;
                                break;
                            }
                        }
                        if (z2 && this.t[com.bf.e.a.h][i5][1] == this.s[com.bf.e.a.h][1] && this.t[com.bf.e.a.h][i5][0] + 1 == this.s[com.bf.e.a.h][0] && com.bf.e.a.g[com.bf.e.a.h][this.t[com.bf.e.a.h][i5][1]][this.t[com.bf.e.a.h][i5][0] - 1] != 1) {
                            int[] iArr3 = this.t[com.bf.e.a.h][i5];
                            iArr3[0] = iArr3[0] - 1;
                        }
                    }
                }
                break;
            case 3:
                for (int i7 = 0; i7 < this.t[com.bf.e.a.h].length; i7++) {
                    if (this.t[com.bf.e.a.h][i7][0] != -1 && this.t[com.bf.e.a.h][i7][1] != -1) {
                        int i8 = 0;
                        while (true) {
                            if (i8 >= this.t[com.bf.e.a.h].length) {
                                z = true;
                                break;
                            } else if (this.t[com.bf.e.a.h][i7][0] == -1 || this.t[com.bf.e.a.h][i7][1] == -1 || this.t[com.bf.e.a.h][i7][0] + 1 != this.t[com.bf.e.a.h][i8][0] || this.t[com.bf.e.a.h][i7][1] != this.t[com.bf.e.a.h][i8][1]) {
                                i8++;
                            } else {
                                z = false;
                                break;
                            }
                        }
                        if (z && this.t[com.bf.e.a.h][i7][1] == this.s[com.bf.e.a.h][1] && this.t[com.bf.e.a.h][i7][0] - 1 == this.s[com.bf.e.a.h][0] && com.bf.e.a.g[com.bf.e.a.h][this.t[com.bf.e.a.h][i7][1]][this.t[com.bf.e.a.h][i7][0] + 1] != 1) {
                            int[] iArr4 = this.t[com.bf.e.a.h][i7];
                            iArr4[0] = iArr4[0] + 1;
                        }
                    }
                }
                break;
        }
        switch (this.q) {
            case 0:
                int i9 = 0;
                while (true) {
                    if (i9 >= this.t[com.bf.e.a.h].length) {
                        z8 = true;
                        break;
                    } else if (this.t[com.bf.e.a.h][i9][0] == -1 || this.t[com.bf.e.a.h][i9][1] == -1 || this.s[com.bf.e.a.h][1] - 1 != this.t[com.bf.e.a.h][i9][1] || this.s[com.bf.e.a.h][0] != this.t[com.bf.e.a.h][i9][0]) {
                        i9++;
                    } else {
                        z8 = false;
                        break;
                    }
                }
                if (z8 && com.bf.e.a.g[com.bf.e.a.h][this.s[com.bf.e.a.h][1] - 1][this.s[com.bf.e.a.h][0]] != 1) {
                    int[] iArr5 = this.s[com.bf.e.a.h];
                    iArr5[1] = iArr5[1] - 1;
                    break;
                }
                break;
            case 1:
                int i10 = 0;
                while (true) {
                    if (i10 >= this.t[com.bf.e.a.h].length) {
                        z7 = true;
                        break;
                    } else if (this.t[com.bf.e.a.h][i10][0] == -1 || this.t[com.bf.e.a.h][i10][1] == -1 || this.s[com.bf.e.a.h][1] + 1 != this.t[com.bf.e.a.h][i10][1] || this.s[com.bf.e.a.h][0] != this.t[com.bf.e.a.h][i10][0]) {
                        i10++;
                    } else {
                        z7 = false;
                        break;
                    }
                }
                if (z7 && com.bf.e.a.g[com.bf.e.a.h][this.s[com.bf.e.a.h][1] + 1][this.s[com.bf.e.a.h][0]] != 1) {
                    int[] iArr6 = this.s[com.bf.e.a.h];
                    iArr6[1] = iArr6[1] + 1;
                    break;
                }
                break;
            case 2:
                int i11 = 0;
                while (true) {
                    if (i11 >= this.t[com.bf.e.a.h].length) {
                        z6 = true;
                        break;
                    } else if (this.t[com.bf.e.a.h][i11][0] == -1 || this.t[com.bf.e.a.h][i11][1] == -1 || this.s[com.bf.e.a.h][0] - 1 != this.t[com.bf.e.a.h][i11][0] || this.s[com.bf.e.a.h][1] != this.t[com.bf.e.a.h][i11][1]) {
                        i11++;
                    } else {
                        z6 = false;
                        break;
                    }
                }
                if (z6 && com.bf.e.a.g[com.bf.e.a.h][this.s[com.bf.e.a.h][1]][this.s[com.bf.e.a.h][0] - 1] != 1) {
                    int[] iArr7 = this.s[com.bf.e.a.h];
                    iArr7[0] = iArr7[0] - 1;
                    break;
                }
                break;
            case 3:
                int i12 = 0;
                while (true) {
                    if (i12 >= this.t[com.bf.e.a.h].length) {
                        z5 = true;
                        break;
                    } else if (this.t[com.bf.e.a.h][i12][0] == -1 || this.t[com.bf.e.a.h][i12][1] == -1 || this.s[com.bf.e.a.h][0] + 1 != this.t[com.bf.e.a.h][i12][0] || this.s[com.bf.e.a.h][1] != this.t[com.bf.e.a.h][i12][1]) {
                        i12++;
                    } else {
                        z5 = false;
                        break;
                    }
                }
                if (z5 && com.bf.e.a.g[com.bf.e.a.h][this.s[com.bf.e.a.h][1]][this.s[com.bf.e.a.h][0] + 1] != 1) {
                    int[] iArr8 = this.s[com.bf.e.a.h];
                    iArr8[0] = iArr8[0] + 1;
                    break;
                }
                break;
        }
        e();
    }

    private boolean p() {
        if (com.bf.e.a.h <= com.bf.e.a.g.length - 1) {
            for (int i = 0; i < this.t[com.bf.e.a.h].length; i++) {
                if (this.t[com.bf.e.a.h][i][0] != -1 && this.t[com.bf.e.a.h][i][1] != -1 && com.bf.e.a.g[com.bf.e.a.h][this.t[com.bf.e.a.h][i][1]][this.t[com.bf.e.a.h][i][0]] != 3) {
                    return false;
                }
            }
        }
        return true;
    }

    private void q() {
        this.v = new int[]{0, -1, -2, -3};
        this.w = new int[]{-135, -100, -30, -10, 0, 10, 20, 15, 10, 5, 0, -5, 0};
        int[] iArr = {0, 0, 0, 0};
    }

    @Override // com.a.a.a.a.a
    public final void a(Graphics graphics) {
        com.a.a.a.Base.a(graphics);
        com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[0], com.a.a.a.a.a.a / 2, com.a.a.a.a.a.b / 2, 3);
        com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[1], (com.a.a.a.a.a.a / 2) - 70, (com.a.a.a.a.a.b / 2) - 90, 3);
        com.a.a.a.Base.e.a(graphics, com.bf.e.c.h[0], (com.a.a.a.a.a.a / 2) - 80, (com.a.a.a.a.a.b / 2) + 80, 40, 40, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
        com.a.a.a.Base.e.a(graphics, com.bf.e.c.h[1], (com.a.a.a.a.a.a / 2) + 55, (com.a.a.a.a.a.b / 2) + 82, 40, 40, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
        for (int i = 0; i < com.bf.e.a.g[com.bf.e.a.h].length; i++) {
            for (int i2 = 0; i2 < com.bf.e.a.g[com.bf.e.a.h][i].length; i2++) {
                switch (com.bf.e.a.g[com.bf.e.a.h][i][i2]) {
                    case 1:
                        com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[8], ((com.a.a.a.a.a.a / 2) - 90) + (com.a.a.a.b.a.b[8].getWidth() * i2), ((com.a.a.a.a.a.b / 2) - 120) + (com.a.a.a.b.a.b[8].getHeight() * i), 3);
                        break;
                    case 2:
                        com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[7], ((com.a.a.a.a.a.a / 2) - 90) + (com.a.a.a.b.a.b[7].getWidth() * i2), ((com.a.a.a.a.a.b / 2) - 120) + (com.a.a.a.b.a.b[7].getHeight() * i), 3);
                        break;
                    case 3:
                        com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[4], ((com.a.a.a.a.a.a / 2) - 90) + (com.a.a.a.b.a.b[4].getWidth() * i2), ((com.a.a.a.a.a.b / 2) - 120) + (com.a.a.a.b.a.b[4].getHeight() * i), 3);
                        break;
                }
            }
        }
        for (int i3 = 0; i3 < this.t[com.bf.e.a.h].length; i3++) {
            if (this.t[com.bf.e.a.h][i3][0] != -1 && this.t[com.bf.e.a.h][i3][1] != -1) {
                com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[2], ((com.a.a.a.a.a.a / 2) - 90) + (this.t[com.bf.e.a.h][i3][0] * com.a.a.a.b.a.b[2].getWidth()), ((com.a.a.a.a.a.b / 2) - 120) + (this.t[com.bf.e.a.h][i3][1] * com.a.a.a.b.a.b[2].getHeight()), 3);
            }
        }
        com.a.b.a.e eVar = com.a.a.a.Base.d;
        Image image = com.a.a.a.b.a.b[5];
        int width = ((com.a.a.a.a.a.a / 2) - 90) + (this.s[com.bf.e.a.h][0] * com.a.a.a.b.a.b[8].getWidth());
        int height = ((com.a.a.a.a.a.b / 2) - 120) + (this.s[com.bf.e.a.h][1] * com.a.a.a.b.a.b[8].getHeight());
        int i4 = this.r;
        int width2 = image.getWidth();
        int height2 = image.getHeight() / 4;
        graphics.drawRegion(image, 0, i4 * height2, width2, height2, 0, width, height, 3);
        for (int i5 = 0; i5 < this.t[com.bf.e.a.h].length; i5++) {
            if (this.t[com.bf.e.a.h][i5][0] != -1 && this.t[com.bf.e.a.h][i5][1] != -1) {
                if (com.bf.e.a.g[com.bf.e.a.h][this.t[com.bf.e.a.h][i5][1]][this.t[com.bf.e.a.h][i5][0]] == 3) {
                    com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[3], ((com.a.a.a.a.a.a / 2) - 90) + (this.t[com.bf.e.a.h][i5][0] * com.a.a.a.b.a.b[3].getWidth()), ((com.a.a.a.a.a.b / 2) - 120) + (this.t[com.bf.e.a.h][i5][1] * com.a.a.a.b.a.b[3].getHeight()), 3);
                } else {
                    com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[2], ((com.a.a.a.a.a.a / 2) - 90) + (this.t[com.bf.e.a.h][i5][0] * com.a.a.a.b.a.b[2].getWidth()), ((com.a.a.a.a.a.b / 2) - 120) + (this.t[com.bf.e.a.h][i5][1] * com.a.a.a.b.a.b[2].getHeight()), 3);
                }
            }
        }
        switch (this.j) {
            case 1:
            case 2:
                return;
            case 3:
                com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[0], com.a.a.a.a.a.a / 2, com.a.a.a.a.a.b / 2, 3);
                graphics.setColor(255, 125, 55);
                graphics.drawRect((com.a.a.a.a.a.a / 2) - 85, (com.a.a.a.a.a.b / 2) - 85, 168, 170);
                com.a.a.a.Base.e.a(graphics, "Hướng dẫn", (com.a.a.a.a.a.a / 2) - 30, (com.a.a.a.a.a.b / 2) - 95, 80, 50, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
                com.a.a.a.Base.e.a(graphics, "Thao tác: Phím 2/mũi tên lên để di chuyển lên trên; phím 4/mũi tên trái để di chuyển sang trái; phím 6/mũi tên phải để di chuyển sang phải; phím 8/mũi tên xuống để di chuyển xuống dưới; phím mềm trái để xem lại, phím mềm phải về trình đơn chính.", (com.a.a.a.a.a.a / 2) - 80, (com.a.a.a.a.a.b / 2) - 70, 160, 160, com.bf.e.c.b, com.bf.e.c.c, 3, 1);
                com.a.a.a.Base.e.a(graphics, com.bf.e.c.a[3], (com.a.a.a.a.a.a / 2) + 55, (com.a.a.a.a.a.b / 2) + 80, 40, 50, com.bf.e.c.b, com.bf.e.c.c, 2, 4);
                return;
            default:
                switch (this.i) {
                    case 5:
                        switch (this.l) {
                            case 1:
                                return;
                            case 2:
                                com.bf.e.b.a(graphics);
                                com.bf.e.b.a(graphics, 0);
                                return;
                            case 3:
                                com.a.b.a.e.a(graphics, com.a.a.a.b.a.b[0], com.a.a.a.a.a.a / 2, com.a.a.a.a.a.b / 2, 3);
                                graphics.setColor(255, 125, 55);
                                graphics.drawRect((com.a.a.a.a.a.a / 2) - 85, (com.a.a.a.a.a.b / 2) - 85, 168, 170);
                                com.a.a.a.Base.e.a(graphics, "Thao tác: Phím 2/mũi tên lên để di chuyển lên trên; phím 4/mũi tên trái để di chuyển sang trái; phím 6/mũi tên phải để di chuyển sang phải; phím 8/mũi tên xuống để di chuyển xuống dưới; phím mềm trái để xem lại, phím mềm phải về trình đơn chính.", (com.a.a.a.a.a.a / 2) - 80, (com.a.a.a.a.a.b / 2) - 70, 160, 160, com.bf.e.c.b, com.bf.e.c.c, 3, 3);
                                com.a.a.a.Base.e.a(graphics, com.bf.e.c.d[4], (com.a.a.a.a.a.a / 2) - 30, (com.a.a.a.a.a.b / 2) - 95, 80, 80, com.bf.e.a.a, com.bf.e.a.b, 2, 1);
                                com.a.a.a.Base.e.a(graphics, com.bf.e.c.a[2], (com.a.a.a.a.a.a / 2) + 55, (com.a.a.a.a.a.b / 2) + 80, 320, 320, com.bf.e.a.a, com.bf.e.a.b, 2, 1);
                                return;
                            case 4:
                                com.bf.e.b.a(graphics);
                                com.bf.e.b.a(graphics, 2);
                                return;
                            default:
                                com.bf.e.b.a(graphics);
                                com.a.a.a.Base.e.a(graphics, "Tạm dừng", (com.a.a.a.a.a.a / 2) - 30, (com.a.a.a.a.a.b / 2) - 60, 80, 80, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
                                int i6 = 0;
                                int i7 = (com.a.a.a.a.a.a / 2) - 30;
                                int i8 = 0;
                                while (true) {
                                    int i9 = i8;
                                    int i10 = i6;
                                    if (i9 >= 4) {
                                        return;
                                    }
                                    if (i9 != 1) {
                                        int i11 = ((com.a.a.a.a.a.b / 2) + (i10 * 25)) - 31;
                                        if (i9 == this.k - 1) {
                                            com.a.a.a.Base.e.a(graphics, com.bf.e.c.e[i9], i7, i11, 80, 80, com.bf.e.a.c, com.bf.e.a.d, 2, 1);
                                        } else {
                                            com.a.a.a.Base.e.a(graphics, com.bf.e.c.e[i9], i7, i11, 80, 80, com.bf.e.a.a, com.bf.e.a.b, 2, 1);
                                        }
                                        i6 = i10 + 1;
                                    } else {
                                        i6 = i10;
                                    }
                                    i8 = i9 + 1;
                                }
                        }
                    case 6:
                        this.o = com.a.a.a.Base.b;
                        if (this.o - this.n > this.m) {
                            this.n = this.o;
                            this.p++;
                        }
                        if (this.p != 1) {
                            com.bf.e.b.a(graphics);
                            a(graphics, 0);
                            com.a.a.a.Base.e.a(graphics, com.bf.e.c.a[1], (com.a.a.a.a.a.a / 2) - 60, (com.a.a.a.a.a.b / 2) + 45, 40, 40, com.bf.e.a.a, com.bf.e.a.b, 2, 1);
                            return;
                        }
                        return;
                    case 7:
                        this.o = com.a.a.a.Base.b;
                        if (this.o - this.n > this.m) {
                            this.n = this.o;
                            this.p++;
                        }
                        if (this.p != 1) {
                            com.bf.e.b.a(graphics);
                            a(graphics, 0);
                            com.a.a.a.Base.e.a(graphics, com.bf.e.c.a[2], (com.a.a.a.a.a.a / 2) + 35, (com.a.a.a.a.a.b / 2) + 45, 80, 80, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
                            return;
                        }
                        return;
                    case 8:
                    default:
                        return;
                    case 9:
                        if (this.x < 0) {
                            com.a.a.a.Base.e.a(graphics, "Cửa", (com.a.a.a.a.a.a / 2) - 15, (com.a.a.a.a.a.b / 2) - (this.y * this.z), 40, 40, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
                            com.a.a.a.Base.e.a(graphics, new StringBuffer().append("").append(com.bf.e.a.h + 1).toString(), (com.a.a.a.a.a.a / 2) + 15, (com.a.a.a.a.a.b / 2) - (this.y * this.z), 40, 40, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
                            a(8, true);
                            return;
                        }
                        if (com.a.a.a.Base.b - this.n >= 5) {
                            this.n = com.a.a.a.Base.b;
                            this.x -= 5;
                            this.y += 5;
                        }
                        graphics.setColor(0, 0, 0);
                        graphics.fillRect(0, 0, (com.a.a.a.a.a.a / 2) - this.y, com.a.a.a.a.a.b);
                        graphics.fillRect((com.a.a.a.a.a.a / 2) + this.y, 0, (com.a.a.a.a.a.a / 2) - this.y, com.a.a.a.a.a.b);
                        com.a.a.a.Base.e.a(graphics, "Cửa", (com.a.a.a.a.a.a / 2) - 15, (com.a.a.a.a.a.b / 2) - (this.y * this.z), 40, 40, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
                        com.a.a.a.Base.e.a(graphics, new StringBuffer().append("").append(com.bf.e.a.h + 1).toString(), (com.a.a.a.a.a.a / 2) + 15, (com.a.a.a.a.a.b / 2) - (this.y * this.z), 40, 40, com.bf.e.a.a, com.bf.e.a.b, 2, 4);
                        return;
                }
        }
    }

    @Override // com.a.a.a.a.a
    public final void b() {
        switch (this.j) {
            case 1:
            case 2:
                return;
            case 3:
                if (com.a.a.a.a.b.b.b(65536)) {
                    h();
                    this.j = 0;
                }
                if (com.a.a.a.a.b.b.b(1024) || com.a.a.a.a.b.b.b(4)) {
                    com.a.a.a.Base.e.a(1, -1);
                    return;
                } else if ((com.a.a.a.a.b.b.b(2048) || com.a.a.a.a.b.b.b(256)) && com.a.a.a.Base.e.a(1, 1)) {
                    h();
                    this.j = 0;
                    return;
                } else {
                    return;
                }
            default:
                switch (this.i) {
                    case 5:
                        switch (this.l) {
                            case 1:
                                a(8, true);
                                this.k = 1;
                                this.l = 0;
                                this.j = 0;
                                return;
                            case 2:
                                if (com.a.a.a.a.a.a(32768)) {
                                    com.bf.d.b.c = true;
                                    this.k = 2;
                                    this.l = 0;
                                    this.j = 0;
                                    return;
                                } else if (com.a.a.a.a.a.a(65536)) {
                                    com.bf.d.b.c = false;
                                    this.k = 2;
                                    this.l = 0;
                                    this.j = 0;
                                    return;
                                } else {
                                    return;
                                }
                            case 3:
                                if (com.a.a.a.a.a.a(65536)) {
                                    this.k = 3;
                                    this.l = 0;
                                    return;
                                } else if (com.a.a.a.a.b.b.b(1024) || com.a.a.a.a.b.b.b(4)) {
                                    com.a.a.a.Base.e.a(3, -1);
                                    return;
                                } else if (com.a.a.a.a.b.b.b(2048) || com.a.a.a.a.b.b.b(256)) {
                                    com.a.a.a.Base.e.a(3, 1);
                                    return;
                                } else {
                                    return;
                                }
                            case 4:
                                if (com.a.a.a.a.a.a(32768)) {
                                    m();
                                    h();
                                    this.j = 0;
                                    BF_MIDlet.a.a();
                                    return;
                                } else if (com.a.a.a.a.a.a(65536)) {
                                    this.k = 4;
                                    this.l = 0;
                                    this.j = 0;
                                    return;
                                } else {
                                    return;
                                }
                            default:
                                if (com.a.a.a.a.b.b.b(4096) || com.a.a.a.a.b.b.b(1024) || com.a.a.a.a.b.b.b(4) || com.a.a.a.a.b.b.b(16)) {
                                    this.k--;
                                    if (this.k == 2) {
                                        this.k--;
                                    }
                                    if (this.k <= 0) {
                                        this.k = 4;
                                    }
                                } else if (com.a.a.a.a.b.b.b(8192) || com.a.a.a.a.b.b.b(2048) || com.a.a.a.a.b.b.b(256) || com.a.a.a.a.b.b.b(64)) {
                                    this.k++;
                                    if (this.k == 2) {
                                        this.k++;
                                    }
                                    if (this.k > 4) {
                                        this.k = 1;
                                    }
                                }
                                if (com.a.a.a.a.a.a(16384) || com.a.a.a.a.a.a(32)) {
                                    this.l = this.k;
                                    return;
                                }
                                return;
                        }
                    case 6:
                        if (com.a.a.a.a.a.a(32768)) {
                            n();
                            this.h = false;
                            q();
                            if (com.bf.e.a.h < com.bf.e.a.g.length - 1) {
                                com.bf.e.a.h++;
                                for (int i = 0; i < this.t[com.bf.e.a.h].length; i++) {
                                    for (int i2 = 0; i2 < this.t[com.bf.e.a.h][i].length; i2++) {
                                        this.t[com.bf.e.a.h][i][i2] = -1;
                                    }
                                }
                                m();
                                h();
                            }
                            com.bf.b.a.a().a(com.bf.e.a.h);
                            return;
                        }
                        return;
                    case 7:
                        if (com.a.a.a.a.a.a(65536)) {
                            com.bf.e.a.h = com.bf.b.a.a().d();
                            m();
                            h();
                            n();
                            this.h = false;
                            q();
                            BF_MIDlet.a.a();
                            return;
                        }
                        return;
                    case 8:
                        com.a.a.a.a.a.a(1);
                        if (com.a.a.a.a.b.b.b(65536)) {
                            i();
                            a(5, true);
                            return;
                        } else if (com.a.a.a.a.b.b.b(32768)) {
                            m();
                            i();
                            return;
                        } else if (com.a.a.a.a.a.a(4096) || com.a.a.a.a.a.a(16)) {
                            this.q = 2;
                            this.r = this.q;
                            o();
                            this.q = -1;
                            return;
                        } else if (com.a.a.a.a.a.a(8192) || com.a.a.a.a.a.a(64)) {
                            this.q = 3;
                            this.r = this.q;
                            o();
                            this.q = -1;
                            return;
                        } else if (com.a.a.a.a.a.a(1024) || com.a.a.a.a.a.a(4)) {
                            this.q = 0;
                            this.r = this.q;
                            o();
                            this.q = -1;
                            return;
                        } else if (com.a.a.a.a.a.a(2048) || com.a.a.a.a.a.a(256)) {
                            this.q = 1;
                            this.r = this.q;
                            o();
                            this.q = -1;
                            return;
                        } else {
                            return;
                        }
                    default:
                        return;
                }
        }
    }

    @Override // com.a.a.a.a.a
    public final void c() {
        switch (this.j) {
            case 1:
            case 2:
            case 6:
            case 7:
                return;
            case 3:
            case 4:
            case 5:
            default:
                switch (this.i) {
                    case 8:
                        if (p() && com.bf.e.a.h < com.bf.e.a.g.length - 1) {
                            a(6, true);
                        }
                        if (p() && com.bf.e.a.h == com.bf.e.a.g.length - 1) {
                            a(7, true);
                            return;
                        }
                        return;
                    default:
                        return;
                }
        }
    }

    @Override // com.a.a.a.a.a
    public final void d() {
        BF_MIDlet bF_MIDlet = BF_MIDlet.a;
        if (!(bF_MIDlet.b.i == 8)) {
            if (bF_MIDlet.f) {
                bF_MIDlet.f = false;
                com.bf.c.b.a().b().a();
                return;
            }
            return;
        }
        if (bF_MIDlet.f != com.bf.d.b.c) {
            bF_MIDlet.f = com.bf.d.b.c;
            if (bF_MIDlet.f) {
                com.bf.c.b.a().b().a(0, 100);
            } else {
                com.bf.c.b.a().b().a();
            }
        }
        if (bF_MIDlet.f && com.bf.c.b.a().b().b() == 300) {
            com.bf.c.b.a().b().a(0, 100);
        }
    }

    @Override // com.a.a.a.a.a
    public final void f() {
        if (com.bf.d.a.a) {
            l();
        }
    }

    public final void g() {
        this.j = 3;
    }

    public final void h() {
        a(9, true);
    }

    public final void i() {
        this.k = 1;
        this.l = 0;
    }

    public final void j() {
        if (this.f.size() != this.g.length) {
            this.f.removeAllElements();
            for (int i = 0; i < this.g.length; i++) {
                this.f.addElement(new Integer(this.g[i]));
            }
        }
        com.a.a.a.b.a.a(this.f);
        if (this.u) {
            return;
        }
        m();
        i();
        this.u = true;
    }

    public final void k() {
        com.a.a.a.b.a.b(this.f);
    }

    public final void l() {
        if (this.i == 8) {
            a(5, true);
        }
    }

    public final void m() {
        this.q = -1;
        this.r = 1;
        this.p = 0;
        switch (com.bf.e.a.h) {
            case 0:
                this.s[com.bf.e.a.h][0] = 6;
                this.s[com.bf.e.a.h][1] = 8;
                break;
            case 1:
                this.s[com.bf.e.a.h][0] = 3;
                this.s[com.bf.e.a.h][1] = 4;
                break;
            case 2:
                this.s[com.bf.e.a.h][0] = 3;
                this.s[com.bf.e.a.h][1] = 7;
                break;
            case 3:
                this.s[com.bf.e.a.h][0] = 4;
                this.s[com.bf.e.a.h][1] = 6;
                break;
            case 4:
                this.s[com.bf.e.a.h][0] = 5;
                this.s[com.bf.e.a.h][1] = 5;
                break;
            case 5:
                this.s[com.bf.e.a.h][0] = 9;
                this.s[com.bf.e.a.h][1] = 5;
                break;
            case 6:
                this.s[com.bf.e.a.h][0] = 9;
                this.s[com.bf.e.a.h][1] = 8;
                break;
            case 7:
                this.s[com.bf.e.a.h][0] = 3;
                this.s[com.bf.e.a.h][1] = 8;
                break;
            case 8:
                this.s[com.bf.e.a.h][0] = 7;
                this.s[com.bf.e.a.h][1] = 6;
                break;
            case 9:
                this.s[com.bf.e.a.h][0] = 5;
                this.s[com.bf.e.a.h][1] = 10;
                break;
            case 10:
                this.s[com.bf.e.a.h][0] = 3;
                this.s[com.bf.e.a.h][1] = 8;
                break;
            case 11:
                this.s[com.bf.e.a.h][0] = 6;
                this.s[com.bf.e.a.h][1] = 10;
                break;
            case 12:
                this.s[com.bf.e.a.h][0] = 5;
                this.s[com.bf.e.a.h][1] = 10;
                break;
            case 13:
                this.s[com.bf.e.a.h][0] = 6;
                this.s[com.bf.e.a.h][1] = 10;
                break;
            case 14:
                this.s[com.bf.e.a.h][0] = 6;
                this.s[com.bf.e.a.h][1] = 10;
                break;
            case 15:
                this.s[com.bf.e.a.h][0] = 5;
                this.s[com.bf.e.a.h][1] = 10;
                break;
            case 16:
                this.s[com.bf.e.a.h][0] = 8;
                this.s[com.bf.e.a.h][1] = 5;
                break;
            case 17:
                this.s[com.bf.e.a.h][0] = 6;
                this.s[com.bf.e.a.h][1] = 10;
                break;
            case 18:
                this.s[com.bf.e.a.h][0] = 8;
                this.s[com.bf.e.a.h][1] = 8;
                break;
            case 19:
                this.s[com.bf.e.a.h][0] = 5;
                this.s[com.bf.e.a.h][1] = 3;
                break;
        }
        for (int i = 0; i < this.t[com.bf.e.a.h].length; i++) {
            for (int i2 = 0; i2 < this.t[com.bf.e.a.h][i].length; i2++) {
                this.t[com.bf.e.a.h][i][i2] = -1;
            }
        }
        for (int i3 = 0; i3 < this.t.length; i3++) {
            switch (com.bf.e.a.h) {
                case 0:
                    this.t[com.bf.e.a.h][0][0] = 5;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 6;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 8;
                    this.t[com.bf.e.a.h][3][0] = 7;
                    this.t[com.bf.e.a.h][3][1] = 7;
                    break;
                case 1:
                    this.t[com.bf.e.a.h][0][0] = 5;
                    this.t[com.bf.e.a.h][0][1] = 5;
                    this.t[com.bf.e.a.h][1][0] = 4;
                    this.t[com.bf.e.a.h][1][1] = 6;
                    this.t[com.bf.e.a.h][2][0] = 4;
                    this.t[com.bf.e.a.h][2][1] = 5;
                    break;
                case 2:
                    this.t[com.bf.e.a.h][0][0] = 3;
                    this.t[com.bf.e.a.h][0][1] = 6;
                    this.t[com.bf.e.a.h][1][0] = 7;
                    this.t[com.bf.e.a.h][1][1] = 8;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 8;
                    this.t[com.bf.e.a.h][3][1] = 7;
                    break;
                case 3:
                    this.t[com.bf.e.a.h][0][0] = 5;
                    this.t[com.bf.e.a.h][0][1] = 6;
                    this.t[com.bf.e.a.h][1][0] = 5;
                    this.t[com.bf.e.a.h][1][1] = 7;
                    this.t[com.bf.e.a.h][2][0] = 6;
                    this.t[com.bf.e.a.h][2][1] = 8;
                    this.t[com.bf.e.a.h][3][0] = 5;
                    this.t[com.bf.e.a.h][3][1] = 9;
                    this.t[com.bf.e.a.h][4][0] = 6;
                    this.t[com.bf.e.a.h][4][1] = 10;
                    break;
                case 4:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 9;
                    this.t[com.bf.e.a.h][1][0] = 7;
                    this.t[com.bf.e.a.h][1][1] = 10;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 6;
                    break;
                case 5:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 5;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 8;
                    this.t[com.bf.e.a.h][3][0] = 8;
                    this.t[com.bf.e.a.h][3][1] = 6;
                    this.t[com.bf.e.a.h][4][0] = 7;
                    this.t[com.bf.e.a.h][4][1] = 7;
                    break;
                case 6:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 8;
                    this.t[com.bf.e.a.h][1][0] = 5;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 6;
                    this.t[com.bf.e.a.h][3][1] = 8;
                    this.t[com.bf.e.a.h][4][0] = 7;
                    this.t[com.bf.e.a.h][4][1] = 9;
                    break;
                case 7:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 9;
                    this.t[com.bf.e.a.h][1][0] = 5;
                    this.t[com.bf.e.a.h][1][1] = 8;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 6;
                    this.t[com.bf.e.a.h][3][1] = 7;
                    this.t[com.bf.e.a.h][4][0] = 7;
                    this.t[com.bf.e.a.h][4][1] = 7;
                    break;
                case 8:
                    this.t[com.bf.e.a.h][0][0] = 6;
                    this.t[com.bf.e.a.h][0][1] = 8;
                    this.t[com.bf.e.a.h][1][0] = 7;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 6;
                    this.t[com.bf.e.a.h][3][1] = 9;
                    break;
                case 9:
                    this.t[com.bf.e.a.h][0][0] = 6;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 6;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 8;
                    this.t[com.bf.e.a.h][3][0] = 7;
                    this.t[com.bf.e.a.h][3][1] = 9;
                    break;
                case 10:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 4;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 4;
                    this.t[com.bf.e.a.h][2][1] = 8;
                    this.t[com.bf.e.a.h][3][0] = 7;
                    this.t[com.bf.e.a.h][3][1] = 7;
                    this.t[com.bf.e.a.h][4][0] = 6;
                    this.t[com.bf.e.a.h][4][1] = 8;
                    this.t[com.bf.e.a.h][5][0] = 7;
                    this.t[com.bf.e.a.h][5][1] = 9;
                    break;
                case 11:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 7;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 6;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 7;
                    this.t[com.bf.e.a.h][3][1] = 7;
                    this.t[com.bf.e.a.h][4][0] = 4;
                    this.t[com.bf.e.a.h][4][1] = 9;
                    this.t[com.bf.e.a.h][5][0] = 5;
                    this.t[com.bf.e.a.h][5][1] = 9;
                    break;
                case 12:
                    this.t[com.bf.e.a.h][0][0] = 3;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 4;
                    this.t[com.bf.e.a.h][1][1] = 7;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 7;
                    this.t[com.bf.e.a.h][3][1] = 9;
                    break;
                case 13:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 7;
                    this.t[com.bf.e.a.h][1][1] = 6;
                    this.t[com.bf.e.a.h][2][0] = 6;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 8;
                    this.t[com.bf.e.a.h][3][1] = 7;
                    this.t[com.bf.e.a.h][4][0] = 8;
                    this.t[com.bf.e.a.h][4][1] = 8;
                    this.t[com.bf.e.a.h][5][0] = 4;
                    this.t[com.bf.e.a.h][5][1] = 8;
                    this.t[com.bf.e.a.h][6][0] = 3;
                    this.t[com.bf.e.a.h][6][1] = 8;
                    break;
                case 14:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 7;
                    this.t[com.bf.e.a.h][1][0] = 6;
                    this.t[com.bf.e.a.h][1][1] = 7;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 5;
                    this.t[com.bf.e.a.h][3][0] = 5;
                    this.t[com.bf.e.a.h][3][1] = 7;
                    this.t[com.bf.e.a.h][4][0] = 5;
                    this.t[com.bf.e.a.h][4][1] = 8;
                    this.t[com.bf.e.a.h][5][0] = 5;
                    this.t[com.bf.e.a.h][5][1] = 9;
                    this.t[com.bf.e.a.h][6][0] = 4;
                    this.t[com.bf.e.a.h][6][1] = 9;
                    this.t[com.bf.e.a.h][7][0] = 6;
                    this.t[com.bf.e.a.h][7][1] = 9;
                    break;
                case 15:
                    this.t[com.bf.e.a.h][0][0] = 3;
                    this.t[com.bf.e.a.h][0][1] = 8;
                    this.t[com.bf.e.a.h][1][0] = 3;
                    this.t[com.bf.e.a.h][1][1] = 9;
                    this.t[com.bf.e.a.h][2][0] = 4;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 5;
                    this.t[com.bf.e.a.h][3][1] = 9;
                    this.t[com.bf.e.a.h][4][0] = 7;
                    this.t[com.bf.e.a.h][4][1] = 9;
                    this.t[com.bf.e.a.h][5][0] = 7;
                    this.t[com.bf.e.a.h][5][1] = 8;
                    break;
                case 16:
                    this.t[com.bf.e.a.h][0][0] = 4;
                    this.t[com.bf.e.a.h][0][1] = 6;
                    this.t[com.bf.e.a.h][1][0] = 5;
                    this.t[com.bf.e.a.h][1][1] = 6;
                    this.t[com.bf.e.a.h][2][0] = 6;
                    this.t[com.bf.e.a.h][2][1] = 6;
                    this.t[com.bf.e.a.h][3][0] = 5;
                    this.t[com.bf.e.a.h][3][1] = 8;
                    this.t[com.bf.e.a.h][4][0] = 4;
                    this.t[com.bf.e.a.h][4][1] = 9;
                    break;
                case 17:
                    this.t[com.bf.e.a.h][0][0] = 6;
                    this.t[com.bf.e.a.h][0][1] = 6;
                    this.t[com.bf.e.a.h][1][0] = 7;
                    this.t[com.bf.e.a.h][1][1] = 7;
                    this.t[com.bf.e.a.h][2][0] = 7;
                    this.t[com.bf.e.a.h][2][1] = 8;
                    this.t[com.bf.e.a.h][3][0] = 4;
                    this.t[com.bf.e.a.h][3][1] = 8;
                    this.t[com.bf.e.a.h][4][0] = 5;
                    this.t[com.bf.e.a.h][4][1] = 9;
                    break;
                case 18:
                    this.t[com.bf.e.a.h][0][0] = 6;
                    this.t[com.bf.e.a.h][0][1] = 6;
                    this.t[com.bf.e.a.h][1][0] = 5;
                    this.t[com.bf.e.a.h][1][1] = 7;
                    this.t[com.bf.e.a.h][2][0] = 7;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 6;
                    this.t[com.bf.e.a.h][3][1] = 8;
                    this.t[com.bf.e.a.h][4][0] = 4;
                    this.t[com.bf.e.a.h][4][1] = 8;
                    this.t[com.bf.e.a.h][5][0] = 3;
                    this.t[com.bf.e.a.h][5][1] = 8;
                    this.t[com.bf.e.a.h][6][0] = 5;
                    this.t[com.bf.e.a.h][6][1] = 9;
                    this.t[com.bf.e.a.h][7][0] = 6;
                    this.t[com.bf.e.a.h][7][1] = 10;
                    this.t[com.bf.e.a.h][8][0] = 7;
                    this.t[com.bf.e.a.h][8][1] = 9;
                    break;
                case 19:
                    this.t[com.bf.e.a.h][0][0] = 5;
                    this.t[com.bf.e.a.h][0][1] = 4;
                    this.t[com.bf.e.a.h][1][0] = 5;
                    this.t[com.bf.e.a.h][1][1] = 6;
                    this.t[com.bf.e.a.h][2][0] = 5;
                    this.t[com.bf.e.a.h][2][1] = 7;
                    this.t[com.bf.e.a.h][3][0] = 5;
                    this.t[com.bf.e.a.h][3][1] = 8;
                    this.t[com.bf.e.a.h][4][0] = 5;
                    this.t[com.bf.e.a.h][4][1] = 9;
                    this.t[com.bf.e.a.h][5][0] = 5;
                    this.t[com.bf.e.a.h][5][1] = 11;
                    this.t[com.bf.e.a.h][6][0] = 4;
                    this.t[com.bf.e.a.h][6][1] = 9;
                    this.t[com.bf.e.a.h][7][0] = 6;
                    this.t[com.bf.e.a.h][7][1] = 9;
                    this.t[com.bf.e.a.h][8][0] = 3;
                    this.t[com.bf.e.a.h][8][1] = 7;
                    this.t[com.bf.e.a.h][9][0] = 4;
                    this.t[com.bf.e.a.h][9][1] = 7;
                    this.t[com.bf.e.a.h][10][0] = 6;
                    this.t[com.bf.e.a.h][10][1] = 7;
                    this.t[com.bf.e.a.h][11][0] = 7;
                    this.t[com.bf.e.a.h][11][1] = 7;
                    break;
            }
        }
    }

    public final void n() {
        this.x = com.a.a.a.a.a.a / 2;
        this.y = 0;
        this.z = com.a.a.a.a.a.b / com.a.a.a.a.a.a;
    }
}
