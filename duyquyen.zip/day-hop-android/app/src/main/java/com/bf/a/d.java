package com.bf.a;

import com.bf.midlet.BF_MIDlet;
import java.io.IOException;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.media.Player;

/* loaded from: classes.dex */
public final class d extends com.a.a.a.a.a {
    public static Image m;
    private volatile Thread A;
    private Player D;
    private Image[] F;
    public boolean g;
    private int p;
    private int q;
    private Image s;
    private Image x;
    private Image y;
    private Image z;
    private static boolean n = false;
    private static int t = -1;
    public static int j = 50;
    public static int k = 0;
    private int o = 176;
    private boolean r = false;
    public boolean f = true;
    public boolean h = false;
    private Image u = null;
    private Image v = null;
    private Runnable w = new e(this);
    long i = 0;
    private Image B = null;
    private Image C = null;
    private Image E = null;
    private int[] G = {16, 14, 5, 1, -3, -2, 0};
    private int[] H = {18, 15, -2, 0};
    int[][] l = {new int[]{2, this.G[6], 0, this.G[6], 1, this.G[6], com.bf.d.a.h}, new int[]{2, this.G[2], 0, this.G[2], 1, this.G[2], j}, new int[]{2, this.G[1], 0, this.G[1], 1, this.G[1], j}, new int[]{2, this.G[0], 0, this.G[0], 1, this.G[0], j, 2}, new int[]{-1, this.H[0], -1, this.H[0], -1, this.H[0], j}, new int[]{-1, this.H[0], 5, this.H[0], -1, this.H[0], j}, new int[]{-1, this.H[0], 5, this.H[1], -1, this.H[0], j}, new int[]{-1, this.H[0], 5, this.H[2], -1, this.H[0], j}, new int[]{-1, this.H[0], 5, this.H[3], -1, this.H[0], j}, new int[]{-1, this.H[0], 5, this.H[0], -1, this.H[0], j}, new int[]{-1, this.H[0], 5, this.H[1], 5, this.H[0], j, 1}, new int[]{-1, this.H[0], 5, this.H[2], 5, this.H[1], j}, new int[]{5, this.H[0], 5, this.H[3], 5, this.H[2], j}, new int[]{5, this.H[1], 5, this.H[0], 5, this.H[3], j}, new int[]{5, this.H[2], 5, this.H[1], 5, this.H[0], j}, new int[]{5, this.H[3], 5, this.H[2], 5, this.H[1], j}, new int[]{5, this.H[0], 5, this.H[3], 5, this.H[2], j}, new int[]{5, this.H[1], 5, this.H[0], 5, this.H[3], j}, new int[]{5, this.H[2], 2, this.G[0], 5, this.H[0], j}, new int[]{5, this.H[3], 2, this.G[1], 5, this.H[1], j}, new int[]{5, this.H[0], 2, this.G[2], 5, this.H[2], j}, new int[]{5, this.H[1], 2, this.G[3], 5, this.H[3], j}, new int[]{5, this.H[2], 2, this.G[4], 5, this.H[0], j}, new int[]{5, this.H[3], 2, this.G[5], 5, this.H[1], j}, new int[]{2, this.G[0], 2, this.G[6], 5, this.H[2], j}, new int[]{2, this.G[1], 2, this.G[6], 5, this.H[3], j}, new int[]{2, this.G[2], 2, this.G[6], 5, this.H[0], j}, new int[]{2, this.G[3], 2, this.G[6], 5, this.H[1], j}, new int[]{2, this.G[4], 2, this.G[6], 5, this.H[2], j}, new int[]{2, this.G[5], 2, this.G[6], 5, this.H[3], j}, new int[]{3, this.G[3], 2, this.G[6], 4, this.G[6], j}, new int[]{3, this.G[4], 2, this.G[6], 4, this.G[6], j}, new int[]{3, this.G[5], 2, this.G[6], 4, this.G[6], j}, new int[]{3, this.G[6], 2, this.G[6], 4, this.G[6], 1000}};

    static {
        int[][] iArr = {new int[]{0, 295, 48, 25}, new int[]{192, 295, 48, 25}};
    }

    public d() {
        this.g = true;
        int[] iArr = {35, 88, 140};
        int[] iArr2 = {48, 119, 191};
        int[] iArr3 = {16, 12, 2, -8, -12};
        this.g = false;
        b(0);
        this.A = new Thread(this.w);
        this.A.start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(d dVar) {
        return dVar.o;
    }

    public static void b(int i) {
        if (t != i) {
            t = i;
        }
    }

    public static void k() {
        m = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean l() {
        return false;
    }

    private boolean m() {
        try {
            if (this.u == null) {
                this.u = Image.createImage("/cm/logo.png");
            }
            if (this.v == null) {
                this.v = Image.createImage("/cm/b.png");
            }
            return true;
        } catch (Exception e) {
            this.u = null;
            this.v = null;
            return false;
        }
    }

    private boolean n() {
        try {
            if (this.E == null) {
                this.E = Image.createImage("/cm/bg.png");
            }
            if (this.F == null) {
                this.F = new Image[6];
                for (int i = 0; i < 6; i++) {
                    this.F[i] = Image.createImage(new StringBuffer().append("/cm/logo").append(i).append(".png").toString());
                }
            }
            if (this.B == null) {
                this.B = Image.createImage("/cm/logo51.png");
            }
            if (this.C == null) {
                this.C = Image.createImage("/cm/logo52.png");
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.a.a.a.a.a
    public final void a(int i, int i2) {
        boolean z;
        if (this.s != null) {
            switch (this.o) {
                case 128:
                    if (i <= (com.a.a.a.a.a.a / 2) - 61 || i >= (com.a.a.a.a.a.a / 2) - 28 || i2 <= com.a.a.a.a.a.b - 13 || i2 >= com.a.a.a.a.a.b) {
                        z = false;
                    } else {
                        this.r = true;
                        this.f = true;
                        this.h = false;
                        z = true;
                    }
                    if (i < (com.a.a.a.a.a.a / 2) + 61 && i > (com.a.a.a.a.a.a / 2) + 28 && i2 > com.a.a.a.a.a.b - 13 && i2 < com.a.a.a.a.a.b) {
                        this.r = false;
                        this.f = true;
                        this.h = false;
                        z = true;
                        break;
                    }
                    break;
                case 176:
                    if (i <= (com.a.a.a.a.a.a / 2) - 88 || i >= (com.a.a.a.a.a.a / 2) - 66 || i2 <= com.a.a.a.a.a.b - 26 || i2 >= com.a.a.a.a.a.b) {
                        z = false;
                    } else {
                        this.r = true;
                        this.f = true;
                        this.h = false;
                        z = true;
                    }
                    if (i < (com.a.a.a.a.a.a / 2) + 88 && i > (com.a.a.a.a.a.a / 2) + 66 && i2 > com.a.a.a.a.a.b - 26 && i2 < com.a.a.a.a.a.b) {
                        this.r = false;
                        this.f = true;
                        this.h = false;
                        z = true;
                        break;
                    }
                    break;
                case 208:
                    if (i <= (com.a.a.a.a.a.a / 2) - 104 || i >= (com.a.a.a.a.a.a / 2) - 82 || i2 <= com.a.a.a.a.a.b - 26 || i2 >= com.a.a.a.a.a.b) {
                        z = false;
                    } else {
                        this.r = true;
                        this.f = true;
                        this.h = false;
                        z = true;
                    }
                    if (i < (com.a.a.a.a.a.a / 2) + 104 && i > (com.a.a.a.a.a.a / 2) + 82 && i2 > com.a.a.a.a.a.b - 26 && i2 < com.a.a.a.a.a.b) {
                        this.r = false;
                        this.f = true;
                        this.h = false;
                        z = true;
                        break;
                    }
                    break;
                case 240:
                    if (i <= (com.a.a.a.a.a.a / 2) - 120 || i >= (com.a.a.a.a.a.a / 2) - 98 || i2 <= com.a.a.a.a.a.b - 24 || i2 >= com.a.a.a.a.a.b) {
                        z = false;
                    } else {
                        this.r = true;
                        this.f = true;
                        this.h = false;
                        z = true;
                    }
                    if (i < (com.a.a.a.a.a.a / 2) + 120 && i > (com.a.a.a.a.a.a / 2) + 98 && i2 > com.a.a.a.a.a.b - 24 && i2 < com.a.a.a.a.a.b) {
                        this.r = false;
                        this.f = true;
                        this.h = false;
                        z = true;
                        break;
                    }
                    break;
                case 320:
                    if (i <= (com.a.a.a.a.a.a / 2) - 160 || i >= (com.a.a.a.a.a.a / 2) - 136 || i2 <= com.a.a.a.a.a.b - 23 || i2 >= com.a.a.a.a.a.b) {
                        z = false;
                    } else {
                        this.r = true;
                        this.f = true;
                        this.h = false;
                        z = true;
                    }
                    if (i < (com.a.a.a.a.a.a / 2) + 160 && i > (com.a.a.a.a.a.a / 2) + 136 && i2 > com.a.a.a.a.a.b - 23 && i2 < com.a.a.a.a.a.b) {
                        this.r = false;
                        this.f = true;
                        this.h = false;
                        z = true;
                        break;
                    }
                    break;
                case 360:
                    if (i <= (com.a.a.a.a.a.a / 2) - 180 || i >= (com.a.a.a.a.a.a / 2) - 157 || i2 <= com.a.a.a.a.a.b - 36 || i2 >= com.a.a.a.a.a.b) {
                        z = false;
                    } else {
                        this.r = true;
                        this.f = true;
                        this.h = false;
                        z = true;
                    }
                    if (i < (com.a.a.a.a.a.a / 2) + 180 && i > (com.a.a.a.a.a.a / 2) + 157 && i2 > com.a.a.a.a.a.b - 36 && i2 < com.a.a.a.a.a.b) {
                        this.r = false;
                        this.f = true;
                        this.h = false;
                        z = true;
                        break;
                    }
                    break;
                default:
                    z = false;
                    break;
            }
            if (z) {
                b(2);
                this.u = null;
                this.v = null;
                this.s = null;
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // com.a.a.a.a.a
    public final void a(Graphics graphics) {
        int clipWidth;
        if (this.p == 0) {
            this.p = com.a.a.a.a.a.a;
            this.q = com.a.a.a.a.a.b;
        }
        com.a.a.a.Base.a(graphics);
        switch (t) {
            case 0:
            case 1:
                if (!m()) {
                    b(1);
                    return;
                }
                int i = 59;
                if (this.o == 128) {
                    i = 32;
                } else if (this.o == 360) {
                    i = 66;
                }
                int i2 = this.q - i;
                int height = i2 - (this.u.getHeight() + this.v.getHeight());
                int i3 = height > 0 ? height / 3 : 0;
                graphics.drawImage(this.u, this.p / 2, i3, 17);
                if (this.u.getHeight() + i3 + 5 + this.v.getHeight() > i2) {
                    graphics.drawImage(this.v, this.p / 2, i2, 33);
                    return;
                } else {
                    graphics.drawImage(this.v, this.p / 2, i3 + this.u.getHeight() + 5, 17);
                    return;
                }
            case 2:
                if (this.o == 128) {
                    if (k == 1) {
                        if (this.x == null) {
                            try {
                                this.x = Image.createImage("/cm/mobile.png");
                            } catch (Exception e) {
                                b(3);
                            }
                        }
                        graphics.drawImage(this.x, graphics.getClipWidth() / 2, graphics.getClipHeight() / 2, 3);
                        return;
                    } else if (k == 2) {
                        this.x = null;
                        if (this.y == null) {
                            try {
                                this.y = Image.createImage("/cm/logoa.png");
                            } catch (Exception e2) {
                            }
                        }
                        graphics.drawImage(this.y, graphics.getClipWidth() / 2, graphics.getClipHeight() / 2, 3);
                        return;
                    } else if (k == 3) {
                        this.y = null;
                        if (this.z == null) {
                            try {
                                this.z = Image.createImage("/cm/logob.png");
                            } catch (Exception e3) {
                            }
                        }
                        graphics.drawImage(this.z, graphics.getClipWidth() / 2, graphics.getClipHeight() / 2, 3);
                        this.f = false;
                        return;
                    } else if (k == 4) {
                        this.z = null;
                        graphics.setColor(16777215);
                        graphics.drawString("Đang tải trò chơi...", (graphics.getClipWidth() - graphics.getFont().stringWidth("Đang tải trò chơi...")) / 2, (graphics.getClipHeight() - graphics.getFont().getHeight()) / 2, 20);
                        return;
                    } else {
                        return;
                    }
                } else if (!n()) {
                    this.f = false;
                    return;
                } else if (!this.f || k >= this.l.length) {
                    return;
                } else {
                    graphics.setClip(0, 0, graphics.getClipWidth(), graphics.getClipHeight());
                    graphics.setColor(0);
                    graphics.fillRect(0, 0, graphics.getClipWidth(), graphics.getClipHeight());
                    graphics.drawImage(this.E, graphics.getClipWidth() / 2, graphics.getClipHeight() / 2, 3);
                    int clipHeight = this.o == 360 ? (graphics.getClipHeight() / 2) + 31 : this.o == 176 ? (graphics.getClipHeight() / 2) + 10 : this.o == 240 ? graphics.getClipHeight() / 2 : this.o == 208 ? (graphics.getClipHeight() / 2) + 15 : (graphics.getClipHeight() / 2) + 20;
                    for (int i4 = 0; i4 < 3; i4++) {
                        if (this.l[k][i4 << 1] != -1) {
                            switch (i4) {
                                case 0:
                                    if (this.o != 176 && this.o != 208) {
                                        if (this.o != 240 && this.o != 320) {
                                            if (this.o == 360) {
                                                clipWidth = (graphics.getClipWidth() / 2) - 112;
                                                break;
                                            }
                                            clipWidth = 0;
                                            break;
                                        } else {
                                            clipWidth = (graphics.getClipWidth() / 2) - 72;
                                            break;
                                        }
                                    } else {
                                        clipWidth = (graphics.getClipWidth() / 2) - 53;
                                        break;
                                    }
                                case 1:
                                    if (this.o == 360) {
                                        clipWidth = (graphics.getClipWidth() / 2) - 2;
                                        break;
                                    } else {
                                        clipWidth = graphics.getClipWidth() / 2;
                                        break;
                                    }
                                case 2:
                                    if (this.o != 176 && this.o != 208) {
                                        if (this.o != 240 && this.o != 320) {
                                            if (this.o == 360) {
                                                clipWidth = (graphics.getClipWidth() / 2) + 106;
                                                break;
                                            }
                                            clipWidth = 0;
                                            break;
                                        } else {
                                            clipWidth = (graphics.getClipWidth() / 2) + 72;
                                            break;
                                        }
                                    } else {
                                        clipWidth = (graphics.getClipWidth() / 2) + 52;
                                        break;
                                    }
                                default:
                                    clipWidth = 0;
                                    break;
                            }
                            int[] iArr = {0, -1, -1};
                            if (this.l[k][i4 << 1] != 5) {
                                graphics.drawImage(this.F[this.l[k][i4 << 1]], clipWidth - 2, (this.l[k][(i4 << 1) + 1] + clipHeight) - 20, 3);
                            } else if (this.l[k][(i4 << 1) + 1] == this.H[0]) {
                                graphics.drawImage(this.B, clipWidth + iArr[i4], clipHeight - 20, 3);
                            } else if (this.l[k][(i4 << 1) + 1] == this.H[1]) {
                                graphics.drawImage(this.F[this.l[k][i4 << 1]], clipWidth, clipHeight - 20, 3);
                            } else if (this.l[k][(i4 << 1) + 1] == this.H[2]) {
                                graphics.drawImage(this.C, clipWidth + iArr[i4], clipHeight - 20, 3);
                            }
                        }
                    }
                    return;
                }
            default:
                return;
        }
    }

    @Override // com.a.a.a.a.a
    public final void b() {
        boolean z;
        if (this.h) {
            if (com.a.a.a.a.a.a(32768)) {
                this.r = true;
                this.f = true;
                this.h = false;
                z = true;
            } else if (com.a.a.a.a.a.a(65536)) {
                this.r = false;
                this.f = true;
                this.h = false;
                z = true;
            } else {
                z = false;
            }
            if (z) {
                b(2);
                this.u = null;
                this.v = null;
                this.s = null;
            }
        }
    }

    @Override // com.a.a.a.a.a
    public final void c() {
    }

    @Override // com.a.a.a.a.a
    public final void d() {
    }

    public final synchronized void g() {
        if (this.A != null) {
            this.A = null;
        }
    }

    public final void h() {
        try {
            if (!this.r) {
                this.D.close();
                this.D = null;
            } else if (this.D != null) {
                this.D.start();
            }
        } catch (Exception e) {
        }
    }

    public final void i() {
        this.s = null;
        this.u = null;
        this.v = null;
        this.E = null;
        if (this.F != null) {
            for (byte b = 0; b < this.F.length; b = (byte) (b + 1)) {
                this.F[b] = null;
            }
        }
        this.B = null;
        this.C = null;
        this.D = null;
        this.s = null;
        this.E = null;
        this.B = null;
        this.C = null;
        this.D = null;
        BF_MIDlet.a.a();
        if (this.r) {
            com.bf.d.b.c = true;
        } else {
            com.bf.d.b.c = false;
        }
    }

    public final void j() {
        if (m == null) {
            try {
                m = Image.createImage("/cm/last.png");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
