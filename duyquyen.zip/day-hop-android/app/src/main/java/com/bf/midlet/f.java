package com.bf.midlet;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class f implements Runnable {
    /* JADX INFO: Access modifiers changed from: package-private */
    public f(BF_MIDlet bF_MIDlet) {
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            Thread.sleep(2000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        BF_MIDlet.c();
    }
}
