package com.bf.midlet;

/* Ban goc mo link quang cao http://Zing4u.us roi thoat game; da go bo. */
final class e implements Runnable {
    e(BF_MIDlet bF_MIDlet) {
    }

    public final void run() {
        BF_MIDlet.c();
    }
}
