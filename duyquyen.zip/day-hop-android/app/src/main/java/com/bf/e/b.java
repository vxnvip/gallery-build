package com.bf.e;

import javax.microedition.lcdui.Graphics;

/* loaded from: classes.dex */
public final class b {
    public static b a = new b();

    public b() {
        int[] iArr = {1, -1, 1};
        int[][] iArr2 = {new int[]{50, 10}, new int[]{30, 6}, new int[]{10, 2}, new int[]{0, 0}};
        a = this;
    }

    public static void a(Graphics graphics) {
        graphics.setColor(0, 0, 0);
        graphics.fillRect(0, 0, com.a.a.a.a.a.a, com.a.a.a.a.a.b);
    }

    public static void a(Graphics graphics, int i) {
        com.a.a.a.Base.e.a(graphics, c.f[i], (com.a.a.a.a.a.a / 2) - 43, (com.a.a.a.a.a.b / 2) - 20, 320, 320, com.bf.e.a.a, com.bf.e.a.b, 2, 0);
        com.a.a.a.Base.e.a(graphics, c.g[0], (com.a.a.a.a.a.a / 2) - 55, (com.a.a.a.a.a.b / 2) + 45, 320, 320, com.bf.e.a.a, com.bf.e.a.b, 2, 0);
        com.a.a.a.Base.e.a(graphics, c.g[1], (com.a.a.a.a.a.a / 2) + 45, (com.a.a.a.a.a.b / 2) + 45, 320, 320, com.bf.e.a.a, com.bf.e.a.b, 2, 0);
    }
}
