package com.bf.midlet;

/* loaded from: classes.dex */
final class d implements Runnable {
    /* JADX INFO: Access modifiers changed from: package-private */
    public d(BF_MIDlet bF_MIDlet) {
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.a.a.a.Base.f.a();
    }
}
