package com.bf.e;

/* loaded from: classes.dex */
public final class c {
    public static final String[] a = {"Trình đơn", "Xác định", "Trở về", "Bỏ qua"};
    public static final int[] b = {220, 220, 220};
    public static final int[] c = {0, 0, 255};
    public static final String[] d = {"Trò chơi mới", "Tiếp tục", "Liên kết", "Cài đặt", "Trợ giúp", "Giới thiệu", "Thoát"};
    public static final String[] e = {"Tiếp tục", "Cài đặt", "Trợ giúp", "Về trình đơn chính"};
    public static final String[] f = {"Bật âm thanh?", "Thoát khỏi trò chơi?", "Về trình đơn chính?", "Xóa lưu trữ?"};
    public static final String[] g = {"Có", "Không"};
    public static final String[] h = {"Chơi lại", "Trình đơn"};
    public static final String[] i = {"Chúc mừng bạn đã qua cửa!", "Chúc mừng bạn đã chiến thắng!"};

    static {
        int[] iArr = {255, 152, 8};
        int[] iArr2 = {42, 25, 2};
        int[] iArr3 = {255, 255, 146};
        int[] iArr4 = {126, 29, 20};
        String[] strArr = {"只要没有被压盖,就可以把他消灭掉", "帮助你找寻到一对可以消失的麻将", "增加游戏的可用时", "刷新当前游戏各麻将的顺序"};
    }
}
