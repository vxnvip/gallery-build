package com.bf.b;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import javax.microedition.rms.InvalidRecordIDException;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;
import javax.microedition.rms.RecordStoreNotFoundException;
import javax.microedition.rms.RecordStoreNotOpenException;

/* loaded from: classes.dex */
public final class a {
    private static RecordStore b = null;
    private static a c;
    private String a = "ZHIHERENGAMECONFIG";
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;

    private a() {
        String stringBuffer;
        this.d = 0;
        this.e = 0;
        this.f = 0;
        this.g = 1;
        this.h = 1;
        this.i = 5;
        this.j = 3;
        try {
            try {
                    if (b == null) {
                        b = RecordStore.openRecordStore(this.a, true);
                    }
                    if (b.getNumRecords() > 0) {
                        try {
                            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(b.getRecord(1));
                            DataInputStream dataInputStream = new DataInputStream(byteArrayInputStream);
                            this.d = dataInputStream.readInt();
                            this.e = dataInputStream.readInt();
                            this.f = dataInputStream.readInt();
                            this.g = dataInputStream.readInt();
                            this.h = dataInputStream.readInt();
                            this.i = dataInputStream.readInt();
                            this.j = dataInputStream.readInt();
                            dataInputStream.close();
                            byteArrayInputStream.close();
                            stringBuffer = "";
                        } catch (InvalidRecordIDException e) {
                            stringBuffer = new StringBuffer().append("").append(e.getMessage()).append("\n").toString();
                        } catch (RecordStoreException e2) {
                            stringBuffer = new StringBuffer().append("").append(e2.getMessage()).append("\n").toString();
                        } catch (IOException e3) {
                            stringBuffer = new StringBuffer().append("").append(e3.getMessage()).append("\n").toString();
                        }
                    } else {
                        a(true);
                        stringBuffer = "";
                    }
                    if (stringBuffer.trim().equals("")) {
                        return;
                    }
                    com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java RMS : ").append(stringBuffer).toString());
                } catch (RecordStoreException e5) {
                    String stringBuffer2 = new StringBuffer().append("").append(e5.getMessage()).append("\n").toString();
                    if (stringBuffer2.trim().equals("")) {
                        return;
                    }
                    com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java RMS : ").append(stringBuffer2).toString());
                }
        } catch (Throwable th) {
            if (!"".trim().equals("")) {
                com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java RMS : ").append("").toString());
            }
            throw th;
        }
    }

    public static a a() {
        if (c == null) {
            c = new a();
        }
        return c;
    }

    private void a(boolean z) {
        try {
            try {
                try {
                    try {
                        try {
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
                            dataOutputStream.writeInt(this.d);
                            dataOutputStream.writeInt(this.e);
                            dataOutputStream.writeInt(this.f);
                            dataOutputStream.writeInt(this.g);
                            dataOutputStream.writeInt(this.h);
                            dataOutputStream.writeInt(this.i);
                            dataOutputStream.writeInt(this.j);
                            byte[] byteArray = byteArrayOutputStream.toByteArray();
                            if (z) {
                                b.addRecord(byteArray, 0, byteArray.length);
                            } else {
                                b.setRecord(1, byteArray, 0, byteArray.length);
                            }
                            dataOutputStream.close();
                            byteArrayOutputStream.close();
                        } catch (IOException e) {
                            String stringBuffer = new StringBuffer().append("").append(e.getMessage()).append("\n").toString();
                            com.a.a.a.Base.a(new StringBuffer().append(this.d).append("").toString());
                            com.a.a.a.Base.a(new StringBuffer().append(this.e).append("").toString());
                            if (stringBuffer.trim().equals("")) {
                                return;
                            }
                            com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java save : ").append(stringBuffer).toString());
                        }
                    } catch (RecordStoreNotOpenException e2) {
                        String stringBuffer2 = new StringBuffer().append("").append(e2.getMessage()).append("\n").toString();
                        com.a.a.a.Base.a(new StringBuffer().append(this.d).append("").toString());
                        com.a.a.a.Base.a(new StringBuffer().append(this.e).append("").toString());
                        if (stringBuffer2.trim().equals("")) {
                            return;
                        }
                        com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java save : ").append(stringBuffer2).toString());
                    }
                } catch (RecordStoreFullException e3) {
                    String stringBuffer3 = new StringBuffer().append("").append(e3.getMessage()).append("\n").toString();
                    com.a.a.a.Base.a(new StringBuffer().append(this.d).append("").toString());
                    com.a.a.a.Base.a(new StringBuffer().append(this.e).append("").toString());
                    if (stringBuffer3.trim().equals("")) {
                        return;
                    }
                    com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java save : ").append(stringBuffer3).toString());
                }
            } catch (RecordStoreException e4) {
                String stringBuffer4 = new StringBuffer().append("").append(e4.getMessage()).append("\n").toString();
                com.a.a.a.Base.a(new StringBuffer().append(this.d).append("").toString());
                com.a.a.a.Base.a(new StringBuffer().append(this.e).append("").toString());
                if (stringBuffer4.trim().equals("")) {
                    return;
                }
                com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java save : ").append(stringBuffer4).toString());
            }
        } finally {
            com.a.a.a.Base.a(new StringBuffer().append(this.d).append("").toString());
            com.a.a.a.Base.a(new StringBuffer().append(this.e).append("").toString());
            if (!"".trim().equals("")) {
                com.a.a.a.Base.a(new StringBuffer().append("GAMECONFIG.java save : ").append("").toString());
            }
        }
    }

    public final void a(int i) {
        this.d = i;
        a(false);
    }

    public final void b() {
        try {
            this.d = 0;
            this.e = 0;
            this.f = 0;
            this.g = 1;
            this.h = 1;
            this.i = 5;
            this.j = 3;
            a(false);
        } catch (Exception e) {
            com.a.a.a.Base.a(e.getMessage());
        }
    }

    public final boolean c() {
        return this.d > 0;
    }

    public final int d() {
        return this.d;
    }
}
