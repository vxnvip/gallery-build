package com.bf.dayhop;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import com.bf.midlet.BF_MIDlet;
import javax.microedition.lcdui.MidpView;
import javax.microedition.media.Manager;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

public class MainActivity extends Activity {
    private static final String TAG = "DayHop";
    private MidpView view;
    private volatile MIDlet midlet;
    private boolean paused;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        RecordStore.dir = getFilesDir();
        Manager.cacheDir = getCacheDir();

        view = new MidpView(this);
        setContentView(view);
        view.requestFocus();

        MIDlet.exitHook = new Runnable() {
            public void run() {
                runOnUiThread(new Runnable() {
                    public void run() { finish(); }
                });
            }
        };

        Thread t = new Thread(new Runnable() {
            public void run() {
                try {
                    MIDlet m = new BF_MIDlet();
                    midlet = m;
                    m.internalStart();
                } catch (Throwable e) {
                    Log.e(TAG, "Khoi dong game loi", e);
                }
            }
        }, "midlet-main");
        t.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        MIDlet m = midlet;
        if (m != null) {
            paused = true;
            m.internalPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        MIDlet m = midlet;
        if (m != null && paused) {
            paused = false;
            try { m.internalStart(); } catch (Throwable e) { Log.e(TAG, "Resume loi", e); }
        }
    }

    @Override
    public void onBackPressed() {
        // Back = phím mềm phải (SK2), giống nút "Back" trên điện thoại Java
        view.tapKey(-7);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) {
            System.exit(0); // dọn sạch trạng thái static của game
        }
    }
}
