package com.bf.a;

import com.bf.midlet.BF_MIDlet;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;

/* loaded from: classes.dex */
public final class c extends com.a.a.a.a.a {
    public static int f;
    private long k;
    private long l;
    private int g = 0;
    private int h = 0;
    private int i = 100;
    private int j = 500;
    private Vector m = new Vector();
    private int[] n = new int[0];

    public c() {
        g();
        f = 0;
    }

    private void g() {
        if (this.m.size() != this.n.length) {
            this.m.removeAllElements();
            for (int i = 0; i < this.n.length; i++) {
                this.m.addElement(new Integer(this.n[i]));
            }
        }
        com.a.a.a.b.a.a(this.m);
    }

    @Override // com.a.a.a.a.a
    public final void a() {
        this.g = 0;
        this.h = 0;
        super.a();
    }

    @Override // com.a.a.a.a.a
    public final void a(Graphics graphics) {
        com.a.a.a.Base.a(graphics);
        if (this.h < this.g) {
            if (this.g - this.h >= 10 && this.g == this.i) {
                this.h += 10;
            } else if (this.g - this.h < 5 || this.g != this.i) {
                this.h++;
            } else {
                this.h += 5;
            }
        }
        com.a.a.a.Base.e.a(graphics, "Đang tải...", (com.a.a.a.a.a.a / 2) - 35, (com.a.a.a.a.a.b / 2) - 20, 100, 50, com.bf.e.a.a, com.bf.e.a.b, 2, 0);
        com.a.a.a.Base.e.a(graphics, new StringBuffer().append(" ").append(this.h).append("%").toString(), (com.a.a.a.a.a.a / 2) + 5, com.a.a.a.a.a.b / 2, 100, 50, com.bf.e.a.a, com.bf.e.a.b, 2, 0);
    }

    @Override // com.a.a.a.a.a
    public final void b() {
    }

    @Override // com.a.a.a.a.a
    public final void c() {
        if (!BF_MIDlet.a.e && this.h == this.i) {
            switch (f) {
                case 1:
                    BF_MIDlet.a.d.a();
                    break;
                case 2:
                    BF_MIDlet.a.c.a();
                    break;
                case 3:
                    BF_MIDlet.a.b.a();
                    break;
            }
        }
        if (!BF_MIDlet.a.e) {
            this.g = this.i;
        } else if (this.g <= this.i - 10) {
            this.l = System.currentTimeMillis();
            if (this.l - this.k >= this.j) {
                this.k = this.l;
                this.g += com.a.a.a.Base.a(2) + 9;
            }
        }
    }

    @Override // com.a.a.a.a.a
    public final void d() {
    }
}
