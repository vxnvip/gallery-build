package com.a.a.a.a;

import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;
import javax.microedition.midlet.MIDlet;

/* loaded from: classes.dex */
public final class b {
    public static b b = new b();
    private static int r;
    private static int s;
    private int d;
    private int e;
    private int f;
    private e g;
    private Display h;
    private Thread i;
    private Thread j;
    private long k;
    private long l;
    private a m;
    private long p;
    private long q;
    public int a = -1;
    private int c = 50;
    private String n = "";
    private int o = 16777215;
    private int t = 0;
    private int u = 0;

    private b() {
        b = this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static e a(b bVar) {
        return bVar.g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(b bVar, int i) {
        if (bVar.m != null) {
            int c = bVar.c(i);
            bVar.e |= c;
            bVar.d = c | bVar.d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int b(b bVar) {
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b(b bVar, int i) {
        if (bVar.m != null) {
            bVar.e &= bVar.c(i) ^ (-1);
            bVar.f = bVar.c(i) | bVar.f;
        }
    }

    private int c(int i) {
        switch (this.a) {
            case 0:
                switch (i) {
                    case -11:
                        return 2097152;
                    case -10:
                        return 1048576;
                    case -8:
                        return 131072;
                    case 1:
                        return 1024;
                    case 2:
                        return 4096;
                    case 5:
                        return 8192;
                    case 6:
                        return 2048;
                    case 8:
                        return 16384;
                    case 9:
                        return 32768;
                    case 10:
                        return 65536;
                    case 35:
                        return 524288;
                    case 42:
                        return 262144;
                    case 48:
                        return 1;
                    case 49:
                        return 2;
                    case 50:
                        return 4;
                    case 51:
                        return 8;
                    case 52:
                        return 16;
                    case 53:
                        return 32;
                    case 54:
                        return 64;
                    case 55:
                        return 128;
                    case 56:
                        return 256;
                    case 57:
                        return 512;
                }
            case 1:
                switch (i) {
                    case -22:
                    case -7:
                        return 65536;
                    case -21:
                    case -6:
                        return 32768;
                    case -11:
                        return 2097152;
                    case -10:
                        return 1048576;
                    case -8:
                        return 131072;
                    case -5:
                        return 16384;
                    case -4:
                        return 8192;
                    case -3:
                        return 4096;
                    case -2:
                        return 2048;
                    case -1:
                        return 1024;
                    case 35:
                        return 524288;
                    case 42:
                        return 262144;
                    case 48:
                        return 1;
                    case 49:
                        return 2;
                    case 50:
                        return 4;
                    case 51:
                        return 8;
                    case 52:
                        return 16;
                    case 53:
                        return 32;
                    case 54:
                        return 64;
                    case 55:
                        return 128;
                    case 56:
                        return 256;
                    case 57:
                        return 512;
                }
            case 2:
                switch (i) {
                    case -22:
                        return 65536;
                    case -21:
                        return 32768;
                    case -20:
                        return 16384;
                    case -11:
                        return 2097152;
                    case -10:
                        return 1048576;
                    case -8:
                        return 131072;
                    case -6:
                        return 2048;
                    case -5:
                        return 8192;
                    case -2:
                        return 4096;
                    case -1:
                        return 1024;
                    case 35:
                        return 524288;
                    case 42:
                        return 262144;
                    case 48:
                        return 1;
                    case 49:
                        return 2;
                    case 50:
                        return 4;
                    case 51:
                        return 8;
                    case 52:
                        return 16;
                    case 53:
                        return 32;
                    case 54:
                        return 64;
                    case 55:
                        return 128;
                    case 56:
                        return 256;
                    case 57:
                        return 512;
                }
            case 3:
                switch (i) {
                    case -7:
                        return 65536;
                    case -6:
                        return 32768;
                    case -5:
                        return 16384;
                    case -4:
                        return 8192;
                    case -3:
                        return 4096;
                    case -2:
                        return 2048;
                    case -1:
                        return 1024;
                    case 35:
                        return 8;
                    case 42:
                        return 4;
                    case 55:
                        return 1;
                    case 57:
                        return 2;
                }
            case 4:
                switch (i) {
                    case -11:
                        return 2097152;
                    case -10:
                        return 1048576;
                    case -8:
                        return 131072;
                    case -7:
                        return 65536;
                    case -6:
                        return 32768;
                    case -5:
                        return 16384;
                    case -4:
                        return 8192;
                    case -3:
                        return 4096;
                    case -2:
                        return 2048;
                    case -1:
                        return 1024;
                    case 98:
                        return 256;
                    case 102:
                        return 16;
                    case 103:
                        return 32;
                    case 104:
                        return 64;
                    case 106:
                        return 524288;
                    case 109:
                        return 1;
                    case 110:
                        return 512;
                    case 114:
                        return 2;
                    case 116:
                        return 4;
                    case 117:
                        return 262144;
                    case 118:
                        return 128;
                    case 121:
                        return 8;
                }
            case 5:
                switch (i) {
                    case -11:
                        return 2097152;
                    case -10:
                        return 1048576;
                    case -8:
                        return 131072;
                    case 1:
                        return 1024;
                    case 2:
                        return 4096;
                    case 5:
                        return 8192;
                    case 6:
                        return 2048;
                    case 20:
                        return 16384;
                    case 21:
                        return 32768;
                    case 22:
                        return 65536;
                    case 35:
                        return 524288;
                    case 42:
                        return 262144;
                    case 48:
                        return 1;
                    case 49:
                        return 2;
                    case 50:
                        return 4;
                    case 51:
                        return 8;
                    case 52:
                        return 16;
                    case 53:
                        return 32;
                    case 54:
                        return 64;
                    case 55:
                        return 128;
                    case 56:
                        return 256;
                    case 57:
                        return 512;
                }
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int c(b bVar) {
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static a d(b bVar) {
        return bVar.m;
    }

    public static int e() {
        return r;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void e(b bVar) {
        if (bVar.m != null) {
            bVar.m.f();
        }
    }

    public static int f() {
        return s;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void f(b bVar) {
        while (true) {
            try {
                com.a.a.a.Base.b = System.currentTimeMillis();
                if (bVar.m != null) {
                    bVar.m.b();
                    bVar.d = 0;
                    bVar.f = 0;
                    bVar.m.c();
                    bVar.m.e();
                }
                bVar.k = System.currentTimeMillis() - com.a.a.a.Base.b;
                Thread.sleep(Math.max(1L, bVar.c - bVar.k));
                bVar.l = System.currentTimeMillis() - com.a.a.a.Base.b;
            } catch (Exception e) {
                e.printStackTrace();
                e.toString();
                bVar.c();
                return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void g(b bVar) {
        while (true) {
            try {
                bVar.p = System.currentTimeMillis();
                if (bVar.m != null) {
                    bVar.m.d();
                }
                bVar.q = System.currentTimeMillis() - bVar.p;
                Thread.sleep(Math.max(1L, bVar.c - bVar.q));
            } catch (Exception e) {
                e.printStackTrace();
                e.toString();
                bVar.c();
                return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int i() {
        return r;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int j() {
        return s;
    }

    public final void a() {
        this.g = new e(this);
    }

    public final void a(int i) {
        this.c = 66;
    }

    public final void a(int i, int i2, int i3, boolean z) {
        r = i;
        s = i2;
        this.a = i3;
        com.a.a.a.Base.a = z;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(a aVar) {
        if (this.m != aVar) {
            this.m = aVar;
            this.h.setCurrent(this.g);
            this.e = 0;
            this.d = 0;
        }
    }

    public final void a(MIDlet mIDlet) {
        this.h = Display.getDisplay(mIDlet);
        if (this.i == null) {
            this.i = new c(this);
            this.i.setPriority(10);
            this.i.start();
        }
        if (this.j == null) {
            this.j = new d(this);
            this.j.setPriority(5);
            this.j.start();
        }
    }

    public final void b() {
        this.d = 0;
        this.e = 0;
        this.f = 0;
    }

    public final boolean b(int i) {
        boolean z = (this.d & i) != 0;
        if (z) {
            this.d = 0;
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void c() {
        if (this.g != null) {
            this.g.a();
        }
        this.g.repaint();
        this.g.serviceRepaints();
    }

    public final Graphics d() {
        return this.g.a();
    }

    public final int g() {
        return this.g.getWidth();
    }

    public final int h() {
        return this.g.getHeight();
    }
}
