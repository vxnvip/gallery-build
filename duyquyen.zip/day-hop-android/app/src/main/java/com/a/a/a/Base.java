package com.a.a.a;

import com.a.b.a.b;
import com.a.b.a.d;
import com.a.b.a.e;
import com.a.b.a.f;
import java.util.Random;
import javax.microedition.lcdui.Graphics;

/* loaded from: classes.dex */
public final class Base {
    public static long b;
    public static e d;
    public static f e;
    public static b f;
    public static boolean g;
    private static int h;
    private static int i;
    private static Random j;
    public static boolean a = true;
    public static com.a.b.a.a c = new com.a.b.a.a();

    static {
        new d();
        d = new e();
        e = new f();
        f = new b();
        g = false;
        j = new Random();
    }

    public static int a(int i2) {
        return Math.abs(j.nextInt()) % 2;
    }

    public static void a(int i2, int i3) {
        h = i2;
        i = i3;
    }

    public static void a(String str) {
    }

    public static void a(Graphics graphics) {
        int[] iArr = new int[3];
        graphics.setColor(iArr[0], iArr[1], iArr[2]);
        graphics.setClip(0, 0, h, i);
        graphics.fillRect(0, 0, h, i);
    }
}
