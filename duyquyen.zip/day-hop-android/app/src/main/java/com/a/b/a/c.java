package com.a.b.a;

import javax.microedition.lcdui.Image;

/* loaded from: classes.dex */
final class c {
    private int a;
    private Image b;
    private int[] c;
    private int[] d;

    public c(b bVar, int i, Image image, int[] iArr, int[] iArr2) {
        this.a = i;
        this.b = image;
        this.c = iArr;
        this.d = iArr2;
    }

    public final Image a() {
        return this.b;
    }

    public final boolean a(int i, int[] iArr, int[] iArr2) {
        if (this.a != i) {
            return false;
        }
        return this.c[0] == iArr[0] && this.c[1] == iArr[1] && this.c[2] == iArr[2] && this.d[0] == iArr2[0] && this.d[1] == iArr2[1] && this.d[2] == iArr2[2];
    }
}
