package com.a.a.a.a;

/* loaded from: classes.dex */
final class d extends Thread {
    private b a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(b bVar) {
        this.a = bVar;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        b.g(this.a);
    }
}
