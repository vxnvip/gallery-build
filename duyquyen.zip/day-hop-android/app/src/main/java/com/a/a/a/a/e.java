package com.a.a.a.a;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class e extends Canvas {
    private Image a;
    private Graphics b;
    private int c;
    private int d;
    private b e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(b bVar) {
        this.e = bVar;
        setFullScreenMode(true);
        repaint();
        this.d = getWidth();
        this.c = getHeight();
        if (this.d < com.a.a.a.a.b.i()) {
            this.d = com.a.a.a.a.b.i();
        }
        if (this.c < com.a.a.a.a.b.j()) {
            this.c = com.a.a.a.a.b.j();
        }
        this.a = Image.createImage(this.d, this.c);
        com.a.a.a.Base.a(this.d, this.c);
        this.b = this.a.getGraphics();
        this.b.setFont(Font.getFont(0, 0, 8));
    }

    public final Graphics a() {
        return this.b;
    }

    protected final void hideNotify() {
        com.a.a.a.a.b.e(this.e);
    }

    protected final void keyPressed(int i) {
        com.a.a.a.a.b.a(this.e, i);
    }

    protected final void keyReleased(int i) {
        com.a.a.a.a.b.b(this.e, i);
    }

    protected final void keyRepeated(int i) {
        super.keyRepeated(i);
    }

    protected final void paint(Graphics graphics) {
        if (this.a != null) {
            graphics.setColor(0, 0, 0);
            graphics.fillRect(0, 0, com.a.a.a.a.b.a(this.e).getWidth(), com.a.a.a.a.b.a(this.e).getHeight());
            graphics.drawImage(this.a, com.a.a.a.a.b.b(this.e), com.a.a.a.a.b.c(this.e), 0);
        }
    }

    protected final void pointerDragged(int i, int i2) {
    }

    protected final void pointerPressed(int i, int i2) {
        com.a.a.a.a.b.d(this.e).a(i, i2);
    }

    protected final void pointerReleased(int i, int i2) {
    }

    protected final void showNotify() {
    }
}
