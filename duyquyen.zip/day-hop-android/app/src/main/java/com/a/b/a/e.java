package com.a.b.a;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/* loaded from: classes.dex */
public final class e {
    private String[] c;
    private Image h;
    private int[] i;
    private int a = 0;
    private String b = "/icons/";
    private InputStream d = null;
    private ByteArrayInputStream e = null;
    private Image f = null;
    private String g = "";
    private boolean j = false;

    public static void a(Graphics graphics, Image image, int i, int i2, int i3) {
        graphics.drawImage(image, i, i2, i3);
    }

    private void closeStreams() {
        try {
            if (this.e != null) {
                this.e.close();
            }
            if (this.d != null) {
                this.d.close();
            }
        } catch (IOException e) {
            com.a.a.a.Base.a(new StringBuffer("T.java createImage finally \n").append(e.getMessage()).toString());
        }
    }

    /* Viet lai thu cong: ban jadx dich sai khoi try/finally va vong lap. */
    private Image b(String str, String str2) {
        if (this.j) {
            return null;
        }
        switch (this.a) {
            case 0:
                this.b = str;
                try {
                    com.a.a.a.Base.a(new StringBuffer("|  |").append(this.b).append(str2).toString());
                    return Image.createImage(new StringBuffer(String.valueOf(this.b)).append(str2).toString());
                } catch (Exception e) {
                    com.a.a.a.Base.a(new StringBuffer("T.java createImage() ").append(this.b).append(str2).append(" = null : \n").append(e.getMessage()).toString());
                    return null;
                }
            case 1:
                this.b = str;
                com.a.a.a.Base.a(new StringBuffer("|* |").append(this.b).append(str2).toString());
                for (int i = 0; i < this.c.length; i += 2) {
                    try {
                        if (this.c[i].equals(str2.trim())) {
                            this.d = getClass().getResourceAsStream(new StringBuffer(String.valueOf(this.b)).append(str2).toString());
                            if (!String.valueOf(this.d.available()).equals(this.c[i + 1])) {
                                this.j = true;
                            }
                        }
                    } catch (Exception e2) {
                        com.a.a.a.Base.a(new StringBuffer("T.java createImage catch ").append(str2).append(" = null : \n").append(e2.getMessage()).toString());
                    } finally {
                        closeStreams();
                    }
                }
                try {
                    Image createImage = Image.createImage(new StringBuffer(String.valueOf(this.b)).append(str2).toString());
                    closeStreams();
                    return createImage;
                } catch (IOException e5) {
                    closeStreams();
                    return null;
                }
            case 2:
                this.b = "/icons/";
                com.a.a.a.Base.a(new StringBuffer("|**|").append(this.b).append(str2).toString());
                if (!this.g.equals(str2)) {
                    this.g = str2.trim();
                    this.f = null;
                    System.gc();
                } else if (this.f != null) {
                    return this.f;
                }
                String substring = str2.substring(0, str2.indexOf("."));
                try {
                    for (int i2 = 0; i2 < this.c.length; i2 += 2) {
                        if (this.c[i2].equals(str2.trim())) {
                            this.d = getClass().getResourceAsStream(new StringBuffer(String.valueOf(this.b)).append(substring).append(".bf").toString());
                            int available = this.d.available() - 12;
                            if (String.valueOf(available).equals(this.c[i2 + 1])) {
                                byte[] bArr = new byte[available];
                                this.d.skip(12L);
                                this.d.read(bArr);
                                this.e = new ByteArrayInputStream(bArr);
                                this.f = Image.createImage(this.e);
                                return this.f;
                            }
                            this.j = true;
                            return null;
                        }
                    }
                    return null;
                } catch (Exception e9) {
                    com.a.a.a.Base.a(new StringBuffer("T.java createImage catch ").append(str2).append(" = null : \n").append(e9.getMessage()).toString());
                    return null;
                } finally {
                    closeStreams();
                }
            default:
                return null;
        }
    }

    public final Image a(String str, String str2) {
        Image image;
        try {
            this.h = b(str, str2);
            if (com.a.a.a.Base.a) {
                this.i = new int[this.h.getWidth() * this.h.getHeight()];
                this.h.getRGB(this.i, 0, this.h.getWidth(), 0, 0, this.h.getWidth(), this.h.getHeight());
                image = Image.createRGBImage(this.i, this.h.getWidth(), this.h.getHeight(), true);
            } else {
                image = this.h;
            }
            return image;
        } catch (Exception e) {
            com.a.a.a.Base.a(new StringBuffer("T RGBIMAGE ERROR : \n").append(e.getMessage()).toString());
            return null;
        }
    }
}
