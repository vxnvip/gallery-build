package com.a.a.a.b;

import java.util.Vector;
import javax.microedition.lcdui.Image;

/* loaded from: classes.dex */
public final class a {
    public static int[] a = new int[0];
    private static final Vector c = new Vector();
    public static Image[] b = null;

    public static void a(Vector vector) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= vector.size()) {
                return;
            }
            int intValue = ((Integer) vector.elementAt(i2)).intValue();
            if (b[intValue] == null) {
                b[intValue] = com.a.a.a.Base.d.a("/pic/", new StringBuffer().append(intValue).append(".png").toString());
            }
            i = i2 + 1;
        }
    }

    public static void b(Vector vector) {
        if (c.size() != a.length) {
            c.removeAllElements();
            for (int i = 0; i < a.length; i++) {
                c.addElement(new Integer(a[i]));
            }
        }
        for (int i2 = 0; i2 < vector.size(); i2++) {
            int intValue = ((Integer) vector.elementAt(i2)).intValue();
            if (!c.contains(new Integer(intValue))) {
                b[intValue] = null;
            }
        }
        System.gc();
    }
}
