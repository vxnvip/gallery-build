package com.a.b.a;

import java.io.DataInputStream;
import java.io.InputStream;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/* loaded from: classes.dex */
public final class b {
    private static boolean e = true;
    private static Vector[] f;
    private int[][] b;
    private int[] c;
    private int[] d;
    private int j;
    private int k;
    private int l;
    private int m;
    private int n;
    private String o;
    private int[] p;
    private int[] q;
    private int r;
    private int a = 0;
    private int g = 1;
    private boolean h = false;
    private int i = 0;
    private int s = 1;
    private int t = 3;
    private int u = 0;

    private void a(int i) {
        System.arraycopy(this.p, this.q.length * i, this.q, 0, this.q.length);
    }

    private void a(int[] iArr) {
        switch (this.a) {
            case 0:
                for (int i = 0; i < this.l; i++) {
                    for (int i2 = 0; i2 < this.m; i2++) {
                        for (int i3 = 0; i3 < 8; i3++) {
                            if ((i2 << 3) + i3 < this.k && (this.q[(this.m * i) + i2] & (128 >> i3)) != 0) {
                                iArr[((this.g + i) * (this.k + (this.g << 1))) + (i2 << 3) + i3 + this.g] = ((this.c[0] << 16) & 16711680) | (-16777216) | ((this.c[1] << 8) & 65280) | (this.c[2] & 255);
                            }
                        }
                    }
                }
                return;
            case 1:
                for (int i4 = 0; i4 < this.l; i4++) {
                    for (int i5 = 0; i5 < this.m; i5++) {
                        for (int i6 = 0; i6 < 8; i6++) {
                            if ((i5 << 3) + i6 < this.k && (this.q[(this.m * i4) + i5] & (128 >> i6)) != 0) {
                                if (i4 < this.b.length) {
                                    iArr[((this.g + i4) * (this.k + (this.g << 1))) + (i5 << 3) + i6 + this.g] = ((this.b[i4][0] << 16) & 16711680) | (-16777216) | ((this.b[i4][1] << 8) & 65280) | (this.b[i4][2] & 255);
                                } else {
                                    iArr[((this.g + i4) * (this.k + (this.g << 1))) + (i5 << 3) + i6 + this.g] = ((this.b[this.b.length - 1][0] << 16) & 16711680) | (-16777216) | ((this.b[this.b.length - 1][1] << 8) & 65280) | (this.b[this.b.length - 1][2] & 255);
                                }
                            }
                        }
                    }
                }
                return;
            case 2:
                for (int i7 = 0; i7 < this.l; i7++) {
                    for (int i8 = 0; i8 < this.m; i8++) {
                        for (int i9 = 0; i9 < 8; i9++) {
                            int i10 = (i8 << 3) + i9;
                            if (i10 < this.k && (this.q[(this.m * i7) + i8] & (128 >> i9)) != 0) {
                                int length = this.b.length;
                                iArr[((this.g + i7) * (this.k + (this.g << 1))) + (i8 << 3) + i9 + this.g] = (this.b[i10][2] & 255) | ((this.b[i10][0] << 16) & 16711680) | (-16777216) | ((this.b[i10][1] << 8) & 65280);
                            }
                        }
                    }
                }
                return;
            case 3:
                for (int i11 = 0; i11 < this.l; i11++) {
                    for (int i12 = 0; i12 < this.m; i12++) {
                        for (int i13 = 0; i13 < 8; i13++) {
                            if ((i12 << 3) + i13 < this.k && (this.q[(this.m * i11) + i12] & (128 >> i13)) != 0) {
                                iArr[((this.k + (this.g << 1)) * i11) + (i12 << 3) + i13 + this.g] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[(((this.g << 1) + i11) * (this.k + (this.g << 1))) + (i12 << 3) + i13 + this.g] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[((this.g + i11) * (this.k + (this.g << 1))) + (i12 << 3) + i13] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[((this.g + i11) * (this.k + (this.g << 1))) + (i12 << 3) + i13 + (this.g << 1)] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                            }
                        }
                    }
                }
                for (int i14 = 0; i14 < this.l; i14++) {
                    for (int i15 = 0; i15 < this.m; i15++) {
                        for (int i16 = 0; i16 < 8; i16++) {
                            if ((i15 << 3) + i16 < this.k && (this.q[(this.m * i14) + i15] & (128 >> i16)) != 0) {
                                iArr[((this.g + i14) * (this.k + (this.g << 1))) + (i15 << 3) + i16 + this.g] = ((this.c[0] << 16) & 16711680) | (-16777216) | ((this.c[1] << 8) & 65280) | (this.c[2] & 255);
                            }
                        }
                    }
                }
                return;
            case 4:
                for (int i17 = 0; i17 < this.l; i17++) {
                    for (int i18 = 0; i18 < this.m; i18++) {
                        for (int i19 = 0; i19 < 8; i19++) {
                            if ((i18 << 3) + i19 < this.k && (this.q[(this.m * i17) + i18] & (128 >> i19)) != 0) {
                                iArr[((this.k + (this.g << 1)) * i17) + (i18 << 3) + i19 + this.g] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[(((this.g << 1) + i17) * (this.k + (this.g << 1))) + (i18 << 3) + i19 + this.g] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[((this.g + i17) * (this.k + (this.g << 1))) + (i18 << 3) + i19] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[((this.g + i17) * (this.k + (this.g << 1))) + (i18 << 3) + i19 + (this.g << 1)] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                            }
                        }
                    }
                }
                for (int i20 = 0; i20 < this.l; i20++) {
                    for (int i21 = 0; i21 < this.m; i21++) {
                        for (int i22 = 0; i22 < 8; i22++) {
                            if ((i21 << 3) + i22 < this.k && (this.q[(this.m * i20) + i21] & (128 >> i22)) != 0) {
                                if (i20 < this.b.length) {
                                    iArr[((this.g + i20) * (this.k + (this.g << 1))) + (i21 << 3) + i22 + this.g] = ((this.b[i20][0] << 16) & 16711680) | (-16777216) | ((this.b[i20][1] << 8) & 65280) | (this.b[i20][2] & 255);
                                } else {
                                    iArr[((this.g + i20) * (this.k + (this.g << 1))) + (i21 << 3) + i22 + this.g] = ((this.b[this.b.length - 1][0] << 16) & 16711680) | (-16777216) | ((this.b[this.b.length - 1][1] << 8) & 65280) | (this.b[this.b.length - 1][2] & 255);
                                }
                            }
                        }
                    }
                }
                return;
            case 5:
                for (int i23 = 0; i23 < this.l; i23++) {
                    for (int i24 = 0; i24 < this.m; i24++) {
                        for (int i25 = 0; i25 < 8; i25++) {
                            if ((i24 << 3) + i25 < this.k && (this.q[(this.m * i23) + i24] & (128 >> i25)) != 0) {
                                iArr[((this.k + (this.g << 1)) * i23) + (i24 << 3) + i25 + this.g] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[(((this.g << 1) + i23) * (this.k + (this.g << 1))) + (i24 << 3) + i25 + this.g] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[((this.g + i23) * (this.k + (this.g << 1))) + (i24 << 3) + i25] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                                iArr[((this.g + i23) * (this.k + (this.g << 1))) + (i24 << 3) + i25 + (this.g << 1)] = ((this.d[0] << 16) & 16711680) | (-16777216) | ((this.d[1] << 8) & 65280) | (this.d[2] & 255);
                            }
                        }
                    }
                }
                for (int i26 = 0; i26 < this.l; i26++) {
                    for (int i27 = 0; i27 < this.m; i27++) {
                        for (int i28 = 0; i28 < 8; i28++) {
                            int i29 = (i27 << 3) + i28;
                            if (i29 < this.k && (this.q[(this.m * i26) + i27] & (128 >> i28)) != 0) {
                                int length2 = this.b.length;
                                iArr[((this.g + i26) * (this.k + (this.g << 1))) + (i27 << 3) + i28 + this.g] = (this.b[i29][2] & 255) | ((this.b[i29][0] << 16) & 16711680) | (-16777216) | ((this.b[i29][1] << 8) & 65280);
                            }
                        }
                    }
                }
                return;
            default:
                return;
        }
    }

    private void b(Graphics graphics, String str, int i, int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        if (e) {
            int length = str.length();
            int i9 = 0;
            int a = a(graphics, str);
            int i10 = (i3 & 8) != 0 ? i - a : i;
            int a2 = (i3 & 32) != 0 ? i2 - a(graphics) : i2;
            int i11 = (i3 & 1) != 0 ? i10 - (a >> 1) : i10;
            int a3 = ((i3 & 2) == 0 && (i3 & 64) == 0) ? a2 : a2 - (a(graphics) >> 1);
            for (int i12 = 0; i12 < length; i12++) {
                boolean z = true;
                char charAt = str.charAt(i12);
                int indexOf = this.o.indexOf(charAt);
                int i13 = indexOf == -1 ? 0 : indexOf;
                switch (this.a) {
                    case 0:
                        i4 = i9;
                        int i14 = 0;
                        while (i14 < f[i13].size()) {
                            c cVar = (c) f[i13].elementAt(i14);
                            if (cVar.a(this.a, this.c, this.c)) {
                                z = false;
                                com.a.b.a.e.a(graphics, cVar.a(), (i11 - this.g) + i4, a3 - this.g, 20);
                                i8 = charAt < 127 ? this.r + this.s + i4 : this.k + this.s + i4;
                            } else {
                                i8 = i4;
                            }
                            i14++;
                            i4 = i8;
                        }
                        if (z) {
                            a(i13);
                            int[] iArr = new int[(this.k + (this.g << 1)) * (this.l + (this.g << 1))];
                            a(iArr);
                            f[i13].addElement(new c(this, this.a, Image.createRGBImage(iArr, this.k + (this.g << 1), this.l + (this.g << 1), true), this.c, this.c));
                            i9 = i4;
                            continue;
                        }
                        break;
                    case 1:
                    case 2:
                        i4 = i9;
                        int i15 = 0;
                        while (i15 < f[i13].size()) {
                            c cVar2 = (c) f[i13].elementAt(i15);
                            if (cVar2.a(this.a, this.b[0], this.b[this.b.length - 1])) {
                                z = false;
                                com.a.b.a.e.a(graphics, cVar2.a(), (i11 - this.g) + i4, a3 - this.g, 20);
                                i7 = charAt < 127 ? this.r + this.s + i4 : this.k + this.s + i4;
                            } else {
                                i7 = i4;
                            }
                            i15++;
                            i4 = i7;
                        }
                        if (z) {
                            a(i13);
                            int[] iArr2 = new int[(this.k + (this.g << 1)) * (this.l + (this.g << 1))];
                            a(iArr2);
                            f[i13].addElement(new c(this, this.a, Image.createRGBImage(iArr2, this.k + (this.g << 1), this.l + (this.g << 1), true), this.b[0], this.b[this.b.length - 1]));
                            i9 = i4;
                            continue;
                        }
                        break;
                    case 3:
                        i4 = i9;
                        int i16 = 0;
                        while (i16 < f[i13].size()) {
                            c cVar3 = (c) f[i13].elementAt(i16);
                            if (cVar3.a(this.a, this.c, this.d)) {
                                z = false;
                                com.a.b.a.e.a(graphics, cVar3.a(), (i11 - this.g) + i4, a3 - this.g, 20);
                                i6 = charAt < 127 ? this.r + this.s + i4 : this.k + this.s + i4;
                            } else {
                                i6 = i4;
                            }
                            i16++;
                            i4 = i6;
                        }
                        if (z) {
                            a(i13);
                            int[] iArr3 = new int[(this.k + (this.g << 1)) * (this.l + (this.g << 1))];
                            a(iArr3);
                            f[i13].addElement(new c(this, this.a, Image.createRGBImage(iArr3, this.k + (this.g << 1), this.l + (this.g << 1), true), this.c, this.d));
                            i9 = i4;
                            continue;
                        }
                        break;
                    case 4:
                    case 5:
                        i4 = i9;
                        int i17 = 0;
                        while (i17 < f[i13].size()) {
                            c cVar4 = (c) f[i13].elementAt(i17);
                            if (cVar4.a(this.a, this.b[0], this.b[this.b.length - 1])) {
                                z = false;
                                com.a.b.a.e.a(graphics, cVar4.a(), (i11 - this.g) + i4, a3 - this.g, 20);
                                i5 = charAt < 127 ? this.r + this.s + i4 : this.k + this.s + i4;
                            } else {
                                i5 = i4;
                            }
                            i17++;
                            i4 = i5;
                        }
                        if (z) {
                            a(i13);
                            int[] iArr4 = new int[(this.k + (this.g << 1)) * (this.l + (this.g << 1))];
                            a(iArr4);
                            f[i13].addElement(new c(this, this.a, Image.createRGBImage(iArr4, this.k + (this.g << 1), this.l + (this.g << 1), true), this.b[0], this.b[this.b.length - 1]));
                            break;
                        }
                        break;
                    default:
                        i4 = i9;
                        break;
                }
                i9 = i4;
            }
        }
    }

    public final int a(Graphics graphics) {
        return this.h ? this.l + this.t : graphics.getFont().getHeight() + this.u;
    }

    public final int a(Graphics graphics, String str) {
        int i;
        int i2;
        int i3 = 0;
        if (this.h) {
            int length = str.length();
            for (int i4 = 0; i4 < length; i4++) {
                if (str.charAt(i4) < 127) {
                    i = this.r;
                    i2 = this.s;
                } else {
                    i = this.k;
                    i2 = this.s;
                }
                i3 += i + i2;
            }
            return i3;
        }
        return graphics.getFont().stringWidth(str);
    }

    public final void a() {
        try {
            InputStream resourceAsStream = getClass().getResourceAsStream(new StringBuffer(String.valueOf("/font/")).append("font.fbf").toString());
            DataInputStream dataInputStream = new DataInputStream(resourceAsStream);
            this.j = dataInputStream.read();
            if (this.j != 0) {
                return;
            }
            this.k = dataInputStream.read();
            this.l = dataInputStream.read();
            this.m = dataInputStream.read();
            this.n = (dataInputStream.read() << 8) + dataInputStream.read();
            this.o = "";
            for (int i = 0; i < this.n; i++) {
                this.o = new StringBuffer(String.valueOf(this.o)).append(dataInputStream.readChar()).toString();
            }
            this.p = new int[this.n * this.l * this.m];
            this.q = new int[this.l * this.m];
            f = new Vector[this.n];
            int i2 = 0;
            int i3 = 0;
            while (i2 < this.n) {
                f[i2] = new Vector();
                int i4 = i3;
                int i5 = 0;
                while (i5 < this.l) {
                    int i6 = i4;
                    for (int i7 = 0; i7 < this.m; i7++) {
                        this.p[i6] = dataInputStream.read();
                        i6++;
                    }
                    i5++;
                    i4 = i6;
                }
                i2++;
                i3 = i4;
            }
            this.r = dataInputStream.read();
            this.h = true;
            dataInputStream.close();
            resourceAsStream.close();
        } catch (Exception e2) {
            com.a.a.a.Base.a(new StringBuffer("FontG loading error : ").append(e2.getMessage()).toString());
        }
    }

    public final void a(Graphics graphics, String str, int i, int i2, int i3) {
        if (!this.h) {
            graphics.drawString(str, i, i2, 20);
            return;
        }
        this.a = 0;
        int color = graphics.getColor();
        this.c = new int[]{(color >> 16) & 255, (color >> 8) & 255, color & 255};
        b(graphics, str, i, i2, 20);
    }

    public final void a(Graphics graphics, String str, int i, int i2, int i3, int[] iArr, int[] iArr2) {
        if (this.h) {
            this.a = 3;
            this.c = iArr;
            this.d = iArr2;
            b(graphics, str, i, i2, i3);
            return;
        }
        graphics.setColor(iArr2[0], iArr2[1], iArr2[2]);
        graphics.drawString(str, i, i2, i3);
        graphics.drawString(str, i, i2 - 1, i3);
        graphics.drawString(str, i + 1, i2, i3);
        graphics.drawString(str, i, i2 + 1, i3);
        graphics.drawString(str, i - 1, i2, i3);
        graphics.setColor(iArr[0], iArr[1], iArr[2]);
        graphics.drawString(str, i, i2, i3);
    }

    public final void a(Graphics graphics, String str, int i, int i2, int i3, int[][] iArr) {
        if (!this.h) {
            graphics.setColor(iArr[iArr.length / 2][0], iArr[iArr.length / 2][1], iArr[iArr.length / 2][2]);
            graphics.drawString(str, i, i2, 20);
            return;
        }
        this.a = 1;
        this.b = iArr;
        if (this.b == null) {
            this.a = 0;
        }
        b(graphics, str, i, i2, 20);
    }

    public final void a(Graphics graphics, String str, int i, int i2, int i3, int[][] iArr, int[] iArr2) {
        if (this.h) {
            this.a = 4;
            this.b = iArr;
            this.d = iArr2;
            b(graphics, str, i, i2, 20);
            return;
        }
        graphics.setColor(iArr2[0], iArr2[1], iArr2[2]);
        graphics.drawString(str, i, i2, 20);
        graphics.drawString(str, i, i2 - 1, 20);
        graphics.drawString(str, i + 1, i2, 20);
        graphics.drawString(str, i, i2 + 1, 20);
        graphics.drawString(str, i - 1, i2, 20);
        int length = iArr.length / 2;
        graphics.setColor(iArr[length][0], iArr[length][1], iArr[length][2]);
        graphics.drawString(str, i, i2, 20);
    }

    public final void b() {
        if (!this.h || f.length <= 0) {
            return;
        }
        for (int i = 0; i < f.length; i++) {
            f[i].removeAllElements();
        }
    }

    public final void b(Graphics graphics, String str, int i, int i2, int i3, int[][] iArr) {
        if (!this.h) {
            graphics.setColor(iArr[iArr.length / 2][0], iArr[iArr.length / 2][1], iArr[iArr.length / 2][2]);
            graphics.drawString(str, i, i2, 20);
            return;
        }
        this.a = 2;
        this.b = iArr;
        if (this.b == null) {
            this.a = 0;
        }
        b(graphics, str, i, i2, 20);
    }

    public final void b(Graphics graphics, String str, int i, int i2, int i3, int[][] iArr, int[] iArr2) {
        if (this.h) {
            this.a = 5;
            this.b = iArr;
            this.d = iArr2;
            b(graphics, str, i, i2, 20);
            return;
        }
        graphics.setColor(iArr2[0], iArr2[1], iArr2[2]);
        graphics.drawString(str, i, i2, 20);
        graphics.drawString(str, i, i2 - 1, 20);
        graphics.drawString(str, i + 1, i2, 20);
        graphics.drawString(str, i, i2 + 1, 20);
        graphics.drawString(str, i - 1, i2, 20);
        int length = iArr.length / 2;
        graphics.setColor(iArr[length][0], iArr[length][1], iArr[length][2]);
        graphics.drawString(str, i, i2, 20);
    }
}
