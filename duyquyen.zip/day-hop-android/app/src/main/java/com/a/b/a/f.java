package com.a.b.a;

import java.util.Vector;
import javax.microedition.lcdui.Graphics;

/* loaded from: classes.dex */
public final class f {
    private int a;
    private Vector[] b = new Vector[5];
    private Vector[] c = new Vector[5];
    private String[] d = {"", "", "", "", ""};
    private int[] e = new int[5];
    private int[] f = new int[5];
    private int[] g = new int[5];
    private int[] h = new int[5];
    private int[] i = new int[5];
    private int[] j = new int[5];
    private int[] k = new int[5];
    private int[] l = new int[5];
    private int[] m = new int[5];
    private int[] n = new int[5];
    private int[] o = new int[5];
    private int[] p = new int[5];
    private int[] q = new int[5];
    private int r = 5;
    private int[] s = {255, 255, 255};
    private int[] t = {255, 255};

    public f() {
        String[] strArr = {"", "", "", "", ""};
        String[] strArr2 = {"", "", "", "", ""};
        a();
    }

    private void a() {
        for (int i = 0; i < this.c.length; i++) {
            this.c[i] = new Vector();
        }
        for (int i2 = 0; i2 < this.b.length; i2++) {
            this.b[i2] = new Vector();
        }
    }

    private void a(Graphics graphics, String str, int i, int i2, int i3, int i4, int i5, int i6) {
        boolean z = (i5 & 1) != 0;
        boolean z2 = (i5 & 2) != 0;
        int i7 = z2 ? i3 - this.r : i3;
        if (!this.d[i6].trim().equals(str.trim()) || this.h[i6] != i || this.i[i6] != i2 || this.j[i6] != i7 || this.k[i6] != i4) {
            this.h[i6] = i;
            this.i[i6] = i2;
            this.j[i6] = i7;
            this.k[i6] = i4;
            this.e[i6] = 0;
            this.f[i6] = 0;
            this.g[i6] = 0;
            this.d[i6] = str.trim();
            this.c[i6].removeAllElements();
            int i8 = 0;
            for (int i9 = 0; i9 < this.d[i6].length(); i9++) {
                if (this.d[i6].charAt(i9) == '*') {
                    this.c[i6].addElement(this.d[i6].substring(i8, i9));
                    i8 = i9 + 1;
                } else {
                    if (com.a.a.a.Base.f.a(graphics, this.d[i6].substring(i8, i9 + 1)) > this.j[i6]) {
                        this.c[i6].addElement(this.d[i6].substring(i8, i9));
                        i8 = i9;
                    }
                    if (i9 == this.d[i6].length() - 1) {
                        this.c[i6].addElement(this.d[i6].substring(i8));
                    }
                }
            }
            this.e[i6] = this.k[i6] / com.a.a.a.Base.f.a(graphics);
            int[] iArr = this.e;
            iArr[i6] = iArr[i6] - 1;
            if (this.k[i6] % com.a.a.a.Base.f.a(graphics) != 0) {
                int[] iArr2 = this.e;
                iArr2[i6] = iArr2[i6] + 1;
            }
            this.f[i6] = this.c[i6].size() / this.e[i6];
            if (this.c[i6].size() % this.e[i6] != 0) {
                int[] iArr3 = this.f;
                iArr3[i6] = iArr3[i6] + 1;
            }
        }
        if (this.c[i6] != null && this.c[i6].size() > 0) {
            int i10 = 0;
            while (true) {
                int i11 = i10;
                if (i11 < this.e[i6]) {
                    if ((this.g[i6] * this.e[i6]) + i11 < this.c[i6].size()) {
                        if (z) {
                            switch (this.a) {
                                case 0:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), ((this.j[i6] - com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11))) / 2) + this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20);
                                    continue;
                                case 1:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), ((this.j[i6] - com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11))) / 2) + this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, null);
                                    continue;
                                case 2:
                                    com.a.a.a.Base.f.b(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), ((this.j[i6] - com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11))) / 2) + this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, null);
                                    continue;
                                case 3:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), ((this.j[i6] - com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11))) / 2) + this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, new int[]{this.l[i6], this.m[i6], this.n[i6]}, new int[]{this.o[i6], this.p[i6], this.q[i6]});
                                    continue;
                                case 4:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), ((this.j[i6] - com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11))) / 2) + this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, (int[][]) null, new int[]{this.o[i6], this.p[i6], this.q[i6]});
                                    continue;
                                case 5:
                                    com.a.a.a.Base.f.b(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), ((this.j[i6] - com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11))) / 2) + this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, null, new int[]{this.o[i6], this.p[i6], this.q[i6]});
                                    continue;
                            }
                        } else {
                            switch (this.a) {
                                case 0:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20);
                                    continue;
                                case 1:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, null);
                                    continue;
                                case 2:
                                    com.a.a.a.Base.f.b(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, null);
                                    continue;
                                case 3:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, new int[]{this.l[i6], this.m[i6], this.n[i6]}, new int[]{this.o[i6], this.p[i6], this.q[i6]});
                                    continue;
                                case 4:
                                    com.a.a.a.Base.f.a(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, (int[][]) null, new int[]{this.o[i6], this.p[i6], this.q[i6]});
                                    continue;
                                case 5:
                                    com.a.a.a.Base.f.b(graphics, (String) this.c[i6].elementAt((this.g[i6] * this.e[i6]) + i11), this.h[i6], (com.a.a.a.Base.f.a(graphics) * i11) + this.i[i6], 20, null, new int[]{this.o[i6], this.p[i6], this.q[i6]});
                                    continue;
                            }
                        }
                    }
                    i10 = i11 + 1;
                }
            }
        }
        if (!z2 || this.f[i6] <= 1) {
            return;
        }
        graphics.setColor(this.s[0], this.s[1], this.s[2]);
        graphics.fillRect(this.h[i6] + this.j[i6], this.i[i6] + ((this.g[i6] * this.k[i6]) / this.f[i6]), this.r, (this.k[i6] / this.f[i6]) + (this.k[i6] % this.f[i6]));
        graphics.setColor(this.t[0], this.t[1], this.t[2]);
        graphics.drawRect(this.h[i6] + this.j[i6], this.i[i6], this.r, this.k[i6]);
    }

    public final void a(Graphics graphics, String str, int i, int i2, int i3, int i4, int[] iArr, int[] iArr2, int i5, int i6) {
        this.a = 3;
        this.l[i6] = iArr[0];
        this.m[i6] = iArr[1];
        this.n[i6] = iArr[2];
        this.o[i6] = iArr2[0];
        this.p[i6] = iArr2[1];
        this.q[i6] = iArr2[2];
        a(graphics, str, i, i2, i3, i4, i5, i6);
    }

    public final boolean a(int i, int i2) {
        int[] iArr = this.g;
        iArr[i] = iArr[i] + i2;
        if (this.g[i] >= this.f[i]) {
            this.g[i] = 0;
            return true;
        }
        if (this.g[i] < 0) {
            if (this.f[i] - 1 >= 0) {
                this.g[i] = this.f[i] - 1;
            } else {
                this.g[i] = 0;
            }
        }
        return false;
    }
}
