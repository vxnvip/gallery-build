package com.a.a.a.a;

import javax.microedition.lcdui.Graphics;

/* loaded from: classes.dex */
public abstract class a {
    public static int a;
    public static int b;
    public static int d;
    public static int e;
    public static int c = com.a.a.a.a.b.e();
    private static int f = com.a.a.a.a.b.f();

    public static boolean a(int i) {
        return com.a.a.a.a.b.b.b(i);
    }

    public void a() {
        com.a.a.a.a.b.b.a(this);
        e();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(int i, int i2) {
    }

    public abstract void a(Graphics graphics);

    public abstract void b();

    public abstract void c();

    public abstract void d();

    public final void e() {
        Graphics d2 = com.a.a.a.a.b.b.d();
        a = com.a.a.a.a.b.b.g();
        b = com.a.a.a.a.b.b.h();
        d = (a - c) / 2;
        e = (b - f) / 2;
        com.a.a.a.Base.a(d2);
        a(d2);
        com.a.a.a.a.b.b.c();
    }

    public void f() {
        com.a.a.a.a.b.b.b();
    }
}
