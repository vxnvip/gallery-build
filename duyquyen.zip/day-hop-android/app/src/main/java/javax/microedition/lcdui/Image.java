package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import java.io.IOException;
import java.io.InputStream;

public class Image {
    final Bitmap bmp;
    private final boolean mutable;

    private Image(Bitmap b, boolean mutable) {
        this.bmp = b;
        this.mutable = mutable;
    }

    public static Image createImage(int w, int h) {
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        b.eraseColor(0xFFFFFFFF);
        return new Image(b, true);
    }

    public static Image createImage(String name) throws IOException {
        InputStream in = Image.class.getResourceAsStream(name);
        if (in == null) throw new IOException("Khong tim thay tai nguyen: " + name);
        try {
            return createImage(in);
        } finally {
            try { in.close(); } catch (IOException ignored) { }
        }
    }

    public static Image createImage(InputStream in) throws IOException {
        Bitmap b = BitmapFactory.decodeStream(in);
        if (b == null) throw new IOException("Khong giai ma duoc anh");
        return new Image(b, false);
    }

    public static Image createImage(byte[] data, int off, int len) {
        Bitmap b = BitmapFactory.decodeByteArray(data, off, len);
        if (b == null) throw new IllegalArgumentException("Khong giai ma duoc anh");
        return new Image(b, false);
    }

    public static Image createImage(Image src) {
        return new Image(src.bmp.copy(Bitmap.Config.ARGB_8888, false), false);
    }

    public static Image createImage(Image src, int x, int y, int w, int h, int transform) {
        Matrix m = transformMatrix(transform, w, h);
        Bitmap b = Bitmap.createBitmap(src.bmp, x, y, w, h, m, false);
        return new Image(b, false);
    }

    public static Image createRGBImage(int[] rgb, int w, int h, boolean alpha) {
        int[] px = rgb;
        if (!alpha) {
            px = new int[w * h];
            for (int i = 0; i < px.length; i++) px[i] = rgb[i] | 0xFF000000;
        }
        return new Image(Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888), false);
    }

    public Graphics getGraphics() {
        if (!mutable) throw new IllegalStateException("Image khong sua duoc");
        return new Graphics(new android.graphics.Canvas(bmp), bmp.getWidth(), bmp.getHeight());
    }

    public int getWidth() { return bmp.getWidth(); }
    public int getHeight() { return bmp.getHeight(); }
    public boolean isMutable() { return mutable; }

    public void getRGB(int[] rgb, int off, int scan, int x, int y, int w, int h) {
        bmp.getPixels(rgb, off, scan, x, y, w, h);
    }

    /** Sprite.TRANS_*: 0 none, 1 mirror+rot180, 2 mirror, 3 rot180, 4 mirror+rot270, 5 rot90, 6 rot270, 7 mirror+rot90 */
    static Matrix transformMatrix(int t, int w, int h) {
        Matrix m = new Matrix();
        switch (t) {
            case 1: m.postScale(1, -1); break;
            case 2: m.postScale(-1, 1); break;
            case 3: m.postRotate(180); break;
            case 4: m.postScale(-1, 1); m.postRotate(270); break;
            case 5: m.postRotate(90); break;
            case 6: m.postRotate(270); break;
            case 7: m.postScale(-1, 1); m.postRotate(90); break;
            default: break;
        }
        return m;
    }
}
