package javax.microedition.lcdui;

import javax.microedition.midlet.MIDlet;

public class Display {
    /** Kích thước màn hình ảo mà game nhìn thấy (view tự co giãn ra màn hình thật). */
    public static final int WIDTH = 240;
    public static final int HEIGHT = 320;

    private static final Display INSTANCE = new Display();
    static volatile Displayable current;
    private static volatile Runnable repaintHook;

    public static Display getDisplay(MIDlet m) { return INSTANCE; }

    public static void setRepaintHook(Runnable r) { repaintHook = r; }
    public static Displayable currentDisplayable() { return current; }

    static void requestRepaint() {
        Runnable r = repaintHook;
        if (r != null) r.run();
    }

    public void setCurrent(Displayable d) {
        Displayable old = current;
        if (old != d && old instanceof Canvas) {
            ((Canvas) old).hideNotify();
        }
        current = d;
        if (d instanceof Canvas) {
            ((Canvas) d).showNotify();
        }
        requestRepaint();
    }

    public Displayable getCurrent() { return current; }
}
