package javax.microedition.lcdui;

import android.graphics.Paint;
import android.graphics.Typeface;

public final class Font {
    public static final int STYLE_PLAIN = 0, STYLE_BOLD = 1, STYLE_ITALIC = 2, STYLE_UNDERLINED = 4;
    public static final int SIZE_SMALL = 8, SIZE_MEDIUM = 0, SIZE_LARGE = 16;
    public static final int FACE_SYSTEM = 0, FACE_MONOSPACE = 32, FACE_PROPORTIONAL = 64;

    final Typeface typeface;
    final float textSize;
    final boolean underline;
    private final int face, style, size;
    private final Paint metrics = new Paint();

    private Font(int face, int style, int size) {
        this.face = face;
        this.style = style;
        this.size = size;
        int ts = ((style & STYLE_BOLD) != 0 ? Typeface.BOLD : 0) | ((style & STYLE_ITALIC) != 0 ? Typeface.ITALIC : 0);
        Typeface base = face == FACE_MONOSPACE ? Typeface.MONOSPACE
                : face == FACE_PROPORTIONAL ? Typeface.SANS_SERIF : Typeface.DEFAULT;
        this.typeface = Typeface.create(base, ts);
        this.textSize = size == SIZE_SMALL ? 11f : size == SIZE_LARGE ? 18f : 14f;
        this.underline = (style & STYLE_UNDERLINED) != 0;
        metrics.setTypeface(typeface);
        metrics.setTextSize(textSize);
        metrics.setAntiAlias(true);
    }

    public static Font getDefaultFont() { return new Font(FACE_SYSTEM, STYLE_PLAIN, SIZE_MEDIUM); }
    public static Font getFont(int face, int style, int size) { return new Font(face, style, size); }

    public int getFace() { return face; }
    public int getStyle() { return style; }
    public int getSize() { return size; }
    public boolean isBold() { return (style & STYLE_BOLD) != 0; }
    public boolean isItalic() { return (style & STYLE_ITALIC) != 0; }
    public boolean isPlain() { return style == STYLE_PLAIN; }

    public int getHeight() {
        Paint.FontMetricsInt fm = metrics.getFontMetricsInt();
        return fm.descent - fm.ascent + fm.leading;
    }
    public int getBaselinePosition() { return -metrics.getFontMetricsInt().ascent; }
    public int stringWidth(String s) { return (int) Math.ceil(metrics.measureText(s)); }
    public int charWidth(char c) { return (int) Math.ceil(metrics.measureText(String.valueOf(c))); }
    public int charsWidth(char[] ch, int off, int len) { return (int) Math.ceil(metrics.measureText(new String(ch, off, len))); }
    public int substringWidth(String s, int off, int len) { return (int) Math.ceil(metrics.measureText(s, off, off + len)); }
}
