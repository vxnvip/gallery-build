package javax.microedition.lcdui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import java.util.HashMap;

/**
 * Hiển thị Canvas của MIDlet trên màn hình Android (co giãn vừa chiều ngang)
 * và vẽ phím ảo: D-pad, OK, hai phím mềm.
 */
public class MidpView extends View {
    private static final int UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3, FIRE = 4, LSK = 5, RSK = 6;
    private static final int[] CODES = {-1, -2, -3, -4, -5, -6, -7};
    private static final String[] LABELS = {"\u25B2", "\u25BC", "\u25C0", "\u25B6", "OK", "SK1", "SK2"};

    private final Bitmap screen = Bitmap.createBitmap(Display.WIDTH, Display.HEIGHT, Bitmap.Config.ARGB_8888);
    private final android.graphics.Canvas screenCanvas = new android.graphics.Canvas(screen);
    private final Paint screenPaint = new Paint();
    private final Paint btnPaint = new Paint();
    private final Paint textPaint = new Paint();
    private final RectF dest = new RectF();

    private final float[] bx = new float[7];
    private final float[] by = new float[7];
    private float btnR;
    private float scale = 1f;
    private final boolean[] down = new boolean[7];
    private final HashMap<Integer, Integer> pressed = new HashMap<Integer, Integer>();
    private final HashMap<Integer, Boolean> pointerInGame = new HashMap<Integer, Boolean>();

    public MidpView(Context ctx) {
        super(ctx);
        setFocusable(true);
        setFocusableInTouchMode(true);
        screenPaint.setFilterBitmap(true);
        btnPaint.setAntiAlias(true);
        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        Display.setRepaintHook(new Runnable() {
            public void run() { postInvalidate(); }
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        float padH = h * 0.30f;
        scale = Math.min(w / (float) Display.WIDTH, (h - padH) / (float) Display.HEIGHT);
        float gw = Display.WIDTH * scale, gh = Display.HEIGHT * scale;
        float gx = (w - gw) / 2f;
        dest.set(gx, 0, gx + gw, gh);
        float areaTop = gh;
        float areaH = h - areaTop;
        float cx = w / 2f, cy = areaTop + areaH * 0.52f;
        float r = Math.min(areaH * 0.30f, w * 0.20f);
        btnR = r * 0.55f;
        bx[UP] = cx; by[UP] = cy - r;
        bx[DOWN] = cx; by[DOWN] = cy + r;
        bx[LEFT] = cx - r; by[LEFT] = cy;
        bx[RIGHT] = cx + r; by[RIGHT] = cy;
        bx[FIRE] = cx; by[FIRE] = cy;
        bx[LSK] = w * 0.13f; by[LSK] = cy;
        bx[RSK] = w * 0.87f; by[RSK] = cy;
        textPaint.setTextSize(btnR * 0.7f);
    }

    @Override
    protected void onDraw(android.graphics.Canvas canvas) {
        canvas.drawColor(Color.BLACK);
        Displayable d = Display.current;
        screenCanvas.drawColor(Color.BLACK);
        if (d instanceof Canvas) {
            Graphics g = new Graphics(screenCanvas, Display.WIDTH, Display.HEIGHT);
            try {
                ((Canvas) d).paint(g);
            } catch (RuntimeException e) {
                android.util.Log.e("DayHop", "paint loi", e);
            }
        }
        canvas.drawBitmap(screen, null, dest, screenPaint);
        for (int i = 0; i < 7; i++) {
            btnPaint.setStyle(Paint.Style.FILL);
            btnPaint.setColor(down[i] ? 0xCC5599FF : 0x66FFFFFF);
            canvas.drawCircle(bx[i], by[i], btnR, btnPaint);
            canvas.drawText(LABELS[i], bx[i], by[i] + btnR * 0.25f, textPaint);
        }
    }

    // ---- gửi phím tới Canvas của game ----
    private void sendKey(boolean press, int code) {
        Displayable d = Display.current;
        if (d instanceof Canvas) {
            if (press) ((Canvas) d).keyPressed(code); else ((Canvas) d).keyReleased(code);
        }
    }

    /** Bấm nhả nhanh một phím (dùng cho nút Back). */
    public void tapKey(final int code) {
        sendKey(true, code);
        postDelayed(new Runnable() {
            public void run() { sendKey(false, code); }
        }, 80);
    }

    private int hit(float x, float y) {
        int best = -1;
        float bestD = btnR * btnR * 1.2f;
        for (int i = 0; i < 7; i++) {
            float dx = x - bx[i], dy = y - by[i];
            float dd = dx * dx + dy * dy;
            if (dd <= bestD) { bestD = dd; best = i; }
        }
        return best;
    }

    private void press(int id, float x, float y) {
        int b = hit(x, y);
        if (b >= 0) {
            pressed.put(id, b);
            down[b] = true;
            sendKey(true, CODES[b]);
            invalidate();
        } else if (dest.contains(x, y)) {
            pointerInGame.put(id, true);
            Displayable d = Display.current;
            if (d instanceof Canvas) ((Canvas) d).pointerPressed((int) ((x - dest.left) / scale), (int) (y / scale));
        }
    }

    private void release(int id, float x, float y) {
        Integer b = pressed.remove(id);
        if (b != null) {
            down[b] = false;
            sendKey(false, CODES[b]);
            invalidate();
        } else if (pointerInGame.remove(id) != null) {
            Displayable d = Display.current;
            if (d instanceof Canvas) ((Canvas) d).pointerReleased((int) ((x - dest.left) / scale), (int) (y / scale));
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                press(e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                release(e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                for (Integer id : new java.util.ArrayList<Integer>(pressed.keySet())) release(id, 0, 0);
                break;
            default:
                break;
        }
        return true;
    }

    // ---- bàn phím cứng ----
    private static int mapKey(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP: return -1;
            case KeyEvent.KEYCODE_DPAD_DOWN: return -2;
            case KeyEvent.KEYCODE_DPAD_LEFT: return -3;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return -4;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER: return -5;
            case KeyEvent.KEYCODE_MENU: return -6;
            case KeyEvent.KEYCODE_STAR: return 42;
            case KeyEvent.KEYCODE_POUND: return 35;
            default:
                if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) return 48 + (k - KeyEvent.KEYCODE_0);
                return 0;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent ev) {
        int c = mapKey(keyCode);
        if (c == 0) return super.onKeyDown(keyCode, ev);
        if (ev.getRepeatCount() == 0) sendKey(true, c);
        return true;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent ev) {
        int c = mapKey(keyCode);
        if (c == 0) return super.onKeyUp(keyCode, ev);
        sendKey(false, c);
        return true;
    }
}
