package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;

public class Graphics {
    public static final int HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64;
    public static final int SOLID = 0, DOTTED = 1;

    private final android.graphics.Canvas c;
    private final Paint p = new Paint();
    private final Rect srcRect = new Rect();
    private final Rect dstRect = new Rect();
    private final RectF rectF = new RectF();
    private Font font = Font.getDefaultFont();
    private int color;
    private int tx, ty;
    private int clipX, clipY, clipW, clipH;
    private int base;
    private int stroke = SOLID;

    Graphics(android.graphics.Canvas canvas, int w, int h) {
        c = canvas;
        clipX = 0; clipY = 0; clipW = w; clipH = h;
        c.clipRect(0, 0, w, h);
        base = c.save();
        setColor(0);
    }

    // ---- màu / font ----
    public void setColor(int rgb) { color = rgb & 0xFFFFFF; }
    public void setColor(int r, int g, int b) { color = ((r & 255) << 16) | ((g & 255) << 8) | (b & 255); }
    public int getColor() { return color; }
    public int getRedComponent() { return (color >> 16) & 255; }
    public int getGreenComponent() { return (color >> 8) & 255; }
    public int getBlueComponent() { return color & 255; }
    public void setFont(Font f) { font = f == null ? Font.getDefaultFont() : f; }
    public Font getFont() { return font; }
    public void setStrokeStyle(int s) { stroke = s; }
    public int getStrokeStyle() { return stroke; }

    private void shapePaint(boolean fill) {
        p.setAntiAlias(false);
        p.setStyle(fill ? Paint.Style.FILL : Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0xFF000000 | color);
    }

    // ---- clip / translate ----
    public void translate(int x, int y) {
        tx += x; ty += y;
        clipX -= x; clipY -= y;
    }
    public int getTranslateX() { return tx; }
    public int getTranslateY() { return ty; }

    public void setClip(int x, int y, int w, int h) {
        c.restoreToCount(base);
        base = c.save();
        clipX = x; clipY = y; clipW = w; clipH = h;
        c.clipRect(x + tx, y + ty, x + tx + w, y + ty + h);
    }

    public void clipRect(int x, int y, int w, int h) {
        int nx = Math.max(clipX, x), ny = Math.max(clipY, y);
        int nr = Math.min(clipX + clipW, x + w), nb = Math.min(clipY + clipH, y + h);
        clipX = nx; clipY = ny;
        clipW = Math.max(0, nr - nx); clipH = Math.max(0, nb - ny);
        c.clipRect(x + tx, y + ty, x + tx + w, y + ty + h);
    }

    public int getClipX() { return clipX; }
    public int getClipY() { return clipY; }
    public int getClipWidth() { return clipW; }
    public int getClipHeight() { return clipH; }

    // ---- hình ----
    public void fillRect(int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return;
        shapePaint(true);
        c.drawRect(x + tx, y + ty, x + tx + w, y + ty + h, p);
    }

    public void drawRect(int x, int y, int w, int h) {
        if (w < 0 || h < 0) return;
        shapePaint(false);
        c.drawRect(x + tx + 0.5f, y + ty + 0.5f, x + tx + w + 0.5f, y + ty + h + 0.5f, p);
    }

    public void drawLine(int x1, int y1, int x2, int y2) {
        shapePaint(false);
        c.drawLine(x1 + tx + 0.5f, y1 + ty + 0.5f, x2 + tx + 0.5f, y2 + ty + 0.5f, p);
    }

    public void fillRoundRect(int x, int y, int w, int h, int aw, int ah) {
        shapePaint(true);
        p.setAntiAlias(true);
        rectF.set(x + tx, y + ty, x + tx + w, y + ty + h);
        c.drawRoundRect(rectF, aw / 2f, ah / 2f, p);
    }

    public void drawRoundRect(int x, int y, int w, int h, int aw, int ah) {
        shapePaint(false);
        p.setAntiAlias(true);
        rectF.set(x + tx + 0.5f, y + ty + 0.5f, x + tx + w + 0.5f, y + ty + h + 0.5f);
        c.drawRoundRect(rectF, aw / 2f, ah / 2f, p);
    }

    public void fillArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        shapePaint(true);
        p.setAntiAlias(true);
        rectF.set(x + tx, y + ty, x + tx + w, y + ty + h);
        c.drawArc(rectF, -startAngle, -arcAngle, true, p);
    }

    public void drawArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        shapePaint(false);
        p.setAntiAlias(true);
        rectF.set(x + tx, y + ty, x + tx + w, y + ty + h);
        c.drawArc(rectF, -startAngle, -arcAngle, false, p);
    }

    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
        shapePaint(true);
        Path path = new Path();
        path.moveTo(x1 + tx, y1 + ty);
        path.lineTo(x2 + tx, y2 + ty);
        path.lineTo(x3 + tx, y3 + ty);
        path.close();
        c.drawPath(path, p);
    }

    public void drawRGB(int[] rgb, int off, int scan, int x, int y, int w, int h, boolean alpha) {
        c.drawBitmap(rgb, off, scan, x + tx, y + ty, w, h, alpha, null);
    }

    // ---- chữ ----
    public void drawString(String s, int x, int y, int anchor) { drawText(s, 0, s.length(), x, y, anchor); }
    public void drawSubstring(String s, int off, int len, int x, int y, int anchor) { drawText(s, off, off + len, x, y, anchor); }
    public void drawChar(char ch, int x, int y, int anchor) { String s = String.valueOf(ch); drawText(s, 0, 1, x, y, anchor); }
    public void drawChars(char[] data, int off, int len, int x, int y, int anchor) {
        String s = new String(data, off, len);
        drawText(s, 0, s.length(), x, y, anchor);
    }

    private void drawText(String s, int start, int end, int x, int y, int anchor) {
        p.setStyle(Paint.Style.FILL);
        p.setAntiAlias(true);
        p.setColor(0xFF000000 | color);
        p.setTypeface(font.typeface);
        p.setTextSize(font.textSize);
        p.setUnderlineText(font.underline);
        float w = p.measureText(s, start, end);
        float bx = x + tx;
        if ((anchor & HCENTER) != 0) bx -= w / 2f;
        else if ((anchor & RIGHT) != 0) bx -= w;
        Paint.FontMetricsInt fm = p.getFontMetricsInt();
        float by;
        if ((anchor & BASELINE) != 0) by = y + ty;
        else if ((anchor & BOTTOM) != 0) by = y + ty - fm.descent;
        else by = y + ty - fm.ascent;
        c.drawText(s, start, end, bx, by, p);
        p.setUnderlineText(false);
    }

    // ---- ảnh ----
    public void drawImage(Image img, int x, int y, int anchor) {
        if (img == null) return;
        int w = img.getWidth(), h = img.getHeight();
        if ((anchor & HCENTER) != 0) x -= w / 2; else if ((anchor & RIGHT) != 0) x -= w;
        if ((anchor & VCENTER) != 0) y -= h / 2; else if ((anchor & BOTTOM) != 0) y -= h;
        c.drawBitmap(img.bmp, x + tx, y + ty, null);
    }

    public void drawRegion(Image src, int xs, int ys, int w, int h, int transform, int xd, int yd, int anchor) {
        if (src == null || w <= 0 || h <= 0) return;
        if (transform == 0) {
            int dx = xd, dy = yd;
            if ((anchor & HCENTER) != 0) dx -= w / 2; else if ((anchor & RIGHT) != 0) dx -= w;
            if ((anchor & VCENTER) != 0) dy -= h / 2; else if ((anchor & BOTTOM) != 0) dy -= h;
            srcRect.set(xs, ys, xs + w, ys + h);
            dstRect.set(dx + tx, dy + ty, dx + tx + w, dy + ty + h);
            c.drawBitmap(src.bmp, srcRect, dstRect, null);
        } else {
            Image part = Image.createImage(src, xs, ys, w, h, transform);
            drawImage(part, xd, yd, anchor);
        }
    }
}
