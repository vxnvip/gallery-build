package javax.microedition.midlet;

import javax.microedition.io.ConnectionNotFoundException;

public abstract class MIDlet {
    /** Được Activity gán: chạy khi MIDlet gọi notifyDestroyed(). */
    public static volatile Runnable exitHook;

    protected MIDlet() {}

    protected abstract void startApp() throws MIDletStateChangeException;
    protected abstract void pauseApp();
    protected abstract void destroyApp(boolean unconditional) throws MIDletStateChangeException;

    public final void notifyDestroyed() {
        Runnable r = exitHook;
        if (r != null) r.run();
    }

    public final void notifyPaused() {}
    public final void resumeRequest() {}
    public final String getAppProperty(String key) { return null; }

    public final boolean platformRequest(String url) throws ConnectionNotFoundException {
        return false;
    }

    // Cầu nối cho Activity (startApp/pauseApp/destroyApp là protected)
    public final void internalStart() throws MIDletStateChangeException { startApp(); }
    public final void internalPause() { pauseApp(); }
    public final void internalDestroy() throws MIDletStateChangeException { destroyApp(true); }
}
