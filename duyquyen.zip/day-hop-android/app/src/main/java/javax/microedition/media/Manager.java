package javax.microedition.media;

import android.media.MediaPlayer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.microedition.media.control.VolumeControl;

public final class Manager {
    /** Được Activity gán (getCacheDir()). */
    public static volatile File cacheDir;

    private Manager() {}

    public static Player createPlayer(InputStream in, String type) throws IOException, MediaException {
        if (in == null) throw new IOException("stream null");
        File f = File.createTempFile("snd", ".mid", cacheDir);
        FileOutputStream out = new FileOutputStream(f);
        try {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            out.close();
        }
        return new AndroidPlayer(f);
    }

    public static Player createPlayer(String locator) throws IOException, MediaException {
        throw new MediaException("Khong ho tro locator: " + locator);
    }

    public static void playTone(int note, int duration, int volume) throws MediaException {}

    private static final class AndroidPlayer implements Player, VolumeControl {
        private final File file;
        private MediaPlayer mp;
        private int state = UNREALIZED;
        private int level = 100;
        private boolean loop;

        AndroidPlayer(File f) { file = f; }

        public synchronized void realize() throws MediaException {
            if (mp != null) return;
            try {
                mp = new MediaPlayer();
                mp.setDataSource(file.getAbsolutePath());
                state = REALIZED;
            } catch (Exception e) {
                throw new MediaException(String.valueOf(e.getMessage()));
            }
        }

        public synchronized void prefetch() throws MediaException {
            realize();
            if (state >= PREFETCHED) return;
            try {
                mp.prepare();
                mp.setLooping(loop);
                applyVolume();
                state = PREFETCHED;
            } catch (Exception e) {
                throw new MediaException(String.valueOf(e.getMessage()));
            }
        }

        public synchronized void start() throws MediaException {
            prefetch();
            try {
                mp.start();
                state = STARTED;
            } catch (Exception e) {
                throw new MediaException(String.valueOf(e.getMessage()));
            }
        }

        public synchronized void stop() throws MediaException {
            if (mp != null && state == STARTED) {
                try { mp.pause(); } catch (Exception ignored) { }
                state = PREFETCHED;
            }
        }

        public synchronized void deallocate() {
            try { stop(); } catch (MediaException ignored) { }
        }

        public synchronized void close() {
            if (mp != null) {
                try { mp.release(); } catch (Exception ignored) { }
                mp = null;
            }
            file.delete();
            state = CLOSED;
        }

        public synchronized int getState() { return state; }

        public synchronized void setLoopCount(int count) {
            loop = (count == -1 || count > 1);
            if (mp != null) {
                try { mp.setLooping(loop); } catch (Exception ignored) { }
            }
        }

        public void addPlayerListener(PlayerListener l) {}
        public void removePlayerListener(PlayerListener l) {}

        public synchronized long setMediaTime(long now) throws MediaException {
            if (mp != null) {
                try { mp.seekTo((int) (now / 1000)); } catch (Exception ignored) { }
            }
            return now;
        }

        public synchronized long getMediaTime() {
            try { return mp == null ? TIME_UNKNOWN : mp.getCurrentPosition() * 1000L; }
            catch (Exception e) { return TIME_UNKNOWN; }
        }

        public synchronized long getDuration() {
            try { return mp == null ? TIME_UNKNOWN : mp.getDuration() * 1000L; }
            catch (Exception e) { return TIME_UNKNOWN; }
        }

        public Control getControl(String type) {
            if (type != null && type.endsWith("VolumeControl")) return this;
            return null;
        }

        public Control[] getControls() { return new Control[] { this }; }

        // VolumeControl
        private void applyVolume() {
            if (mp != null) {
                float v = level / 100f;
                try { mp.setVolume(v, v); } catch (Exception ignored) { }
            }
        }

        public synchronized void setMute(boolean mute) {
            if (mp != null) {
                float v = mute ? 0f : level / 100f;
                try { mp.setVolume(v, v); } catch (Exception ignored) { }
            }
        }

        public boolean isMuted() { return false; }

        public synchronized int setLevel(int l) {
            level = Math.max(0, Math.min(100, l));
            applyVolume();
            return level;
        }

        public int getLevel() { return level; }
    }
}
