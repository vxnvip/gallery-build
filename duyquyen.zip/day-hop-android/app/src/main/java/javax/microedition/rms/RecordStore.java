package javax.microedition.rms;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/** RMS đơn giản: mỗi store là một file trong thư mục dữ liệu của app. */
public class RecordStore {
    /** Được Activity gán (getFilesDir()). */
    public static volatile File dir;

    private static final HashMap<String, RecordStore> OPEN = new HashMap<String, RecordStore>();

    private final String name;
    private final TreeMap<Integer, byte[]> recs = new TreeMap<Integer, byte[]>();
    private int nextId = 1;
    private int refs = 0;
    private boolean closed = false;

    private RecordStore(String name) { this.name = name; }

    private static File fileOf(String name) { return new File(dir, "rms_" + name); }

    public static synchronized RecordStore openRecordStore(String name, boolean create)
            throws RecordStoreException, RecordStoreFullException, RecordStoreNotFoundException {
        RecordStore rs = OPEN.get(name);
        if (rs == null) {
            File f = fileOf(name);
            if (!f.exists() && !create) throw new RecordStoreNotFoundException(name);
            rs = new RecordStore(name);
            if (f.exists()) rs.load(f);
            OPEN.put(name, rs);
        }
        rs.refs++;
        rs.closed = false;
        return rs;
    }

    public static synchronized void deleteRecordStore(String name)
            throws RecordStoreException, RecordStoreNotFoundException {
        File f = fileOf(name);
        if (!f.exists()) throw new RecordStoreNotFoundException(name);
        OPEN.remove(name);
        f.delete();
    }

    public static synchronized String[] listRecordStores() {
        File[] fs = dir == null ? null : dir.listFiles();
        if (fs == null) return null;
        ArrayList<String> out = new ArrayList<String>();
        for (File f : fs) if (f.getName().startsWith("rms_")) out.add(f.getName().substring(4));
        return out.isEmpty() ? null : out.toArray(new String[0]);
    }

    private void load(File f) throws RecordStoreException {
        try {
            DataInputStream in = new DataInputStream(new FileInputStream(f));
            try {
                nextId = in.readInt();
                int n = in.readInt();
                for (int i = 0; i < n; i++) {
                    int id = in.readInt();
                    byte[] b = new byte[in.readInt()];
                    in.readFully(b);
                    recs.put(id, b);
                }
            } finally {
                in.close();
            }
        } catch (IOException e) {
            throw new RecordStoreException(e.getMessage());
        }
    }

    private void save() throws RecordStoreException {
        try {
            DataOutputStream out = new DataOutputStream(new FileOutputStream(fileOf(name)));
            try {
                out.writeInt(nextId);
                out.writeInt(recs.size());
                for (Map.Entry<Integer, byte[]> e : recs.entrySet()) {
                    out.writeInt(e.getKey());
                    out.writeInt(e.getValue().length);
                    out.write(e.getValue());
                }
            } finally {
                out.close();
            }
        } catch (IOException e) {
            throw new RecordStoreException(e.getMessage());
        }
    }

    private void checkOpen() throws RecordStoreNotOpenException {
        if (closed) throw new RecordStoreNotOpenException(name);
    }

    public synchronized void closeRecordStore() throws RecordStoreNotOpenException, RecordStoreException {
        checkOpen();
        if (--refs <= 0) {
            closed = true;
            synchronized (RecordStore.class) { OPEN.remove(name); }
        }
    }

    public synchronized int getNumRecords() throws RecordStoreNotOpenException {
        checkOpen();
        return recs.size();
    }

    public synchronized int getNextRecordID() throws RecordStoreNotOpenException, RecordStoreException {
        checkOpen();
        return nextId;
    }

    public synchronized int addRecord(byte[] data, int off, int len)
            throws RecordStoreNotOpenException, RecordStoreException, RecordStoreFullException {
        checkOpen();
        byte[] b = new byte[len];
        if (data != null) System.arraycopy(data, off, b, 0, len);
        int id = nextId++;
        recs.put(id, b);
        save();
        return id;
    }

    public synchronized void setRecord(int id, byte[] data, int off, int len)
            throws RecordStoreNotOpenException, InvalidRecordIDException, RecordStoreException, RecordStoreFullException {
        checkOpen();
        if (!recs.containsKey(id)) throw new InvalidRecordIDException("id " + id);
        byte[] b = new byte[len];
        if (data != null) System.arraycopy(data, off, b, 0, len);
        recs.put(id, b);
        save();
    }

    public synchronized byte[] getRecord(int id)
            throws RecordStoreNotOpenException, InvalidRecordIDException, RecordStoreException {
        checkOpen();
        byte[] b = recs.get(id);
        if (b == null) throw new InvalidRecordIDException("id " + id);
        byte[] c = new byte[b.length];
        System.arraycopy(b, 0, c, 0, b.length);
        return c;
    }

    public synchronized int getRecord(int id, byte[] buf, int off)
            throws RecordStoreNotOpenException, InvalidRecordIDException, RecordStoreException {
        byte[] b = getRecord(id);
        System.arraycopy(b, 0, buf, off, b.length);
        return b.length;
    }

    public synchronized int getRecordSize(int id)
            throws RecordStoreNotOpenException, InvalidRecordIDException, RecordStoreException {
        return getRecord(id).length;
    }

    public synchronized void deleteRecord(int id)
            throws RecordStoreNotOpenException, InvalidRecordIDException, RecordStoreException {
        checkOpen();
        if (recs.remove(id) == null) throw new InvalidRecordIDException("id " + id);
        save();
    }
}
