# Đẩy hộp – APK độc lập

Game Sokoban J2ME dựng lại từ APK cũ (Netmite AndME), nay chạy độc lập trên Android bằng lớp giả lập `javax.microedition` tự viết (thư mục `app/src/main/java/javax/microedition`).

## Build trên GitHub
1. Push cả thư mục này lên repo.
2. Thêm secret `DEBUG_KEYSTORE_B64` (keystore debug cố định, base64).
3. Tab **Actions** → **Build APK** → **Run workflow** → tải artifact `DayHop-debug-apk`.

Bước `Verify APK signature` so khớp SHA-256 `322a8179607bd784…` của key cũ. Dùng key khác thì sửa hoặc xoá bước đó.

## Điều khiển
- Phím ảo dưới màn hình: ▲ ▼ ◀ ▶, OK, SK1 (phím mềm trái), SK2 (phím mềm phải).
- Nút Back của Android = SK2.
- Bàn phím cứng/D-pad: dùng được.
- Chạm vào vùng game: gửi thành `pointerPressed`.

## Cấu trúc
- `app/src/main/java/com/bf`, `com/a`: code game (dịch ngược bằng jadx, đã sửa tay để biên dịch được; tên vẫn bị obfuscate)
- `app/src/main/resources`: ảnh, nhạc MIDI (nạp bằng `getResourceAsStream`)
- `app/src/main/java/javax/microedition`: lớp giả lập Canvas, Graphics, Image, Font, RecordStore, MediaPlayer…
- `com/bf/dayhop/MainActivity.java`: khởi động MIDlet, phím ảo

## Ghi chú
- Màn hình ảo 240x320, tự co giãn vừa chiều ngang (đổi trong `Display.java`).
- Chưa được thử trên máy thật.
