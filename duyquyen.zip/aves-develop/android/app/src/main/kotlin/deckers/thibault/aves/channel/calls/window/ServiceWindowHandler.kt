package deckers.thibault.aves.channel.calls.window

import android.app.Service
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class ServiceWindowHandler(service: Service) : WindowHandler(service) {
    override fun isActivity(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun keepScreenOn(call: MethodCall, result: MethodChannel.Result) {
        result.success(null)
    }

    override fun secureScreen(call: MethodCall, result: MethodChannel.Result) {
        result.success(null)
    }

    override fun isCrossWindowBlurEnabled(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun isInMultiWindowMode(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun isInPictureInPictureMode(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun getOrientation(call: MethodCall, result: MethodChannel.Result) {
        result.success(0)
    }

    override fun requestOrientation(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun isCutoutAware(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun getCutoutInsets(call: MethodCall, result: MethodChannel.Result) {
        result.success(HashMap<String, Any>())
    }

    override fun supportsWideGamut(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun supportsHdr(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun isInWideColorGamutMode(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun isInHdrMode(call: MethodCall, result: MethodChannel.Result) {
        result.success(false)
    }

    override fun getDisplayHdrSdrRatio(call: MethodCall, result: MethodChannel.Result) {
        result.success(0)
    }

    override fun getDesiredHdrHeadroom(call: MethodCall, result: MethodChannel.Result) {
        result.success(0)
    }

    override fun setColorMode(call: MethodCall, result: MethodChannel.Result) {
        result.success(null)
    }

    override fun startGlobalDrag(call: MethodCall, result: MethodChannel.Result) {
        result.success(null)
    }
}