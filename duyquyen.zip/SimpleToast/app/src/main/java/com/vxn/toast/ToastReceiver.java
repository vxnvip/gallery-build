package com.vxn.toast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class ToastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        final String text = intent.getStringExtra("text");
        if (text == null || text.isEmpty()) return;

        final int duration = intent.getBooleanExtra("long", false)
                ? Toast.LENGTH_LONG
                : Toast.LENGTH_SHORT;

        final Context app = context.getApplicationContext();

        // Toast mặc định hiện ở giữa phía dưới màn hình
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(app, text, duration).show();
            }
        });
    }
}
