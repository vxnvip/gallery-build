package com.vxn.toast;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView tv = new TextView(this);
        tv.setPadding(48, 96, 48, 48);
        tv.setTextSize(16);
        tv.setText("SimpleToast đã sẵn sàng.\n\n"
                + "Gửi từ Termux:\n"
                + "am broadcast -n com.vxn.toast/.ToastReceiver "
                + "-a com.vxn.TOAST --es text \"Xin chào\"");
        setContentView(tv);

        Toast.makeText(this, "SimpleToast OK", Toast.LENGTH_SHORT).show();
    }
}
