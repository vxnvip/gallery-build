# BlueWAP Server (Android)

Build bang GitHub Actions (Gradle 8.10.2, JDK 17, android-35) hoac mo bang Android Studio. Khong co thu vien ngoai. Dung Groovy DSL (settings.gradle) de workflow tim duoc.

## Dung
1. Mo app -> "1. Allow display over other apps" (de WebView render ngam).
2. "2. Disable battery optimization" (de khong bi he thong giet khi tat man hinh).
3. Bluetooth: ghep doi (pair) dien thoai jar voi dien thoai Android truoc.
4. Bam Start. Tren may jar: "Search Bluetooth devices" hoac "Wi-Fi/TCP" nhap `ip:8765`.
5. Dang nhap Facebook mot lan; cookie luu trong WebView. Nut "Clear cookies" de dang xuat.

## Cach hoat dong
- `RemoteService`: foreground service, mo cong TCP 8765 va dich vu Bluetooth SPP (UUID trong `Proto.kt`).
- `BrowserHost`: WebView gan vao cua so overlay dat ngoai man hinh, render rong `cssWidth*density`
  roi thu nho ve kich thuoc man hinh jar; chia o 64x64, chi gui o thay doi (JPEG).
  Nut Zoom doi `cssWidth` (240..520).
- `Session`: doc goi tin theo giao thuc trong README cua jar.

## Luu y bao mat
- Cong TCP khong co mat khau: ai cung mang Wi-Fi deu dieu khien duoc phien da dang nhap cua ban.
  Chi bat khi o mang tin cay (hoac dung hotspot cua chinh dien thoai Android). Tat o muc "Wi-Fi / TCP" neu chi dung Bluetooth.
- Bluetooth dung socket co xac thuc (can pair).

## Gioi han da biet / chua test
- Chua compile va chua chay tren may that.
- Mot so may/hang kill service du da tat toi uu pin.
- Video/am thanh khong co. Facebook co the hoi xac minh dang nhap.
