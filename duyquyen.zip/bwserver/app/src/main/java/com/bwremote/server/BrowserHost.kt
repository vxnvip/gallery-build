package com.bwremote.server

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.View.MeasureSpec
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Giu mot WebView that, ve ra Bitmap theo kich thuoc man hinh jar, gui ve cac o thay doi.
 * Moi thao tac WebView deu chay tren luong chinh.
 */
@SuppressLint("SetJavaScriptEnabled")
class BrowserHost(private val ctx: Context, private val home: () -> String) {

    private val main = Handler(Looper.getMainLooper())
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val enc = Executors.newSingleThreadExecutor()
    private val density = ctx.resources.displayMetrics.density
    private val cssWidths = intArrayOf(240, 300, 360, 440, 520)
    private val tile = 64

    private var web: WebView? = null
    private var attached = false
    private var lp: WindowManager.LayoutParams? = null

    @Volatile private var session: Session? = null
    private var jw = 240
    private var jh = 320
    private var quality = 3
    private var zoomIdx = 2
    private var renderW = 0
    private var renderH = 0
    private var scale = 1f
    private var title = ""
    private var curUrl = ""
    private var loading = false
    private var looping = false
    private var activeUntil = 0L
    @Volatile private var busy = false
    private var hotUntil = 0L
    private var fullBmp: Bitmap? = null
    @Volatile private var prev: IntArray? = null

    // ---------- phien ----------
    fun attach(s: Session?) {
        main.post {
            session = s
            prev = null
            if (s != null) {
                ensureWeb()
                web?.onResume()
                web?.resumeTimers()
                sendMeta()
                poke(3000)
            } else {
                web?.onPause()
            }
        }
    }

    fun destroy() {
        main.post {
            web?.let {
                try { if (attached) wm.removeView(it) } catch (e: Exception) { }
                CookieManager.getInstance().flush()
                it.destroy()
            }
            fullBmp?.recycle()
            fullBmp = null
            web = null
            attached = false
            enc.shutdown()
        }
    }

    // ---------- WebView ----------
    private fun ensureWeb() {
        if (web != null) return
        val w = WebView(ctx)
        w.visibility = View.VISIBLE
        w.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        val st = w.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.useWideViewPort = true
        st.loadWithOverviewMode = false
        st.setSupportZoom(false)
        st.builtInZoomControls = false
        st.mediaPlaybackRequiresUserGesture = true
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val sc = req?.url?.scheme
                return sc != "http" && sc != "https" && sc != "about"
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                loading = true
                curUrl = url ?: ""
                sendAsync(Proto.S_URL, curUrl.toByteArray())
                sendAsync(Proto.S_LOADING, byteArrayOf(1))
                poke(1000)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                loading = false
                curUrl = url ?: ""
                sendAsync(Proto.S_URL, curUrl.toByteArray())
                sendAsync(Proto.S_LOADING, byteArrayOf(0))
                CookieManager.getInstance().flush()
                poke(2500)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, t: String?) {
                title = t ?: ""
                sendAsync(Proto.S_TITLE, title.toByteArray())
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                poke(800)
            }
        }
        web = w
        applyLayout()
        w.loadUrl(normalize(home()))
    }

    private fun applyLayout() {
        val w = web ?: return
        renderW = (cssWidths[zoomIdx] * density).toInt().coerceAtLeast(100)
        scale = renderW / jw.toFloat()
        renderH = (jh * scale).toInt().coerceAtLeast(100)
        if (!attached) attached = tryAttach(w)
        val p = lp
        if (attached && p != null) {
            p.width = renderW
            p.height = renderH
            p.x = 0
            try { wm.updateViewLayout(w, p) } catch (e: Exception) { }
        } else {
            w.measure(
                MeasureSpec.makeMeasureSpec(renderW, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(renderH, MeasureSpec.EXACTLY)
            )
            w.layout(0, 0, renderW, renderH)
        }
    }

    @Suppress("DEPRECATION")
    private fun tryAttach(w: WebView): Boolean {
        return try {
            if (!Settings.canDrawOverlays(ctx)) return false
            val type = if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            val p = WindowManager.LayoutParams(renderW, renderH, type, flags, PixelFormat.TRANSLUCENT)
            p.gravity = Gravity.TOP or Gravity.START
            p.x = 0
            p.y = 0
            p.alpha = 0.01f
            wm.addView(w, p)
            lp = p
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- lenh tu jar ----------
    fun hello(w: Int, h: Int, q: Int) {
        main.post {
            jw = w.coerceIn(32, 1024)
            jh = h.coerceIn(32, 1024)
            quality = q.coerceIn(0, 4)
            prev = null
            applyLayout()
            poke(1500)
        }
    }

    fun click(x: Int, y: Int) {
        main.post {
            val w = web ?: return@post
            val px = x * scale
            val py = y * scale
            val t = SystemClock.uptimeMillis()
            val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, px, py, 0)
            down.source = InputDevice.SOURCE_TOUCHSCREEN
            w.dispatchTouchEvent(down)
            down.recycle()
            main.postDelayed({
                val up = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, px, py, 0)
                up.source = InputDevice.SOURCE_TOUCHSCREEN
                w.dispatchTouchEvent(up)
                up.recycle()
                hotUntil = SystemClock.uptimeMillis() + 1200
                poke(2500)
            }, 60)
        }
    }

    fun scroll(dx: Int, dy: Int) {
        main.post {
            web?.scrollBy((dx * scale).toInt(), (dy * scale).toInt())
            hotUntil = SystemClock.uptimeMillis() + 1200
            poke(1500)
        }
    }

    fun text(s: String) {
        main.post {
            js(INSERT_JS.replace("__T__", JSONObject.quote(s)))
            poke(1500)
        }
    }

    fun key(code: Int) {
        main.post {
            when (code) {
                1 -> js(BACKSPACE_JS)
                2 -> js(ENTER_JS)
                3 -> {
                    web?.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_TAB))
                    web?.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_TAB))
                }
            }
            poke(2000)
        }
    }

    fun nav(code: Int) {
        main.post {
            val w = web ?: return@post
            when (code) {
                1 -> if (w.canGoBack()) w.goBack()
                2 -> if (w.canGoForward()) w.goForward()
                3 -> w.reload()
                4 -> w.loadUrl(normalize(home()))
                5 -> w.stopLoading()
                6 -> { if (zoomIdx > 0) { zoomIdx--; applyLayout(); prev = null } }
                7 -> { if (zoomIdx < cssWidths.size - 1) { zoomIdx++; applyLayout(); prev = null } }
            }
            poke(3000)
        }
    }

    fun url(s: String) {
        main.post {
            web?.loadUrl(normalize(s))
            poke(3000)
        }
    }

    private fun js(code: String) {
        web?.evaluateJavascript(code, null)
    }

    private fun normalize(s0: String): String {
        val s = s0.trim()
        if (s.isEmpty()) return "about:blank"
        if (s.startsWith("http://") || s.startsWith("https://") || s.startsWith("about:")) return s
        if (!s.contains(' ') && (s.contains('.') || s.startsWith("localhost"))) return "https://$s"
        return "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
    }

    // ---------- gui du lieu ----------
    private fun sendAsync(type: Int, data: ByteArray) {
        val s = session ?: return
        try { enc.execute { s.send(type, data) } } catch (e: Exception) { }
    }

    private fun sendMeta() {
        sendAsync(Proto.S_TITLE, title.toByteArray())
        sendAsync(Proto.S_URL, curUrl.toByteArray())
        sendAsync(Proto.S_LOADING, byteArrayOf(if (loading) 1 else 0))
    }

    private val tick = object : Runnable {
        override fun run() {
            if (session == null) { looping = false; return }
            captureTick()
            val now = SystemClock.uptimeMillis()
            if (now < activeUntil || loading) {
                val d = if (now < hotUntil) 50L else if (loading) 400L else 250L
                main.postDelayed(this, d)
            } else {
                looping = false
            }
        }
    }

    /** Bao hieu "co the co thay doi": chup khung hinh trong ms tiep theo. */
    private fun poke(ms: Long) {
        activeUntil = maxOf(activeUntil, SystemClock.uptimeMillis() + ms)
        if (!looping && session != null) {
            looping = true
            main.postDelayed(tick, 30)
        }
    }

    private fun captureTick() {
        val w = web ?: return
        val s = session ?: return
        if (busy) {
            activeUntil = maxOf(activeUntil, SystemClock.uptimeMillis() + 400)
            return
        }
        // Ve WebView o kich thuoc that (canvas khong scale) roi moi thu nho.
        // Ve thang vao canvas co scale lam WebView ra trang trang khi da cuon.
        val prevFull = fullBmp
        val fb: Bitmap
        if (prevFull != null && prevFull.width == renderW && prevFull.height == renderH) {
            fb = prevFull
        } else {
            prevFull?.recycle()
            fb = try {
                Bitmap.createBitmap(renderW, renderH, Bitmap.Config.ARGB_8888)
            } catch (e: OutOfMemoryError) {
                fullBmp = null
                return
            }
            fullBmp = fb
        }
        val c = Canvas(fb)
        c.drawColor(Color.WHITE)
        // View.draw() truc tiep khong tu tru offset cuon (viec nay do ViewGroup cha lam khi ve con).
        // WebView lai tu cong offset do khi ve, nen phai tru truoc, neu khong noi dung bi lech
        // xuong duoi bang dung luong da cuon va hinh bi trang.
        c.translate(-w.scrollX.toFloat(), -w.scrollY.toFloat())
        try {
            w.invalidate()
            w.draw(c)
        } catch (e: Exception) {
            return
        }
        val bmp = downscale(fb, jw, jh) ?: return
        busy = true
        val q = JPEG_Q[quality]
        try {
            enc.execute {
                try { sendDiff(s, bmp, q) } catch (e: Exception) { } finally {
                    busy = false
                    bmp.recycle()
                }
            }
        } catch (e: Exception) {
            busy = false
        }
    }

    /** Thu nho bang cach chia doi lien tiep de chu khong bi rang cua. */
    private fun downscale(src: Bitmap, tw: Int, th: Int): Bitmap? {
        return try {
            var cur = src
            var owned = false
            while (cur.width / 2 >= tw && cur.height / 2 >= th) {
                val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
                if (owned) cur.recycle()
                cur = n
                owned = true
            }
            var out = if (cur.width == tw && cur.height == th) cur
            else Bitmap.createScaledBitmap(cur, tw, th, true)
            if (owned && out !== cur) cur.recycle()
            if (out === src) out = src.copy(Bitmap.Config.ARGB_8888, false)
            out
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    private fun sendDiff(s: Session, bmp: Bitmap, q: Int) {
        val bw = bmp.width
        val bh = bmp.height
        val px = IntArray(bw * bh)
        bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
        // Muc thap: chuyen xam (va giam so muc xam) de JPEG nho hon nhieu qua Bluetooth.
        val lvl = LEVELS[quality]
        var pb: Bitmap? = null
        var src = bmp
        if (GRAY[quality]) {
            for (i in px.indices) {
                val c = px[i]
                var g = (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 151 + (c and 255) * 28) shr 8
                if (lvl > 1) g = ((g * (lvl - 1) + 127) / 255) * 255 / (lvl - 1)
                px[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
            }
            pb = Bitmap.createBitmap(px, bw, bh, Bitmap.Config.ARGB_8888)
            src = pb
        }
        val tw = (bw + tile - 1) / tile
        val th = (bh + tile - 1) / tile
        val hs = IntArray(tw * th)
        for (ty in 0 until th) {
            for (tx in 0 until tw) {
                var hash = 17
                val x0 = tx * tile
                val x1 = minOf(bw, x0 + tile)
                val y0 = ty * tile
                val y1 = minOf(bh, y0 + tile)
                for (y in y0 until y1) {
                    var i = y * bw + x0
                    for (x in x0 until x1) {
                        hash = hash * 31 + px[i]
                        i++
                    }
                }
                hs[ty * tw + tx] = hash
            }
        }
        val old = prev
        val same = old != null && old.size == hs.size
        val changed = ArrayList<Int>()
        if (same) {
            for (i in hs.indices) if (hs[i] != old!![i]) changed.add(i)
            if (changed.isEmpty()) { pb?.recycle(); return }
        }
        if (!same || changed.size * 2 > hs.size) {
            s.send(Proto.S_FULL, jpeg(src, q))
        } else {
            for (i in changed) {
                val x = (i % tw) * tile
                val y = (i / tw) * tile
                val cw = minOf(tile, bw - x)
                val ch = minOf(tile, bh - y)
                val t = Bitmap.createBitmap(src, x, y, cw, ch)
                val j = jpeg(t, q)
                t.recycle()
                val out = ByteArray(4 + j.size)
                out[0] = (x shr 8).toByte()
                out[1] = x.toByte()
                out[2] = (y shr 8).toByte()
                out[3] = y.toByte()
                System.arraycopy(j, 0, out, 4, j.size)
                s.send(Proto.S_TILE, out)
            }
        }
        prev = hs
        pb?.recycle()
    }

    private fun jpeg(b: Bitmap, q: Int): ByteArray {
        val bo = ByteArrayOutputStream(8192)
        b.compress(Bitmap.CompressFormat.JPEG, q, bo)
        return bo.toByteArray()
    }

    companion object {
        // Muc chat luong 0..4: sieu thap, rat thap, thap, vua, cao
        private val JPEG_Q = intArrayOf(18, 25, 30, 55, 80)
        private val GRAY = booleanArrayOf(true, true, false, false, false)
        private val LEVELS = intArrayOf(4, 0, 0, 0, 0) // so muc xam (0 = khong giam)

        private const val INSERT_JS = """
(function(t){var e=document.activeElement;if(!e)return;
if(e.isContentEditable){document.execCommand('insertText',false,t);return;}
var P=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
var d=Object.getOwnPropertyDescriptor(P,'value');if(!d||!d.set)return;
var v=e.value||'',s=e.selectionStart,n=e.selectionEnd;
if(s==null){s=n=v.length;}
d.set.call(e,v.slice(0,s)+t+v.slice(n));
try{e.selectionStart=e.selectionEnd=s+t.length;}catch(x){}
e.dispatchEvent(new Event('input',{bubbles:true}));
})(__T__)"""

        private const val BACKSPACE_JS = """
(function(){var e=document.activeElement;if(!e)return;
if(e.isContentEditable){document.execCommand('delete');return;}
var P=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
var d=Object.getOwnPropertyDescriptor(P,'value');if(!d||!d.set)return;
var v=e.value||'',s=e.selectionStart,n=e.selectionEnd;
if(s==null){s=n=v.length;}
if(s===n){if(s===0)return;s=s-1;}
d.set.call(e,v.slice(0,s)+v.slice(n));
try{e.selectionStart=e.selectionEnd=s;}catch(x){}
e.dispatchEvent(new Event('input',{bubbles:true}));
})()"""

        private const val ENTER_JS = """
(function(){var e=document.activeElement;if(!e)return;
var o={key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true};
var ok=e.dispatchEvent(new KeyboardEvent('keydown',o));
e.dispatchEvent(new KeyboardEvent('keypress',o));
e.dispatchEvent(new KeyboardEvent('keyup',o));
if(ok&&e.tagName==='INPUT'&&e.form){if(e.form.requestSubmit)e.form.requestSubmit();else e.form.submit();}
else if(ok&&e.isContentEditable){document.execCommand('insertParagraph');}
})()"""
    }
}
