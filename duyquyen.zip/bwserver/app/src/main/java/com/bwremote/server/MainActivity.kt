package com.bwremote.server

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.webkit.CookieManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var cbBt: CheckBox
    private lateinit var cbTcp: CheckBox
    private lateinit var home: EditText
    private lateinit var startBtn: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)
        val root = ScrollView(this)
        root.addView(col)
        setContentView(root)

        status = TextView(this)
        col.addView(status)

        cbBt = CheckBox(this)
        cbBt.text = "Bluetooth (pair the old phone first)"
        cbBt.isChecked = prefs.getBoolean("bt", true)
        col.addView(cbBt)

        cbTcp = CheckBox(this)
        cbTcp.text = "Wi-Fi / TCP (anyone on the network can connect)"
        cbTcp.isChecked = prefs.getBoolean("tcp", true)
        col.addView(cbTcp)

        val lbl = TextView(this)
        lbl.text = "Home page"
        col.addView(lbl)
        home = EditText(this)
        home.setText(prefs.getString("home", Proto.DEFAULT_HOME))
        home.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        col.addView(home)

        startBtn = addBtn(col, "Start") { toggle() }
        addBtn(col, "1. Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        addBtn(col, "2. Disable battery optimization") {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
        addBtn(col, "3. Make Bluetooth discoverable (5 min)") {
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
            )
        }
        addBtn(col, "Clear cookies (log out)") {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            Toast.makeText(this, "Cookies cleared", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addBtn(parent: LinearLayout, text: String, onClick: () -> Unit): Button {
        val bt = Button(this)
        bt.text = text
        bt.setOnClickListener { onClick() }
        parent.addView(bt)
        return bt
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val on = RemoteService.running
        startBtn.text = if (on) "Stop" else "Start"
        val sb = StringBuilder()
        sb.append(if (on) "Server: RUNNING\n" else "Server: stopped\n")
        sb.append("Overlay permission: ")
            .append(if (Settings.canDrawOverlays(this)) "granted" else "NOT granted (page may render blank)")
            .append("\n")
        val ips = localIps()
        sb.append("Wi-Fi address: ")
            .append(if (ips.isEmpty()) "(no network)" else ips.joinToString(", "))
            .append("\n")
        sb.append("Bluetooth UUID: ").append(Proto.BT_UUID.toString())
        status.text = sb.toString()
    }

    private fun localIps(): List<String> {
        val r = ArrayList<String>()
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (a in Collections.list(ni.inetAddresses)) {
                    if (!a.isLoopbackAddress && a is Inet4Address) r.add(a.hostAddress + ":" + Proto.PORT)
                }
            }
        } catch (e: Exception) { }
        return r
    }

    private fun toggle() {
        if (RemoteService.running) {
            stopService(Intent(this, RemoteService::class.java))
            startBtn.postDelayed({ refresh() }, 400)
            return
        }
        prefs.edit()
            .putBoolean("bt", cbBt.isChecked)
            .putBoolean("tcp", cbTcp.isChecked)
            .putString("home", home.text.toString().trim().ifEmpty { Proto.DEFAULT_HOME })
            .apply()
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) {
            need.add(Manifest.permission.BLUETOOTH_CONNECT)
            need.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        }
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty() && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(missing.toTypedArray(), 1)
        } else {
            startServer()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        startServer()
    }

    private fun startServer() {
        val i = Intent(this, RemoteService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        startBtn.postDelayed({ refresh() }, 600)
    }
}
