package com.bwremote.server

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Mot phien ket noi voi jar: doc goi tin va chuyen cho BrowserHost. */
class Session(
    input: InputStream,
    output: OutputStream,
    private val closer: Closeable,
    private val host: BrowserHost,
    private val onEnd: (Session) -> Unit
) : Thread("bw-session") {

    private val din = DataInputStream(BufferedInputStream(input, 4096))
    private val dout = DataOutputStream(BufferedOutputStream(output, 8192))

    @Volatile
    private var alive = true

    override fun run() {
        try {
            while (alive) {
                val type = din.readUnsignedByte()
                val len = din.readInt()
                if (len < 0 || len > 65536) throw IOException("bad length $len")
                val b = ByteArray(len)
                din.readFully(b)
                handle(type, b)
            }
        } catch (e: Exception) {
            // ket noi dong
        } finally {
            close()
            onEnd(this)
        }
    }

    private fun u16(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)

    private fun s16(b: ByteArray, o: Int): Int = u16(b, o).toShort().toInt()

    private fun handle(type: Int, b: ByteArray) {
        when (type) {
            Proto.C_HELLO -> if (b.size >= 5) host.hello(u16(b, 0), u16(b, 2), b[4].toInt())
            Proto.C_CLICK -> if (b.size >= 4) host.click(u16(b, 0), u16(b, 2))
            Proto.C_TEXT -> host.text(String(b, Charsets.UTF_8))
            Proto.C_SCROLL -> if (b.size >= 4) host.scroll(s16(b, 0), s16(b, 2))
            Proto.C_NAV -> if (b.isNotEmpty()) host.nav(b[0].toInt())
            Proto.C_URL -> host.url(String(b, Charsets.UTF_8))
            Proto.C_KEY -> if (b.isNotEmpty()) host.key(b[0].toInt())
            else -> {}
        }
    }

    fun send(type: Int, data: ByteArray) {
        try {
            synchronized(dout) {
                dout.writeByte(type)
                dout.writeInt(data.size)
                dout.write(data)
                dout.flush()
            }
        } catch (e: Exception) {
            close()
        }
    }

    fun close() {
        alive = false
        try { closer.close() } catch (e: Exception) { }
    }
}
