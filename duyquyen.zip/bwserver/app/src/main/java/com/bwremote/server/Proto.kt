package com.bwremote.server

import java.util.UUID

object Proto {
    const val PORT = 8765
    const val DEFAULT_HOME = "https://m.facebook.com/"
    val BT_UUID: UUID = UUID.fromString("7D3C5E1A-4B6F-4D2E-9A8C-1F0E5B2D3A47")

    // server -> jar
    const val S_FULL = 1
    const val S_TILE = 2
    const val S_TITLE = 3
    const val S_URL = 4
    const val S_LOADING = 5
    const val S_BYE = 6

    // jar -> server
    const val C_HELLO = 16
    const val C_CLICK = 17
    const val C_TEXT = 18
    const val C_SCROLL = 19
    const val C_NAV = 20
    const val C_URL = 21
    const val C_KEY = 22
}
