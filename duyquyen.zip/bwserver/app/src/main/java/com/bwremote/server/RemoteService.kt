package com.bwremote.server

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.io.Closeable
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import kotlin.concurrent.thread

class RemoteService : Service() {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "bw_server"
    }

    private var host: BrowserHost? = null
    private var tcp: ServerSocket? = null
    private var bt: BluetoothServerSocket? = null
    @Volatile private var session: Session? = null
    @Volatile private var up = false
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (up) return START_STICKY
        up = true
        running = true
        startFg()
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        host = BrowserHost(applicationContext) {
            prefs.getString("home", Proto.DEFAULT_HOME) ?: Proto.DEFAULT_HOME
        }
        acquireLocks()
        if (prefs.getBoolean("tcp", true)) thread(name = "bw-tcp") { tcpLoop() }
        if (prefs.getBoolean("bt", true)) thread(name = "bw-bt") { btLoop() }
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "BlueWAP Server", NotificationManager.IMPORTANCE_LOW)
            )
            b = Notification.Builder(this, CHANNEL)
        } else {
            @Suppress("DEPRECATION")
            b = Notification.Builder(this)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = b.setContentTitle("BlueWAP Server")
            .setContentText("Waiting for the phone to connect")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bw:server").also { it.acquire() }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "bw:wifi").also { it.acquire() }
    }

    private fun tcpLoop() {
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(Proto.PORT))
            tcp = ss
            while (up) {
                val s = ss.accept()
                s.tcpNoDelay = true
                begin(s.getInputStream(), s.getOutputStream(), s)
            }
        } catch (e: Exception) {
            // dong server
        }
    }

    @Suppress("DEPRECATION")
    private fun btLoop() {
        try {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) return
            val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
            if (!adapter.isEnabled) return
            val ss = adapter.listenUsingRfcommWithServiceRecord("BlueWAP Remote", Proto.BT_UUID)
            bt = ss
            while (up) {
                val s = ss.accept()
                begin(s.inputStream, s.outputStream, s)
            }
        } catch (e: Exception) {
            // Bluetooth tat hoac bi tu choi quyen
        }
    }

    private fun begin(i: InputStream, o: OutputStream, c: Closeable) {
        val h = host ?: return
        val s = Session(i, o, c, h) { ended ->
            if (session === ended) {
                session = null
                h.attach(null)
            }
        }
        val old = session
        session = s
        old?.close()
        h.attach(s)
        s.start()
    }

    override fun onDestroy() {
        up = false
        running = false
        try { tcp?.close() } catch (e: Exception) { }
        try { bt?.close() } catch (e: Exception) { }
        session?.close()
        host?.destroy()
        try { wake?.release() } catch (e: Exception) { }
        try { wifi?.release() } catch (e: Exception) { }
        super.onDestroy()
    }
}
