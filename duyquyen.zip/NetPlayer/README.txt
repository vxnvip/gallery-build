NetPlayer - player xem link truc tiep (android.media.MediaPlayer cua he thong, KHONG dung ExoPlayer/Media3)
- Doc http(s) bang HTTP Range: tua dau tai do, khong can /sdcard, khong can bridge.
- Ho tro dinh dang tuy may (mp4, mkv, HLS...). Khong co cache dia, khong ho tro DASH.
- MOI lenh tua (vuot, keo thanh, nut +-10s, cham doi, thanh tren thong bao) deu la seekTo(ms, SEEK_CLOSEST).
- Lop chinh: MpEngine.java (boc MediaPlayer), VideoFrame.java (khung TextureView), EqEffects.java (bo can bang).
- Cu chi: cham 1 lan an/hien; cham doi trai/phai = +-10s, giua = play/pause;
  vuot doc trai = sang, phai = am luong; vuot ngang = tua.
HLS QUA PROXY (v3): link m3u8 (hoac noi dung bat dau #EXTM3U du URL khong co duoi) -> LocalProxyServer viet lai playlist, moi doan/key deu qua localhost, gan UA+Referer, theo redirect; doan gia dang anh (PNG/JPG truoc goi TS) duoc cat bo phan dau. Loi HLS hien trong thong bao loi + nhat ky.
TOC DO HLS (v4): proxy cache RAM 64MB + tai truoc 4 doan ke tiep + tai san 3 doan dau; playlist VOD cache; keep-alive; link .m3u8 bo buoc do (probe), vao thang proxy. Tua: doan chua co thi tai ngay (khong xep sau prefetch), doan dang tai thi doc dan khong doi tai xong.
V5: link http(s) phat bang ExoPlayer (Media3 1.5.1: progressive, HLS, DASH, phu de, EQ qua audio session rieng). File / content:// van MediaPlayer + SEEK_CLOSEST nhu cu (khong doi). Exo tua dung SeekParameters.EXACT (MpEngine.initExo). LocalProxyServer/HttpMediaSource con lai chi phuc vu anh xem truoc khi tua.
V6: link http(s) = ExoPlayer cau hinh y het ban 22: cache dia 512MB (SimpleCache), DefaultLoadControl 20s/60s/0.5s/1s, MediaCodec bat dong bo, decoder fallback, read timeout 30s. Cai dat moi "Tua nhanh (link mang)" (mac dinh BAT = CLOSEST_SYNC, tat = EXACT). File/content:// van MediaPlayer + SEEK_CLOSEST.
V7: link http(s) tua SeekParameters.EXACT co dinh (lay tu ban exo), bo cai dat "Tua nhanh". File/content:// khong doi.
V9: sua lech vi tri / khung khi phat nen roi vao lai (MediaPlayer, file/content://). Nguyen nhan: NuPlayer moi lan DOI mat hien thi (ke ca null hay ImageReader) luc dang chay deu huy decoder hinh, dung lai va tua ve khung khoa truoc (v8 doi 2 lan nen nang hon). Nay MediaPlayer chi setSurface DUNG 1 LAN suot doi engine (MpEngine.videoTexture, SurfaceTexture roi). TextureView muon lai bang setSurfaceTexture (VideoFrame.bind), khong huy no khi mat man hinh. Luc phat nen SurfaceDrain (EGL pbuffer, chi updateTexImage) hut khung de decoder chay dung nhip. Khong dung logic tua, Exo khong doi.
V10: bam THAN thong bao phat nen phai bam 2 lan (trong 4s, TAP_WINDOW_MS) moi mo video; lan 1 hien toast nhac. He thong tu thu bang thong bao sau lan bam 1 nen lan 2 phai keo xuong lai. Di qua NotiTapActivity (trong suot, khong UI). Nut Phat/Tam dung/Dong va thanh tua khong doi.
Build: gradle assembleDebug (khong con thu vien ngoai)
Test:  am start -a android.intent.action.VIEW -d "https://host/a.mp4" -t video/mp4 -n com.duy.netplayer/.PlayerActivity
Chrome: intent://host/a.mp4#Intent;scheme=https;type=video/*;package=com.duy.netplayer;end;

BO CAN BANG (nut ⋮ tren thanh tren cua player)
- 10 bang: 31Hz..16kHz, +-15dB, vuot ngang de doi 2 trang (5 thanh/trang).
- Preset: Binh thuong, Tin tuc, To tieng, Phong cho, Dan piano, RB, Rock, Pop, Jazz, Co dien, Tram manh.
- Tang am tram (low-shelf 100Hz), Ao hoa am thanh (mo rong stereo), Am vang (Freeverb, 5 kieu).
- Dung audiofx cua he thong (EqEffects.java) vi MediaPlayer khong cho chen vao luong am thanh: 10 bang bang DynamicsProcessing (Android 9+), may khong co thi dung Equalizer cua may (thuong 5 bang, noi suy). Tang tram = BassBoost, ao hoa = Virtualizer, am vang = PresetReverb. Tieng co the khac nhau tuy may; hieu ung nao may khong ho tro se bi bo qua. Tu ha preamp khi tang nhieu + limiter.
- Cai dat luu SharedPreferences "eq". Sua preset o EqSettings.PRESET.

ZOOM VIDEO
- Chum 2 ngon (toan man): phong to / thu nho tu 0.3x den 6x, 2 ngon truot thi doi luon vi tri.
- Cham 2 lan roi GIU keo xuong = phong to, keo len = thu nho (toan man, nhay: ~10% chieu cao man hinh = 2.7x). Cham 2 lan roi tha = tua +-10s / phat-tam dung nhu cu.
- Tha tay gan 1x thi tu hit ve dung 1x.
- Khi dang zoom to (>1x), hinh chu nhat giua (24%-77% ngang, tren 75% doc) dung 1 ngon keo de doi phan bi che; tha tay nhanh thi hinh troi tiep theo da vuot (quan tinh, chinh FLING_FRICTION).
- Cham 2 lan vao hinh chu nhat giua: dang 1x -> phong 3x (TAP_ZOOM) (tai diem cham), dang zoom -> ve 1x. Pause/play (cham 2 lan giua, khong hien thanh chuc nang) + tua +-10s (cham 2 lan trai/phai) nam o dai duoi va 2 ben. Hai ben va dai duoi giu chuc nang cu (sang / am luong / tua). Khong co chu nao hien tren man hinh.
- Chinh vung keo o PlayerActivity: ZX0, ZX1, ZY1. Do nhay keo zoom: he so 0.1f trong onDoubleTapEvent.
- PlayerView doi sang texture_view de zoom/clip on dinh.

GIU DE TAM DUNG
- Ccham 1 ngon giu >0.1s (HOLD_MS) khi dang phat: tam dung; tha ra: phat tiep. Dang giu them 1 ngon nua thi chum 2 ngon de zoom van duoc.
- Nut chup (camera) nam cung hang nut tron voi xoay / tat tieng / tai nghe / toc do.

XEM TRUOC KHI TUA
- Thanh chuc nang AN: vuot ngang -> hien thanh tien trinh rieng (thap hon thanh cu) + the anh xem truoc + gio "17[-00:18]" (gio dich [lech so voi luc bat dau]); tha tay de tua.
- Thanh chuc nang HIEN: keo thanh tien trinh cu (hoac vuot ngang tren man hinh) -> thanh cu chay theo tay + the anh xem truoc; tha tay de tua.
- Anh lay bang MediaMetadataRetriever (khung khoa gan nhat, chay nen, cache 40 anh). Link HLS/DASH thuong khong lay duoc anh -> chi hien gio.

THANH DIEU HUONG HE THONG
- Thanh 3 nut hien/an dong bo voi thanh chuc nang (showControls/hideControls -> sysUi). Thanh trang thai van an. Cac nut tu dich vao khi thanh dieu huong hien (applyInsets).

TUA / QUAY LAI
- Do nhay vuot tua tu tinh theo thoi luong: vuot het chieu ngang = 80% thoi luong (SEEK_FRAC), toi thieu 10s, toi da 60 phut. Video 40s -> ~32s/man hinh; video 2h -> 60 phut/man hinh.
- Thoat ra luc dang phat thi vao lai phat tiep; thoat luc dang pause thi giu pause.

THOAT BANG KEO XUONG
- O dai duoi (y > ZY1), phan giua (ZX0..ZX1) - cho thanh tua: keo xuong, video tuot theo tay (nhan DISMISS_GAIN); keo nhanh (DISMISS_FLING) hoac qua DISMISS_FRAC man hinh thi thoat co hieu ung tuot xuong, khong thi tu bat lai.
- Vuot doc o 2 ben dai duoi van la sang / am luong.
- Sua: dang 1x thi keo xuong o dai giua (ZX0..ZX1) tu tren xuong duoi deu thoat duoc; dang zoom chi phan giua cua dai duoi. Hai ben van vuot doc = sang / am luong. Moi vao video thi thanh chuc nang an.
- Cham 2 lan giu keo ma thu nho <1x: tha tay tu ve 1x (co hieu ung). Chum 2 ngon <1x thi giu nguyen.

PHAT NEN (nut tai nghe)
- Bam icon tai nghe: thoat man hinh player, video tiep tuc phat nen (chi am thanh, go mat hien thi khoi MediaPlayer).
- Player khong bi tao lai: PlayerActivity giao nguyen MpEngine (MediaPlayer) cho BackgroundPlayService (foreground service, mediaPlayback), nen khong buffer lai, bo can bang EQ van giu nguyen.
- Thong bao co nut Phat/Tam dung va Dong. Bam vao thong bao: mo lai player dung video do, xem tiep ca hinh tu vi tri dang phat (toc do / tat tieng giu nguyen).
- Phat het video hoac bam Dong: service tu dung, luu vi tri xem do. Mo video khac thi player nen cu bi bo.
- Android 13+: lan dau bam se xin quyen thong bao (tu choi van phat nen duoc, chi khong thay thong bao trong khay).
- Them: giu CPU/wifi khi phat nen (wake lock + wifi lock), tu tam dung khi rut tai nghe, xu ly audio focus (co cuoc goi / app khac phat thi tam dung). Tat ca nam trong MpEngine.
- File: BackgroundPlayService.java, ic_close.xml; sua PlayerActivity (startBackgroundPlay / doBackgroundPlay / initPlayer), AndroidManifest (service + quyen).
- content:// : MediaPlayer mo thanh fd ngay luc setDataSource nen sau khi quyen tam bi thu hoi van tua duoc (khong can FdDataSource nua).

THANH TUA TREN THONG BAO PHAT NEN
- Dung MediaSession (BackgroundPlayService.updateSession) + Notification.MediaStyle.setMediaSession: Android 13+ tu ve thanh tua keo duoc tren thong bao, chay theo thoi gian khi dang phat.
- Android 8-12: he thong khong ve thanh tua tuong tac tren thong bao, chi co nut Phat/Tam dung/Dong.
- Kem theo: dieu khien tren man hinh khoa, nut tren tai nghe (bam 1 lan = phat/tam dung).

LOG CRASH TREN MAY (khong can adb)
- App.java bat moi crash va luu lai; lan mo app sau (MainActivity) hien hop thoai co log, bam 'Sao chep' de gui.

VUOT NHANH LEN DE PHAT NEN
- Vuot nhanh len tu dai duoi, phan giua (ZX0..ZX1, y > ZY1): khong co hieu ung theo tay khi dang giu; chi xet luc tha (van toc > BG_FLING = 1200 px/s).
- Hieu ung: video khep lai thanh hinh tron, thu nho va bay len goc trai thanh trang thai, roi chuyen sang phat nen (swipeUpBackground).
- Vuot cham (khong du nhanh) o dai duoi giua: khong lam gi. Vuot doc o 2 ben van la sang / am luong.
- Nut tai nghe van thoat ngay, khong co hieu ung.

NHAT KY LOI
- App.saveLog ghi loi phat nen / loi mo fd content://; lan mo app sau hien trong hop thoai 'Nhat ky loi lan truoc'.

HUONG MAN HINH
- Video ngang: xoay theo huong cam may (SCREEN_ORIENTATION_SENSOR): cam doc thi hien doc, xoay ngang thi hien ngang.
- Video doc: khoa cung doc (SCREEN_ORIENTATION_PORTRAIT), khong tu xoay.
- Nut xoay: doi tay sang huong nguoc voi huong dang hien va giu co dinh.

CAI DAT (man hinh chinh -> "Cai dat")
- Nho do sang: luu do sang khi vuot chinh, video sau tu ap dung (mac dinh bat).
- Nho ti le khung hinh: luu kieu Vua / Cat / Keo (mac dinh bat).
- Thoi gian tua: 5s, 10s, 15s, 20s, 30s, 60s hoac Tuy chinh (nhap 1-600 giay, nut Luu). Ap dung cho cham doi trai/phai va nut tua.
- SettingsActivity.java, luu SharedPreferences "settings".

DO THOI GIAN TUA (Cai dat -> "Hien thoi gian tua", mac dinh BAT)
- Sau moi lan tua (tha tay, keo thanh, nut +-10s): hien "tua: dem Xms  tua xong Yms  hien hinh Zms  phat Wms" tinh tu luc goi seekTo(ms, SEEK_CLOSEST).

PHU DE
- Nut CC: chi hien phu de timed-text nhung trong file (vd mp4 tx3g). Phu de kieu khac (srt roi, ASS/SSA trong mkv) MediaPlayer khong ho tro.

SUA LOI LOAD MAI KHI MO URL (HttpMediaSource.java)
- Truoc: MediaPlayer tu doc URL (MediaHTTP cua he thong) nen hay ket khi gap redirect, https, server khong tra Range, mp4 co moov o cuoi.
- Nay: HttpMediaSource (MediaDataSource) tu doc mang bang HttpURLConnection roi dua cho MediaPlayer.
  + Server ho tro Range: doc tung khoi 512KB, cache RAM 16MB, doc truoc 2 khoi. Tua / moov o cuoi deu nhanh.
  + Server khong ho tro Range: tai tuan tu xuong file tam trong cache, MediaPlayer doi du du lieu moi doc.
  + Tu theo redirect, gui User-Agent/Referer, tat gzip (Accept-Encoding: identity), thu lai 3 lan moi khoi.
  + HLS (.m3u8): van de MediaPlayer doc theo dia chi cuoi (MediaDataSource khong chay HLS).
- Watchdog (MpEngine.watchdog): khong nhan them byte nao trong 25s (hoac tong qua 120s) thi bao loi thay vi quay mai. Link cham nhung van tai thi duoc doi.
- Anh xem truoc khi tua (MediaMetadataRetriever) cung dung HttpMediaSource.
- Nhat ky loi: hop thoai lan mo app sau co dong "Probe url=... http=... range=..." va "Nguon HTTP: ..." de biet server tra gi.

LOCAL HTTP PROXY + PRE-BUFFER DUOI FILE (LocalProxyServer.java)
- MediaPlayer khong doc mang nua: no doc http://127.0.0.1:<cong tu chon>/<token> (loopback, ping < 1ms). Mang that do HttpMediaSource lo.
- Proxy hieu Range (a-b, a-, -n): tra 206 + Content-Range / 416 / HEAD dung chuan. Server goc khong co Range van tua duoc (tai tuan tu roi phuc vu Range).
- Pre-buffer moov: doc box mp4 o khoi dau. moov o dau file -> khong doc them. moov nam sau mdat -> tai song song 1-4 khoi (512KB) cuoi file
  vao RAM va GHIM (khong bi LRU da ra), nen MediaPlayer doi moov la tra ngay. Khoi dau file cung duoc ghim (tua ve 0 tuc thi).
- Doc truoc 3 khoi phia sau vi tri dang doc; cache LRU 16MB + vung ghim.
- Khong mo duoc proxy -> tu dong dung MediaDataSource truc tiep nhu ban truoc. HLS (.m3u8) van de MediaPlayer doc thang.
- Sua: MpEngine.resolveThenOpen (dang ky proxy), MpEngine.release (huy dang ky). Chinh: HttpMediaSource.CHUNK / prebufferTail.

TAI DUOI FILE SONG SONG (HttpMediaSource.readHeadStaged / prebufferTail)
- Truoc: doc het khoi dau 512KB roi moi bat dau tai duoi file (moov). Nay: co 4KB dau la biet moov o dau -> tai duoi SONG SONG voi phan con lai cua khoi dau.
- Ghim toi da 12 khoi (~6MB) cuoi file cho moov lon, tai tu dau vung moov di len, vao hang doi truoc prefetch phia truoc (uu tien bang thong cho moov + dau file, kieu media_proxy).
- Chinh: STAGE_BYTES, MAX_TAIL_CHUNKS. Pool tang 3 -> 4 luong.

V11: giu setContentIntent (NotiTapActivity, chi finish, khong lam gi) chi de Samsung hien chip tai nghe + ten tren thanh trang thai. Mo video bang nut "Mo" (custom action MediaSession, 1 cham) tren the media, qua extra from_bg. Overlay 1px trong suot (quyen "Hien thi tren ung dung khac") de Android 15 cho mo Activity tu nen.

V12: hieu ung cot nhac tren thanh trang thai khi phat nen (SpectrumOverlay: Visualizer gan vao audio session cua player, ve trong cua so overlay cao bang thanh trang thai, nam DUOI thanh trang thai nen bieu tuong van nhin ro). Can quyen RECORD_AUDIO (xin 1 lan o man hinh chinh) + "Hien thi tren cac ung dung khac". Doi mau: SpectrumOverlay.COLOR; so cot: BARS.

V13: sua cot nhac khong hien: (1) MainActivity xin lai quyen Micro moi lan mo app khi con thieu (truoc day chi xin 1 lan), neu bi tu choi han thi mo Cai dat; (2) THEM xin quyen "Hien thi tren cac ung dung khac" (truoc do app khong he xin); (3) service thu bat cot nhac lai sau 0.4s/1.5s neu player chua kip bao dang phat; (4) log ro ly do khi thieu quyen (tag NPBG).
V14: trong player, bang chuc nang hien thi thi thanh trang thai hien theo (go FLAG_FULLSCREEN cua cua so), an bang thi an ca hai.
V16: khoi phuc contentIntent (chip Samsung) nhu v26; chip va than the gui cung 1 intent nen khong phan biet duoc.
V17: cai dat "Tiep tuc phat video" (SettingsActivity.K_RESUME): Bat (phat tiep vi tri cu) / Tat (tu dau) / Bat dau tu dau + thong bao tiep tuc vi tri cu / Choi vi tri cu + hoi bat dau lai. Thanh thong bao 8 giay o day player (PlayerActivity.showResumeBar), chi hien khi vi tri cu > 3 giay. Mac dinh: Bat.
V17b: doi ten 2 lua chon: "Bat dau, hoi tiep tuc" va "Tiep tuc, hoi bat dau lai".
V17c: thanh thong bao doi chu "Tiep tuc vi tri (mm:ss)", hien 0,5 giay (PlayerActivity.RESUME_BAR_MS).
V18: nut 3 cham mo bang "Khac" (MoreSheet): Bo can bang mo EQ; Lap lai chay that (Lap lai 1 video / Thu tu - chua dung duoc, hien cho co / Khong lap, MpEngine.setLoop); cac muc con lai chi de hien thi.
V19: Lap lai bam 1 nut chuyen doi Khong lap <-> Lap lai (toan bo), doi icon, bo muc Thu tu; thanh thong bao tiep tuc/bat dau lai hien 1,5s.
V20: vong quay loading chi hien voi link http(s); file trong may khong hien khi tua/mo.
V21: che do Lap lai luu vao cai dat (K_LOOP), ap dung cho moi video va nho giua cac lan mo.
