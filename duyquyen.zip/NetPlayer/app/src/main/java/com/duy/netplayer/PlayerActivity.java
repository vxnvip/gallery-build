package com.duy.netplayer;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.media.MediaMetadataRetriever;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ViewConfiguration;
import android.view.ViewOutlineProvider;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;

/** Player toàn màn hình bằng android.media.MediaPlayer: link http(s) đọc bằng Range (tua đâu tải đó), mọi lệnh tua = SEEK_CLOSEST. */
public class PlayerActivity extends Activity {
    static final String UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    private MpEngine player;
    private VideoFrame playerView;
    private TextView sub;
    private View top, quick, camera, bottom, unlockBtn, gesture;
    private ImageView playBtn, muteBtn, phonesBtn, ccBtn, speedBtn;
    private View nightOverlay, quickMore, volBar, brtBar;
    private ProgressBar volProgress, brtProgress;
    private ImageView volIcon, brtIcon, chevBtn;
    private boolean night, quickOpen, pipEntering;
    private TextView posTv, durTv, info;
    private boolean muted, ccOn = true;
    private boolean handedOff; // đã giao player cho BackgroundPlayService
    private boolean fromBg; // vừa nhận lại player từ phát nền
    private boolean openedFromBgBtn; // mở bằng nút Mở trên thẻ phát nền: thoát thì không ở lại trang chủ app
    private MpEngine.Listener playerListener;
    private static final int REQ_NOTI = 77;
    private SeekBar seek;
    private ProgressBar loading;
    private final Handler h = new Handler(Looper.getMainLooper());

    private boolean locked, dragging, landscape = true;
    private final float[] speeds = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
    private int speedIdx = 2, aspectIdx = 0;
    private final int[] aspects = {VideoFrame.FIT, VideoFrame.ZOOM, VideoFrame.FILL};
    private final String[] aspectNames = {"Vừa", "FULL", "Kéo"};
    private String key;

    // zoom: 2 ngón / chạm đôi giữ kéo (toàn màn), kéo dời vùng che (hình chữ nhật giữa)
    private static final float MAX_ZOOM = 6f, MIN_ZOOM = 0.1f;
    private static final float ZX0 = 0.24f, ZX1 = 0.77f, ZY1 = 0.75f; // vùng "KÉO"
    private float zoom = 1f, panX, panY;
    private boolean multi, dtDrag;
    private float dtY0, dtFx, dtFy, dtZoom0;

    // thanh điều hướng hệ thống (3 nút): hiện/ẩn cùng thanh chức năng
    private boolean navShown;
    private boolean resumeOnReturn; // lúc thoát đang phát -> quay lại phát tiếp
    private int stL, stR, stB;

    // xem trước khi tua (ảnh + giờ). Thanh chức năng ẩn: vuốt ngang hiện thanh riêng; đang hiện: thanh cũ chạy theo tay
    private View seekOverlay, seekCard, seekBarRow;
    private ImageView seekThumb;
    private TextView seekTime, seekPos, seekDur;
    private SeekLine seekLine;
    private boolean seekUiOn, swiping, thumbBusy, thumbDead;
    private long seekT, seekFrom, seekDurMs, dragFrom, thumbWant = -1;
    private int thumbMiss;
    private Uri mediaUri;
    private String referer;
    private ExecutorService thumbExec;
    private MediaMetadataRetriever mmr; // chỉ đụng tới trong thumbExec
    private HttpMediaSource mmrSrc;     // nguồn HTTP của mmr (đóng cùng lúc)
    private final LruCache<Long, Bitmap> thumbCache = new LruCache<>(40);

    // giữ 1 ngón > HOLD_MS: tạm dừng, thả ra: phát tiếp (thêm ngón thứ 2 vẫn zoom được)
    private static final long HOLD_MS = 100, HOLD_TAP_MAX = 350;
    private boolean holdPaused, holdMoved;
    private long holdStart, lastTapUp;
    private float holdX, holdY;
    private final Runnable holdRun = () -> {
        if (locked || player == null) return;
        if (player.isPlaying()) {
            player.pause();
            holdPaused = true;
        }
    };

    // quán tính khi vuốt dời hình lúc đang zoom + hoạt ảnh chạm đôi 1x <-> 2x
    private static final float TAP_ZOOM = 3f; // mức phóng khi chạm đôi vào vùng giữa
    private static final float SEEK_FRAC = 0.8f; // vuốt hết bề ngang = 80% thời lượng
    private static final long SEEK_MIN_MS = 10000, SEEK_MAX_MS = 60 * 60 * 1000L;
    // kéo nhanh xuống ở dải dưới (giữa) để thoát: video tuột theo tay
    private static final float DISMISS_GAIN = 2f, DISMISS_FRAC = 0.3f, DISMISS_FLING = 900f;
    private static final float DISMISS_COAST = 0.35f; // giây: quãng video còn trôi theo đà tay lúc thả (quán tính)
    private float dismissVy;
    private static final float DISMISS_BOOST = 1.4f; // nhân vận tốc lúc thả: vuốt nhanh thì phóng xuống mạnh hơn
    private boolean dismissing, dismissFast, bgFast;
    private static final float BG_FLING = 1200f; // px/s: vuốt lên nhanh hơn mức này = phát nền
    private static final float FLING_FRICTION = 3.2f; // càng lớn càng nhanh dừng
    private ValueAnimator zoomAnim;
    private boolean flinging;
    private float flingVx, flingVy;
    private long flingLast;
    private final Choreographer.FrameCallback flingCb = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long t) {
            if (!flinging) return;
            float dt = Math.max(0f, Math.min(0.05f, (t - flingLast) / 1e9f));
            flingLast = t;
            float nx = panX + flingVx * dt, ny = panY + flingVy * dt;
            panX = nx;
            panY = ny;
            applyZoom(); // kẹp biên
            if (panX != nx) flingVx = 0; // chạm mép thì dừng trục đó
            if (panY != ny) flingVy = 0;
            float decay = (float) Math.exp(-FLING_FRICTION * dt);
            flingVx *= decay;
            flingVy *= decay;
            if (Math.abs(flingVx) < 25f && Math.abs(flingVy) < 25f) {
                flinging = false;
                return;
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    // bộ cân bằng
    private EqSettings eq;
    private EqPanel eqPanel;
    private View eqHost;
    private boolean eqOpen;

    // trạng thái cử chỉ
    private int mode; // 0 chưa rõ, 1 tua, 2 sáng, 3 âm lượng, 4 dời hình, 5 thoát, 6 phát nền, 7 đổi tỉ lệ, 8 vuốt lên ở góc phải dưới (chưa dùng)
    private long startPos, seekTarget;
    private float startBright;
    private int startVolPct, volPct = -1, lastSysStep = -1;
    private float volAcc, volLastUp;
    private boolean quickTouch;
    private AudioManager am;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_player);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Window win = getWindow(); // thanh điều hướng / trạng thái trong suốt hoàn toàn
        win.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        win.setNavigationBarColor(Color.TRANSPARENT);
        win.setStatusBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            win.setNavigationBarContrastEnforced(false); // không tự phủ lớp mờ lên thanh 3 nút
            win.setStatusBarContrastEnforced(false);
        }
        am = (AudioManager) getSystemService(AUDIO_SERVICE);

        Intent in = getIntent();
        openedFromBgBtn = in.getBooleanExtra("from_bg", false);
        Uri uri = in.getData();
        if (uri == null && in.getStringExtra("url") != null) uri = Uri.parse(in.getStringExtra("url"));
        if (uri == null && in.getBooleanExtra("from_bg", false)) uri = BackgroundPlayService.currentUri(); // nút Mở trên thẻ media
        if (uri == null) {
            finish();
            return;
        }
        key = uri.toString();
        mediaUri = uri;
        referer = in.getStringExtra("referer");

        playerView = findViewById(R.id.player);
        // khung đổi kích thước (xoay màn hình...): áp lại zoom sau khi layout xong để video luôn quanh tâm
        playerView.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (r - l != or - ol || b - t != ob - ot) applyZoom();
        });
        sub = findViewById(R.id.sub);
        top = findViewById(R.id.top);
        quick = findViewById(R.id.quick);
        camera = findViewById(R.id.camera);
        bottom = findViewById(R.id.bottom);
        gesture = findViewById(R.id.gesture);
        unlockBtn = findViewById(R.id.unlock);
        playBtn = findViewById(R.id.play);
        posTv = findViewById(R.id.pos);
        durTv = findViewById(R.id.dur);
        speedBtn = findViewById(R.id.speed);
        muteBtn = findViewById(R.id.mute);
        phonesBtn = findViewById(R.id.phones);
        nightOverlay = findViewById(R.id.nightOverlay);
        volBar = findViewById(R.id.volBar);
        brtBar = findViewById(R.id.brtBar);
        volProgress = findViewById(R.id.volProgress);
        brtProgress = findViewById(R.id.brtProgress);
        volIcon = findViewById(R.id.volIcon);
        brtIcon = findViewById(R.id.brtIcon);
        quickMore = findViewById(R.id.quickMore);
        ccBtn = findViewById(R.id.cc);
        info = findViewById(R.id.info);
        seek = findViewById(R.id.seek);
        loading = findViewById(R.id.loading);
        seekOverlay = findViewById(R.id.seekOverlay);
        seekCard = findViewById(R.id.seekCard);
        seekBarRow = findViewById(R.id.seekBarRow);
        seekThumb = findViewById(R.id.seekThumb);
        seekTime = findViewById(R.id.seekTime);
        seekPos = findViewById(R.id.seekPos);
        seekDur = findViewById(R.id.seekDur);
        seekLine = findViewById(R.id.seekLine);

        String title = in.getStringExtra("title");
        if (title == null) title = uri.getLastPathSegment();
        ((TextView) findViewById(R.id.title)).setText(title == null ? "" : title);

        eq = new EqSettings(this);
        eqHost = findViewById(R.id.eqHost);

        getWindow().getDecorView().setOnApplyWindowInsetsListener((v, ins) -> {
            stL = ins.getStableInsetLeft();
            stR = ins.getStableInsetRight();
            stB = ins.getStableInsetBottom();
            applyInsets();
            return v.onApplyWindowInsets(ins);
        });

        if (!initPlayer(uri, in.getStringExtra("referer"))) return;
        restoreVolGain();
        initControls();
        applySavedPrefs();
        if (fromBg) restoreViewFromBg(); // quay lại từ phát nền: giữ nguyên zoom / vị trí hình
        int va = SettingsActivity.validAspect(this, aspectIdx); // tỉ lệ đang dùng mà bị ẩn -> chuyển sang cái bật đầu tiên
        if (va != aspectIdx) setAspect(va, false);
        h.post(tick);
        hideControls(); // mới vào: thanh chức năng ẩn
        applySysUi();
    }

    private boolean initPlayer(Uri uri, String referer) {
        // đang phát nền đúng video này -> nhận lại player, xem tiếp cả hình (không buffer lại)
        if (BackgroundPlayService.has(uri)) {
            if (referer == null) this.referer = BackgroundPlayService.takeReferer();
            player = BackgroundPlayService.take(this);
            fromBg = true;
            eq = player.eq;
            muted = player.isMuted();
            float spd = player.getSpeed();
            for (int i = 0; i < speeds.length; i++) if (speeds[i] == spd) speedIdx = i;
            muteBtn.setImageResource(muted ? R.drawable.ic_volume_off : R.drawable.ic_volume);
            player.setTimedTextEnabled(ccOn);
            playerView.setVideoSize(player.getVideoWidth(), player.getVideoHeight());
            playerView.bind(player); // hình phát lại lên khung này
            attachListener();
            applyOrientation(player.getVideoWidth(), player.getVideoHeight()); // player đã biết kích thước sẵn
            playBtn.setImageResource(player.isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);
            return true;
        }
        BackgroundPlayService.discard(this); // video khác: bỏ player nền cũ (nếu có)

        long saved = getSharedPreferences("pos", 0).getLong(key, 0);
        int rmode = SettingsActivity.resumeMode(this);
        // bật / "chơi vị trí cũ, hỏi bắt đầu lại": mở ở vị trí cũ; tắt / "bắt đầu từ đầu + thông báo": mở từ đầu
        long resume = (rmode == SettingsActivity.RESUME_ON || rmode == SettingsActivity.RESUME_ASK_RESTART) ? saved : 0;
        try {
            player = new MpEngine(this, eq, uri, referer, resume);
        } catch (Exception e) {
            App.saveLog(this, "Không mở được video", e);
            Toast.makeText(this, "Lỗi mở video: " + e, Toast.LENGTH_LONG).show();
            finish();
            return false;
        }
        player.setLoop(SettingsActivity.prefs(this).getBoolean(SettingsActivity.K_LOOP, false)); // lặp lại: áp dụng mọi video
        playerView.bind(player);
        attachListener();
        h.postDelayed(showLoading, 300); // đang mở link: hiện vòng quay
        player.play(); // phát ngay khi sẵn sàng
        if (saved > 3000) { // vị trí cũ quá ngắn thì không đáng hỏi
            final long sv = saved;
            if (rmode == SettingsActivity.RESUME_OFFER) {
                showResumeBar("Tiếp tục vị trí (" + fmt(sv) + ")", "Tiếp tục", () -> {
                    if (player != null) player.seekTo(sv);
                });
            } else if (rmode == SettingsActivity.RESUME_ASK_RESTART) {
                showResumeBar("Tiếp tục chơi từ vị trí bạn đã dừng lại.", "Bắt đầu lại", () -> {
                    if (player != null) player.seekTo(0);
                });
            }
        }
        return true;
    }

    private static final long RESUME_BAR_MS = 1500; // thời gian thanh thông báo hiện; đổi ở đây
    private View resumeBar;
    private final Runnable dismissResumeBar = this::hideResumeBar;

    private void hideResumeBar() {
        h.removeCallbacks(dismissResumeBar);
        if (resumeBar != null && resumeBar.getParent() instanceof android.view.ViewGroup) {
            ((android.view.ViewGroup) resumeBar.getParent()).removeView(resumeBar);
        }
        resumeBar = null;
    }

    /** Thanh thông báo nhỏ dưới đáy: [✕] nội dung [hành động]; tự tắt sau RESUME_BAR_MS. */
    private void showResumeBar(String msg, String action, final Runnable onAction) {
        hideResumeBar();
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(6), dp(8), dp(6));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xF0333333);
        bg.setCornerRadius(dp(12));
        bar.setBackground(bg);
        bar.setClickable(true); // nuốt chạm để không lọt xuống cử chỉ của player

        TextView x = new TextView(this);
        x.setText("✕");
        x.setTextColor(0xFFFFFFFF);
        x.setTextSize(18);
        x.setGravity(android.view.Gravity.CENTER);
        x.setOnClickListener(v -> hideResumeBar());
        bar.addView(x, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView t = new TextView(this);
        t.setText(msg);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(15);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        tlp.leftMargin = dp(4);
        bar.addView(t, tlp);

        TextView a = new TextView(this);
        a.setText(action);
        a.setTextColor(0xFF5BC27A);
        a.setTextSize(15);
        a.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        a.setPadding(dp(12), dp(12), dp(12), dp(12));
        a.setOnClickListener(v -> {
            hideResumeBar();
            onAction.run();
        });
        bar.addView(a);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, android.view.Gravity.BOTTOM);
        lp.setMargins(dp(16), 0, dp(16), dp(40));
        ((FrameLayout) findViewById(android.R.id.content)).addView(bar, lp);
        resumeBar = bar;
        h.postDelayed(dismissResumeBar, RESUME_BAR_MS);
    }

    /** Video ngang: xoay theo hướng cầm máy (dọc/ngang). Video dọc: khóa cứng dọc. */
    private void applyOrientation(int w, int h) {
        if (w <= 0 || h <= 0) return;
        landscape = w >= h;
        setRequestedOrientation(landscape
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    /** Link http(s) mới hiện vòng quay; file trong máy (tua / mở) không hiện. */
    private boolean isNetworkMedia() {
        String sch = mediaUri == null ? null : mediaUri.getScheme();
        return "http".equalsIgnoreCase(sch) || "https".equalsIgnoreCase(sch);
    }

    private final Runnable showLoading = () -> {
        if (isNetworkMedia()) loading.setVisibility(View.VISIBLE);
    };

    private void attachListener() {
        playerListener = new MpEngine.Listener() {
            @Override
            void onState(int st) {
                h.removeCallbacks(showLoading);
                if (st == MpEngine.BUFFERING) {
                    h.postDelayed(showLoading, 300); // tua ngắn không nháy vòng quay
                } else {
                    loading.setVisibility(View.GONE);
                }
                if (st == MpEngine.ENDED) showControls();
            }

            @Override
            void onPlaying(boolean playing) {
                playBtn.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
            }

            @Override
            void onSeekDone() {
            }

            @Override
            void onFirstFrame() {
            }

            @Override
            void onVideoSize(int w, int hh) {
                playerView.setVideoSize(w, hh);
                applyOrientation(w, hh);
            }

            @Override
            void onSubtitle(String t) {
                sub.setText(t);
                sub.setVisibility(ccOn && !t.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            void onError(int what, int extra) {
                App.saveLog(PlayerActivity.this, "Lỗi MediaPlayer what=" + what + " extra=" + extra, null);
                h.removeCallbacks(showLoading);
                loading.setVisibility(View.GONE);
                String msg = MpEngine.errorText(what, extra);
                Toast.makeText(PlayerActivity.this, msg, Toast.LENGTH_LONG).show();
                showInfo(msg);
                showControls();
            }
        };
        player.setListener(playerListener);
    }

    /** Cài đặt: nhớ độ sáng / nhớ tỉ lệ khung hình từ lần xem trước. */
    private void applySavedPrefs() {
        android.content.SharedPreferences st = SettingsActivity.prefs(this);
        if (st.getBoolean(SettingsActivity.K_BRIGHT, true)) {
            float b = st.getFloat(SettingsActivity.K_BRIGHT_VAL, -1f);
            if (b >= 0f) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = b;
                getWindow().setAttributes(lp);
            }
        }
        if (st.getBoolean(SettingsActivity.K_ASPECT, true)) {
            int i = st.getInt(SettingsActivity.K_ASPECT_VAL, 0);
            if (i >= 0 && i < aspects.length) {
                aspectIdx = i;
                playerView.setResizeMode(aspects[i]);
            }
        }
    }

    private void initControls() {
        findViewById(R.id.back).setOnClickListener(v -> exitPlayer());
        playBtn.setOnClickListener(v -> togglePlay());
        findViewById(R.id.prev).setOnClickListener(v -> seekBy(-seekMs()));
        findViewById(R.id.next).setOnClickListener(v -> seekBy(seekMs()));
        findViewById(R.id.lock).setOnClickListener(v -> {
            locked = true;
            hideControls();
            unlockBtn.setVisibility(View.VISIBLE);
            h.postDelayed(() -> { if (locked) unlockBtn.setVisibility(View.GONE); }, 2500);
        });
        unlockBtn.setOnClickListener(v -> {
            locked = false;
            unlockBtn.setVisibility(View.GONE);
            showControls();
        });
        speedBtn.setOnClickListener(v -> {
            speedIdx = (speedIdx + 1) % speeds.length;
            player.setSpeed(speeds[speedIdx]);
            toast("Tốc độ " + String.valueOf(speeds[speedIdx]).replace(".0", "") + "X");
            showControls();
        });
        findViewById(R.id.aspect).setOnClickListener(v -> {
            setAspect(SettingsActivity.nextAspect(this, aspectIdx), true);
            showControls();
        });
        muteBtn.setOnClickListener(v -> {
            muted = !muted;
            player.setMuted(muted);
            muteBtn.setImageResource(muted ? R.drawable.ic_volume_off : R.drawable.ic_volume);
            showControls();
        });
        phonesBtn.setAlpha(1f);
        phonesBtn.setOnClickListener(v -> startBackgroundPlay());
        ccBtn.setOnClickListener(v -> {
            ccOn = !ccOn;
            player.setTimedTextEnabled(ccOn);
            if (!ccOn) sub.setVisibility(View.GONE);
            ccBtn.setAlpha(ccOn ? 1f : 0.4f);
            toast(!player.hasTimedText() ? "Video không có phụ đề nhúng" : ccOn ? "Phụ đề: bật" : "Phụ đề: tắt");
            showControls();
        });
        int[] soon = {R.id.cast, R.id.hd, R.id.list, R.id.camera};
        findViewById(R.id.more).setOnClickListener(v -> openMore());
        for (int id : soon) findViewById(id).setOnClickListener(v -> toast("Chưa hỗ trợ"));
        setupQuickMore();
        findViewById(R.id.rotate).setOnClickListener(v -> {
            // xoay tay: đổi sang hướng ngược với hướng đang hiển thị, giữ cố định
            boolean toLand = getResources().getConfiguration().orientation != Configuration.ORIENTATION_LANDSCAPE;
            landscape = toLand;
            setRequestedOrientation(toLand
                    ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            showControls();
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user) {
                    posTv.setText(fmt(p));
                    showSeekUi(p, dragFrom, Math.max(player.getDuration(), 0));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                dragging = true;
                dragFrom = player.getCurrentPosition();
                h.removeCallbacks(hideRun);
                showSeekUi(s.getProgress(), dragFrom, Math.max(player.getDuration(), 0));
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                timedSeek(s.getProgress());
                dragging = false;
                hideSeekUi();
                showControls();
            }
        });

        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                mode = 0;
                startPos = player.getCurrentPosition();
                startVolPct = getVolPct();
                volAcc = startVolPct;
                volLastUp = 0f;
                float b = getWindow().getAttributes().screenBrightness;
                startBright = b < 0 ? 0.5f : b;
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (eqOpen) {
                    closeEq();
                } else if (locked) {
                    unlockBtn.setVisibility(View.VISIBLE);
                    h.postDelayed(() -> { if (locked) unlockBtn.setVisibility(View.GONE); }, 2500);
                } else if (top.getVisibility() == View.VISIBLE) hideControls();
                else showControls();
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                return true; // hành động thật xử lý ở onDoubleTapEvent (nhả tay = tua/phát, kéo = zoom)
            }

            @Override
            public boolean onDoubleTapEvent(MotionEvent e) {
                if (locked) return true;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dtDrag = false;
                        dtY0 = e.getY();
                        dtFx = e.getX();
                        dtFy = e.getY();
                        dtZoom0 = zoom;
                        break;
                    case MotionEvent.ACTION_MOVE: {
                        float dy = e.getY() - dtY0;
                        if (!dtDrag) {
                            if (Math.abs(dy) <= ViewConfiguration.get(PlayerActivity.this).getScaledTouchSlop() / 2) break;
                            dtDrag = true; // bắt đầu tính từ lúc vượt ngưỡng nên không bị giật
                            dtY0 = e.getY();
                            dtZoom0 = zoom;
                            dy = 0;
                        }
                        // kéo xuống = phóng, kéo lên = thu; nhạy: ~10% chiều cao màn hình ứng với e lần
                        float nz = dtZoom0 * (float) Math.exp(dy / (gesture.getHeight() * 0.1f));
                        zoomAbout(Math.max(minZoom(), Math.min(MAX_ZOOM, nz)), dtFx, dtFy);
                        showInfo(String.format(java.util.Locale.US, "%.1fx", zoom));
                        break;
                    }
                    case MotionEvent.ACTION_UP:
                        if (!dtDrag) doubleTapAction(e.getX(), e.getY());
                        else snapZoom();
                        dtDrag = false;
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        dtDrag = false;
                        break;
                }
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (mode == 6) {
                    bgFast = vy < -BG_FLING;
                    return true;
                }
                if (mode == 5) {
                    dismissVy = Math.max(0f, vy);
                    dismissFast = vy > DISMISS_FLING;
                    return true;
                }
                if (mode == 4 && !locked && zoom > 1.01f) { // thả tay khi đang dời hình: chạy tiếp theo đà vuốt
                    startFling(vx, vy);
                    return true;
                }
                return false;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (locked || e1 == null) return false;
                float w = gesture.getWidth(), hgt = gesture.getHeight();
                if (mode == 0 && zoom > 1.01f && inPanZone(e1.getX(), e1.getY())) mode = 4;
                if (mode == 4) { // kéo dời vùng bị che khi đang zoom
                    panX -= dx;
                    panY -= dy;
                    applyZoom();
                    return true;
                }
                if (mode == 0) {
                    if (Math.abs(e2.getX() - e1.getX()) < 30 && Math.abs(e2.getY() - e1.getY()) < 30) return true;
                    if (Math.abs(e2.getX() - e1.getX()) > Math.abs(e2.getY() - e1.getY())) mode = 1;
                    else if (e2.getY() > e1.getY() && inExitZone(e1.getX(), e1.getY())) mode = 5;
                    else if (e2.getY() < e1.getY() && inBgZone(e1.getX(), e1.getY())) mode = 6;
                    else if (inAspectCorner(e1.getX(), e1.getY())) { // góc phải dưới: vuốt xuống = đổi tỉ lệ (như bấm icon), vuốt lên = chưa dùng
                        if (e2.getY() > e1.getY()) {
                            mode = 7;
                            setAspect(SettingsActivity.nextAspect(PlayerActivity.this, aspectIdx), true); // không hiện thanh chức năng
                        } else mode = 8;
                    } else mode = e1.getX() < w / 2 ? 2 : 3;
                }
                float up = (e1.getY() - e2.getY()) / hgt;
                if (mode == 7 || mode == 8) return true; // góc phải dưới: mỗi lần vuốt chỉ đổi tỉ lệ 1 lần; vuốt lên: không làm gì (để dành)
                if (mode == 6) return true; // vuốt lên phát nền: không có hiệu ứng theo tay, chỉ xét lúc thả
                if (mode == 5) {
                    dragDown(e2.getY() - e1.getY());
                    return true;
                }
                if (mode == 1) {
                    long dur = Math.max(player.getDuration(), 0);
                    seekTarget = Math.max(0, Math.min(dur, startPos + (long) ((e2.getX() - e1.getX()) / w * seekSpan(dur))));
                    swiping = true;
                    showSeekUi(seekTarget, startPos, dur);
                } else if (mode == 2) {
                    float b = Math.max(0.02f, Math.min(1f, startBright + up * 2.4f));
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.screenBrightness = b;
                    getWindow().setAttributes(lp);
                    SettingsActivity.prefs(PlayerActivity.this).edit()
                            .putFloat(SettingsActivity.K_BRIGHT_VAL, b).apply();
                    int pc = Math.round(b * 100);
                    brtProgress.setProgress(pc);
                    brtIcon.setImageResource(pc < 30 ? R.drawable.ic_brightness_low
                            : pc < 80 ? R.drawable.ic_brightness_moderate : R.drawable.ic_brightness);
                    brtBar.setVisibility(View.VISIBLE);
                } else {
                    // dưới 5%: hệ số nhạy 0.5 (thay vì 2.4) để chỉnh mịn mức nhỏ
                    volAcc += (up - volLastUp) * 100f * (volAcc < 5f ? 0.5f : 2.4f);
                    volAcc = Math.max(0f, Math.min(100f, volAcc));
                    volLastUp = up;
                    int v = Math.round(volAcc);
                    setVolPct(v);
                    volProgress.setProgress(v);
                    volIcon.setImageResource(v == 0 ? R.drawable.ic_volume_off : R.drawable.ic_volume);
                    volBar.setVisibility(View.VISIBLE);
                }
                return true;
            }
        });
        gd.setIsLongpressEnabled(false);

        final ScaleGestureDetector sgd = new ScaleGestureDetector(this,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    private float lx, ly;

                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector d) {
                        lx = d.getFocusX();
                        ly = d.getFocusY();
                        return !locked;
                    }

                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        if (locked) return false;
                        float fx = d.getFocusX(), fy = d.getFocusY();
                        zoomAbout(Math.max(minZoom(), Math.min(MAX_ZOOM, zoom * d.getScaleFactor())), fx, fy);
                        panX += fx - lx; // 2 ngón trượt = dời luôn
                        panY += fy - ly;
                        lx = fx;
                        ly = fy;
                        applyZoom();
                        showInfo(String.format(java.util.Locale.US, "%.1fx", zoom));
                        return true;
                    }
                });
        sgd.setQuickScaleEnabled(false); // chạm-đôi-giữ-kéo tự xử lý ở trên

        gesture.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (dismissing) return true; // đang tuột ra ngoài
            if (a == MotionEvent.ACTION_DOWN) {
                dismissFast = false;
                bgFast = false;
                multi = false;
                stopMotion(); // chạm vào là dừng quán tính / hoạt ảnh
                holdMoved = false;
                holdStart = e.getEventTime();
                holdX = e.getX();
                holdY = e.getY();
                h.removeCallbacks(holdRun);
                boolean second = holdStart - lastTapUp < ViewConfiguration.getDoubleTapTimeout();
                if (!locked && !second) h.postDelayed(holdRun, HOLD_MS); // lần chạm thứ 2 của chạm đôi thì không tính giữ
            } else if (a == MotionEvent.ACTION_POINTER_DOWN) {
                if (!holdPaused) h.removeCallbacks(holdRun); // 2 ngón đến trước khi kịp giữ = chụm zoom
            } else if (a == MotionEvent.ACTION_MOVE && !holdMoved) {
                if (Math.hypot(e.getX() - holdX, e.getY() - holdY) > ViewConfiguration.get(this).getScaledTouchSlop()) {
                    holdMoved = true;
                    if (!holdPaused) h.removeCallbacks(holdRun); // đã di chuyển = vuốt, không phải giữ
                }
            }
            boolean endHold = false;
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                h.removeCallbacks(holdRun);
                if (holdPaused) { // thả hết ngón: phát tiếp
                    holdPaused = false;
                    player.play();
                    endHold = e.getEventTime() - holdStart > HOLD_TAP_MAX; // giữ lâu thì không tính là chạm
                }
            }
            if (!locked) sgd.onTouchEvent(e);
            if (!multi && (e.getPointerCount() > 1 || sgd.isInProgress())) {
                multi = true; // đang chụm 2 ngón: huỷ cử chỉ 1 ngón
                MotionEvent c = MotionEvent.obtain(e);
                c.setAction(MotionEvent.ACTION_CANCEL);
                gd.onTouchEvent(c);
                c.recycle();
                if (mode == 5) restoreDrag();
                mode = 0;
                hideSwipeBars();
                dtDrag = false;
                if (swiping) {
                    swiping = false;
                    hideSeekUi();
                    if (top.getVisibility() == View.VISIBLE) showControls();
                }
            }
            if (multi) {
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    multi = false;
                    lastTapUp = 0;
                    snapZoom();
                    h.postDelayed(() -> info.setVisibility(View.GONE), 600);
                }
                return true;
            }
            if (endHold) { // thả sau khi giữ: không cho thành chạm 1 lần / chạm đôi
                MotionEvent c = MotionEvent.obtain(e);
                c.setAction(MotionEvent.ACTION_CANCEL);
                gd.onTouchEvent(c);
                c.recycle();
            } else {
                gd.onTouchEvent(e);
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                lastTapUp = (a == MotionEvent.ACTION_UP && !holdMoved && !endHold) ? e.getEventTime() : 0;
                if (mode == 1 && !locked) timedSeek(seekTarget); // chỉ tua khi THẢ TAY
                if (mode == 6 && a == MotionEvent.ACTION_UP && bgFast && !locked) swipeUpBackground();
                bgFast = false;
                if (mode == 5) {
                    // quán tính: tính cả quãng video sẽ trôi tiếp theo đà tay lúc thả
                    float coast = dismissVy * DISMISS_GAIN;
                    boolean go = a == MotionEvent.ACTION_UP
                            && (dismissFast || playerView.getTranslationY() + coast * DISMISS_COAST > gesture.getHeight() * DISMISS_FRAC);
                    if (go) dismissPlayer(coast);
                    else restoreDrag();
                }
                dismissFast = false;
                dismissVy = 0f;
                if (swiping) {
                    swiping = false;
                    hideSeekUi();
                    if (top.getVisibility() == View.VISIBLE) showControls();
                }
                mode = 0;
                hideSwipeBars();
                h.postDelayed(() -> info.setVisibility(View.GONE), 600);
            }
            return true;
        });
    }

    /** Thời gian tua được khi vuốt hết bề ngang màn hình: tỉ lệ theo thời lượng (ngắn = chậm, dài = nhanh). */
    private static long seekSpan(long dur) {
        if (dur <= 0) return 90000; // chưa biết thời lượng (vd live)
        return Math.max(SEEK_MIN_MS, Math.min(SEEK_MAX_MS, (long) (dur * SEEK_FRAC)));
    }

    /** Vùng vuốt xuống để thoát: đang 1x = cả dải giữa từ trên xuống dưới; đang zoom = chỉ phần giữa của dải dưới. */
    private boolean inExitZone(float x, float y) {
        float w = gesture.getWidth(), hgt = gesture.getHeight();
        if (x <= w * ZX0 || x >= w * ZX1) return false;
        return zoom <= 1.01f || y > hgt * ZY1;
    }

    /** Góc phải dưới (phải vùng giữa, dưới dải trên): vuốt xuống đổi tỉ lệ khung hình. */
    private boolean inAspectCorner(float x, float y) {
        float w = gesture.getWidth(), hgt = gesture.getHeight();
        return x >= w * ZX1 && y > hgt * ZY1;
    }

    /** Vùng vuốt nhanh lên để phát nền: giống vùng vuốt xuống thoát (1x = cả dải giữa, đang zoom = phần giữa dải dưới). */
    private boolean inBgZone(float x, float y) {
        return inExitZone(x, y);
    }

    private static float smooth(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    /**
     * Vuốt nhanh lên: video khép lại thành hình tròn, thu nhỏ và bay lên góc trái thanh trạng thái,
     * xong mới chuyển sang phát nền.
     */
    private void swipeUpBackground() {
        if (player == null || handedOff || dismissing) return;
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            startBackgroundPlay(); // chưa có quyền thông báo: xin trước, không chạy hiệu ứng
            return;
        }
        dismissing = true; // chặn cảm ứng trong lúc chạy hiệu ứng
        ((View) playerView.getParent()).setBackgroundColor(Color.TRANSPARENT); // bỏ nền đen: hình bay trên màn hình phía sau
        stopMotion();
        h.removeCallbacks(hideRun);
        hideControls();
        info.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);

        final float w = Math.max(1, playerView.getWidth()), hgt = Math.max(1, playerView.getHeight());
        final float r0 = (float) Math.hypot(w, hgt) / 2f;     // vòng tròn phủ kín màn hình
        final float r1 = Math.min(w, hgt) * 0.25f;            // rồi khép lại
        final float[] rad = {r0};
        playerView.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                float cx = v.getWidth() / 2f, cy = v.getHeight() / 2f, r = rad[0];
                o.setRoundRect((int) (cx - r), (int) (cy - r), (int) (cx + r), (int) (cy + r), r);
            }
        });
        playerView.setClipToOutline(true);
        playerView.setPivotX(w / 2f);
        playerView.setPivotY(hgt / 2f);

        int sbId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        float sb = sbId > 0 ? getResources().getDimensionPixelSize(sbId) : dp(24);
        final float tx = dp(28) - w / 2f;      // tâm đích: góc trái, giữa thanh trạng thái
        final float ty = sb / 2f - hgt / 2f;

        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(420);
        va.addUpdateListener(a -> {
            float p = (float) a.getAnimatedValue();
            rad[0] = r0 + (r1 - r0) * smooth(p / 0.5f);          // 0 -> 0.5: khép thành tròn
            playerView.invalidateOutline();
            float m = smooth((p - 0.3f) / 0.7f);                 // từ 0.3: thu nhỏ + bay lên góc
            float sc = 1f + (0.14f - 1f) * m;
            playerView.setScaleX(sc);
            playerView.setScaleY(sc);
            playerView.setTranslationX(tx * m);
            playerView.setTranslationY(ty * m);
            playerView.setAlpha(p < 0.75f ? 1f : 1f - (p - 0.75f) / 0.25f);
        });
        va.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                doBackgroundPlay();
                overridePendingTransition(0, 0);
            }
        });
        va.start();
    }

    private void dragDown(float dy) {
        if (top.getVisibility() == View.VISIBLE) hideControls();
        h.removeCallbacks(hideRun);
        float ty = Math.max(0f, dy * DISMISS_GAIN);
        float p = Math.min(1f, ty / Math.max(1, gesture.getHeight()));
        playerView.setTranslationY(ty);
        playerView.setScaleX(1f - 0.12f * p);
        playerView.setScaleY(1f - 0.12f * p);
        playerView.setAlpha(1f - 0.5f * p);
    }

    private void restoreDrag() {
        playerView.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(200).setInterpolator(new DecelerateInterpolator()).start();
    }

    /**
     * Vuốt xuống nhanh: video lao xuống tiếp theo đà tay (vận tốc đầu = vận tốc lúc thả, có tăng tốc thêm),
     * vuốt càng nhanh càng phóng nhanh. Thả chậm: tăng tốc dần như cũ.
     */
    private void dismissPlayer(float vy) {
        dismissing = true;
        final float remain = Math.max(1f, gesture.getHeight() - playerView.getTranslationY());
        boolean fast = vy > 300f;
        long dur = 240L;
        android.animation.TimeInterpolator ip = new AccelerateInterpolator();
        if (fast) {
            final float v0 = Math.max(1200f, vy * DISMISS_BOOST); // px/s lúc buông tay
            final float acc = 9000f;                                // px/s^2: lao xuống nhanh dần
            float t = (float) ((-v0 + Math.sqrt(v0 * v0 + 2f * acc * remain)) / acc); // giây tới khi ra khỏi màn
            dur = (long) Math.max(90f, Math.min(450f, t * 1000f));
            final float tt = dur / 1000f;
            final float total = v0 * tt + 0.5f * acc * tt * tt;
            ip = x -> {
                float ts = x * tt;
                return Math.min(1f, (v0 * ts + 0.5f * acc * ts * ts) / total);
            };
        }
        playerView.animate().translationY(gesture.getHeight()).alpha(0f)
                .setDuration(dur)
                .setInterpolator(ip)
                .withEndAction(() -> {
                    exitPlayer();
                    overridePendingTransition(0, 0);
                }).start();
    }

    /** Thoát player. Mở từ nút Mở của phát nền: gỡ luôn task để về app trước đó, không rơi vào trang chủ của app. */
    private void exitPlayer() {
        if (openedFromBgBtn) finishAndRemoveTask();
        else finish();
    }

    private void doubleTapAction(float x, float y) {
        if (inPanZone(x, y)) { // hình chữ nhật giữa: 1x -> TAP_ZOOM, đang zoom -> về 1x
            toggleZoom(x, y);
            return;
        }
        float w = gesture.getWidth(); // dải dưới + 2 bên: tua / phát-tạm dừng
        if (x < w / 3) seekBy(-seekMs());
        else if (x > 2 * w / 3) seekBy(seekMs());
        else togglePlay(false); // chạm đôi: không bật thanh chức năng
    }

    private void startFling(float vx, float vy) {
        stopMotion();
        flingVx = vx;
        flingVy = vy;
        flinging = true;
        flingLast = System.nanoTime();
        Choreographer.getInstance().postFrameCallback(flingCb);
    }

    private void stopMotion() {
        flinging = false;
        Choreographer.getInstance().removeFrameCallback(flingCb);
        if (zoomAnim != null) {
            zoomAnim.cancel();
            zoomAnim = null;
        }
    }

    /** Chạm đôi vào vùng giữa: đang ~1x thì phóng 2x quanh điểm chạm, ngược lại về 1x. */
    private void toggleZoom(float fx, float fy) {
        stopMotion();
        final float z0 = zoom, px0 = panX, py0 = panY;
        final float zt = Math.abs(z0 - 1f) < 0.07f ? TAP_ZOOM : 1f;
        final float tx, ty;
        if (zt == 1f) {
            tx = 0;
            ty = 0;
        } else {
            float cx = playerView.getLeft() + playerView.getWidth() / 2f;
            float cy = playerView.getTop() + playerView.getHeight() / 2f;
            float px = fx - cx, py = fy - cy, r = zt / z0;
            tx = px - r * (px - px0);
            ty = py - r * (py - py0);
        }
        animateZoomTo(zt, tx, ty);
        toast(String.format(Locale.US, "%.1fx", zt));
    }

    /** Hoạt ảnh từ mức zoom/vị trí hiện tại tới (zt, tx, ty). */
    private void animateZoomTo(final float zt, final float tx, final float ty) {
        stopMotion();
        final float z0 = zoom, px0 = panX, py0 = panY;
        zoomAnim = ValueAnimator.ofFloat(0f, 1f);
        zoomAnim.setDuration(220);
        zoomAnim.setInterpolator(new DecelerateInterpolator());
        zoomAnim.addUpdateListener(an -> {
            float t = (float) an.getAnimatedValue();
            zoom = z0 + (zt - z0) * t;
            panX = px0 + (tx - px0) * t;
            panY = py0 + (ty - py0) * t;
            applyZoom();
        });
        zoomAnim.start();
    }

    /** Hình chữ nhật giữa (phía trên dải dưới): kéo dời khi zoom, chạm đôi đổi 1x/2x. */
    private boolean inPanZone(float x, float y) {
        float w = gesture.getWidth(), hgt = gesture.getHeight();
        return x > w * ZX0 && x < w * ZX1 && y < hgt * ZY1;
    }

    /** Đổi mức zoom nhưng giữ điểm (fx, fy) dưới ngón tay đứng yên. */
    private void zoomAbout(float nz, float fx, float fy) {
        float cx = playerView.getLeft() + playerView.getWidth() / 2f;
        float cy = playerView.getTop() + playerView.getHeight() / 2f;
        float px = fx - cx, py = fy - cy, r = nz / zoom;
        panX = px - r * (px - panX);
        panY = py - r * (py - panY);
        zoom = nz;
        applyZoom();
    }

    /** Thả tay gần mức 1x thì hít về đúng 1x (vừa màn hình). */
    private void snapZoom() {
        if (zoom != 1f && Math.abs(zoom - 1f) < 0.07f) {
            zoom = 1f;
            panX = panY = 0;
            applyZoom();
        }
    }

    private boolean cropMode() {
        return aspects[aspectIdx] == VideoFrame.ZOOM;
    }

    /**
     * Mức zoom nhỏ nhất: mặc định MIN_ZOOM. Chế độ FULL + màn dọc + video ngang: được thu nhỏ vượt MIN_ZOOM
     * tới khi chiều ngang video chạm 2 mép rồi dừng. Xoay ngang thì về lại MIN_ZOOM.
     */
    private float minZoom() {
        if (!cropMode()) return MIN_ZOOM;
        float m = playerView.cropMinZoom();
        return m > 0f ? Math.min(MIN_ZOOM, m) : MIN_ZOOM;
    }

    /** Kẹp vị trí để không lộ mép đen rồi áp lên mặt video. */
    private void applyZoom() {
        View sv = playerView.getVideoSurfaceView();
        if (sv == null) return;
        zoom = Math.max(minZoom(), zoom); // xoay ngang: đang vượt mức tối thiểu thì về đúng mức tối thiểu
        float cw = sv.getWidth(), ch = sv.getHeight();
        float mx = Math.max(0, (cw * zoom - playerView.getWidth()) / 2f);
        float my = Math.max(0, (ch * zoom - playerView.getHeight()) / 2f);
        panX = Math.max(-mx, Math.min(mx, panX));
        panY = Math.max(-my, Math.min(my, panY));
        sv.setPivotX(cw / 2f);
        sv.setPivotY(ch / 2f);
        sv.setScaleX(zoom);
        sv.setScaleY(zoom);
        sv.setTranslationX(panX);
        sv.setTranslationY(panY);
    }


    // ---------------- xem trước khi tua ----------------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showSeekUi(long target, long from, long dur) {
        if (!seekUiOn) seekThumb.setVisibility(View.GONE); // bắt đầu phiên mới: bỏ ảnh cũ
        seekT = target;
        seekFrom = from;
        seekDurMs = dur;
        seekUiOn = true;
        if (top.getVisibility() == View.VISIBLE) { // thanh cũ chạy theo tay
            h.removeCallbacks(hideRun);
            if (!dragging) seek.setProgress((int) target);
            posTv.setText(fmt(target));
            seekBarRow.setVisibility(View.INVISIBLE);
        } else { // thanh riêng, thấp hơn thanh cũ
            seekLine.set(target, dur);
            seekPos.setText(fmt(target));
            seekDur.setText(fmt(dur));
            seekBarRow.setVisibility(View.VISIBLE);
        }
        long d = target - from;
        seekTime.setText(fmt(target) + "[" + (d < 0 ? "-" : "+") + fmt(Math.abs(d)) + "]");
        seekOverlay.setVisibility(View.VISIBLE);
        layoutSeekUi();
        requestThumb(target);
    }

    private void hideSeekUi() {
        seekUiOn = false;
        thumbWant = -1;
        seekOverlay.setVisibility(View.INVISIBLE);
    }

    /** Đặt thẻ ảnh ngay trên thanh, giữa thẻ trùng với núm (kẹp trong màn hình). */
    private void layoutSeekUi() {
        if (!seekUiOn) return;
        int[] o = new int[2], l = new int[2];
        seekOverlay.getLocationOnScreen(o);
        float ax;
        if (seekBarRow.getVisibility() == View.VISIBLE) {
            seekLine.getLocationOnScreen(l);
            ax = l[0] - o[0] + seekLine.thumbX();
        } else {
            seek.getLocationOnScreen(l);
            float t = seekDurMs > 0 ? Math.min(1f, seekT / (float) seekDurMs) : 0f;
            int av = seek.getWidth() - seek.getPaddingLeft() - seek.getPaddingRight();
            ax = l[0] - o[0] + seek.getPaddingLeft() + t * av;
        }
        int barTop = l[1] - o[1];
        seekCard.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int cw = seekCard.getMeasuredWidth();
        float x = Math.max(dp(8), Math.min(seekOverlay.getWidth() - cw - dp(8), ax - cw / 2f));
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) seekCard.getLayoutParams();
        int bm = seekOverlay.getHeight() - barTop + dp(6);
        if (lp.bottomMargin != bm) {
            lp.bottomMargin = bm;
            seekCard.setLayoutParams(lp);
        }
        seekCard.setTranslationX(x);
    }

    private void requestThumb(long ms) {
        if (thumbDead) return;
        Bitmap c = thumbCache.get(ms / 1000);
        if (c != null) {
            thumbWant = -1;
            setThumb(c);
            return;
        }
        thumbWant = ms;
        if (!thumbBusy) runThumbJob();
    }

    private void setThumb(Bitmap b) {
        seekThumb.setImageBitmap(b);
        seekThumb.setVisibility(View.VISIBLE);
        layoutSeekUi();
    }

    /** Lấy khung hình ở nền (mỗi lần 1 việc, luôn lấy vị trí mới nhất). */
    private void runThumbJob() {
        final long want = thumbWant;
        if (want < 0 || thumbDead) return;
        thumbWant = -1;
        thumbBusy = true;
        if (thumbExec == null) thumbExec = Executors.newSingleThreadExecutor();
        thumbExec.execute(() -> {
            Bitmap b = null;
            boolean dead = false;
            try {
                if (mmr == null) openRetriever();
            } catch (Exception ex) {
                dead = true; // nguồn này không lấy được ảnh (vd HLS): chỉ hiện giờ
            }
            if (!dead) {
                try {
                    b = grab(want);
                } catch (Exception ignored) {
                }
            }
            final Bitmap fb = b;
            final boolean fd = dead;
            h.post(() -> {
                thumbBusy = false;
                if (isDestroyed()) return;
                if (fd) {
                    thumbDead = true;
                    return;
                }
                if (fb != null) {
                    thumbMiss = 0;
                    thumbCache.put(want / 1000, fb);
                    if (seekUiOn) setThumb(fb);
                } else if (++thumbMiss >= 3) {
                    thumbDead = true;
                }
                if (seekUiOn && thumbWant >= 0) runThumbJob();
            });
        });
    }

    private static void closeQuietly(MediaMetadataRetriever r) {
        if (r == null) return;
        try {
            r.release(); // compileSdk 35 khai báo throws IOException
        } catch (Exception ignored) {
        }
    }

    private void openRetriever() {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            String sch = mediaUri.getScheme();
            if ("http".equals(sch) || "https".equals(sch)) {
                Map<String, String> hd = new HashMap<>();
                hd.put("User-Agent", UA);
                if (referer != null && !referer.isEmpty()) hd.put("Referer", referer);
                // dùng cùng bộ đọc HTTP với player (redirect / Range / Referer) thay vì để retriever tự đọc mạng
                HttpMediaSource hs = new HttpMediaSource(getApplicationContext(), mediaUri.toString(), hd);
                try {
                    hs.open();
                    if (hs.looksLikeHls()) {
                        hs.close();
                        r.setDataSource(hs.finalUrl(), hd);
                    } else {
                        r.setDataSource(hs);
                        mmrSrc = hs;
                    }
                } catch (java.io.IOException ioe) {
                    hs.close();
                    throw new RuntimeException(ioe);
                }
            } else {
                r.setDataSource(getApplicationContext(), mediaUri);
            }
        } catch (RuntimeException ex) {
            closeQuietly(r);
            throw ex;
        }
        mmr = r;
    }

    private Bitmap grab(long ms) {
        Bitmap b = mmr.getFrameAtTime(ms * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        if (b == null) return null;
        final int th = 240;
        if (b.getHeight() > th) {
            int tw = Math.max(1, Math.round(b.getWidth() * (float) th / b.getHeight()));
            Bitmap s = Bitmap.createScaledBitmap(b, tw, th, true);
            if (s != b) b.recycle();
            b = s;
        }
        return b;
    }

    private void togglePlay() {
        togglePlay(true);
    }

    private void togglePlay(boolean showUi) {
        if (player.getState() == MpEngine.ENDED) player.seekTo(0);
        if (player.isPlaying()) player.pause();
        else player.play();
        if (showUi) showControls();
    }

    /** Thời gian tua (cài đặt): chạm đôi trái/phải và nút prev/next. */
    private long seekMs() {
        return SettingsActivity.seekSec(this) * 1000L;
    }

    private void seekBy(long ms) {
        long dur = Math.max(player.getDuration(), 0);
        timedSeek(Math.max(0, Math.min(dur, player.getCurrentPosition() + ms)));
        showInfo(ms > 0 ? "+10s" : "-10s");
    }

    private void timedSeek(long ms) {
        player.seekTo(ms);
    }

    private void showInfo(String s) {
        info.setText(s);
        info.setVisibility(View.VISIBLE);
    }

    /** Nút tai nghe: thoát màn hình, video tiếp tục phát nền (chỉ âm thanh) trong foreground service. */
    private void startBackgroundPlay() {
        if (player == null || handedOff) return;
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
            return; // xin quyền xong sẽ gọi lại doBackgroundPlay() (dù được hay từ chối)
        }
        doBackgroundPlay();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_NOTI) doBackgroundPlay(); // từ chối thông báo vẫn phát nền được
    }

    private void doBackgroundPlay() {
        if (player == null || handedOff) return;
        handedOff = true;
        h.removeCallbacks(holdRun);
        holdPaused = false;
        getSharedPreferences("pos", 0).edit().putLong(key,
                player.getState() == MpEngine.ENDED ? 0 : player.getCurrentPosition()).apply();
        if (playerListener != null) player.removeListener(playerListener);
        playerView.unbind(); // gỡ mặt hiển thị: chỉ còn tiếng, đỡ tốn pin
        sub.setVisibility(View.GONE);
        if (player.getState() == MpEngine.ENDED) player.seekTo(0);
        player.play();
        String title = ((TextView) findViewById(R.id.title)).getText().toString();
        BackgroundPlayService.start(this, player, mediaUri, title, referer);
        BackgroundPlayService.saveView(key, zoom, panX, panY, aspectIdx); // giữ zoom lúc phát nền, chỉ reset khi thoát hẳn
        // thoát ngay, không hiện chữ "Đang phát nền" và không có hoạt ảnh đóng (tránh màn đen còn lại)
        info.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);
        getWindow().getDecorView().setVisibility(View.INVISIBLE);
        exitPlayer();
        overridePendingTransition(0, 0);
    }

    private void restoreViewFromBg() {
        float[] v = BackgroundPlayService.takeView(key);
        if (v == null) return;
        int ai = (int) v[3];
        if (ai >= 0 && ai < aspects.length && ai != aspectIdx) {
            aspectIdx = ai;
            playerView.setResizeMode(aspects[ai]);
        }
        zoom = v[0];
        panX = v[1];
        panY = v[2];
        playerView.post(this::applyZoom);
    }

    private MoreSheet moreSheet;

    /** Đổi tỉ lệ khung hình (Vừa / FULL / Kéo) và nhớ lại. */
    private void setAspect(int i, boolean showToast) {
        aspectIdx = i;
        SettingsActivity.prefs(this).edit().putInt(SettingsActivity.K_ASPECT_VAL, aspectIdx).apply();
        playerView.setResizeMode(aspects[aspectIdx]);
        playerView.post(this::applyZoom);
        if (showToast) toast("Tỉ lệ: " + aspectNames[aspectIdx]);
    }

    /** Nút 3 chấm: bảng "Khác" (Bộ cân bằng bên trong mở EQ). */
    private void openMore() {
        if (moreSheet != null || player == null) return;
        h.removeCallbacks(hideRun);
        hideControls();
        int cnt = SettingsActivity.aspectEnabledCount(this);
        final int[] map = new int[Math.max(1, cnt)];
        String[] names = new String[map.length];
        int sel = -1, k = 0;
        for (int i = 0; i < aspects.length && k < map.length; i++) {
            if (cnt > 0 && !SettingsActivity.aspectEnabled(this, i)) continue;
            map[k] = i;
            names[k] = aspectNames[i];
            if (i == aspectIdx) sel = k;
            k++;
        }
        moreSheet = new MoreSheet(this, player, () -> {
            closeMore();
            openEq();
        }, this::closeMore, names, sel, i -> setAspect(map[i], false));
        ((FrameLayout) findViewById(android.R.id.content)).addView(moreSheet,
                new FrameLayout.LayoutParams(-1, -1));
    }

    private void closeMore() {
        if (moreSheet == null) return;
        if (moreSheet.getParent() instanceof android.view.ViewGroup) {
            ((android.view.ViewGroup) moreSheet.getParent()).removeView(moreSheet);
        }
        moreSheet = null;
    }

    private void openEq() {
        if (eqPanel == null) {
            eqPanel = new EqPanel(this, eq, this::closeEq);
            ((FrameLayout) eqHost).addView(eqPanel, new FrameLayout.LayoutParams(-1, -1));
        }
        eqPanel.refresh();
        eqOpen = true;
        h.removeCallbacks(hideRun);
        hideControls();
        layoutEq();
        eqHost.setVisibility(View.VISIBLE);
    }

    private void closeEq() {
        eq.save();
        eqOpen = false;
        eqHost.setVisibility(View.GONE);
        setVideoBottom(0);
        showControls();
    }

    /** Dọc: bảng chiếm 52% phía dưới, video co lại phía trên. Ngang: bảng nằm bên phải. */
    private void layoutEq() {
        if (!eqOpen) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        FrameLayout.LayoutParams lp;
        if (dm.heightPixels > dm.widthPixels) {
            int hh = (int) (dm.heightPixels * 0.52f);
            lp = new FrameLayout.LayoutParams(-1, hh, Gravity.BOTTOM);
            setVideoBottom(hh);
        } else {
            lp = new FrameLayout.LayoutParams((int) (dm.widthPixels * 0.5f), -1, Gravity.END);
            setVideoBottom(0);
        }
        eqHost.setLayoutParams(lp);
    }

    private void setVideoBottom(int b) {
        for (View v : new View[]{playerView, gesture, seekOverlay}) {
            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) v.getLayoutParams();
            p.bottomMargin = b;
            v.setLayoutParams(p);
        }
        playerView.post(this::applyZoom);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        layoutEq();
        stopMotion();
        panX = panY = 0; // xoay màn hình: đưa video về giữa (giữ nguyên mức zoom)
        playerView.post(this::applyZoom);
    }

    @Override
    public void onBackPressed() {
        if (moreSheet != null) closeMore();
        else if (eqOpen) closeEq();
        else if (openedFromBgBtn) exitPlayer();
        else super.onBackPressed();
    }

    private final Runnable hideRun = this::hideControls;

    private void showControls() {
        if (locked || eqOpen) return;
        sysUi(true);
        top.setVisibility(View.VISIBLE);
        quick.setVisibility(View.VISIBLE);
        camera.setVisibility(View.VISIBLE);
        bottom.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideRun);
        h.postDelayed(hideRun, 3500);
    }

    private void hideControls() {
        sysUi(false);
        collapseQuick();
        top.setVisibility(View.GONE);
        quick.setVisibility(View.GONE);
        camera.setVisibility(View.GONE);
        bottom.setVisibility(View.GONE);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (player != null && !dragging && !swiping) {
                long dur = player.getDuration();
                if (dur > 0) {
                    seek.setMax((int) dur);
                    seek.setSecondaryProgress((int) player.getBufferedPosition());
                    durTv.setText(fmt(dur));
                }
                seek.setProgress((int) player.getCurrentPosition());
                posTv.setText(fmt(player.getCurrentPosition()));
            }
            h.postDelayed(this, 500);
        }
    };

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        long hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        return hh > 0 ? String.format(Locale.US, "%d:%02d:%02d", hh, mm, ss)
                : String.format(Locale.US, "%02d:%02d", mm, ss);
    }

    private void toast(String s) {
        showInfo(s);
        h.postDelayed(() -> info.setVisibility(View.GONE), 1500);
    }

    private final long bornAt = android.os.SystemClock.uptimeMillis();

    /**
     * Luôn phủ toàn màn hình (bố cục không nhảy). Bảng chức năng hiện -> hiện thanh điều hướng + thanh trạng thái; ẩn -> ẩn cả hai.
     * Giống bản 15: lúc player vừa mở (hoạt ảnh chuyển màn hình) thanh trạng thái vẫn ẩn, chỉ bật thanh điều hướng,
     * để trang bên dưới (thư viện) không bị đổi vùng hiển thị rồi nhảy layout.
     */
    private void applySysUi() {
        boolean opening = android.os.SystemClock.uptimeMillis() - bornAt < 700;
        boolean statusShown = navShown && !opening;
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        if (!navShown) f |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
        if (!statusShown) f |= View.SYSTEM_UI_FLAG_FULLSCREEN;
        // theme có windowFullscreen=true (cờ cửa sổ) nên phải gỡ cờ đó thì thanh trạng thái mới hiện được
        if (statusShown) getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        else getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(f);
        if (navShown && opening) h.postDelayed(this::applySysUi, 720 - (android.os.SystemClock.uptimeMillis() - bornAt));
    }

    private void sysUi(boolean show) {
        if (navShown == show) return;
        navShown = show;
        applySysUi();
        applyInsets();
    }

    /** Khi thanh điều hướng hiện, đẩy các nút vào trong để không bị nó che. */
    private void applyInsets() {
        if (bottom == null) return;
        int l = navShown ? stL : 0, r = navShown ? stR : 0, b = navShown ? stB : 0;
        bottom.setPadding(dp(16) + l, bottom.getPaddingTop(), dp(16) + r, dp(14) + b);
        top.setPadding(dp(8) + l, top.getPaddingTop(), dp(8) + r, top.getPaddingBottom());
        FrameLayout.LayoutParams q = (FrameLayout.LayoutParams) quick.getLayoutParams();
        q.setMarginStart(dp(12) + l);
        quick.setLayoutParams(q);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) applySysUi();
    }


    /** Nút > mở rộng hàng chức năng + các nút mở rộng (ban đêm, popup, EQ, âm lượng, độ sáng, phụ đề). */
    private void setupQuickMore() {
        chevBtn = findViewById(R.id.chevron);
        chevBtn.setOnClickListener(v -> {
            quickOpen = !quickOpen;
            quickMore.setVisibility(quickOpen ? View.VISIBLE : View.GONE);
            chevBtn.setImageResource(quickOpen ? R.drawable.ic_left : R.drawable.ic_right);
            // nút < luôn ở mép phải hàng, phần mở rộng chèn bên trái; mở/thu đều cuộn về đầu bên trái
            quick.post(() -> ((android.widget.HorizontalScrollView) quick).scrollTo(0, 0));
            showControls();
        });
        findViewById(R.id.night).setOnClickListener(v -> {
            night = !night;
            nightOverlay.setVisibility(night ? View.VISIBLE : View.GONE);
            showControls();
        });
        findViewById(R.id.popup).setOnClickListener(v -> enterPip());
        findViewById(R.id.eqBtn).setOnClickListener(v -> openEq());
        findViewById(R.id.brtBtn).setOnClickListener(v -> {
            float b = getWindow().getAttributes().screenBrightness;
            sliderDialog("Độ sáng", R.drawable.ic_brightness, 100, Math.round((b < 0 ? 0.5f : b) * 100), p -> {
                float nb = Math.max(0.02f, p / 100f);
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = nb;
                getWindow().setAttributes(lp);
                SettingsActivity.prefs(this).edit().putFloat(SettingsActivity.K_BRIGHT_VAL, nb).apply();
            });
        });
        findViewById(R.id.subBtn).setOnClickListener(v -> ccBtn.performClick());
    }

    /**
     * Âm lượng theo % (0..100, từng 1%): chỉnh bậc âm lượng hệ thống gần nhất không thấp hơn,
     * phần còn lại hạ bằng hệ số âm lượng của trình phát -> đặt được 1%, 2%... dù máy chỉ có ~15 bậc.
     */
    private void setVolPct(int p) {
        p = Math.max(0, Math.min(100, p));
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        int s = p == 0 ? 0 : Math.max(1, (int) Math.ceil(p * max / 100.0));
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, s, 0);
        } catch (Exception ignored) {
        }
        int real = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        float g = 1f;
        if (real > 0 && p > 0) g = Math.min(1f, (p / 100f) / ((float) real / max));
        if (player != null) player.setGain(g);
        volPct = p;
        lastSysStep = real;
        SettingsActivity.prefs(this).edit().putInt("volPct", p).putInt("volStep", real).apply();
    }

    /** % hiện tại; nếu âm lượng hệ thống bị đổi từ ngoài (nút cứng...) thì bỏ hệ số riêng, tính lại theo bậc. */
    private int getVolPct() {
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        int step = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        if (volPct < 0 || step != lastSysStep) {
            volPct = Math.round(step * 100f / max);
            lastSysStep = step;
            if (player != null) player.setGain(1f);
        }
        return volPct;
    }

    /** Mở lại video: nếu bậc hệ thống vẫn như lần chỉnh trước thì áp lại hệ số để không to hơn đã đặt. */
    private void restoreVolGain() {
        android.content.SharedPreferences st = SettingsActivity.prefs(this);
        int sp = st.getInt("volPct", -1), ss = st.getInt("volStep", -1);
        if (sp >= 0 && ss == am.getStreamVolume(AudioManager.STREAM_MUSIC)) setVolPct(sp);
    }

    /** Đang chạm/cuộn hàng chức năng thì không tự ẩn; thả tay ra mới tính giờ lại như lúc bấm hiện bảng. */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int a = ev.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            quickTouch = false;
            if (quick != null && quick.getVisibility() == View.VISIBLE && !locked) {
                int[] loc = new int[2];
                quick.getLocationOnScreen(loc);
                float x = ev.getRawX(), y = ev.getRawY();
                if (x >= loc[0] && x <= loc[0] + quick.getWidth() && y >= loc[1] && y <= loc[1] + quick.getHeight()) {
                    quickTouch = true;
                    h.removeCallbacks(hideRun);
                }
            }
        } else if (quickTouch && (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)) {
            quickTouch = false;
            showControls();
        }
        return super.dispatchTouchEvent(ev);
    }

    /** Ẩn thanh chức năng thì phần mở rộng tự thu lại. */
    private void collapseQuick() {
        if (!quickOpen || quickMore == null) return;
        quickOpen = false;
        quickMore.setVisibility(View.GONE);
        chevBtn.setImageResource(R.drawable.ic_right);
        quick.scrollTo(0, 0);
    }

    private void hideSwipeBars() {
        volBar.setVisibility(View.GONE);
        brtBar.setVisibility(View.GONE);
    }

    private interface IntCb { void on(int v); }

    private void sliderDialog(String title, int iconRes, int max, int cur, IntCb cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), dp(16), dp(20), dp(8));
        ImageView ic = new ImageView(this);
        ic.setImageResource(iconRes);
        ic.setColorFilter(Color.WHITE);
        row.addView(ic, new LinearLayout.LayoutParams(dp(28), dp(28)));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(cur);
        row.addView(sb, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView num = new TextView(this);
        num.setTextColor(Color.WHITE);
        num.setText(String.valueOf(Math.round(cur * 100f / max)));
        row.addView(num);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                cb.on(p);
                num.setText(String.valueOf(Math.round(p * 100f / max)));
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        new android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(title).setView(row).setPositiveButton("OK", null).show();
        showControls();
    }

    /** Popup (hình trong hình). */
    private void enterPip() {
        if (player == null || handedOff) return;
        int w = player.getVideoWidth(), hgt = player.getVideoHeight();
        float r = (w > 0 && hgt > 0) ? (float) w / hgt : 16f / 9f;
        if (r < 0.42f || r > 2.39f) r = 16f / 9f;
        try {
            pipEntering = true;
            enterPictureInPictureMode(new android.app.PictureInPictureParams.Builder()
                    .setAspectRatio(new android.util.Rational(Math.round(r * 1000), 1000)).build());
        } catch (Exception e) {
            pipEntering = false;
            toast("Không bật được popup");
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean inPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        if (inPip) hideControls();
        else showControls();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // cửa sổ popup bị đóng (X) -> dừng phát
        if (pipEntering && !isInPictureInPictureMode()) {
            pipEntering = false;
            if (player != null && !handedOff) player.pause();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(holdRun);
        if (handedOff) return;
        if (pipEntering || isInPictureInPictureMode()) return; // popup: cứ để phát // player đã giao cho service, cứ để nó phát
        // đang phát (kể cả đang bị giữ tạm dừng) thì lúc quay lại phát tiếp; đang pause thì giữ nguyên
        resumeOnReturn = player != null && (holdPaused
                || (player.getPlayWhenReady() && player.getState() != MpEngine.ENDED));
        holdPaused = false;
        if (player != null) {
            getSharedPreferences("pos", 0).edit().putLong(key,
                    player.getState() == MpEngine.ENDED ? 0 : player.getCurrentPosition()).apply();
            player.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        pipEntering = false;
        if (resumeOnReturn && player != null) player.play();
        resumeOnReturn = false;
    }

    @Override
    protected void onDestroy() {
        stopMotion();
        if (thumbExec != null) {
            thumbExec.execute(() -> {
                closeQuietly(mmr);
                mmr = null;
                if (mmrSrc != null) {
                    mmrSrc.close();
                    mmrSrc = null;
                }
            });
            thumbExec.shutdown();
        }
        h.removeCallbacksAndMessages(null);
        if (player != null && !handedOff) {
            playerView.unbind();
            player.release(); // đã giao service thì KHÔNG release
        }
        player = null;
        super.onDestroy();
    }
}
