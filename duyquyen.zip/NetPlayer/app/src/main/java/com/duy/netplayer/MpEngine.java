package com.duy.netplayer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.media.TimedText;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.SurfaceTexture;
import android.view.Surface;

import androidx.media3.common.AuxEffectInfo;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.common.text.Cue;
import androidx.media3.common.text.CueGroup;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.cache.CacheDataSource;
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.SeekParameters;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Bọc android.media.MediaPlayer (thay ExoPlayer). Mọi lệnh tua đều dùng seekTo(ms, SEEK_CLOSEST).
 * Tự lo: audio focus, rút tai nghe thì tạm dừng, wake/wifi lock, tốc độ, tắt tiếng, phụ đề timed-text,
 * bộ cân bằng (EqEffects). Chỉ dùng trên main thread.
 * Activity và BackgroundPlayService chuyền nguyên đối tượng này cho nhau khi phát nền.
 */
final class MpEngine {
    static final int BUFFERING = 2, READY = 3, ENDED = 4;

    static abstract class Listener {
        void onState(int state) {}
        void onPlaying(boolean playing) {}
        void onSeekDone() {}
        void onVideoSize(int w, int h) {}
        void onFirstFrame() {}
        void onError(int what, int extra) {}
        void onSubtitle(String text) {}
    }

    final EqSettings eq;
    private final Context app;
    private final MediaPlayer mp = new MediaPlayer();
    private final EqEffects fx;
    private final AudioManager am;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build();
    private final boolean network;
    private Listener l;
    private WifiManager.WifiLock wifi;

    private boolean prepareStarted, prepared, released;
    private boolean playWhenReady, buffering, seeking, lastPlaying;
    private boolean pausedByFocus, muted, textOn = true, noisyRegistered;
    private int state = BUFFERING, bufPercent, vw, vh, textTrack = -1;
    private long seekTarget = -1, resumeMs;
    private float speed = 1f, appliedSpeed = 1f, duck = 1f, gain = 1f;
    private AudioFocusRequest focusReq;
    private Map<String, String> headers;
    private ExecutorService io;
    private boolean errored;
    // ExoPlayer: chỉ dùng cho link http(s). file / content:// vẫn chạy MediaPlayer + SEEK_CLOSEST như cũ.
    private ExoPlayer exo;
    private boolean exoSeeking, exoHasText, exoRetriedHls;
    private Uri exoUri;
    static volatile String lastExoError;

    MpEngine(Context c, EqSettings eq, Uri uri, String referer, long resumeMs) throws Exception {
        this.app = c.getApplicationContext();
        this.eq = eq;
        this.resumeMs = resumeMs;
        this.am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        String sch = uri.getScheme();
        network = "http".equals(sch) || "https".equals(sch);
        fx = new EqEffects(eq);
        eq.listener = fx::apply; // chỉnh bộ cân bằng thì áp ngay

        mp.setAudioAttributes(attrs);
        mp.setWakeMode(app, android.os.PowerManager.PARTIAL_WAKE_LOCK); // giữ CPU khi phát nền

        if (network) {
            headers = new HashMap<>();
            headers.put("User-Agent", PlayerActivity.UA);
            if (referer != null && !referer.isEmpty()) headers.put("Referer", referer);
        }
        // file / content:// mở trực tiếp.
        // URL http(s) phải resolve redirect trước: không để MediaPlayer tự treo ở URL
        // trung gian rồi mới chờ onError mới thử lại.
        this.srcUri = uri;
        if (!network) {
            mp.setDataSource(app, uri, headers);
            sourceSet = true;
        }

        mp.setOnPreparedListener(m -> onPrepared());
        mp.setOnVideoSizeChangedListener((m, w, hh) -> {
            vw = w;
            vh = hh;
            if (l != null) l.onVideoSize(w, hh);
        });
        mp.setOnSeekCompleteListener(m -> {
            seeking = false;
            seekTarget = -1;
            setState(buffering ? BUFFERING : READY);
            if (l != null) l.onSeekDone();
        });
        mp.setOnBufferingUpdateListener((m, p) -> bufPercent = p);
        mp.setOnInfoListener((m, what, extra) -> {
            if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                buffering = true;
                setState(BUFFERING);
            } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) {
                buffering = false;
                if (!seeking) setState(READY);
            } else if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
                if (l != null) l.onFirstFrame();
            }
            return false;
        });
        mp.setOnCompletionListener(m -> {
            seekTarget = -1;
            setState(ENDED);
            abandonFocus();
            unregisterNoisy();
            notifyPlaying();
        });
        mp.setOnErrorListener((m, what, extra) -> {
            fail(what, extra);
            return true;
        });
        if (network) {
            initExo(uri); // link mạng: ExoPlayer
        } else {
            videoTexture(); // mặt hiển thị cố định, đặt 1 lần trước khi chuẩn bị
            prepareOnce(); // chuẩn bị ngay, không đợi màn hình (gắn sau vẫn hiện hình)
        }
        h.postDelayed(watchdog, 2000);
    }

    /**
     * Canh việc mở video: fail nếu mạng không có thêm byte nào trong STALL_MS (hoặc quá MAX_OPEN_MS tổng cộng).
     * Link chậm nhưng vẫn đang tải thì được đợi tiếp, link đứng hẳn thì báo lỗi rõ ràng thay vì quay mãi.
     */
    private static final long STALL_MS = 25000, MAX_OPEN_MS = 120000;
    private final long openStart = SystemClock.uptimeMillis();
    private long lastBytes = -1, lastMove = openStart;
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            if (exo != null || prepared || errored || released) return;
            long now = SystemClock.uptimeMillis();
            HttpMediaSource s = src;
            long b = s != null ? s.receivedBytes() : LocalProxyServer.get().hlsReceived();
            if (b != lastBytes) {
                lastBytes = b;
                lastMove = now;
            }
            if (now - lastMove > STALL_MS || now - openStart > MAX_OPEN_MS) {
                App.saveLog(app, "Timeout mở video. " + probeInfo + " sourceSet=" + sourceSet
                        + " prepareStarted=" + prepareStarted + " bytes=" + b
                        + " lastError=" + (s != null ? s.lastError : null) + " hlsErr=" + LocalProxyServer.get().lastHlsError, null);
                fail(ERR_TIMEOUT, rangeOk ? 0 : 1);
                return;
            }
            h.postDelayed(this, 2000);
        }
    };

    static final int ERR_TIMEOUT = -9001, ERR_HTTP = -9002, ERR_NET = -9003, ERR_EXO = -9004;
    private boolean sourceSet;
    private boolean rangeOk = true; // server trả 206 cho Range?
    private String probeInfo = "";
    private Uri srcUri;
    private HttpMediaSource src; // nguồn HTTP riêng (null nếu file/content/HLS)
    private String proxyUrl;       // http://127.0.0.1:port/token nếu đang phát qua proxy nội bộ

    private void fail(int what, int extra) {
        if (errored || released) return;
        errored = true;
        if (src != null && src.lastError != null) App.saveLog(app, "Nguồn HTTP: " + src.lastError, null);
        playWhenReady = false;
        notifyPlaying();
        if (l != null) l.onError(what, extra);
    }

    /**
     * Link http(s): HttpMediaSource tự kết nối (theo redirect, đúng UA/Referer, thử Range), rồi đưa cho MediaPlayer
     * dưới dạng MediaDataSource nên MediaPlayer không còn tự đọc mạng (hay kẹt). HLS (.m3u8) thì vẫn để
     * MediaPlayer đọc theo địa chỉ cuối vì MediaDataSource không chạy được HLS.
     */
    private void resolveThenOpen(Uri uri) {
        // Link có .m3u8: bỏ bước dò (đỡ 1 vòng mạng), đưa thẳng cho proxy HLS (proxy tự tải playlist + đoạn đầu).
        if (uri.toString().toLowerCase(java.util.Locale.ROOT).contains(".m3u8")) {
            String hu = LocalProxyServer.get().registerHls(uri.toString(), headers);
            if (hu != null) {
                try {
                    proxyUrl = hu;
                    mp.setDataSource(app, Uri.parse(hu));
                    sourceSet = true;
                    prepareOnce();
                    return;
                } catch (Exception e) {
                    App.saveLog(app, "setDataSource HLS lỗi", e);
                    fail(MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
                    return;
                }
            }
        }
        if (io != null) io.shutdownNow();
        io = Executors.newSingleThreadExecutor();
        final HttpMediaSource s = new HttpMediaSource(app, uri.toString(), headers);
        src = s;
        io.execute(() -> {
            int code = 0;
            String err = null;
            try {
                s.open();
            } catch (HttpMediaSource.HttpStatusException e) {
                code = e.code;
                err = e.toString();
            } catch (Exception e) {
                err = e.toString();
            }
            final int fc = code;
            final String ferr = err;
            final String info = "url=" + s.finalUrl() + " http=" + (err == null ? (s.isRangeOk() ? 206 : 200) : fc)
                    + " range=" + s.isRangeOk() + " err=" + err;
            h.post(() -> {
                if (released || errored) {
                    s.close();
                    return;
                }
                probeInfo = info;
                rangeOk = s.isRangeOk();
                App.saveLog(app, "Probe " + info, null);
                if (ferr != null) {
                    s.close();
                    if (fc >= 400) fail(ERR_HTTP, fc);
                    else fail(ERR_NET, 0);
                    return;
                }
                try {
                    if (s.looksLikeHls()) {
                        // HLS: playlist + đoạn + key đều đi qua proxy nội bộ (gắn UA/Referer, theo redirect),
                        // MediaPlayer chỉ đọc localhost nên không kẹt vì header/redirect.
                        s.close();
                        src = null;
                        String hu = LocalProxyServer.get().registerHls(uri.toString(), headers);
                        if (hu != null) {
                            proxyUrl = hu;
                            mp.setDataSource(app, Uri.parse(hu));
                        } else {
                            mp.setDataSource(app, Uri.parse(s.finalUrl()), headers);
                        }
                    } else {
                        // Ưu tiên Local HTTP Proxy (MediaPlayer đọc localhost, HttpMediaSource lo mạng + pre-buffer moov);
                        // không mở được proxy thì đưa MediaDataSource trực tiếp.
                        String pu = LocalProxyServer.get().register(s);
                        if (pu != null) {
                            proxyUrl = pu;
                            mp.setDataSource(app, Uri.parse(pu));
                        } else {
                            mp.setDataSource(s);
                        }
                    }
                    sourceSet = true;
                    prepareOnce();
                } catch (Exception e) {
                    App.saveLog(app, "setDataSource lỗi", e);
                    fail(MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
                }
            });
        });
    }

    // ---------------- ExoPlayer (link http/https) ----------------

    private static SimpleCache exoCache;

    /** Cache đĩa 512MB cho link mạng (xem lại / tua lại không tải lại). */
    static synchronized SimpleCache exoCache(Context c) {
        if (exoCache == null) {
            exoCache = new SimpleCache(new java.io.File(c.getCacheDir(), "exo"),
                    new LeastRecentlyUsedCacheEvictor(512L * 1024 * 1024),
                    new StandaloneDatabaseProvider(c));
        }
        return exoCache;
    }

    /** Link mạng: luôn tua EXACT (đúng từng khung hình) như bản ExoPlayer gốc. File / content:// không đụng tới. */
    private void applyExoSeekMode() {
        if (exo == null) return;
        exo.setSeekParameters(SeekParameters.EXACT);
    }

    private void initExo(Uri uri) {
        exoUri = uri;
        DefaultHttpDataSource.Factory hf = new DefaultHttpDataSource.Factory()
                .setUserAgent(PlayerActivity.UA)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000);
        if (headers != null && headers.get("Referer") != null) {
            hf.setDefaultRequestProperties(java.util.Collections.singletonMap("Referer", headers.get("Referer")));
        }
        DataSource.Factory up = new DefaultDataSource.Factory(app, hf);
        DataSource.Factory df = new CacheDataSource.Factory()
                .setCache(exoCache(app))
                .setUpstreamDataSourceFactory(up)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);

        DefaultRenderersFactory rf = new DefaultRenderersFactory(app);
        rf.setEnableDecoderFallback(true);
        rf.forceEnableMediaCodecAsynchronousQueueing(); // giải mã bất đồng bộ: bỏ khung nhanh hơn khi tua
        // buffer nhỏ để phát lại nhanh sau khi tua (mặc định chờ 2,5s / 5s mới phát)
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(20000, 60000, 500, 1000)
                .build();

        exo = new ExoPlayer.Builder(app, rf)
                .setLoadControl(lc)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(df))
                .setHandleAudioBecomingNoisy(true)   // rút tai nghe -> tạm dừng
                .setWakeMode(C.WAKE_MODE_NETWORK)    // giữ CPU + wifi khi phát nền
                .build();
        if (loop) exo.setRepeatMode(Player.REPEAT_MODE_ONE); // chế độ lặp đặt trước khi exo được tạo
        exo.setAudioAttributes(new androidx.media3.common.AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true); // true = tự xử lý audio focus
        applyExoSeekMode();
        exo.setTrackSelectionParameters(exo.getTrackSelectionParameters().buildUpon()
                .setSelectUndeterminedTextLanguage(true).build());

        // bộ cân bằng: dùng audio session riêng để gắn audiofx trước khi phát
        try {
            int sid = am.generateAudioSessionId();
            if (sid > 0) {
                exo.setAudioSessionId(sid);
                int rid = fx.attachSession(sid);
                if (rid != 0) exo.setAuxEffectInfo(new AuxEffectInfo(rid, 1f));
            }
        } catch (Throwable t) {
            App.saveLog(app, "Gắn EQ cho ExoPlayer lỗi", t);
        }

        exo.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int st) {
                if (released) return;
                if (st == Player.STATE_ENDED) {
                    seekTarget = -1;
                    setState(ENDED);
                } else if (st == Player.STATE_READY) {
                    prepared = true;
                    setState(READY);
                    if (exoSeeking) {
                        exoSeeking = false;
                        if (l != null) l.onSeekDone();
                    }
                } else {
                    setState(BUFFERING);
                }
            }

            @Override
            public void onIsPlayingChanged(boolean playing) {
                if (!released) notifyPlaying();
            }

            @Override
            public void onPlayWhenReadyChanged(boolean pwr, int reason) {
                if (!released) notifyPlaying();
            }

            @Override
            public void onVideoSizeChanged(VideoSize v) {
                if (released) return;
                vw = Math.round(v.width * v.pixelWidthHeightRatio);
                vh = v.height;
                if (l != null) l.onVideoSize(vw, vh);
            }

            @Override
            public void onRenderedFirstFrame() {
                if (!released && l != null) l.onFirstFrame();
            }

            @Override
            public void onTracksChanged(Tracks t) {
                exoHasText = t.containsType(C.TRACK_TYPE_TEXT);
            }

            @Override
            public void onCues(CueGroup g) {
                if (released || l == null || !textOn) return;
                StringBuilder sb = new StringBuilder();
                for (Cue c : g.cues) {
                    if (c.text != null) {
                        if (sb.length() > 0) sb.append('\n');
                        sb.append(c.text);
                    }
                }
                l.onSubtitle(sb.toString());
            }

            @Override
            public void onPlayerError(PlaybackException e) {
                if (released) return;
                // Link HLS không có đuôi .m3u8: thử lại 1 lần với kiểu HLS
                if (!exoRetriedHls && (e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
                        || e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED)) {
                    exoRetriedHls = true;
                    exo.setMediaItem(new MediaItem.Builder().setUri(exoUri).setMimeType(MimeTypes.APPLICATION_M3U8).build());
                    exo.prepare();
                    return;
                }
                int what = ERR_EXO, extra = e.errorCode;
                Throwable c = e.getCause();
                if (c instanceof HttpDataSource.InvalidResponseCodeException) {
                    what = ERR_HTTP;
                    extra = ((HttpDataSource.InvalidResponseCodeException) c).responseCode;
                } else if (e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                        || e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
                    what = ERR_NET;
                    extra = 0;
                }
                lastExoError = e.getErrorCodeName() + (c != null ? ": " + c.getMessage() : "");
                App.saveLog(app, "ExoPlayer lỗi " + exoUri + " " + lastExoError, e);
                fail(what, extra);
            }
        });
        exo.setMediaItem(MediaItem.fromUri(uri), resumeMs > 0 ? resumeMs : C.TIME_UNSET);
        resumeMs = 0;
        exo.prepare();
    }

    private final Runnable exoSeekFallback = new Runnable() {
        @Override
        public void run() {
            if (exo != null && exoSeeking && !released && exo.getPlaybackState() == Player.STATE_READY) {
                exoSeeking = false;
                if (l != null) l.onSeekDone();
            }
        }
    };

    private Surface surface;
    private boolean prepareForced;

    static String errorText(int what, int extra) {
        if (what == ERR_EXO) return "Lỗi ExoPlayer: " + lastExoError;
        if (what == ERR_HTTP) return "Server từ chối: HTTP " + extra;
        if (what == ERR_NET) return "Không kết nối được tới link";
        if (what == ERR_TIMEOUT) return extra == 1
                ? "Server không hỗ trợ Range và không gửi thêm dữ liệu trong 25 giây"
                : "Không nhận được dữ liệu trong 25 giây, link chậm hoặc đã chết";
        if (extra == -1004) {
            String he = LocalProxyServer.get().lastHlsError;
            return "Lỗi đọc dữ liệu (IO) - link chết hoặc server chặn" + (he != null ? "\n" + he : "");
        }
        if (extra == -1007 || extra == -1010) return "Định dạng video máy không hỗ trợ";
        if (extra == -110) return "Kết nối quá hạn";
        return "Lỗi phát (" + what + "/" + extra + ")";
    }

    // ---------------- vòng đời ----------------

    private void prepareOnce() {
        if (prepareStarted || released || errored) return;
        if (!sourceSet) { // link mạng chưa xử lý xong chuyển hướng: lát nữa tự chạy
            prepareForced = true;
            return;
        }
        prepareStarted = true;
        try {
            mp.prepareAsync();
        } catch (Exception e) {
            fail(MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
        }
    }

    private void onPrepared() {
        if (released) return;
        prepared = true;
        fx.attach(mp);
        try {
            MediaPlayer.TrackInfo[] ti = mp.getTrackInfo();
            for (int i = 0; i < ti.length; i++) {
                if (ti[i].getTrackType() == MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_TIMEDTEXT) {
                    textTrack = i;
                    break;
                }
            }
            if (textTrack >= 0) {
                mp.setOnTimedTextListener((m, t) -> emitSubtitle(t));
                if (textOn) mp.selectTrack(textTrack);
            }
        } catch (Exception ignored) {
        }
        applyVolume();
        setState(READY);
        if (resumeMs > 0) {
            long r = resumeMs;
            resumeMs = 0;
            seekTo(r);
        }
        if (playWhenReady) startInternal();
    }

    private boolean loop;

    /** Lặp lại 1 video (Không lặp / Lặp lại). */
    void setLoop(boolean on) {
        loop = on;
        if (released) return;
        try { if (exo != null) exo.setRepeatMode(on ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF); } catch (Throwable ignored) {}
        try { if (mp != null) mp.setLooping(on); } catch (Throwable ignored) {}
    }

    boolean isLoop() {
        return loop;
    }

    /** Audio session đang phát (Exo dùng session riêng, MediaPlayer dùng session của nó); 0 nếu chưa có. */
    int audioSession() {
        try {
            if (exo != null) return exo.getAudioSessionId();
            return mp.getAudioSessionId();
        } catch (Throwable t) {
            return 0;
        }
    }

    void release() {
        if (released) return;
        released = true;
        h.removeCallbacksAndMessages(null);
        if (exo != null) {
            try {
                exo.release();
            } catch (Exception ignored) {
            }
            exo = null;
        }
        if (io != null) io.shutdownNow();
        abandonFocus();
        unregisterNoisy();
        releaseWifi();
        eq.listener = null;
        fx.release();
        l = null;
        try {
            mp.setSurface(null);
        } catch (Exception ignored) {
        }
        mp.release();
        releaseVideoSurface();
        LocalProxyServer.get().unregister(proxyUrl);
        proxyUrl = null;
        if (src != null) src.close();
    }

    void setListener(Listener x) {
        l = x;
    }

    void removeListener(Listener x) {
        if (l == x) l = null;
    }

    /** Gắn/gỡ mặt hiển thị. Gỡ (null) = phát nền chỉ còn tiếng. */
    void setSurface(Surface s) {
        surface = s;
        if (released) return;
        if (exo != null) {
            exo.setVideoSurface(s);
            return;
        }
        try {
            mp.setSurface(s);
        } catch (Exception ignored) {
        }
        if (s != null) prepareOnce();
    }

    // ---- MediaPlayer (file / content://): MỘT mặt hiển thị duy nhất suốt đời engine ----
    // Đổi mặt hiển thị (kể cả null) khi MediaPlayer đang chạy làm framework huỷ decoder hình, dựng lại và
    // tua về khung khóa trước đó (lùi vài giây + khựng). Nên mặt hiển thị chỉ đặt 1 lần; màn hình (TextureView)
    // mượn lại SurfaceTexture này, còn lúc phát nền thì SurfaceDrain hút khung để decoder không bị nghẽn.
    private SurfaceTexture vst;
    private Surface vsurf;
    private SurfaceDrain drain;

    boolean constSurface() {
        return !network;
    }

    synchronized SurfaceTexture videoTexture() {
        if (vst == null && !released && !network) {
            vst = new SurfaceTexture(false); // chế độ tách rời: TextureView / SurfaceDrain tự gắn vào GL của mình
            vsurf = new Surface(vst);
            try {
                mp.setSurface(vsurf);
            } catch (Exception ignored) {
            }
        }
        return vst;
    }

    /** Có màn hình nhận lại SurfaceTexture: ngừng hút khung. */
    synchronized void stopDrain() {
        if (drain != null) {
            drain.stop();
            drain = null;
        }
    }

    /** Mất màn hình (phát nền / đóng): hút khung để decoder chạy đúng nhịp, không nghẽn. */
    synchronized void startDrain() {
        if (released || vst == null || drain != null) return;
        drain = new SurfaceDrain(app, vst);
        drain.start();
    }

    synchronized void releaseVideoSurface() {
        stopDrain();
        if (vsurf != null) {
            try {
                vsurf.release();
            } catch (Exception ignored) {
            }
            vsurf = null;
        }
        if (vst != null) {
            try {
                vst.release();
            } catch (Exception ignored) {
            }
            vst = null;
        }
    }

    // ---------------- phát / tạm dừng ----------------

    void play() {
        if (released) return;
        if (exo != null) {
            playWhenReady = true;
            if (exo.getPlaybackState() == Player.STATE_ENDED) exo.seekTo(0);
            exo.setPlayWhenReady(true);
            notifyPlaying();
            return;
        }
        playWhenReady = true;
        pausedByFocus = false;
        if (prepared) startInternal();
        else notifyPlaying();
    }

    void pause() {
        if (released) return;
        if (exo != null) {
            playWhenReady = false;
            exo.setPlayWhenReady(false);
            notifyPlaying();
            return;
        }
        playWhenReady = false;
        pausedByFocus = false;
        pauseInternal();
        abandonFocus();
        notifyPlaying();
    }

    private void startInternal() {
        if (!prepared || released) return;
        requestFocus();
        try {
            if (state == ENDED) setState(READY); // start() sau khi hết = phát lại từ đầu
            mp.start();
            if (speed != appliedSpeed) applySpeed();
        } catch (Exception e) {
            if (l != null) l.onError(MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
            return;
        }
        registerNoisy();
        acquireWifi();
        notifyPlaying();
    }

    private void pauseInternal() {
        if (prepared) {
            try {
                if (mp.isPlaying()) mp.pause();
            } catch (Exception ignored) {
            }
        }
        unregisterNoisy();
        releaseWifi();
    }

    boolean isPlaying() {
        if (exo != null && !released) return exo.isPlaying();
        if (!prepared || released) return false;
        try {
            return mp.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    boolean getPlayWhenReady() {
        if (exo != null && !released) return exo.getPlayWhenReady();
        return playWhenReady;
    }

    int getState() {
        return state;
    }

    private void setState(int s) {
        if (state == s) return;
        state = s;
        if (l != null) l.onState(s);
        notifyPlaying();
    }

    private void notifyPlaying() {
        boolean p = isPlaying();
        if (p != lastPlaying) {
            lastPlaying = p;
            if (l != null) l.onPlaying(p);
        } else if (l != null) {
            l.onPlaying(p); // playWhenReady đổi mà isPlaying không đổi: vẫn báo để thanh thông báo cập nhật
        }
    }

    // ---------------- tua ----------------

    /** Luôn SEEK_CLOSEST: dừng đúng khung hình gần vị trí đích nhất. */
    void seekTo(long ms) {
        if (released) return;
        if (exo != null) {
            long d = getDuration();
            long t = Math.max(0, ms);
            if (d > 0) t = Math.min(t, d);
            exoSeeking = true;
            applyExoSeekMode();
            h.removeCallbacks(exoSeekFallback);
            h.postDelayed(exoSeekFallback, 1500);
            exo.seekTo(t);
            return;
        }
        if (!prepared) {
            resumeMs = Math.max(0, ms);
            return;
        }
        long dur = getDuration();
        long t = Math.max(0, ms);
        if (dur > 0) t = Math.min(t, dur);
        seeking = true;
        seekTarget = t;
        if (state == ENDED) state = READY;
        setState(BUFFERING);
        try {
            mp.seekTo(t, MediaPlayer.SEEK_CLOSEST);
        } catch (Exception e) {
            seeking = false;
            seekTarget = -1;
            setState(READY);
        }
    }

    long getCurrentPosition() {
        if (exo != null && !released) return Math.max(0, exo.getCurrentPosition());
        if (seekTarget >= 0) return seekTarget; // đang tua: trả về đích cho giao diện
        if (!prepared || released) return Math.max(0, resumeMs);
        try {
            return mp.getCurrentPosition();
        } catch (Exception e) {
            return 0;
        }
    }

    /** &lt;= 0 nghĩa là chưa biết (live). */
    long getDuration() {
        if (exo != null && !released) {
            long d = exo.getDuration();
            return d == C.TIME_UNSET || d <= 0 ? -1 : d;
        }
        if (!prepared || released) return -1;
        try {
            return mp.getDuration();
        } catch (Exception e) {
            return -1;
        }
    }

    long getBufferedPosition() {
        if (exo != null && !released) {
            long d = getDuration();
            long b = exo.getBufferedPosition();
            return d > 0 ? Math.min(d, b) : b;
        }
        long d = getDuration();
        if (d <= 0) return 0;
        HttpMediaSource s = src;
        if (s != null && s.getSize() > 0) {
            long sz = s.getSize();
            long from = (long) ((double) getCurrentPosition() / d * sz);
            long end = s.contiguousEnd(Math.max(0, Math.min(sz - 1, from)));
            return Math.min(d, (long) ((double) end / sz * d));
        }
        return network ? d * Math.max(0, Math.min(100, bufPercent)) / 100 : d;
    }

    int getVideoWidth() {
        return vw;
    }

    int getVideoHeight() {
        return vh;
    }

    // ---------------- tốc độ / âm lượng ----------------

    void setSpeed(float s) {
        speed = s;
        if (exo != null && !released) {
            exo.setPlaybackParameters(new PlaybackParameters(s));
            return;
        }
        if (isPlaying()) applySpeed(); // đang tạm dừng mà đặt tốc độ thì một số máy tự phát -> đợi start()
    }

    float getSpeed() {
        return speed;
    }

    private void applySpeed() {
        try {
            mp.setPlaybackParams(new PlaybackParams().setSpeed(speed));
            appliedSpeed = speed;
        } catch (Exception ignored) { // máy/nguồn không hỗ trợ đổi tốc độ
        }
    }

    void setMuted(boolean m) {
        muted = m;
        applyVolume();
    }

    /** Hệ số âm lượng riêng của trình phát (0..1), nhân thêm vào âm lượng hệ thống để chỉnh mịn từng %. */
    void setGain(float g) {
        gain = Math.max(0f, Math.min(1f, g));
        applyVolume();
    }

    boolean isMuted() {
        return muted;
    }

    private void applyVolume() {
        if (released) return;
        if (exo != null) {
            exo.setVolume(muted ? 0f : gain);
            return;
        }
        float v = muted ? 0f : duck * gain;
        try {
            mp.setVolume(v, v);
        } catch (Exception ignored) {
        }
    }

    // ---------------- phụ đề timed-text ----------------

    boolean hasTimedText() {
        if (exo != null) return exoHasText;
        return textTrack >= 0;
    }

    void setTimedTextEnabled(boolean on) {
        textOn = on;
        if (exo != null && !released) {
            exo.setTrackSelectionParameters(exo.getTrackSelectionParameters().buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !on).build());
            if (!on && l != null) l.onSubtitle("");
            return;
        }
        if (!prepared || released || textTrack < 0) return;
        try {
            if (on) mp.selectTrack(textTrack);
            else {
                mp.deselectTrack(textTrack);
                if (l != null) l.onSubtitle("");
            }
        } catch (Exception ignored) {
        }
    }

    private void emitSubtitle(TimedText t) {
        if (l == null) return;
        String s = t == null ? null : t.getText();
        l.onSubtitle(s == null ? "" : s);
    }

    // ---------------- audio focus / rút tai nghe ----------------

    private void requestFocus() {
        if (focusReq != null) return;
        focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(this::onFocus, h)
                .build();
        am.requestAudioFocus(focusReq);
    }

    private void abandonFocus() {
        if (focusReq == null) return;
        am.abandonAudioFocusRequest(focusReq);
        focusReq = null;
    }

    private void onFocus(int f) {
        if (released) return;
        switch (f) {
            case AudioManager.AUDIOFOCUS_LOSS:
                playWhenReady = false;
                pausedByFocus = false;
                pauseInternal();
                abandonFocus();
                notifyPlaying();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (playWhenReady) {
                    pausedByFocus = true;
                    pauseInternal();
                    notifyPlaying();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                duck = 0.2f;
                applyVolume();
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                duck = 1f;
                applyVolume();
                if (pausedByFocus) {
                    pausedByFocus = false;
                    if (playWhenReady) startInternal();
                }
                break;
            default:
                break;
        }
    }

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            pause(); // rút tai nghe -> tạm dừng
        }
    };

    private void registerNoisy() {
        if (noisyRegistered) return;
        IntentFilter f = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(noisy, f, Context.RECEIVER_NOT_EXPORTED);
        else app.registerReceiver(noisy, f);
        noisyRegistered = true;
    }

    private void unregisterNoisy() {
        if (!noisyRegistered) return;
        noisyRegistered = false;
        try {
            app.unregisterReceiver(noisy);
        } catch (Exception ignored) {
        }
    }

    // ---------------- wifi lock (phát nền qua mạng) ----------------

    private void acquireWifi() {
        if (!network) return;
        try {
            if (wifi == null) {
                WifiManager wm = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
                wifi = wm.createWifiLock(Build.VERSION.SDK_INT >= 29
                        ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                        : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "NetPlayer");
                wifi.setReferenceCounted(false);
            }
            if (!wifi.isHeld()) wifi.acquire();
        } catch (Exception ignored) {
        }
    }

    private void releaseWifi() {
        try {
            if (wifi != null && wifi.isHeld()) wifi.release();
        } catch (Exception ignored) {
        }
    }
}
