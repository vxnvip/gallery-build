package com.duy.netplayer;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Bảng "Khác" (nút 3 chấm): lưới chức năng + Phát + Tỉ lệ hình ảnh.
 * Chỉ 2 mục chạy thật: Bộ cân bằng (mở EQ) và Lặp lại (bấm để chuyển Không lặp <-> Lặp lại toàn bộ, đổi icon).
 * Các mục còn lại chỉ để hiển thị, bấm không làm gì.
 */
final class MoreSheet extends FrameLayout {
    private static final int GREEN = 0xFF5BC27A, SUB = 0xFF9E9E9E;

    private final MpEngine player;
    private final Runnable onEq, onDismiss;
    private ImageView repeatIcon;
    private TextView repeatLabel;

    private final TextView[] aspectTiles;

    MoreSheet(Context c, MpEngine player, Runnable onEq, Runnable onDismiss,
              String[] aspectNames, int aspectSel, java.util.function.IntConsumer onAspect) {
        super(c);
        this.player = player;
        this.onEq = onEq;
        this.onDismiss = onDismiss;

        setBackgroundColor(0x66000000);
        setClickable(true);
        setOnClickListener(v -> this.onDismiss.run()); // chạm ra ngoài bảng thì đóng
        setPadding(0, dp(48), 0, 0);

        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setClickable(true); // nuốt chạm trong bảng
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFA121212);
        bg.setCornerRadii(new float[]{dp(16), dp(16), dp(16), dp(16), 0, 0, 0, 0});
        panel.setBackground(bg);
        panel.setPadding(dp(8), dp(12), dp(8), dp(24));

        panel.addView(row(
                tile(R.drawable.ic_music, "Chọn Âm Thanh", null),
                tile(R.drawable.ic_headphones, "Phát Nền", null),
                tile(R.drawable.ic_cc, "Phụ đề", null),
                tile(R.drawable.ic_tune, "Bộ cân bằng", v -> this.onEq.run())));
        panel.addView(row(
                tile(R.drawable.ic_heart, "Mục yêu thích của tôi", null),
                tile(R.drawable.ic_bookmark, "Đánh dấu", null),
                tile(R.drawable.ic_delete, "Xóa bỏ", null),
                tile(R.drawable.ic_more_circle, "Khác", null)));
        panel.addView(divider());

        panel.addView(section("Phát"));
        View repeat = tile(R.drawable.ic_repeat_off, "Không lặp", v -> {
            boolean on = !SettingsActivity.prefs(getContext()).getBoolean(SettingsActivity.K_LOOP, false);
            SettingsActivity.prefs(getContext()).edit().putBoolean(SettingsActivity.K_LOOP, on).apply();
            if (player != null) player.setLoop(on);
            refreshRepeat();
        });
        repeatIcon = (ImageView) ((LinearLayout) repeat).getChildAt(0);
        repeatLabel = (TextView) ((LinearLayout) repeat).getChildAt(1);
        refreshRepeat();
        panel.addView(row(
                repeat,
                tile(R.drawable.ic_moon, "Chế độ nền tối", null),
                textIconTile("AB", "Lặp lại AB"),
                tile(R.drawable.ic_flip, "Phản chiếu", null)));
        panel.addView(divider());

        panel.addView(section("Tỉ lệ hình ảnh"));
        aspectTiles = new TextView[aspectNames.length];
        View[] at = new View[aspectNames.length];
        for (int i = 0; i < aspectNames.length; i++) {
            final int idx = i;
            aspectTiles[i] = (TextView) textTile(aspectNames[i]);
            aspectTiles[i].setOnClickListener(v -> {
                onAspect.accept(idx);
                refreshAspect(idx);
            });
            at[i] = aspectTiles[i];
        }
        refreshAspect(aspectSel);
        panel.addView(row(at));

        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(false);
        sv.addView(panel);
        addView(sv, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private View row(View... items) {
        LinearLayout r = new LinearLayout(getContext());
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (View v : items) r.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        return r;
    }

    private View divider() {
        View d = new View(getContext());
        d.setBackgroundColor(0x22FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
        lp.setMargins(dp(16), dp(8), dp(16), dp(8));
        d.setLayoutParams(lp);
        return d;
    }

    private View section(String s) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextColor(SUB);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(12), dp(12), dp(12), dp(4));
        return t;
    }

    private LinearLayout tileBase(String label) {
        LinearLayout t = new LinearLayout(getContext());
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(4), dp(14), dp(4), dp(14));
        return t;
    }

    private TextView label(String s) {
        TextView l = new TextView(getContext());
        l.setText(s);
        l.setTextColor(Color.WHITE);
        l.setTextSize(15);
        l.setTypeface(Typeface.DEFAULT_BOLD);
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(8), 0, 0);
        return l;
    }

    private View tile(int icon, String text, OnClickListener click) {
        LinearLayout t = tileBase(text);
        ImageView iv = new ImageView(getContext());
        iv.setImageResource(icon);
        t.addView(iv, new LinearLayout.LayoutParams(dp(30), dp(30)));
        t.addView(label(text));
        if (click != null) t.setOnClickListener(click);
        return t;
    }

    /** Icon là chữ trong khung viền (cho "AB"). */
    private View textIconTile(String glyph, String text) {
        LinearLayout t = tileBase(text);
        TextView box = new TextView(getContext());
        box.setText(glyph);
        box.setTextColor(Color.WHITE);
        box.setTextSize(11);
        box.setTypeface(Typeface.DEFAULT_BOLD);
        box.setGravity(Gravity.CENTER);
        GradientDrawable b = new GradientDrawable();
        b.setColor(Color.TRANSPARENT);
        b.setStroke(dp(2), Color.WHITE);
        b.setCornerRadius(dp(4));
        box.setBackground(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(26), dp(22));
        lp.topMargin = dp(4);
        lp.bottomMargin = dp(4);
        t.addView(box, lp);
        t.addView(label(text));
        return t;
    }

    private View textTile(String text) {
        TextView l = label(text);
        l.setTextSize(20);
        l.setPadding(0, dp(16), 0, dp(16));
        return l;
    }

    private void refreshAspect(int sel) {
        for (int i = 0; i < aspectTiles.length; i++) {
            aspectTiles[i].setTextColor(i == sel ? GREEN : Color.WHITE);
        }
    }

    /** Bấm là chuyển: Không lặp (icon gạch chéo, trắng) <-> Lặp lại toàn bộ (icon xanh). */
    private void refreshRepeat() {
        boolean on = SettingsActivity.prefs(getContext()).getBoolean(SettingsActivity.K_LOOP, false);
        repeatIcon.setImageResource(on ? R.drawable.ic_repeat : R.drawable.ic_repeat_off);
        if (on) repeatIcon.setColorFilter(GREEN);
        else repeatIcon.clearColorFilter();
        repeatLabel.setText(on ? "Lặp lại" : "Không lặp");
        repeatLabel.setTextColor(on ? GREEN : Color.WHITE);
    }
}
