package com.duy.netplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Bảng "Bộ cân bằng": preset, 10 băng (2 trang x 5), âm vang, tăng trầm, ảo hóa âm thanh. */
final class EqPanel extends LinearLayout {
    private static final int GREEN = 0xFF5CC97C;

    private final Activity act;
    private final EqSettings s;
    private final EqSlider[] bands = new EqSlider[EqSettings.N];
    private final TextView[] chips = new TextView[EqSettings.PRESET_NAMES.length];
    private EqSlider bassSl, virtSl;
    private TextView reverbVal;
    private Switch sw;
    private View content;
    private boolean updating;
    private final float dp;

    EqPanel(Activity a, EqSettings settings, Runnable onClose) {
        super(a);
        act = a;
        s = settings;
        dp = a.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setBackgroundColor(0xFF000000);
        setClickable(true); // không cho chạm xuyên xuống lớp cử chỉ

        // --- tiêu đề ---
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(px(10), 0, px(16), 0);
        ImageView back = icon(R.drawable.ic_eq_back, 10);
        back.setOnClickListener(v -> onClose.run());
        head.addView(back, new LayoutParams(px(48), px(48)));
        TextView title = text("Bộ cân bằng", 22, 0xFFFFFFFF, true);
        LayoutParams tp = new LayoutParams(0, -2, 1f);
        tp.leftMargin = px(10);
        head.addView(title, tp);
        ImageView reset = icon(R.drawable.ic_eq_refresh, 10);
        reset.setOnClickListener(v -> {
            s.reset();
            s.publish();
            s.save();
            refresh();
        });
        head.addView(reset, new LayoutParams(px(48), px(48)));
        sw = new Switch(a);
        sw.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{GREEN, 0xFF9E9E9E}));
        sw.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0xFF2F6B47, 0xFF3A3A3A}));
        sw.setOnCheckedChangeListener((b, on) -> {
            if (updating) return;
            s.enabled = on;
            s.publish();
            s.save();
            content.setAlpha(on ? 1f : 0.4f);
        });
        head.addView(sw, new LayoutParams(-2, -2));
        addView(head, new LayoutParams(-1, px(56)));

        // --- phần cuộn ---
        ScrollView scroll = new ScrollView(a);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(a);
        body.setOrientation(VERTICAL);
        content = body;
        scroll.addView(body, new FrameLayout.LayoutParams(-1, -2));
        addView(scroll, new LayoutParams(-1, 0, 1f));

        // preset
        HorizontalScrollView cs = new HorizontalScrollView(a);
        cs.setHorizontalScrollBarEnabled(false);
        LinearLayout crow = new LinearLayout(a);
        crow.setOrientation(HORIZONTAL);
        crow.setPadding(px(16), px(6), px(8), px(6));
        for (int i = 0; i < chips.length; i++) {
            final int idx = i;
            TextView t = text(EqSettings.PRESET_NAMES[i], 15, 0xFFFFFFFF, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(px(18), px(9), px(18), px(9));
            t.setOnClickListener(v -> {
                s.applyPreset(idx);
                s.publish();
                s.save();
                refresh();
            });
            LayoutParams lp = new LayoutParams(-2, -2);
            lp.rightMargin = px(10);
            crow.addView(t, lp);
            chips[i] = t;
        }
        cs.addView(crow);
        body.addView(cs, new LayoutParams(-1, -2));

        // 10 băng
        final int sliderH = px(170);
        LinearLayout area = new LinearLayout(a);
        area.setOrientation(HORIZONTAL);
        area.setPadding(0, px(14), 0, 0);
        FrameLayout scale = new FrameLayout(a);
        String[] sc = {"15", "0", "-15"};
        int[] grav = {Gravity.TOP, Gravity.CENTER_VERTICAL, Gravity.BOTTOM};
        for (int i = 0; i < 3; i++) {
            TextView t = text(sc[i], 17, 0xFFFFFFFF, true);
            t.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-1, -2, grav[i] | Gravity.CENTER_HORIZONTAL);
            fp.topMargin = i == 0 ? px(6) : 0;
            fp.bottomMargin = i == 2 ? px(6) : 0;
            scale.addView(t, fp);
        }
        area.addView(scale, new LayoutParams(px(46), sliderH));

        final Pager pager = new Pager(a);
        LinearLayout pages = new LinearLayout(a);
        pages.setOrientation(HORIZONTAL);
        for (int pg = 0; pg < 2; pg++) {
            LinearLayout page = new LinearLayout(a);
            page.setOrientation(HORIZONTAL);
            for (int k = 0; k < 5; k++) {
                final int b = pg * 5 + k;
                LinearLayout col = new LinearLayout(a);
                col.setOrientation(VERTICAL);
                col.setGravity(Gravity.CENTER_HORIZONTAL);
                EqSlider sl = new EqSlider(a, true, -EqSettings.MAX_DB, EqSettings.MAX_DB);
                sl.listener = v -> {
                    if (updating) return;
                    s.gains[b] = v;
                    s.preset = -1;
                    s.publish();
                    updateChips();
                };
                sl.onStop = s::save;
                bands[b] = sl;
                col.addView(sl, new LayoutParams(-1, sliderH));
                TextView lb = text(EqSettings.LABEL[b], 14, 0xFF7C7C7C, true);
                lb.setGravity(Gravity.CENTER);
                lb.setPadding(0, px(10), 0, 0);
                col.addView(lb, new LayoutParams(-1, -2));
                page.addView(col, new LayoutParams(0, -2, 1f));
            }
            pages.addView(page, new LayoutParams(px(300), -2));
            pager.pages[pg] = page;
        }
        pager.addView(pages);
        area.addView(pager, new LayoutParams(0, -2, 1f));
        body.addView(area, new LayoutParams(-1, -2));

        // âm vang
        LinearLayout rv = new LinearLayout(a);
        rv.setOrientation(HORIZONTAL);
        rv.setGravity(Gravity.CENTER_VERTICAL);
        rv.setPadding(px(16), px(4), px(12), px(4));
        rv.addView(text("Âm vang", 20, 0xFFFFFFFF, true), new LayoutParams(0, -2, 1f));
        reverbVal = text("Không", 20, 0xFFFFFFFF, true);
        rv.addView(reverbVal, new LayoutParams(-2, -2));
        ImageView ch = icon(R.drawable.ic_eq_next, 8);
        rv.addView(ch, new LayoutParams(px(40), px(40)));
        rv.setOnClickListener(v -> new AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Âm vang")
                .setSingleChoiceItems(EqSettings.REVERB_NAMES, s.reverb, (d, w) -> {
                    s.reverb = w;
                    s.publish();
                    s.save();
                    reverbVal.setText(EqSettings.REVERB_NAMES[w]);
                    d.dismiss();
                }).show());
        LayoutParams rvp = new LayoutParams(-1, px(56));
        rvp.topMargin = px(8);
        body.addView(rv, rvp);

        // tăng trầm + ảo hóa
        bassSl = new EqSlider(a, false, 0f, 1f);
        bassSl.listener = v -> {
            if (!updating) {
                s.bass = v;
                s.publish();
            }
        };
        bassSl.onStop = s::save;
        virtSl = new EqSlider(a, false, 0f, 1f);
        virtSl.listener = v -> {
            if (!updating) {
                s.virt = v;
                s.publish();
            }
        };
        virtSl.onStop = s::save;
        body.addView(sliderRow("TĂNG ÂM TRẦM", bassSl), new LayoutParams(-1, px(52)));
        body.addView(sliderRow("ẢO HÓA ÂM THANH", virtSl), new LayoutParams(-1, px(52)));
        View pad = new View(a);
        body.addView(pad, new LayoutParams(-1, px(24)));

        refresh();
    }

    private LinearLayout sliderRow(String label, EqSlider sl) {
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(16), 0, px(8), 0);
        r.addView(text(label, 14, 0xFFFFFFFF, true), new LayoutParams(px(150), -2));
        r.addView(sl, new LayoutParams(0, px(44), 1f));
        return r;
    }

    /** Đưa mọi điều khiển về đúng giá trị trong settings. */
    void refresh() {
        updating = true;
        sw.setChecked(s.enabled);
        content.setAlpha(s.enabled ? 1f : 0.4f);
        for (int i = 0; i < EqSettings.N; i++) bands[i].setValue(s.gains[i]);
        bassSl.setValue(s.bass);
        virtSl.setValue(s.virt);
        reverbVal.setText(EqSettings.REVERB_NAMES[s.reverb]);
        updateChips();
        updating = false;
    }

    private void updateChips() {
        for (int i = 0; i < chips.length; i++) {
            boolean on = i == s.preset;
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(px(100));
            if (on) g.setColor(GREEN);
            else g.setStroke(px(1), 0xFFDDDDDD);
            chips[i].setBackground(g);
        }
    }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(act);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private ImageView icon(int res, int padDp) {
        ImageView v = new ImageView(act);
        v.setImageResource(res);
        v.setPadding(px(padDp), px(padDp), px(padDp), px(padDp));
        return v;
    }

    private int px(int v) {
        return (int) (v * dp + 0.5f);
    }

    /** Cuộn ngang 2 trang, tự bám vào trang gần nhất. */
    private static final class Pager extends HorizontalScrollView {
        final LinearLayout[] pages = new LinearLayout[2];
        private int pageW;
        private boolean flung;

        Pager(android.content.Context c) {
            super(c);
            setHorizontalScrollBarEnabled(false);
            setOverScrollMode(OVER_SCROLL_NEVER);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            pageW = w;
            for (LinearLayout p : pages) {
                if (p == null) continue;
                p.getLayoutParams().width = w;
                p.requestLayout();
            }
        }

        @Override
        public void fling(int vx) {
            flung = true;
            int cur = pageW == 0 ? 0 : Math.round(getScrollX() / (float) pageW);
            int target = vx > 300 ? 1 : vx < -300 ? 0 : cur;
            smoothScrollTo(target * pageW, 0);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) flung = false;
            boolean r = super.onTouchEvent(e);
            if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) && !flung && pageW > 0) {
                smoothScrollTo(Math.round(getScrollX() / (float) pageW) * pageW, 0);
            }
            return r;
        }
    }
}
