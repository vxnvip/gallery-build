package com.duy.netplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

/** Màn hình chính: dán link / chọn file / danh sách gần đây. */
public class MainActivity extends Activity {
    private static final int REQ_PICK = 1;
    private EditText urlInput, refInput;
    private ArrayAdapter<String> adapter;
    private final ArrayList<String> recent = new ArrayList<>();
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        sp = getSharedPreferences("main", 0);
        String saved = sp.getString("recent", "");
        if (!saved.isEmpty()) recent.addAll(Arrays.asList(saved.split("\n")));

        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFF121212);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("NetPlayer");
        title.setTextSize(24);
        title.setTextColor(0xFFFFFFFF);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView settings = new TextView(this);
        settings.setText("⚙ Cài đặt");
        settings.setTextSize(16);
        settings.setTextColor(0xFF5BC27A);
        settings.setPadding(dp(12), dp(12), dp(4), dp(12));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        head.addView(settings, new LinearLayout.LayoutParams(-2, -2));
        root.addView(head, new LinearLayout.LayoutParams(-1, dp(56)));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("Dán link video (mp4, mkv, m3u8...)");
        urlInput.setHintTextColor(0xFF888888);
        urlInput.setTextColor(0xFFFFFFFF);
        root.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(56)));

        refInput = new EditText(this);
        refInput.setSingleLine(true);
        refInput.setHint("Referer (tuỳ chọn)");
        refInput.setHintTextColor(0xFF888888);
        refInput.setTextColor(0xFFFFFFFF);
        root.addView(refInput, new LinearLayout.LayoutParams(-1, dp(56)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button play = new Button(this);
        play.setText("Phát link");
        Button pick = new Button(this);
        pick.setText("Chọn file");
        row.addView(play, new LinearLayout.LayoutParams(0, dp(52), 1f));
        row.addView(pick, new LinearLayout.LayoutParams(0, dp(52), 1f));
        root.addView(row, new LinearLayout.LayoutParams(-1, -2));

        TextView rt = new TextView(this);
        rt.setText("Gần đây");
        rt.setTextColor(0xFFAAAAAA);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(16);
        root.addView(rt, rp);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, recent);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        play.setOnClickListener(v -> {
            String u = urlInput.getText().toString().trim();
            String low = u.toLowerCase();
            if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("content://")) {
                start(u);
                return;
            }
            // đường dẫn file trong bộ nhớ máy: /sdcard/..., /storage/emulated/0/..., file:///...
            String path = null;
            if (low.startsWith("file://")) path = Uri.parse(u).getPath();
            else if (u.startsWith("/")) path = u;
            if (path == null) {
                Toast.makeText(this, "Nhập link http(s):// hoặc đường dẫn file (vd /sdcard/a.mp4)", Toast.LENGTH_LONG).show();
                return;
            }
            startLocal(path);
        });
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("video/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_PICK);
        });
        list.setOnItemClickListener((p, view, pos, id) -> start(recent.get(pos)));

        // Không để thư viện nhích lên / xuống khi player (toàn màn hình) ẩn / hiện thanh trạng thái:
        // vẽ dưới thanh hệ thống và chừa chỗ theo insets ỔN ĐỊNH (không đổi dù thanh đang ẩn hay hiện).
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(pad + ins.getStableInsetLeft(), pad + ins.getStableInsetTop(),
                    pad + ins.getStableInsetRight(),
                    pad + Math.max(ins.getStableInsetBottom(), ins.getSystemWindowInsetBottom())); // bàn phím vẫn đẩy nội dung lên
            return ins;
        });
        setContentView(root);
        root.requestApplyInsets();
        showLastCrash();
    }

    /** Lần trước app crash: hiện log để sao chép gửi đi. */
    private void showLastCrash() {
        SharedPreferences cp = getSharedPreferences("crash", 0);
        final String log = cp.getString("log", null);
        if (log == null) return;
        cp.edit().remove("log").apply();
        TextView tv = new TextView(this);
        tv.setText(log);
        tv.setTextSize(11);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(16), dp(8), dp(16), dp(8));
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("Nhật ký lỗi lần trước")
                .setView(sv)
                .setPositiveButton("Sao chép", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("crash", log));
                    Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Đóng", null)
                .show();
    }

    private static final int REQ_STORAGE = 5;
    private String pendingPath;

    /** File trong bộ nhớ máy: cần quyền đọc video, xin lần đầu rồi phát. */
    private void startLocal(String path) {
        String perm = android.os.Build.VERSION.SDK_INT >= 33
                ? android.Manifest.permission.READ_MEDIA_VIDEO
                : android.Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingPath = path;
            requestPermissions(new String[]{perm}, REQ_STORAGE);
            return;
        }
        java.io.File f = new java.io.File(path);
        if (!f.exists()) {
            Toast.makeText(this, "Không thấy file: " + path, Toast.LENGTH_LONG).show();
            return;
        }
        start(Uri.fromFile(f).toString());
    }

    private static final int REQ_MIC = 6;
    private boolean permBusy, micSettingsShown, overlayShown;

    @Override
    protected void onResume() {
        super.onResume();
        showLastCrash(); // nhật ký (kể cả "Chạm thông báo") hiện mỗi lần quay lại app, không chỉ khi khởi động nguội
        ensureSpectrumPerms();
    }

    /** Cột nhạc cần 2 quyền: Micro (Visualizer bắt buộc, app không thu âm) và "Hiển thị trên các ứng dụng khác". Thiếu cái nào thì xin lại cái đó. */
    private void ensureSpectrumPerms() {
        if (permBusy) return;
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            boolean asked = sp.getBoolean("micAsked", false);
            if (!asked || shouldShowRequestPermissionRationale(android.Manifest.permission.RECORD_AUDIO)) {
                sp.edit().putBoolean("micAsked", true).apply();
                permBusy = true;
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                return;
            }
            if (!micSettingsShown) { // bị từ chối hẳn: hệ thống không hiện hộp xin nữa, phải vào cài đặt
                micSettingsShown = true;
                new AlertDialog.Builder(this)
                        .setTitle("Cần quyền Micro")
                        .setMessage("Hiệu ứng cột nhạc dùng Visualizer nên Android bắt buộc quyền Micro (app không thu âm). Bật ở: Quyền > Micro.")
                        .setPositiveButton("Mở cài đặt", (d, w) -> startActivity(new Intent(
                                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))))
                        .setNegativeButton("Để sau", null)
                        .show();
                return;
            }
        }
        if (!android.provider.Settings.canDrawOverlays(this) && !overlayShown) {
            overlayShown = true;
            new AlertDialog.Builder(this)
                    .setTitle("Cần quyền hiển thị trên ứng dụng khác")
                    .setMessage("Để vẽ cột nhạc trên thanh trạng thái, hãy bật \"Hiển thị trên các ứng dụng khác\" cho NetPlayer.")
                    .setPositiveButton("Mở cài đặt", (d, w) -> startActivity(new Intent(
                            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))))
                    .setNegativeButton("Để sau", null)
                    .show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_MIC) {
            permBusy = false;
            ensureSpectrumPerms();
            return;
        }
        if (req != REQ_STORAGE || pendingPath == null) return;
        String p = pendingPath;
        pendingPath = null;
        if (res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) startLocal(p);
        else Toast.makeText(this, "Cần cấp quyền đọc video để phát file trong máy", Toast.LENGTH_LONG).show();
    }

    private void start(String u) {
        recent.remove(u);
        recent.add(0, u);
        while (recent.size() > 15) recent.remove(recent.size() - 1);
        sp.edit().putString("recent", String.join("\n", recent)).apply();
        adapter.notifyDataSetChanged();

        Intent i = new Intent(this, PlayerActivity.class);
        i.setData(Uri.parse(u));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        String ref = refInput.getText().toString().trim();
        if (!ref.isEmpty()) i.putExtra("referer", ref);
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        start(u.toString());
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
