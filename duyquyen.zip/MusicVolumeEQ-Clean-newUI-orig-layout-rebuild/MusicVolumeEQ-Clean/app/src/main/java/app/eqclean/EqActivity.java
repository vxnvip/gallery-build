package app.eqclean;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EqActivity extends Activity {
    private static final int GREEN = 0xFF6DE5FF, CARD = 0xFF1E1E1E;
    private EqService svc;
    private SharedPreferences pos, onPrefs, presets;
    private StudioCurve eqView;
    private StudioKnob knobBass, knobVirt;
    private TextView presetName;
    private AudioManager am;
    private float d;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        pos = getSharedPreferences("prefsEQPos", 0);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        presets = getSharedPreferences("prefsPresets", 0);
        d = getResources().getDisplayMetrics().density;
        
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF000000);
        
        eqView = new StudioCurve(this);
        eqView.setBands(Cfg.bands10);
        eqView.setListener((i, db, fromUser) -> {
            Cfg.bands10[i] = db;
            if (svc != null) svc.dpEqApply(Cfg.bands10);
        });
        
        root.addView(eqView, new LinearLayout.LayoutParams(-1, dp(200)));
        
        knobBass = new StudioKnob(this);
        knobBass.setProgress(pos.getInt("BassLevel", 0));
        knobBass.setListener((p, fromUser) -> { pos.edit().putInt("BassLevel", p).apply(); if (svc != null) svc.setBass(p); });
        root.addView(knobBass, new LinearLayout.LayoutParams(dp(100), dp(100)));
        
        setContentView(root);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    private int dp(float v) { return (int) (v * d + 0.5f); }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unbindService(conn); } catch (Exception ignored) {}
    }
}
