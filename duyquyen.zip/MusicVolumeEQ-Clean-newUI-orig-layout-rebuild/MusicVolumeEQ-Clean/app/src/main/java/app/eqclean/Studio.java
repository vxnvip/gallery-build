package app.eqclean;

import android.content.Context;

/** Helper dùng chung cho StudioKnob / StudioSlider / StudioCurve. */
public final class Studio {
    private Studio() {}

    /** dp -> px */
    public static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }
}
