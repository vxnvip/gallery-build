package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/**
 * Rebuilt StudioCurve (1:1 logic).
 * Draws 10-band EQ curve using Bezier splines and custom Canvas drawing.
 */
public class StudioCurve extends View {
    public interface Listener { void onBand(int index, float db, boolean fromUser); }

    private static final int BANDS = 10;
    private static final float RANGE = 15f;
    private final float[] db = new float[BANDS];
    
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float density;
    private float left, right, top, bottom;
    private int active = -1;
    private Listener listener;

    public StudioCurve(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        
        line.setColor(0xFF6DE5FF); // Studio CYAN
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2f * density);
        line.setStrokeCap(Paint.Cap.ROUND);

        fill.setStyle(Paint.Style.FILL);
    }

    public void setListener(Listener l) { listener = l; }
    public void setBands(float[] v) { for(int i=0; i<BANDS; i++) db[i] = Math.max(-RANGE, Math.min(RANGE, v[i])); invalidate(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        left = 30f * density; right = w - 12f * density; 
        top = 16f * density; bottom = h - 20f * density;
        fill.setShader(new LinearGradient(0, top, 0, bottom, 0x556DE5FF, 0x006DE5FF, Shader.TileMode.CLAMP));
    }

    private float xOf(int i) { return left + (i + 0.5f) * (right - left) / BANDS; }
    private float yOf(float v) { return top + (RANGE - v) / (2f * RANGE) * (bottom - top); }

    @Override protected void onDraw(Canvas canvas) {
        path.reset();
        path.moveTo(xOf(0), yOf(db[0]));
        for (int i = 1; i < BANDS; i++) {
            float mx = (xOf(i - 1) + xOf(i)) / 2f;
            path.cubicTo(mx, yOf(db[i - 1]), mx, yOf(db[i]), xOf(i), yOf(db[i]));
        }
        Path area = new Path(path);
        area.lineTo(xOf(BANDS - 1), bottom);
        area.lineTo(xOf(0), bottom);
        area.close();
        canvas.drawPath(area, fill);
        canvas.drawPath(path, line);
        
        for (int i = 0; i < BANDS; i++) {
            paint.setColor(0xFF6DE5FF);
            canvas.drawCircle(xOf(i), yOf(db[i]), (i == active ? 8f : 6f) * density, paint);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN || e.getAction() == MotionEvent.ACTION_MOVE) {
            int i = (int) ((e.getX() - left) / ((right - left) / BANDS));
            if (i >= 0 && i < BANDS) {
                active = i;
                db[i] = Math.max(-RANGE, Math.min(RANGE, RANGE - (e.getY() - top) / (bottom - top) * 2f * RANGE));
                invalidate();
                if (listener != null) listener.onBand(i, db[i], true);
                return true;
            }
        } else if (e.getAction() == MotionEvent.ACTION_UP) { active = -1; invalidate(); }
        return true;
    }
}
