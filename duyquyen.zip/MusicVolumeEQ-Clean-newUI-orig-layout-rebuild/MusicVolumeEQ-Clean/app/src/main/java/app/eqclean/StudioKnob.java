package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Rebuilt StudioKnob (1:1 logic).
 * Draws a knob face, a track ring (dashed), and a progress arc using pure Canvas.
 */
public class StudioKnob extends View {
    public interface Listener { void onChange(int progress, boolean fromUser); }

    private static final float START = 130f, SWEEP = 279f;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringFg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arc = new RectF();
    
    private final int wheelSize;
    private int max = 1000, progress;
    private boolean pressed;
    private Listener listener;

    public StudioKnob(Context c) {
        super(c);
        wheelSize = Studio.dp(c, 88f);
        float stroke = Studio.dp(c, 10f);
        
        // Background ring (track)
        ringBg.setStyle(Paint.Style.STROKE);
        ringBg.setStrokeWidth(stroke);
        ringBg.setPathEffect(new DashPathEffect(new float[]{3f, 2f}, 0f));
        ringBg.setColor(0xFF5D5D5D);
        
        // Foreground ring (progress)
        ringFg.setStyle(Paint.Style.STROKE);
        ringFg.setStrokeWidth(stroke);
        ringFg.setPathEffect(new DashPathEffect(new float[]{3f, 2f}, 0f));
        ringFg.setColor(0xFFFFFFFF);
        
        paint.setStyle(Paint.Style.FILL);
    }

    public void setListener(Listener l) { listener = l; }
    public void setProgress(int p) { progress = Math.max(0, Math.min(max, p)); invalidate(); }
    public void setActive(boolean on) { setAlpha(on ? 1f : 0.5f); }

    @Override protected void onMeasure(int ws, int hs) { setMeasuredDimension(wheelSize, wheelSize); }

    @Override protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float radius = getWidth() * 0.28f;
        
        // Draw Knob Face
        paint.setColor(pressed ? 0xFF2D2D2D : 0xFF191C1B);
        canvas.drawCircle(cx, cy, radius * 1.5f, paint);
        paint.setColor(0xFF444444);
        canvas.drawCircle(cx, cy, radius * 1.2f, paint);

        // Draw Rings
        arc.set(cx - radius, cy - radius, cx + radius, cy + radius);
        canvas.drawArc(arc, START, SWEEP, false, ringBg);
        float sw = SWEEP * progress / (float) max;
        if (sw > 0.1f) canvas.drawArc(arc, START, sw, false, ringFg);
    }

    private void touch(MotionEvent e) {
        float dx = e.getX() - getWidth() / 2f, dy = e.getY() - getHeight() / 2f;
        float ang = (float) Math.toDegrees(Math.atan2(dy, dx));
        if (ang < 0) ang += 360f;
        float rel = ang - START;
        if (rel < 0) rel += 360f;
        
        int p = (rel <= SWEEP) ? Math.round(rel / SWEEP * max) : (rel < 180 ? max : 0);
        if (p != progress) {
            progress = Math.max(0, Math.min(max, p));
            invalidate();
            if (listener != null) listener.onChange(progress, true);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pressed = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                touch(e);
                return true;
            case MotionEvent.ACTION_MOVE:
                touch(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pressed = false;
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }
}
