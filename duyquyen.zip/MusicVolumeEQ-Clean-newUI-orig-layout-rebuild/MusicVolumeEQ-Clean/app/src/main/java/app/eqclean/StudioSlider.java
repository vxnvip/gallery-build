package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Rebuilt StudioSlider (1:1 logic).
 * Vertical slider with drawing logic based on travel range.
 */
public class StudioSlider extends View {
    public interface Listener { void onChange(int progress, boolean fromUser); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int travel;
    private int progress;
    private Listener listener;

    public StudioSlider(Context c, int travelDp) {
        super(c);
        this.travel = Studio.dp(c, travelDp);
    }

    public void setListener(Listener l) { listener = l; }
    public void setProgress(int p) { progress = Math.max(0, Math.min(travel, p)); invalidate(); }

    @Override protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f;
        // Draw track
        paint.setColor(0xFF191C1B);
        canvas.drawRect(cx - 10, 0, cx + 10, travel, paint);
        // Draw knob
        paint.setColor(0xFF6DE5FF);
        canvas.drawCircle(cx, travel - progress, 20f, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN || e.getAction() == MotionEvent.ACTION_MOVE) {
            int p = (int) (travel - e.getY());
            progress = Math.max(0, Math.min(travel, p));
            invalidate();
            if (listener != null) listener.onChange(progress, true);
            return true;
        }
        return true;
    }
}
