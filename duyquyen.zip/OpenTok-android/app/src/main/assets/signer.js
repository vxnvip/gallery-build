function __otkCtx() {
  if (window.__otkCtxCache) return window.__otkCtxCache;
  var ctx = { deviceId: '', odinId: '', webIdLastTime: '', isLogin: false, csrfToken: '' };
  try {
    var el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
    if (el) {
      var scope = (JSON.parse(el.textContent || '{}')['__DEFAULT_SCOPE__']) || {};
      var app = scope['webapp.app-context'] || {};
      ctx.deviceId = app.wid || '';
      ctx.odinId = app.odinId || '';
      ctx.webIdLastTime = app.webIdCreatedTime || '';
      ctx.isLogin = !!(app.user && (app.user.uid || app.user.secUid));
      ctx.csrfToken = app.csrfToken || '';
    }
  } catch (e) {}
  if (ctx.deviceId) window.__otkCtxCache = ctx;
  return ctx;
}

function __otkCommonParams(mobile) {
  var lang = (navigator.language || 'en').slice(0, 2);
  var p = new URLSearchParams();
  var ctx = __otkCtx();
  if (ctx.deviceId) p.set('device_id', ctx.deviceId);
  if (ctx.odinId) p.set('odinId', ctx.odinId);
  if (ctx.webIdLastTime) p.set('WebIdLastTime', ctx.webIdLastTime);
  p.set('user_is_login', String(ctx.isLogin));
  p.set('data_collection_enabled', 'true');
  p.set('aid', '1988');
  p.set('app_name', 'tiktok_web');
  p.set('app_language', lang);
  p.set('browser_language', navigator.language || 'en-US');
  p.set('browser_name', 'Mozilla');
  p.set('browser_online', String(navigator.onLine));
  p.set('browser_platform', navigator.platform || 'Win32');
  p.set('browser_version', (navigator.userAgent || '').replace('Mozilla/', ''));
  p.set('channel', 'tiktok_web');
  p.set('cookie_enabled', String(navigator.cookieEnabled));
  p.set('device_platform', mobile ? 'web_mobile' : 'web_pc');
  p.set('focus_state', 'true');
  p.set('from_page', 'fyp');
  p.set('history_len', '3');
  p.set('is_fullscreen', 'false');
  p.set('is_page_visible', 'true');
  p.set('language', lang);
  p.set('os', mobile ? 'android' : 'windows');
  p.set('priority_region', '');
  p.set('referer', '');
  p.set('region', 'US');
  p.set('screen_height', String(mobile ? screen.height : 1080));
  p.set('screen_width', String(mobile ? screen.width : 1920));
  p.set('tz_name', Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC');
  p.set('webcast_language', lang);
  var m = (document.cookie || '').match(/s_v_web_id=([^;]+)/);
  if (m) { p.set('verifyFp', m[1]); p.set('fp', m[1]); }
  return p;
}

function __otkRun(id, kind, path, paramsJson, mobile) {
  window.__otkRes = window.__otkRes || {};
  (async function () {
    var out;
    try {
      if (kind === 'page') {
        var r = await fetch('https://www.tiktok.com' + path, { method: 'GET', credentials: 'include' });
        var t = await r.text();
        out = { ok: r.ok, status: r.status, body: t.slice(0, 4000000) };
      } else if (kind === 'account') {
        var ra = await fetch(path, { method: 'GET', credentials: 'include' });
        var ta = await ra.text();
        var emb = null;
        try {
          var el2 = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
          if (el2) {
            var sc = (JSON.parse(el2.textContent || '{}')['__DEFAULT_SCOPE__']) || {};
            var us = ((sc['webapp.app-context'] || {}).user) || {};
            if (us.uid) emb = { id: String(us.uid), uniqueId: us.uniqueId || '' };
          }
        } catch (e2) {}
        out = { ok: ra.ok, status: ra.status, body: ta.slice(0, 200000), embedded: emb };
      } else {
        var params = __otkCommonParams(mobile);
        var extra = JSON.parse(paramsJson);
        for (var k in extra) { params.set(k, extra[k]); }
        var url = 'https://www.tiktok.com' + path + '?' + params.toString();
        var init = { method: 'GET', credentials: 'include' };
        if (kind === 'post') {
          init = {
            method: 'POST', credentials: 'include', body: '',
            headers: {
              'tt-csrf-token': __otkCtx().csrfToken,
              'content-type': 'application/x-www-form-urlencoded'
            }
          };
        }
        var res = await fetch(url, init);
        var text = await res.text();
        out = { ok: res.ok, status: res.status, body: text.slice(0, 2000000) };
      }
    } catch (e) {
      out = { ok: false, status: -1, body: String(e) };
    }
    window.__otkRes[id] = JSON.stringify(out);
  })();
  return true;
}
