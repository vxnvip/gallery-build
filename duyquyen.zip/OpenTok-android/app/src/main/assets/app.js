'use strict';
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ESC[c]);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const fmt = (n) => {
    n = Number(n) || 0;
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
    return String(n);
  };
  const ic = {
    heart: '<svg viewBox="0 0 24 24"><path d="M12 21s-7-4.6-9.5-9C.9 9 2.3 5.5 5.6 5.1c1.9-.2 3.6.8 4.4 2.3.8-1.5 2.5-2.5 4.4-2.3 3.3.4 4.7 3.9 3.1 6.9C19 16.4 12 21 12 21z"/></svg>',
    comment: '<svg viewBox="0 0 24 24"><path d="M4 4h16v12H9l-5 4V4z"/></svg>',
    bookmark: '<svg viewBox="0 0 24 24"><path d="M6 3h12v18l-6-4-6 4V3z"/></svg>',
    download: '<svg viewBox="0 0 24 24"><path d="M12 3v12m0 0l-4-4m4 4l4-4M5 21h14"/></svg>',
  };

  const S = { auth: { isAuthenticated: false }, followed: new Set(), tab: 'home', ft: 'fyp', frames: {} };
  const stack = [];
  let home = null, homeOn = false;

  /* ---------------- puente nativo ---------------- */
  const pending = new Map(); let seq = 0; const handlers = {};
  window.__native = {
    resolve(id, ok, payload) { const p = pending.get(id); if (!p) return; pending.delete(id); ok ? p.res(payload) : p.rej(new Error(payload)); },
    onEvent(name, payload) { let d = {}; try { d = JSON.parse(payload); } catch (e) {} if (handlers[name]) handlers[name](d); },
  };
  function native(method, ...args) {
    return new Promise((res, rej) => {
      const id = 'c' + (++seq); pending.set(id, { res, rej });
      try { Android.call(id, method, JSON.stringify(args)); } catch (e) { pending.delete(id); rej(e); }
    });
  }

  /* ---------------- endpoints (port de endpoints.ts) ---------------- */
  const E = {
    forYouFeed: () => ({ path: '/api/recommend/item_list/', params: { count: '16', pull_type: '0', coverFormat: '2' } }),
    followingFeed: (c) => ({ path: '/api/following/item_list/', params: { count: '9', cursor: c || '0', pullType: '1', level: '1', isResetCounterUsed: 'true', from_page: 'following' } }),
    diggVideo: (id, on) => ({ path: '/api/commit/item/digg/', params: { aweme_id: id, type: on ? '1' : '0', from_page: 'fyp' } }),
    collectVideo: (id, sec, on) => ({ path: '/api/item/collect/', params: { itemId: id, secUid: sec, action: on ? '1' : '2', from_page: 'video' } }),
    followUser: (sec, uid, on) => ({ path: '/api/commit/follow/user/', params: { sec_user_id: sec, user_id: uid, type: on ? '1' : '0', action_type: on ? '1' : '0', channel_id: '0', from: '18', fromWeb: '1', from_pre: '0', from_page: 'fyp' } }),
    diggComment: (vid, cid, on) => ({ path: '/api/comment/digg/', params: { aweme_id: vid, cid, digg_type: on ? '1' : '2', channel_id: '0', from_page: 'video' } }),
    publishComment: (vid, text) => ({ path: '/api/comment/publish/', params: { aweme_id: vid, text, text_extra: '[]', from_page: 'video' } }),
    deleteComment: (cid) => ({ path: '/api/comment/delete/', params: { cid, from_page: 'video' } }),
    userVideos: (sec, c) => ({ path: '/api/post/item_list/', params: { secUid: sec, count: '30', cursor: c || '0', coverFormat: '2', from_page: 'user' } }),
    searchUsers: (k, c) => ({ path: '/api/search/user/full/', params: { keyword: k, cursor: c || '0', from_page: 'search' } }),
    searchVideos: (k, o) => ({ path: '/api/search/item/full/', params: { keyword: k, offset: o || '0', from_page: 'search' } }),
    commentList: (vid, c) => ({ path: '/api/comment/list/', params: { aweme_id: vid, count: '20', cursor: c || '0' } }),
  };

  /* ---------------- API ---------------- */
  const looksLikeCaptcha = (b) => { const h = b.slice(0, 500).toLowerCase(); return h.includes('captcha') || h.includes('verify_page') || h.includes('secsdk') || h.startsWith('<!doctype html'); };
  async function signed(kind, path, params) { return JSON.parse(await native('signed', kind, path, JSON.stringify(params || {}))); }
  async function fetchJson(tag, ep) {
    let last = null;
    for (let i = 0; i < 4; i++) {
      let r;
      try { r = await signed('get', ep.path, ep.params); } catch (e) { last = e; await sleep(500 * (i + 1)); continue; }
      if (r.status === 429 || r.status >= 500) { last = new Error(tag + ': HTTP ' + r.status); await sleep(600 * Math.pow(2, i)); continue; }
      if (!r.ok) throw new Error(tag + ': HTTP ' + r.status);
      const b = (r.body || '').trim();
      if (b === '' || looksLikeCaptcha(b)) { last = new Error('TikTok yêu cầu xác minh'); last.verify = true; await sleep(600 * Math.pow(2, i)); continue; }
      try { return JSON.parse(r.body); } catch (e) { throw new Error(tag + ': phản hồi không phải JSON'); }
    }
    if (last && last.verify) showVerify();
    throw last || new Error(tag);
  }
  async function act(tag, ep) {
    const r = await signed('post', ep.path, ep.params);
    if (!r.ok) throw new Error(tag + ': HTTP ' + r.status);
    let root; try { root = JSON.parse(r.body); } catch (e) { throw new Error(tag + ': phản hồi không phải JSON'); }
    const c = root.status_code;
    if (c !== 0 && c !== undefined) throw new Error(String(root.status_msg || c));
    return true;
  }

  /* ---------------- UI helpers ---------------- */
  let toastT = null;
  function toast(msg, ms) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms || 2200); }
  function requireAuth(what) { if (S.auth.isAuthenticated) return true; toast('Đăng nhập để ' + what + ' (tab Tài khoản)'); return false; }
  function showVerify() {
    const b = $('#banner'); b.hidden = false;
    b.innerHTML = '<span>TikTok yêu cầu xác minh (captcha).</span><button>Giải ngay</button>';
    $('button', b).onclick = () => native('verify').catch(() => {});
  }
  function pushLayer(node, opts) {
    $('#layers').appendChild(node);
    const layer = { node, pausesHome: !opts || opts.pausesHome !== false, onClose: opts && opts.onClose,
      close() { const i = stack.indexOf(layer); if (i >= 0) stack.splice(i, 1); if (layer.onClose) layer.onClose(); node.remove(); syncHome(); } };
    stack.push(layer); syncHome(); return layer;
  }
  window.__onBack = function () {
    const l = stack[stack.length - 1];
    if (l) { l.close(); return true; }
    if (S.tab !== 'home') { setTab('home'); return true; }
    return false;
  };
  function syncHome() {
    if (!home) return;
    const should = S.tab === 'home' && !stack.some((l) => l.pausesHome);
    if (should && !homeOn) { homeOn = true; home.resume(); }
    else if (!should && homeOn) { homeOn = false; home.release(); }
  }
  function setTab(t) {
    if (t === 'me') { openAccount(); return; }
    S.tab = t;
    $('#home').hidden = t !== 'home'; $('#search').hidden = t !== 'search';
    document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
    syncHome();
  }

  /* ---------------- helpers de video ---------------- */
  function videoUrls(item) {
    const v = item.video; if (!v) return [];
    const out = [];
    if (v.playAddr) out.push(v.playAddr);
    v.bitrateInfo.slice().sort((a, b) => b.bitrate - a.bitrate).forEach((b) => { if (out.indexOf(b.playAddr) < 0) out.push(b.playAddr); });
    return out;
  }
  const cover = (it) => (it.video ? it.video.cover : it.images && it.images[0] ? it.images[0].url : '');
  function descHTML(d) { return esc(d).replace(/#[\p{L}\p{N}_]+/gu, (m) => '<span class="tag" data-tag="' + m.slice(1) + '">' + m + '</span>'); }
  function railHTML(item) {
    const a = item.author, mine = S.auth.userId && a.id === S.auth.userId;
    const plus = !mine && !S.followed.has(a.id) ? '<i class="plus" data-act="follow">+</i>' : '';
    return '<div class="rail"><div class="av" data-act="avatar"><img src="' + esc(a.avatar) + '" alt="">' + plus + '</div>' +
      '<button data-act="like" class="' + (item.liked ? 'on' : '') + '">' + ic.heart + '<b>' + fmt(item.stats.likes) + '</b></button>' +
      '<button data-act="comment">' + ic.comment + '<b>' + fmt(item.stats.comments) + '</b></button>' +
      '<button data-act="save" class="save ' + (item.saved ? 'on' : '') + '">' + ic.bookmark + '<b>' + fmt(item.stats.saves) + '</b></button>' +
      '<button data-act="dl">' + ic.download + '<b>Tải</b></button></div>';
  }
  function slideHTML(item) {
    const a = item.author;
    const media = item.video ? '<div class="vwrap"></div>' : '<div class="photos">' + (item.images || []).map((im) => '<img src="' + esc(im.url) + '" alt="">').join('') + '</div>';
    return media + '<div class="shade"></div>' + railHTML(item) +
      '<div class="info"><div class="au" data-act="avatar">@' + esc(a.uniqueId) + (a.verified ? ' ✓' : '') + '</div><div class="desc">' + descHTML(item.desc) + '</div>' +
      '<div class="mus">♪ ' + esc(item.music ? item.music.title : '') + '</div></div>' + (item.video ? '<div class="prog"><i></i></div>' : '');
  }

  /* ---------------- FeedView: 3 <video> reutilizados ---------------- */
  class FeedView {
    constructor(root, onTag) {
      this.root = root; this.onTag = onTag; root.classList.add('feed');
      this.free = []; this.map = new Map(); this.filled = new Set(); this.slides = [];
      this.frame = null; this.active = -1; this.released = false; this._last = 0;
      for (let i = 0; i < 3; i++) this.free.push(this.mkVideo());
      root.addEventListener('scroll', () => { clearTimeout(this._st); this._st = setTimeout(() => this.onScroll(), 70); }, { passive: true });
      root.addEventListener('click', (e) => this.onClick(e));
    }
    mkVideo() {
      const v = document.createElement('video');
      v.playsInline = true; v.loop = true; v.preload = 'auto'; v.setAttribute('playsinline', '');
      v.addEventListener('timeupdate', () => { const s = v.closest('.slide'); const bar = s && $('.prog i', s); if (bar && v.duration) bar.style.width = (v.currentTime / v.duration * 100) + '%'; });
      v.addEventListener('error', () => {
        const j = Number(v.dataset.i); const item = this.frame && this.frame.items[j]; if (!item) return;
        const urls = videoUrls(item); v._try = (v._try || 0) + 1;
        if (v._try < urls.length) { v.src = urls[v._try]; if (j === this.active) v.play().catch(() => {}); }
        else toast('Video không phát được');
      });
      return v;
    }
    setFrame(f) {
      this.release(); this.root.innerHTML = ''; this.frame = f; this.active = -1; this.slides = []; this.filled.clear();
      this.released = false;
      if (f.items.length) { this.append(0); this.root.scrollTop = (f.index || 0) * this.root.clientHeight; this.activate(f.index || 0, true); }
      else this.showEmpty(f.error);
      if (!f.items.length && !f.loading) this.more();
    }
    showEmpty(err) {
      let e = $('.empty', this.root); if (e) e.remove();
      e = el('div', 'empty', err ? '<div>' + esc(err.message || err) + '</div><button data-act="retry">Thử lại</button>' : '<div>Đang tải…</div>');
      this.root.appendChild(e);
    }
    append(from) {
      const e = $('.empty', this.root); if (e) e.remove();
      for (let i = from; i < this.frame.items.length; i++) { const s = el('section', 'slide'); s.dataset.i = i; this.root.appendChild(s); this.slides[i] = s; }
    }
    async more() {
      const f = this.frame; if (!f || f.loading || f.hasMore === false) return;
      f.loading = true; f.error = null;
      try {
        let added = 0;
        for (let k = 0; k < 3 && !added; k++) {
          const page = await f.loader(f.cursor);
          const seen = new Set(f.items.map((x) => x.id));
          const add = page.items.filter((x) => !seen.has(x.id));
          const from = f.items.length; f.items.push(...add); added = add.length;
          f.cursor = page.cursor; f.hasMore = page.hasMore;
          if (this.frame === f && add.length) { this.append(from); this.activate(this.active < 0 ? 0 : this.active, true); }
          if (!page.hasMore) break;
        }
        if (!f.items.length && this.frame === f) this.showEmpty('Không có video nào');
      } catch (e) { f.error = e; if (this.frame === f && !f.items.length) this.showEmpty(e); else toast('Lỗi tải thêm: ' + e.message); }
      f.loading = false;
    }
    onScroll() { const h = this.root.clientHeight; if (h) this.activate(Math.round(this.root.scrollTop / h), false); }
    fill(j) {
      if (this.filled.has(j) || !this.slides[j]) return;
      this.slides[j].innerHTML = slideHTML(this.frame.items[j]); this.filled.add(j);
    }
    empty(j) { if (!this.filled.has(j) || !this.slides[j]) return; this.drop(j); this.slides[j].innerHTML = ''; this.filled.delete(j); }
    drop(j) {
      const v = this.map.get(j); if (!v) return;
      v.pause(); v.removeAttribute('src'); v.load(); v.remove(); this.map.delete(j); this.free.push(v);
    }
    mount(j, active) {
      const item = this.frame.items[j]; if (!item.video || this.map.has(j)) return;
      const slide = this.slides[j]; const wrap = slide && $('.vwrap', slide); if (!wrap) return;
      const v = this.free.pop(); if (!v) return;
      this.map.set(j, v); v.dataset.i = j; v._try = 0; v.preload = active ? 'auto' : 'metadata';
      v.poster = item.video.cover || ''; const urls = videoUrls(item); v.src = urls[0] || '';
      wrap.appendChild(v);
    }
    activate(i, force) {
      const f = this.frame; if (!f || !f.items.length || this.released) return;
      i = Math.max(0, Math.min(i, f.items.length - 1));
      if (i === this.active && !force) return;
      this.active = i; f.index = i;
      const want = [i - 1, i, i + 1].filter((j) => j >= 0 && j < f.items.length);
      for (const j of Array.from(this.map.keys())) if (want.indexOf(j) < 0) this.drop(j);
      for (const j of Array.from(this.filled)) if (Math.abs(j - i) > 3) this.empty(j);
      for (let j = i - 2; j <= i + 2; j++) if (j >= 0 && j < f.items.length) this.fill(j);
      want.forEach((j) => this.mount(j, j === i));
      this.map.forEach((v, j) => { if (j === i) v.play().catch(() => {}); else v.pause(); });
      if (i >= f.items.length - 4) this.more();
    }
    release() { this.released = true; for (const j of Array.from(this.map.keys())) this.drop(j); }
    resume() {
      this.released = false; if (!this.frame || !this.frame.items.length) return;
      this.root.scrollTop = Math.max(0, this.active) * this.root.clientHeight; this.activate(Math.max(0, this.active), true);
    }
    destroy() { this.release(); this.root.innerHTML = ''; }
    refreshRails() { this.filled.forEach((j) => this.updateRail(j)); }
    updateRail(j) {
      const s = this.slides[j]; const r = s && $('.rail', s); if (!r) return;
      const n = el('div', '', railHTML(this.frame.items[j])).firstChild; r.replaceWith(n);
    }
    onClick(e) {
      const a = e.target.closest('[data-act]');
      if (a && a.dataset.act === 'retry') { this.frame.error = null; this.showEmpty(null); this.more(); return; }
      const slide = e.target.closest('.slide'); if (!slide) return;
      const j = Number(slide.dataset.i), item = this.frame.items[j]; if (!item) return;
      const tag = e.target.closest('[data-tag]'); if (tag) { this.onTag(tag.dataset.tag); return; }
      if (a) { this.handleAct(a.dataset.act, item, j); return; }
      const prog = e.target.closest('.prog');
      if (prog) { const v = this.map.get(j); if (v && v.duration) { const r = prog.getBoundingClientRect(); v.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * v.duration; } return; }
      const now = Date.now();
      if (now - this._last < 300) { clearTimeout(this._tt); this._last = 0; if (!item.liked) this.handleAct('like', item, j); }
      else { this._last = now; this._tt = setTimeout(() => { const v = this.map.get(j); if (v) { if (v.paused) v.play().catch(() => {}); else v.pause(); } }, 300); }
    }
    async handleAct(name, item, j) {
      if (name === 'avatar') { openProfile(item.author.uniqueId); return; }
      if (name === 'comment') { openComments(item, () => this.updateRail(j)); return; }
      if (name === 'dl') { download(item); return; }
      if (name === 'like') {
        if (!requireAuth('thích video')) return;
        const on = !item.liked; item.liked = on; item.stats.likes += on ? 1 : -1; this.updateRail(j);
        try { await act('digg', E.diggVideo(item.id, on)); }
        catch (err) { item.liked = !on; item.stats.likes += on ? -1 : 1; this.updateRail(j); toast('Lỗi: ' + err.message); }
      } else if (name === 'save') {
        if (!requireAuth('lưu video')) return;
        const on = !item.saved; item.saved = on; item.stats.saves += on ? 1 : -1; this.updateRail(j);
        try { await act('collect', E.collectVideo(item.id, item.author.secUid, on)); }
        catch (err) { item.saved = !on; item.stats.saves += on ? -1 : 1; this.updateRail(j); toast('Lỗi: ' + err.message); }
      } else if (name === 'follow') {
        if (!requireAuth('theo dõi')) return;
        const a = item.author; S.followed.add(a.id); this.refreshRails();
        try { await act('follow', E.followUser(a.secUid, a.id, true)); }
        catch (err) { S.followed.delete(a.id); this.refreshRails(); toast('Lỗi: ' + err.message); }
      }
    }
  }

  /* ---------------- tải xuống ---------------- */
  handlers.download = (d) => toast('Đang tải ' + d.pct + '%', 1500);
  async function download(item) {
    if (!item.video) { toast('Bài đăng ảnh chưa hỗ trợ tải'); return; }
    const urls = videoUrls(item); if (!urls.length) { toast('Không có link video'); return; }
    const best = item.video.bitrateInfo.slice().sort((a, b) => b.bitrate - a.bitrate)[0];
    const url = best ? best.playAddr : urls[0];
    const desc = item.desc.replace(/\s+/g, ' ').trim().slice(0, 60);
    const name = (item.author.uniqueId || 'anon') + ' - ' + item.id + (desc ? ' - ' + desc : '');
    const sidecar = JSON.stringify({ id: item.id, description: item.desc, createTime: item.createTime,
      createdISO: item.createTime ? new Date(item.createTime * 1000).toISOString() : null, author: item.author,
      music: item.music, stats: item.stats, video: { duration: item.video.duration, width: item.video.width, height: item.video.height }, savedAt: new Date().toISOString() }, null, 2);
    toast('Bắt đầu tải…');
    try { await native('download', JSON.stringify({ id: item.id, url, name, sidecar })); toast('Đã lưu vào Movies/OpenTok'); }
    catch (e) { toast('Tải lỗi: ' + e.message, 3500); }
  }

  /* ---------------- bình luận ---------------- */
  function openComments(item, onChange) {
    const wrap = el('div', ''); wrap.style.cssText = 'position:absolute;inset:0';
    wrap.innerHTML = '<div class="scrim"></div><div class="sheet"><div class="sh-h"><b>' + fmt(item.stats.comments) + ' bình luận</b><button class="x">×</button></div><div class="clist"><div class="loading">Đang tải…</div></div><div class="cin"><input maxlength="150" placeholder="Thêm bình luận…"><button>Gửi</button></div></div>';
    const layer = pushLayer(wrap, { pausesHome: false });
    $('.scrim', wrap).onclick = () => layer.close(); $('.x', wrap).onclick = () => layer.close();
    const list = $('.clist', wrap); const st = { cursor: '0', hasMore: true, loading: false, first: true };
    const mineId = () => S.auth.userId;
    function render(c) {
      const mine = mineId() && c.author.id === mineId();
      const row = el('div', 'cm', '<img src="' + esc(c.author.avatar) + '" alt=""><div class="b"><div class="n">' + esc(c.author.nickname || c.author.uniqueId) + '</div><div class="t">' + esc(c.text) + '</div>' + (mine ? '<button class="del">Xóa</button>' : '') + '</div><button class="l ' + (c.liked ? 'on' : '') + '">' + ic.heart.replace('<svg', '<svg width="18" height="18" fill="' + (c.liked ? '#fe2c55' : 'none') + '" stroke="currentColor"') + '<span>' + fmt(c.likes) + '</span></button>');
      $('.l', row).onclick = async () => {
        if (!requireAuth('thích bình luận')) return;
        const on = !c.liked; c.liked = on; c.likes += on ? 1 : -1; row.replaceWith(render(c));
        try { await act('cdigg', E.diggComment(item.id, c.id, on)); } catch (e) { c.liked = !on; c.likes += on ? -1 : 1; row.replaceWith(render(c)); toast('Lỗi: ' + e.message); }
      };
      const del = $('.del', row);
      if (del) del.onclick = async () => { try { await act('cdel', E.deleteComment(c.id)); row.remove(); } catch (e) { toast('Lỗi: ' + e.message); } };
      return row;
    }
    async function load() {
      if (st.loading || !st.hasMore) return; st.loading = true;
      try {
        const p = P.parseCommentPage(await fetchJson('comments', E.commentList(item.id, st.cursor)));
        if (st.first) { list.innerHTML = ''; st.first = false; }
        p.items.forEach((c) => list.appendChild(render(c))); st.cursor = p.cursor; st.hasMore = p.hasMore;
        if (!list.children.length) list.innerHTML = '<div class="loading">Chưa có bình luận</div>';
      } catch (e) { list.innerHTML = '<div class="loading">' + esc(e.message) + '</div>'; st.hasMore = false; }
      st.loading = false;
    }
    list.addEventListener('scroll', () => { if (list.scrollTop + list.clientHeight > list.scrollHeight - 200) load(); });
    const input = $('input', wrap);
    $('.cin button', wrap).onclick = async () => {
      if (!requireAuth('bình luận')) return;
      const text = input.value.trim(); if (!text) return;
      try { await act('cpub', E.publishComment(item.id, text)); input.value = ''; item.stats.comments++; if (onChange) onChange(); toast('Đã đăng bình luận'); st.cursor = '0'; st.hasMore = true; st.first = true; load(); }
      catch (e) { toast('Lỗi: ' + e.message); }
    };
    load();
  }

  /* ---------------- grids, viewer, profile, search ---------------- */
  function openViewer(items, index, loader, cursor, hasMore) {
    const node = el('div', 'layer viewer'); const feedDiv = el('div', ''); const back = el('button', 'back', '‹');
    node.append(feedDiv, back);
    let fv; const layer = pushLayer(node, { onClose: () => fv && fv.destroy() });
    back.onclick = () => layer.close();
    fv = new FeedView(feedDiv, (t) => { layer.close(); doSearch('#' + t); });
    fv.setFrame({ items, cursor, hasMore, loader, index, loading: false, error: null });
  }
  function makeGrid(container, items, loader, cursor, hasMore, scroller) {
    const g = { items, cursor, hasMore, loading: false, loader };
    const grid = el('div', 'grid'); container.appendChild(grid);
    const add = (from) => { for (let i = from; i < g.items.length; i++) { const it = g.items[i];
      const t = el('div', 'tile', '<img loading="lazy" src="' + esc(cover(it)) + '" alt=""><span>♥ ' + fmt(it.stats.likes) + '</span>'); t.dataset.i = i; grid.appendChild(t); } };
    add(0);
    grid.addEventListener('click', (e) => { const t = e.target.closest('.tile'); if (t) openViewer(g.items.slice(), Number(t.dataset.i), g.loader, g.cursor, g.hasMore); });
    g.more = async () => {
      if (g.loading || !g.hasMore) return; g.loading = true;
      try { const p = await g.loader(g.cursor); const seen = new Set(g.items.map((x) => x.id)); const from = g.items.length;
        p.items.forEach((x) => { if (!seen.has(x.id)) g.items.push(x); }); g.cursor = p.cursor; g.hasMore = p.hasMore; add(from); }
      catch (e) { toast('Lỗi: ' + e.message); g.hasMore = false; }
      g.loading = false;
    };
    scroller.addEventListener('scroll', () => { if (scroller.scrollTop + scroller.clientHeight > scroller.scrollHeight - 400) g.more(); });
    return g;
  }
  async function openProfile(uniqueId) {
    const node = el('div', 'layer'); node.innerHTML = '<div class="topb"><button class="back">‹</button><b>@' + esc(uniqueId) + '</b></div><div class="pbody"><div class="loading">Đang tải…</div></div>';
    const layer = pushLayer(node); $('.back', node).onclick = () => layer.close();
    const body = $('.pbody', node);
    try {
      const r = await signed('page', '/@' + encodeURIComponent(uniqueId.replace(/^@/, '')), {});
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const p = P.userProfileFromPage(r.body); if (!p) throw new Error('Không tìm thấy hồ sơ (có thể cần xác minh)');
      const a = p.author; let following = p.isFollowing || S.followed.has(a.id);
      body.innerHTML = '<div class="phead"><img src="' + esc(a.avatar) + '" alt=""><h2>' + esc(a.nickname) + (a.verified ? ' ✓' : '') + '</h2><div>@' + esc(a.uniqueId) + '</div><div class="st"><span><b>' + fmt(p.stats.following) + '</b> đang theo dõi</span><span><b>' + fmt(p.stats.followers) + '</b> người theo dõi</span><span><b>' + fmt(p.stats.likes) + '</b> thích</span></div><div class="sig">' + esc(a.signature || '') + '</div><button class="btn fb"></button></div>';
      const fb = $('.fb', body); const paint = () => { fb.textContent = following ? 'Đang theo dõi' : 'Theo dõi'; fb.classList.toggle('alt', following); }; paint();
      fb.onclick = async () => {
        if (!requireAuth('theo dõi')) return; const on = !following; following = on; if (on) S.followed.add(a.id); else S.followed.delete(a.id); paint();
        try { await act('follow', E.followUser(a.secUid, a.id, on)); } catch (e) { following = !on; paint(); toast('Lỗi: ' + e.message); }
      };
      const loader = async (c) => P.parseFeedPage(await fetchJson('user_videos', E.userVideos(a.secUid, c)));
      const g = makeGrid(body, [], loader, '0', true, body); g.more();
    } catch (e) { body.innerHTML = '<div class="loading">' + esc(e.message) + '</div>'; }
  }
  let sType = 'videos', sGen = 0;
  async function doSearch(q) {
    q = (q || $('#q').value).trim(); if (!q) return; $('#q').value = q; setTab('search');
    const res = $('#sres'); res.innerHTML = '<div class="loading">Đang tìm…</div>'; const gen = ++sGen;
    try {
      if (sType === 'videos') {
        const loader = async (c) => P.parseFeedPage(await fetchJson('search_videos', E.searchVideos(q, c)));
        const p = await loader('0'); if (gen !== sGen) return; res.innerHTML = '';
        if (!p.items.length) { res.innerHTML = '<div class="loading">Không có kết quả</div>'; return; }
        makeGrid(res, p.items, loader, p.cursor, p.hasMore, res);
      } else {
        const loader = async (c) => P.parseUserSearch(await fetchJson('search_users', E.searchUsers(q, c)));
        const p = await loader('0'); if (gen !== sGen) return; res.innerHTML = '';
        if (!p.users.length) { res.innerHTML = '<div class="loading">Không có kết quả</div>'; return; }
        p.users.forEach((u) => { const r = el('div', 'urow', '<img src="' + esc(u.avatar) + '" alt=""><div><b>' + esc(u.nickname || u.uniqueId) + '</b><small>@' + esc(u.uniqueId) + ' · ' + fmt(u.followerCount) + ' người theo dõi</small></div>'); r.onclick = () => openProfile(u.uniqueId); res.appendChild(r); });
      }
    } catch (e) { if (gen === sGen) res.innerHTML = '<div class="loading">' + esc(e.message) + '</div>'; }
  }

  /* ---------------- tài khoản ---------------- */
  async function refreshAuth() {
    let st = { isAuthenticated: false };
    try {
      const a = JSON.parse(await native('auth'));
      if (a.hasCookie && a.res) {
        try { const j = JSON.parse(a.res.body); const d = j.data || {};
          if (j.message === 'success' && (d.user_id_str || d.user_id)) st = { isAuthenticated: true, userId: String(d.user_id_str || d.user_id), uniqueId: String(d.username || '') };
          else if (d.name === 'session_expired' || d.error_code === 13) st = { isAuthenticated: false, expired: true };
        } catch (e) {}
      }
    } catch (e) {}
    S.auth = st; if (home) home.refreshRails();
  }
  function openAccount() {
    const node = el('div', ''); node.style.cssText = 'position:absolute;inset:0';
    const a = S.auth;
    node.innerHTML = '<div class="scrim"></div><div class="sheet" style="height:auto"><div class="acct">' + (a.isAuthenticated
      ? '<b>Đã đăng nhập: @' + esc(a.uniqueId) + '</b><button class="btn alt" id="lo">Đăng xuất</button>'
      : '<b>Chế độ khách</b><p>' + (a.expired ? 'Phiên đăng nhập đã hết hạn. ' : '') + 'Đăng nhập để thích, theo dõi, lưu và bình luận. Dùng email / SĐT / username (Google thường bị chặn trong WebView).</p><button class="btn" id="li">Đăng nhập TikTok</button>') +
      '<button class="btn alt" id="cl">Đóng</button></div></div>';
    const layer = pushLayer(node, { pausesHome: false });
    $('.scrim', node).onclick = () => layer.close(); $('#cl', node).onclick = () => layer.close();
    const li = $('#li', node); if (li) li.onclick = () => { layer.close(); native('login').catch(() => {}); };
    const lo = $('#lo', node); if (lo) lo.onclick = async () => { layer.close(); try { await native('logout'); await native('ready'); await refreshAuth(); toast('Đã đăng xuất'); } catch (e) { toast('Lỗi: ' + e.message); } };
  }
  handlers.webclosed = async () => {
    $('#banner').hidden = true;
    try { await native('ready'); } catch (e) {}
    await refreshAuth();
    if (home && home.frame && !home.frame.items.length) { home.frame.error = null; home.frame.hasMore = true; home.more(); }
  };

  /* ---------------- arranque ---------------- */
  function newFrame(loader) { return { items: [], cursor: '0', hasMore: true, loading: false, index: 0, loader, error: null }; }
  const loaders = {
    fyp: async () => { const p = P.parseFeedPage(await fetchJson('fyp', E.forYouFeed())); p.hasMore = true; return p; },
    following: async (c) => P.parseFeedPage(await fetchJson('following', E.followingFeed(c))),
  };
  async function boot() {
    $('#splash').hidden = false; $('#splashmsg').textContent = 'Đang kết nối TikTok…'; $('#splashretry').hidden = true;
    let ok = false; try { ok = JSON.parse(await native('ready')).ok; } catch (e) {}
    if (!ok) { $('#splashmsg').textContent = 'Không kết nối được tới TikTok. Kiểm tra mạng.'; $('#splashretry').hidden = false; return; }
    await refreshAuth(); $('#splash').hidden = true;
    S.frames.fyp = newFrame(loaders.fyp); S.frames.following = newFrame(loaders.following);
    home = new FeedView($('#homefeed'), (t) => doSearch('#' + t));
    homeOn = true; home.setFrame(S.frames[S.ft]);
  }
  $('#splashretry').onclick = async () => { try { await native('reload'); } catch (e) {} boot(); };
  document.querySelectorAll('#nav button').forEach((b) => (b.onclick = () => setTab(b.dataset.tab)));
  document.querySelectorAll('#hometabs button').forEach((b) => (b.onclick = () => {
    const ft = b.dataset.ft; if (ft === S.ft) return;
    if (ft === 'following' && !requireAuth('xem feed Đang theo dõi')) return;
    S.ft = ft; document.querySelectorAll('#hometabs button').forEach((x) => x.classList.toggle('on', x === b));
    if (home) home.setFrame(S.frames[ft]);
  }));
  document.querySelectorAll('.stabs button').forEach((b) => (b.onclick = () => {
    sType = b.dataset.st; document.querySelectorAll('.stabs button').forEach((x) => x.classList.toggle('on', x === b)); if ($('#q').value.trim()) doSearch();
  }));
  $('#qgo').onclick = () => doSearch(); $('#q').addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });
  boot();
})();
