'use strict';
/* Port de src/main/tiktok/parse/*.ts (parseo tolerante del JSON de TikTok). */
const P = (function () {
  const obj = (v) => (typeof v === 'object' && v !== null ? v : {});
  const str = (v, d = '') => (typeof v === 'string' ? v : d);
  const num = (v, d = 0) =>
    typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)) ? Number(v) : d;
  const bool = (v) => v === true;
  const arr = (v) => (Array.isArray(v) ? v : []);
  const firstUrl = (v) => {
    const o = obj(v);
    const l = arr(o.url_list).length > 0 ? arr(o.url_list) : arr(o.urlList);
    return l.length > 0 ? str(l[0]) : '';
  };

  function parseAuthor(raw) {
    return {
      id: str(raw.id), secUid: str(raw.secUid), uniqueId: str(raw.uniqueId), nickname: str(raw.nickname),
      avatar: str(raw.avatarThumb) || str(raw.avatarMedium) || str(raw.avatarLarger),
      verified: bool(raw.verified), signature: str(raw.signature) || undefined,
    };
  }

  function parseBitrates(list) {
    const out = [];
    for (const entry of list) {
      const b = obj(entry), pa = obj(b.PlayAddr), urls = arr(pa.UrlList);
      const first = urls.length > 0 ? str(urls[0]) : '';
      if (!first) continue;
      out.push({
        quality: str(b.GearName) || str(b.QualityType) || 'unknown',
        bitrate: num(b.Bitrate), width: num(pa.Width), height: num(pa.Height), playAddr: first,
      });
    }
    return out;
  }

  function parseImages(imagePost) {
    const out = [];
    for (const entry of arr(imagePost.images)) {
      const img = obj(entry), urls = arr(obj(img.imageURL).urlList);
      const url = urls.length > 0 ? str(urls[0]) : '';
      if (!url) continue;
      out.push({ url, width: num(img.imageWidth), height: num(img.imageHeight) });
    }
    return out;
  }

  function parseVideoItem(raw) {
    const id = str(raw.id);
    if (!id) return null;
    const author = parseAuthor(obj(raw.author));
    const stats = obj(raw.stats), music = obj(raw.music), imagePost = obj(raw.imagePost);
    const isPhoto = arr(imagePost.images).length > 0;
    let video = null;
    if (!isPhoto) {
      const v = obj(raw.video);
      video = {
        playAddr: str(v.playAddr),
        cover: str(v.cover) || str(v.originCover) || str(v.dynamicCover),
        duration: num(v.duration), width: num(v.width), height: num(v.height),
        bitrateInfo: parseBitrates(arr(v.bitrateInfo)),
      };
    }
    const item = {
      id, desc: str(raw.desc), createTime: num(raw.createTime), author, video,
      music: { id: str(music.id), title: str(music.title), author: str(music.authorName), playUrl: str(music.playUrl) || undefined },
      stats: {
        plays: num(stats.playCount), likes: num(stats.diggCount), comments: num(stats.commentCount),
        shares: num(stats.shareCount), saves: num(stats.collectCount),
      },
      liked: bool(raw.digged), saved: bool(raw.collected),
    };
    if (isPhoto) item.images = parseImages(imagePost);
    return item;
  }

  function parseFeedPage(root) {
    root = obj(root);
    const camel = arr(root.itemList);
    const rawItems = camel.length > 0 ? camel : arr(root.item_list);
    const items = [];
    for (const e of rawItems) { const p = parseVideoItem(obj(e)); if (p) items.push(p); }
    const more = root.hasMore !== undefined ? root.hasMore : root.has_more;
    return {
      items,
      cursor: str(root.cursor) || str(root.maxCursor) || String(num(root.cursor)),
      hasMore: more === true || num(more) === 1,
    };
  }

  function parseComment(raw) {
    const id = str(raw.cid) || str(raw.id);
    if (!id) return null;
    const u = obj(raw.user);
    return {
      id, text: str(raw.text),
      author: {
        id: str(u.uid) || str(u.id), secUid: str(u.sec_uid) || str(u.secUid),
        uniqueId: str(u.unique_id) || str(u.uniqueId), nickname: str(u.nickname),
        avatar: firstUrl(u.avatar_thumb) || firstUrl(u.avatarThumb) || str(u.avatarThumb), verified: false,
      },
      likes: num(raw.digg_count) || num(raw.diggCount),
      createTime: num(raw.create_time) || num(raw.createTime),
      replyCount: num(raw.reply_comment_total) || num(raw.replyCommentTotal),
      liked: num(raw.user_digged) === 1 || raw.user_digged === true,
    };
  }

  function parseCommentPage(root) {
    root = obj(root);
    const items = [];
    for (const e of arr(root.comments)) { const p = parseComment(obj(e)); if (p) items.push(p); }
    return { items, cursor: String(num(root.cursor)), hasMore: num(root.has_more) === 1 || root.has_more === true };
  }

  function parseUserSearch(root) {
    root = obj(root);
    const users = [];
    for (const entry of arr(root.user_list)) {
      const info = obj(obj(entry).user_info);
      const uniqueId = str(info.unique_id) || str(info.uniqueId);
      if (!uniqueId) continue;
      users.push({
        id: str(info.uid) || str(info.id), secUid: str(info.sec_uid) || str(info.secUid), uniqueId,
        nickname: str(info.nickname),
        avatar: firstUrl(info.avatar_thumb) || firstUrl(info.avatarThumb) || firstUrl(info.avatar_medium),
        verified: str(info.custom_verify).length > 0 || str(info.enterprise_verify_reason).length > 0,
        signature: str(info.signature) || undefined,
        followerCount: num(info.follower_count) || num(info.followerCount),
      });
    }
    const more = root.has_more !== undefined ? root.has_more : root.hasMore;
    return { users, cursor: String(num(root.cursor)), hasMore: more === true || num(more) === 1 };
  }

  function userProfileFromPage(html) {
    const m = String(html).match(/<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/);
    if (!m || !m[1]) return null;
    let data;
    try { data = JSON.parse(m[1]); } catch (e) { return null; }
    const detail = obj(obj(obj(data)['__DEFAULT_SCOPE__'])['webapp.user-detail']);
    if (!str(obj(obj(detail.userInfo).user).uniqueId)) return null;
    const info = obj(detail.userInfo), u = obj(info.user), st = obj(info.stats);
    return {
      author: {
        id: str(u.id), secUid: str(u.secUid), uniqueId: str(u.uniqueId), nickname: str(u.nickname),
        avatar: str(u.avatarLarger) || str(u.avatarMedium) || str(u.avatarThumb),
        verified: bool(u.verified), signature: str(u.signature) || undefined, followerCount: num(st.followerCount),
      },
      stats: { following: num(st.followingCount), followers: num(st.followerCount), likes: num(st.heartCount) || num(st.heart), videos: num(st.videoCount) },
      isFollowing: num(u.relation) === 1 || num(u.relation) === 3,
    };
  }

  return { parseFeedPage, parseCommentPage, parseUserSearch, userProfileFromPage };
})();
if (typeof module !== 'undefined') module.exports = P;
