package app.opentok.android

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException

/** Guarda el video (sin marca de agua) en Movies/OpenTok y un .json con los metadatos en Documents/OpenTok. */
class Downloader(private val ctx: Context, private val emit: (String, String) -> Unit) {

    private fun sanitize(s: String): String {
        val cleaned = s.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .filter { it.code >= 0x20 }
            .replace(Regex("\\s+"), " ")
            .trim()
            .trimEnd('.', ' ')
            .take(120)
        return if (cleaned.isEmpty()) "video" else cleaned
    }

    suspend fun download(args: JSONObject): String = withContext(Dispatchers.IO) {
        val url = args.getString("url")
        val id = args.optString("id", "")
        val base = sanitize(args.optString("name", "video"))
        val sidecar = args.optString("sidecar", "")
        val resolver = ctx.contentResolver

        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, "$base.mp4")
        values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/OpenTok")
        values.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("No se pudo crear el archivo")

        try {
            val conn = MediaProxy.open(url, null)
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val total = conn.contentLengthLong
            var done = 0L
            var lastPct = -5
            val out = resolver.openOutputStream(uri) ?: throw IOException("No se pudo abrir el archivo")
            out.use { o ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct >= lastPct + 5) {
                                lastPct = pct
                                emit("download", JSONObject().put("id", id).put("pct", pct).toString())
                            }
                        }
                    }
                }
            }
            val fin = ContentValues()
            fin.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, fin, null, null)
        } catch (e: Exception) {
            try {
                resolver.delete(uri, null, null)
            } catch (e2: Exception) {
            }
            throw e
        }

        if (sidecar.isNotEmpty()) {
            try {
                val sv = ContentValues()
                sv.put(MediaStore.MediaColumns.DISPLAY_NAME, "$base.json")
                sv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                sv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/OpenTok")
                val su = resolver.insert(MediaStore.Files.getContentUri("external"), sv)
                if (su != null) {
                    resolver.openOutputStream(su)?.use { it.write(sidecar.toByteArray(Charsets.UTF_8)) }
                }
            } catch (e: Exception) {
                // el sidecar es opcional: no hace fallar la descarga
            }
        }
        JSONObject().put("ok", true).put("name", "$base.mp4").toString()
    }
}
