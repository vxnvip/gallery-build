package app.opentok.android

import android.annotation.SuppressLint
import android.app.Activity
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.util.UUID
import kotlin.coroutines.resume

/**
 * WebView oculto (1x1 px) con tiktok.com real. TikTok firma las peticiones con su propio JS,
 * asi que todas las llamadas se ejecutan DENTRO de esa pagina (igual que la ventana oculta de Electron).
 * El resultado se lee por sondeo (window.__otkRes), sin exponer ninguna interfaz Java a tiktok.com.
 */
class Signer(private val activity: Activity, private val scope: CoroutineScope) {
    lateinit var web: WebView
        private set

    private var ready = CompletableDeferred<Boolean>()
    private var armed = false
    private val signerJs: String =
        activity.assets.open("signer.js").bufferedReader().use { it.readText() }
    private val blockedExt = listOf(".mp4", ".webm", ".m4s", ".woff", ".woff2", ".ttf", ".otf")

    @SuppressLint("SetJavaScriptEnabled")
    fun attach(container: FrameLayout) {
        val w = WebView(activity)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.userAgentString = Config.userAgent
        w.settings.mediaPlaybackRequiresUserGesture = true
        w.settings.blockNetworkImage = true
        w.settings.useWideViewPort = true
        w.settings.loadWithOverviewMode = true

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(w, true)

        if (Config.DESKTOP_MODE &&
            WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        ) {
            WebViewCompat.addDocumentStartJavaScript(w, Config.PLATFORM_JS, setOf("https://www.tiktok.com"))
        }

        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(Config.SILENCE_JS, null)
                if (armed) return
                armed = true
                scope.launch {
                    // Espera al cookie de dispositivo: senal de que ya se puede firmar como invitado.
                    repeat(30) {
                        val c = CookieManager.getInstance().getCookie(Config.HOME) ?: ""
                        if (c.contains("ttwid=") || c.contains("s_v_web_id=")) {
                            ready.complete(true)
                            return@launch
                        }
                        delay(500)
                    }
                    ready.complete(true)
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError,
            ) {
                if (request.isForMainFrame) ready.complete(false)
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest,
            ): WebResourceResponse? {
                val path = (request.url.path ?: "").lowercase()
                val heavy = blockedExt.any { path.endsWith(it) } || path.contains("/video/tos/")
                if (!heavy) return null
                return WebResourceResponse(
                    "text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)),
                )
            }
        }

        container.addView(w, FrameLayout.LayoutParams(1, 1))
        w.loadUrl(Config.HOME)
    }

    /** Recarga tiktok.com (tras login, captcha o logout). */
    fun reload() {
        ready = CompletableDeferred()
        armed = false
        web.loadUrl(Config.HOME)
    }

    suspend fun awaitReady(): Boolean = withTimeoutOrNull(45_000) { ready.await() } ?: false

    private suspend fun eval(code: String): String? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<String?> { cont ->
            web.evaluateJavascript(code) { cont.resume(it) }
        }
    }

    /**
     * kind: "get" | "post" | "page" | "account". Devuelve el JSON {ok,status,body} como texto.
     */
    suspend fun run(kind: String, path: String, params: String): String {
        awaitReady()
        val id = UUID.randomUUID().toString().replace("-", "")
        val qid = JSONObject.quote(id)
        val mobile = if (Config.DESKTOP_MODE) "false" else "true"
        val cookie = CookieManager.getInstance().getCookie(Config.HOME) ?: ""
        val csrf = Regex("(^|;\\s*)tt_csrf_token=([^;]+)").find(cookie)?.groupValues?.get(2) ?: ""
        val code = signerJs + "\n__otkRun(" + qid + "," + JSONObject.quote(kind) + "," +
            JSONObject.quote(path) + "," + JSONObject.quote(params) + "," + mobile + "," +
            JSONObject.quote(csrf) + ");"
        eval(code)
        val poll = "(function(){var r=window.__otkRes&&window.__otkRes[" + qid +
            "];if(r){delete window.__otkRes[" + qid + "];return r;}return null;})()"
        repeat(240) {
            delay(125)
            val out = eval(poll)
            if (out != null && out != "null") {
                return JSONTokener(out).nextValue() as String
            }
        }
        throw RuntimeException("timeout esperando a TikTok")
    }
}
