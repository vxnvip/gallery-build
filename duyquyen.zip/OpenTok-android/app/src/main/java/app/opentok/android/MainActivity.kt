package app.opentok.android

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

class MainActivity : Activity() {
    private val scope = MainScope()
    private lateinit var ui: WebView
    private lateinit var signer: Signer
    private lateinit var downloader: Downloader
    private lateinit var assetLoader: WebViewAssetLoader

    inner class Bridge {
        @JavascriptInterface
        fun call(id: String, method: String, argsJson: String) {
            runOnUiThread { handle(id, method, argsJson) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        ui = WebView(this)
        ui.setBackgroundColor(Color.BLACK)
        ui.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        root.addView(
            ui,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        setContentView(root)

        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(Config.ASSET_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        ui.settings.javaScriptEnabled = true
        ui.settings.domStorageEnabled = true
        ui.settings.mediaPlaybackRequiresUserGesture = false
        ui.settings.allowFileAccess = false
        ui.settings.allowContentAccess = false

        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest,
            ): WebResourceResponse? {
                val host = request.url.host ?: ""
                if (host == Config.ASSET_HOST) return assetLoader.shouldInterceptRequest(request.url)
                if (Config.isMediaHost(host)) return MediaProxy.toResponse(request)
                return MediaProxy.blocked()
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
        ui.addJavascriptInterface(Bridge(), "Android")

        downloader = Downloader(this) { name, payload -> emit(name, payload) }
        signer = Signer(this, scope)
        signer.attach(root)

        ui.loadUrl("https://" + Config.ASSET_HOST + "/assets/index.html")
    }

    private fun emit(name: String, payload: String) {
        runOnUiThread {
            ui.evaluateJavascript(
                "window.__native&&window.__native.onEvent(" + JSONObject.quote(name) + "," +
                    JSONObject.quote(payload) + ")",
                null,
            )
        }
    }

    private fun resolve(id: String, ok: Boolean, payload: String) {
        ui.evaluateJavascript(
            "window.__native.resolve(" + JSONObject.quote(id) + "," + ok + "," +
                JSONObject.quote(payload) + ")",
            null,
        )
    }

    private fun openWeb(url: String, title: String) {
        val i = Intent(this, WebActivity::class.java)
        i.putExtra("url", url)
        i.putExtra("title", title)
        startActivityForResult(i, 1)
    }

    private suspend fun logout(): String {
        val cm = CookieManager.getInstance()
        suspendCancellableCoroutine<Unit> { cont -> cm.removeAllCookies { cont.resume(Unit) } }
        cm.flush()
        WebStorage.getInstance().deleteAllData()
        signer.reload()
        return "{}"
    }

    private fun handle(id: String, method: String, argsJson: String) {
        scope.launch {
            try {
                val args = JSONArray(argsJson)
                val out: String = when (method) {
                    "ready" -> JSONObject().put("ok", signer.awaitReady()).toString()
                    "signed" -> signer.run(args.getString(0), args.getString(1), args.getString(2))
                    "auth" -> {
                        val cookie = CookieManager.getInstance().getCookie(Config.HOME) ?: ""
                        val has = Regex("(^|;\\s*)sessionid=[^;]+").containsMatchIn(cookie)
                        val o = JSONObject().put("hasCookie", has)
                        if (has) o.put("res", JSONObject(signer.run("account", Config.ACCOUNT_INFO_URL, "{}")))
                        o.toString()
                    }
                    "login" -> { openWeb(Config.LOGIN_URL, "Dang nhap TikTok"); "{}" }
                    "verify" -> { openWeb(Config.VERIFY_URL, "Xac minh TikTok"); "{}" }
                    "logout" -> logout()
                    "reload" -> { signer.reload(); "{}" }
                    "download" -> downloader.download(JSONObject(args.getString(0)))
                    else -> throw IllegalArgumentException("method: " + method)
                }
                resolve(id, true, out)
            } catch (e: Throwable) {
                resolve(id, false, e.message ?: e.toString())
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            signer.reload()
            emit("webclosed", "{}")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        ui.evaluateJavascript("window.__onBack?window.__onBack():false") { r ->
            if (r != "true") super.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        ui.onPause()
    }

    override fun onResume() {
        super.onResume()
        ui.onResume()
    }

    override fun onDestroy() {
        scope.cancel()
        ui.destroy()
        super.onDestroy()
    }
}
