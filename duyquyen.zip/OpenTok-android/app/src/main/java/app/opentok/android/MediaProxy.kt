package app.opentok.android

import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Los <video>/<img> de la interfaz viven en un origen local, asi que el CDN de TikTok los veria
 * como cross-site y devolveria 403. Aqui reenviamos la peticion con Referer, UA de Chrome y las
 * cookies de la sesion (mismo truco que media.ts en la version de escritorio).
 */
object MediaProxy {
    fun open(url: String, range: String?): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", Config.userAgent)
        c.setRequestProperty("Referer", Config.HOME)
        c.setRequestProperty("Accept", "*/*")
        val ck = CookieManager.getInstance().getCookie(Config.HOME)
        if (!ck.isNullOrEmpty()) c.setRequestProperty("Cookie", ck)
        if (range != null) c.setRequestProperty("Range", range)
        return c
    }

    private fun empty(code: Int, reason: String): WebResourceResponse =
        WebResourceResponse(
            "text/plain", "utf-8", code, reason,
            mapOf("Access-Control-Allow-Origin" to "*"),
            ByteArrayInputStream(ByteArray(0)),
        )

    fun blocked(): WebResourceResponse = empty(403, "Blocked")

    fun toResponse(request: WebResourceRequest): WebResourceResponse {
        return try {
            var range: String? = null
            for ((k, v) in request.requestHeaders) {
                if (k.equals("range", ignoreCase = true)) range = v
            }
            val c = open(request.url.toString(), range)
            val code = c.responseCode
            if (code < 200 || code in 300..399 || code > 599) return empty(502, "Bad Gateway")
            val stream = (if (code >= 400) c.errorStream else c.inputStream)
                ?: ByteArrayInputStream(ByteArray(0))
            val mime = (c.contentType ?: "application/octet-stream").substringBefore(';').trim()
            val headers = HashMap<String, String>()
            headers["Access-Control-Allow-Origin"] = "*"
            headers["Accept-Ranges"] = "bytes"
            c.getHeaderField("Content-Range")?.let { headers["Content-Range"] = it }
            c.getHeaderField("Content-Length")?.let { headers["Content-Length"] = it }
            val reason = (c.responseMessage ?: "").ifBlank { "OK" }
            WebResourceResponse(mime, null, code, reason, headers, stream)
        } catch (e: Exception) {
            empty(502, "Bad Gateway")
        }
    }
}
