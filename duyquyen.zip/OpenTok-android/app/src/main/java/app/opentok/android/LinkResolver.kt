package app.opentok.android

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/**
 * Chuyen link TikTok nhan tu app khac thanh {type: "video"|"user", user, id, kind}.
 * Link rut gon (vm./vt./t./tiktok.me...) se duoc theo redirect thu cong, moi buoc chi cho phep host TikTok.
 */
object LinkResolver {
    private val extraHosts = listOf("tiktok.me", "tt.fun", "tt.inc")
    private val videoRe = Regex("^/@([^/]+)/(video|photo)/(\\d+)")
    private val userRe = Regex("^/@([^/?#]+)/?$")
    private val bareVideoRe = Regex("^/(?:v|video)/(\\d+)")

    private fun allowed(host: String): Boolean =
        Config.isMediaHost(host) || extraHosts.any { host == it || host.endsWith(".$it") }

    private fun parse(u: URI): JSONObject? {
        val path = u.rawPath ?: return null
        videoRe.find(path)?.let {
            return JSONObject().put("type", "video").put("user", it.groupValues[1])
                .put("kind", it.groupValues[2]).put("id", it.groupValues[3])
        }
        userRe.find(path)?.let {
            return JSONObject().put("type", "user").put("user", it.groupValues[1])
        }
        bareVideoRe.find(path)?.let {
            return JSONObject().put("type", "video").put("user", "tiktok")
                .put("kind", "video").put("id", it.groupValues[1])
        }
        return null
    }

    suspend fun resolve(link: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            var current = link
            repeat(6) {
                val uri = URI(current)
                val host = (uri.host ?: "").lowercase()
                if (uri.scheme != "https" && uri.scheme != "http") return@withContext null
                if (!allowed(host)) return@withContext null
                parse(uri)?.let { return@withContext it }
                val c = URL(current.replace("http://", "https://")).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 10_000
                c.readTimeout = 10_000
                c.setRequestProperty("User-Agent", Config.userAgent)
                val code = c.responseCode
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (code !in 300..399 || loc.isNullOrEmpty()) return@withContext null
                current = URI(current).resolve(loc).toString()
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}
