package app.opentok.android

import android.webkit.WebSettings
import android.webkit.WebView
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

object Config {
    const val HOME = "https://www.tiktok.com/"
    const val ASSET_HOST = "appassets.androidplatform.net"
    const val ACCOUNT_INFO_URL =
        "https://www.tiktok.com/passport/web/account/info/?aid=1988&app_language=en&app_name=tiktok_web"
    const val VERIFY_URL = "https://www.tiktok.com/search/video?q=tiktok"
    const val LOGIN_URL = "https://www.tiktok.com/login"

    /**
     * true  = hace de navegador de escritorio (Chrome "Desktop site" en Android: Linux x86_64), igual que la version Electron verificada.
     * false = UA movil de Chrome sin la marca "wv". Si TikTok pide captcha en bucle, prueba a cambiarlo.
     */
    const val DESKTOP_MODE = true

    const val SILENCE_JS =
        "(function(){var s=function(){document.querySelectorAll('video').forEach(function(v){try{v.muted=true;v.pause();}catch(e){}});};" +
            "s();if(!window.__otkSilencer){window.__otkSilencer=true;document.addEventListener('play',function(e){var t=e.target;" +
            "if(t&&t.tagName==='VIDEO'){try{t.muted=true;t.pause();}catch(err){}}},true);" +
            "new MutationObserver(s).observe(document.documentElement,{childList:true,subtree:true});}})();"

    val chromeMajor: String by lazy {
        try {
            (WebView.getCurrentWebViewPackage()?.versionName ?: "130").substringBefore('.')
        } catch (e: Throwable) {
            "130"
        }
    }

    val userAgent: String by lazy {
        if (DESKTOP_MODE) {
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" +
                chromeMajor + ".0.0.0 Safari/537.36"
        } else {
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" +
                chromeMajor + ".0.0.0 Mobile Safari/537.36"
        }
    }

    /**
     * Ap dung UA + Client Hints (sec-ch-ua*, navigator.userAgentData) cho WebView.
     * Neu chi doi UA string, WebView van bao Android/mobile qua Client Hints -> UA va hints mau thuan nhau.
     */
    fun applyUserAgent(s: WebSettings) {
        s.userAgentString = userAgent
        if (!DESKTOP_MODE) return
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
                val full = "$chromeMajor.0.0.0"
                val md = UserAgentMetadata.Builder()
                    .setBrandVersionList(
                        listOf(
                            UserAgentMetadata.BrandVersion.Builder()
                                .setBrand("Chromium").setMajorVersion(chromeMajor).setFullVersion(full).build(),
                            UserAgentMetadata.BrandVersion.Builder()
                                .setBrand("Not;A=Brand").setMajorVersion("99").setFullVersion("99.0.0.0").build(),
                        ),
                    )
                    .setFullVersion(full)
                    .setPlatform("Linux")
                    .setPlatformVersion("")
                    .setArchitecture("x86")
                    .setBitness(64)
                    .setModel("")
                    .setMobile(false)
                    .build()
                WebSettingsCompat.setUserAgentMetadata(s, md)
            }
        } catch (e: Throwable) {
            // thiet bi/WebView cu: bo qua, van dung UA string
        }
    }

    private val mediaSuffixes = listOf(
        "tiktok.com", "tiktokcdn.com", "tiktokcdn-us.com", "tiktokcdn-eu.com", "tiktokv.com",
        "tiktokvcdn.com", "byteoversea.com", "ibyteimg.com", "muscdn.com", "bytecdn.com",
    )

    fun isMediaHost(host: String): Boolean =
        mediaSuffixes.any { host == it || host.endsWith("." + it) }
}
