package app.opentok.android

import android.webkit.WebView

object Config {
    const val HOME = "https://www.tiktok.com/"
    const val ASSET_HOST = "appassets.androidplatform.net"
    const val ACCOUNT_INFO_URL =
        "https://www.tiktok.com/passport/web/account/info/?aid=1988&app_language=en&app_name=tiktok_web"
    const val VERIFY_URL = "https://www.tiktok.com/search/video?q=tiktok"
    const val LOGIN_URL = "https://www.tiktok.com/login"

    /**
     * true  = hace de navegador de escritorio (Windows), igual que la version Electron verificada.
     * false = UA movil de Chrome sin la marca "wv". Si TikTok pide captcha en bucle, prueba a cambiarlo.
     */
    const val DESKTOP_MODE = true

    const val PLATFORM_JS =
        "(function(){try{Object.defineProperty(Navigator.prototype,'platform',{get:function(){return 'Win32';},configurable:true});" +
            "Object.defineProperty(Navigator.prototype,'maxTouchPoints',{get:function(){return 0;},configurable:true});}catch(e){}})();"

    const val SILENCE_JS =
        "(function(){var s=function(){document.querySelectorAll('video').forEach(function(v){try{v.muted=true;v.pause();}catch(e){}});};" +
            "s();if(!window.__otkSilencer){window.__otkSilencer=true;document.addEventListener('play',function(e){var t=e.target;" +
            "if(t&&t.tagName==='VIDEO'){try{t.muted=true;t.pause();}catch(err){}}},true);" +
            "new MutationObserver(s).observe(document.documentElement,{childList:true,subtree:true});}})();"

    val chromeMajor: String by lazy {
        try {
            (WebView.getCurrentWebViewPackage()?.versionName ?: "130").substringBefore('.')
        } catch (e: Throwable) {
            "130"
        }
    }

    val userAgent: String by lazy {
        if (DESKTOP_MODE) {
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" +
                chromeMajor + ".0.0.0 Safari/537.36"
        } else {
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" +
                chromeMajor + ".0.0.0 Mobile Safari/537.36"
        }
    }

    private val mediaSuffixes = listOf(
        "tiktok.com", "tiktokcdn.com", "tiktokcdn-us.com", "tiktokcdn-eu.com", "tiktokv.com",
        "tiktokvcdn.com", "byteoversea.com", "ibyteimg.com", "muscdn.com", "bytecdn.com",
    )

    fun isMediaHost(host: String): Boolean =
        mediaSuffixes.any { host == it || host.endsWith("." + it) }
}
