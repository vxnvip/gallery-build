package com.simplemobiletools.gallery.pro.views

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ViewConfiguration
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView
import kotlin.math.abs
import kotlin.math.sign

/**
 * SubsamplingScaleImageView with a configurable sensitivity for the
 * "double tap, hold and drag up/down" zoom gesture.
 * The library has no setting for it, so while that gesture is active the finger's vertical
 * distance from where it was first pressed is multiplied by [quickScaleSensitivity].
 * Movements smaller than the touch slop are ignored, so a quick double tap (with a bit of finger
 * wobble) is still treated as a plain double tap and resets the zoom instead of "dragging".
 */
class QuickScaleImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SubsamplingScaleImageView(context, attrs) {

    var quickScaleSensitivity = 2f

    private val doubleTapSlop = ViewConfiguration.get(context).scaledDoubleTapSlop
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var lastUpTime = 0L
    private var lastUpX = 0f
    private var lastUpY = 0f
    private var isDoubleTapHold = false
    private var anchorY = 0f

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val closeInTime = lastUpTime > 0L && event.eventTime - lastUpTime <= ViewConfiguration.getDoubleTapTimeout()
                val dx = event.x - lastUpX
                val dy = event.y - lastUpY
                isDoubleTapHold = closeInTime && dx * dx + dy * dy <= doubleTapSlop * doubleTapSlop
                anchorY = event.y
            }

            MotionEvent.ACTION_POINTER_DOWN -> isDoubleTapHold = false

            MotionEvent.ACTION_UP -> {
                if (isDoubleTapHold) {
                    lastUpTime = 0L
                } else {
                    lastUpTime = event.eventTime
                    lastUpX = event.x
                    lastUpY = event.y
                }
                isDoubleTapHold = false
            }

            MotionEvent.ACTION_CANCEL -> {
                lastUpTime = 0L
                isDoubleTapHold = false
            }

            MotionEvent.ACTION_MOVE -> {
                if (isDoubleTapHold && event.pointerCount == 1 && quickScaleSensitivity != 1f) {
                    val scaled = MotionEvent.obtain(event)
                    val dy = event.y - anchorY
                    val newDy = if (abs(dy) <= touchSlop) 0f else dy.sign * (abs(dy) - touchSlop) * quickScaleSensitivity
                    scaled.setLocation(event.x, anchorY + newDy)
                    val handled = super.onTouchEvent(scaled)
                    scaled.recycle()
                    return handled
                }
            }
        }
        return super.onTouchEvent(event)
    }
}
