package com.simplemobiletools.gallery.pro.activities

import android.app.Activity
import android.app.SearchManager
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.appcompat.widget.SearchView
import androidx.core.graphics.ColorUtils
import androidx.core.view.MenuItemCompat
import com.google.android.material.appbar.AppBarLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.simplemobiletools.commons.dialogs.CreateNewFolderDialog
import com.simplemobiletools.commons.extensions.*
import com.simplemobiletools.commons.helpers.*
import com.simplemobiletools.commons.models.FileDirItem
import com.simplemobiletools.commons.views.MyGridLayoutManager
import com.simplemobiletools.commons.views.MyRecyclerView
import com.simplemobiletools.gallery.pro.R
import com.simplemobiletools.gallery.pro.adapters.MediaAdapter
import com.simplemobiletools.gallery.pro.asynctasks.GetMediaAsynctask
import com.simplemobiletools.gallery.pro.databases.GalleryDatabase
import com.simplemobiletools.gallery.pro.dialogs.ChangeGroupingDialog
import com.simplemobiletools.gallery.pro.dialogs.ChangeSortingDialog
import com.simplemobiletools.gallery.pro.dialogs.ChangeViewTypeDialog
import com.simplemobiletools.gallery.pro.dialogs.FilterMediaDialog
import com.simplemobiletools.gallery.pro.extensions.*
import com.simplemobiletools.gallery.pro.helpers.*
import com.simplemobiletools.gallery.pro.interfaces.MediaOperationsListener
import com.simplemobiletools.gallery.pro.models.Medium
import com.simplemobiletools.gallery.pro.models.ThumbnailItem
import com.simplemobiletools.gallery.pro.models.ThumbnailSection
import kotlinx.android.synthetic.main.activity_media.*
import java.io.File
import java.io.IOException

class MediaActivity : SimpleActivity(), MediaOperationsListener {
    private val LAST_MEDIA_CHECK_PERIOD = 3000L

    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false
    private var mLoadedInitialPhotos = false
    private var mIsSearchOpen = false
    private var mWasFullscreenViewOpen = false
    private var mSavedScrollPos = -1
    private var mSavedScrollOffset = 0
    private var mSavedAtEnd = false
    private var mRestoreGuardUntil = 0L
    private var mLastSearchedText = ""
    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mLastMediaHandler = Handler()
    private var mLastOwnChangeTime = 0L
    private val mObserverHandler = Handler(Looper.getMainLooper())
    private val mMediaObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            // thay đổi từ app khác (hoặc từ chính mình): gom lại, refresh một lần
            mObserverHandler.removeCallbacksAndMessages(null)
            mObserverHandler.postDelayed({ refreshFromObserver() }, 250)
        }
    }

    private fun refreshFromObserver() {
        if (isDestroyed || isFinishing || mIsSearchOpen) {
            return
        }

        // thay đổi do chính mình vừa xóa: danh sách đã được cập nhật tại chỗ, tránh nạp lại gây nháy / hiện lại file
        if (System.currentTimeMillis() - mLastOwnChangeTime < 3000) {
            return
        }

        if (mIsGettingMedia) {
            mObserverHandler.postDelayed({ refreshFromObserver() }, 300)
        } else {
            getMedia()
        }
    }
    private var mTempShowHiddenHandler = Handler()
    private var mCurrAsyncTask: GetMediaAsynctask? = null
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null

    private var mStoredAnimateGifs = true
    private var mStoredCropThumbnails = true
    private var mStoredScrollHorizontally = true
    private var mStoredShowFileTypes = true
    private var mStoredRoundedCorners = false
    private var mStoredMarkFavoriteItems = true
    private var mStoredTextColor = 0
    private var mStoredPrimaryColor = 0
    private var mStoredThumbnailSpacing = 0

    // ===== Header ảnh bìa (collapsing) =====
    private val COVER_BLUR = 0.1f         // độ làm mờ (blur) ảnh bìa: 10%, KHÔNG làm tối
    private val COVER_EXPANDED_DP = 88 * 1.1f // chiều cao header (phần dưới thanh trạng thái): bản cũ 88dp, nay dài thêm 10% (~96.8dp)
    private var mStatusInset = 0
    private var mCoverDirName = ""
    private var mCoverSetupDone = false      // đã dựng header rồi => quay lại từ video không dựng lại (giữ nguyên vị trí co/giãn)
    private var mAppliedCover: String? = null
    private var mCoverActive = false
    private var mCoverFraction = 0f       // 0 = mở rộng hết, 1 = co lại hoàn toàn
    private var mTitleLayoutListenerAdded = false
    private var mStatusOnToolbar = false     // thanh trạng thái đang nằm trên màu toolbar (đã cuộn) hay còn nằm trên ảnh bìa
    private var mStatusLightBackup = false   // nhớ kiểu icon thanh trạng thái lúc còn ở trên ảnh bìa để trả lại
    private val mCoverOffsetListener = AppBarLayout.OnOffsetChangedListener { appBar, offset ->
        val range = appBar.totalScrollRange
        mCoverFraction = if (range > 0) (-offset).toFloat() / range else 0f
        applyCoverFraction()
    }

    companion object {
        var mMedia = ArrayList<ThumbnailItem>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_media)
        lockStatusBarInset(
            findViewById(R.id.media_grid),
            isEdgeToEdgeTop = { mCoverActive },
            onTopInset = {
                if (it != mStatusInset) {
                    mStatusInset = it
                    applyCoverInsets()
                }
            }
        )

        intent.apply {
            mIsGetImageIntent = getBooleanExtra(GET_IMAGE_INTENT, false)
            mIsGetVideoIntent = getBooleanExtra(GET_VIDEO_INTENT, false)
            mIsGetAnyIntent = getBooleanExtra(GET_ANY_INTENT, false)
            mAllowPickingMultiple = getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
        }

        media_refresh_layout.setOnRefreshListener { getMedia() }
        setupScrollAnchorListener()
        try {
            mPath = intent.getStringExtra(DIRECTORY) ?: ""
        } catch (e: Exception) {
            showErrorToast(e)
            finish()
            return
        }

        setupOptionsMenu()
        refreshMenuItems()
        storeStateVariables()

        if (mShowAll) {
            registerFileUpdateListener()
        }

        media_empty_text_placeholder_2.setOnClickListener {
            showFilterMediaDialog()
        }

        updateWidgets()
    }

    override fun onStart() {
        super.onStart()
        mTempShowHiddenHandler.removeCallbacksAndMessages(null)
        try {
            contentResolver.registerContentObserver(android.provider.MediaStore.Files.getContentUri("external"), true, mMediaObserver)
        } catch (ignored: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        if (mSavedScrollPos >= 0 && media_grid.adapter != null) {
            if (applyScrollAnchor(mSavedScrollPos, mSavedScrollOffset, mSavedAtEnd)) {
                startRestoreGuard()
                guardPos = mSavedScrollPos
                guardOffset = mSavedScrollOffset
                guardAtEnd = mSavedAtEnd
            }
        }
        if (mStoredAnimateGifs != config.animateGifs) {
            getMediaAdapter()?.updateAnimateGifs(config.animateGifs)
        }

        if (mStoredCropThumbnails != config.cropThumbnails) {
            getMediaAdapter()?.updateCropThumbnails(config.cropThumbnails)
        }

        if (mStoredScrollHorizontally != config.scrollHorizontally) {
            mLoadedInitialPhotos = false
            media_grid.adapter = null
            getMedia()
        }

        if (mStoredShowFileTypes != config.showThumbnailFileTypes) {
            getMediaAdapter()?.updateShowFileTypes(config.showThumbnailFileTypes)
        }

        if (mStoredTextColor != getProperTextColor()) {
            getMediaAdapter()?.updateTextColor(getProperTextColor())
        }

        val primaryColor = getProperPrimaryColor()
        if (mStoredPrimaryColor != primaryColor) {
            getMediaAdapter()?.updatePrimaryColor()
        }

        if (
            mStoredThumbnailSpacing != config.thumbnailSpacing
            || mStoredRoundedCorners != config.fileRoundedCorners
            || mStoredMarkFavoriteItems != config.markFavoriteItems
        ) {
            media_grid.adapter = null
            setupAdapter()
        }

        val navigation = if (mShowAll) {
            NavigationIcon.None
        } else {
            NavigationIcon.Arrow
        }

        setupToolbar(media_toolbar, navigation, searchMenuItem = mSearchMenuItem)
        applyCoverToolbarStyle()
        refreshMenuItems()

        media_fastscroller.updateColors(primaryColor)
        media_refresh_layout.isEnabled = config.enablePullToRefresh
        getMediaAdapter()?.apply {
            dateFormat = config.dateFormat
            timeFormat = getTimeFormat()
        }

        media_empty_text_placeholder.setTextColor(getProperTextColor())
        media_empty_text_placeholder_2.setTextColor(getProperPrimaryColor())
        media_empty_text_placeholder_2.bringToFront()

        // do not refresh Random sorted files after opening a fullscreen image and going Back
        val isRandomSorting = config.getFolderSorting(mPath) and SORT_BY_RANDOM != 0
        if (mMedia.isEmpty() || !isRandomSorting || (isRandomSorting && !mWasFullscreenViewOpen)) {
            if (shouldSkipAuthentication()) {
                tryLoadGallery()
            } else {
                handleLockedFolderOpening(mPath) { success ->
                    if (success) {
                        tryLoadGallery()
                    } else {
                        finish()
                    }
                }
            }
        }
    }

    // ===== Giữ vị trí cuộn của list (không liên quan tới trình phát) =====
    // Lưu: item đầu tiên đang thấy + độ lệch so với mép, và cờ "đang ở cuối list".
    // Nếu đang ở cuối list thì khôi phục bằng cách dán hàng cuối vào đáy, không phụ thuộc chiều cao vùng hiển thị lúc đó
    // (lúc trình phát vừa đóng, thanh điều hướng/hệ thống còn đang đổi kích thước nên chiều cao có thể lệch).

    private fun isVerticalList(): Boolean {
        val lm = media_grid.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager ?: return true
        return lm.orientation == RecyclerView.VERTICAL
    }

    private fun isListAtEnd(): Boolean {
        return if (isVerticalList()) !media_grid.canScrollVertically(1) else !media_grid.canScrollHorizontally(1)
    }

    private fun captureScrollAnchor(): Triple<Int, Int, Boolean>? {
        val lm = media_grid.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager ?: return null
        val pos = lm.findFirstVisibleItemPosition()
        if (pos < 0) {
            return null
        }

        val view = lm.findViewByPosition(pos)
        val offset = when {
            view == null -> 0
            lm.orientation == RecyclerView.VERTICAL -> view.top
            else -> view.left
        }
        return Triple(pos, offset, pos > 0 && isListAtEnd())
    }

    private fun rememberScrollPosition() {
        captureScrollAnchor()?.let {
            mSavedScrollPos = it.first
            mSavedScrollOffset = it.second
            mSavedAtEnd = it.third
        }
    }

    private fun applyScrollAnchor(pos: Int, offset: Int, atEnd: Boolean): Boolean {
        val lm = media_grid.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager ?: return false
        val count = media_grid.adapter?.itemCount ?: 0
        if (pos < 0 || count <= 0) {
            return false
        }

        if (atEnd) {
            lm.scrollToPositionWithOffset(count - 1, 0)   // LayoutManager tự kéo hàng cuối sát đáy
        } else {
            lm.scrollToPositionWithOffset(minOf(pos, count - 1), offset)
        }
        return true
    }

    // Trong ~1,5 giây sau khi khôi phục: nếu vùng hiển thị của list đổi kích thước thì đặt lại vị trí một lần nữa.
    // Người dùng chạm/vuốt thì hủy ngay.
    private fun startRestoreGuard() {
        mRestoreGuardUntil = System.currentTimeMillis() + 1500
    }

    override fun onSaveInstanceState(outState: android.os.Bundle) {
        rememberScrollPosition()
        outState.putInt("saved_scroll_pos", mSavedScrollPos)
        outState.putInt("saved_scroll_offset", mSavedScrollOffset)
        outState.putBoolean("saved_scroll_at_end", mSavedAtEnd)
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: android.os.Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        mSavedScrollPos = savedInstanceState.getInt("saved_scroll_pos", -1)
        mSavedScrollOffset = savedInstanceState.getInt("saved_scroll_offset", 0)
        mSavedAtEnd = savedInstanceState.getBoolean("saved_scroll_at_end", false)
    }

    // adapter vừa được tạo mới: đưa list về đúng chỗ đã lưu
    private fun restoreScrollPosition() {
        if (mSavedScrollPos < 0) {
            return
        }

        if (applyScrollAnchor(mSavedScrollPos, mSavedScrollOffset, mSavedAtEnd)) {
            startRestoreGuard()
            // giữ mốc đến hết thời gian guard để còn đặt lại nếu kích thước đổi
            guardPos = mSavedScrollPos
            guardOffset = mSavedScrollOffset
            guardAtEnd = mSavedAtEnd
            mSavedScrollPos = -1
        }
    }

    private var guardPos = -1
    private var guardOffset = 0
    private var guardAtEnd = false

    private fun setupScrollAnchorListener() {
        media_grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    // người dùng tự cuộn: bỏ mọi mốc cũ
                    mSavedScrollPos = -1
                    mRestoreGuardUntil = 0L
                }
            }
        })

        media_grid.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            val sizeChanged = (bottom - top) != (oldBottom - oldTop) || (right - left) != (oldRight - oldLeft)
            if (sizeChanged && guardPos >= 0 && System.currentTimeMillis() < mRestoreGuardUntil) {
                media_grid.post {
                    if (System.currentTimeMillis() < mRestoreGuardUntil) {
                        applyScrollAnchor(guardPos, guardOffset, guardAtEnd)
                    }
                }
            }
        }
    }

    private fun setRefreshLayoutSize(width: Int, height: Int) {
        val current = media_refresh_layout.layoutParams
        if (current is RelativeLayout.LayoutParams && current.width == width && current.height == height) {
            return
        }
        media_refresh_layout.layoutParams = RelativeLayout.LayoutParams(width, height)
    }

    override fun onPause() {
        super.onPause()
        rememberScrollPosition()
        mIsGettingMedia = false
        media_refresh_layout.isRefreshing = false
        storeStateVariables()
        mLastMediaHandler.removeCallbacksAndMessages(null)

        if (!mMedia.isEmpty()) {
            mCurrAsyncTask?.stopFetching()
        }
    }

    override fun onStop() {
        super.onStop()
        try {
            contentResolver.unregisterContentObserver(mMediaObserver)
        } catch (ignored: Exception) {
        }
        mObserverHandler.removeCallbacksAndMessages(null)

        if (config.temporarilyShowHidden || config.tempSkipDeleteConfirmation) {
            mTempShowHiddenHandler.postDelayed({
                config.temporarilyShowHidden = false
                config.tempSkipDeleteConfirmation = false
            }, SHOW_TEMP_HIDDEN_DURATION)
        } else {
            mTempShowHiddenHandler.removeCallbacksAndMessages(null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (config.showAll && !isChangingConfigurations) {
            config.temporarilyShowHidden = false
            config.tempSkipDeleteConfirmation = false
            unregisterFileUpdateListener()
            GalleryDatabase.destroyInstance()
        }

        mTempShowHiddenHandler.removeCallbacksAndMessages(null)
    }

    override fun onBackPressed() {
        if (mIsSearchOpen && mSearchMenuItem != null) {
            mSearchMenuItem!!.collapseActionView()
        } else {
            super.onBackPressed()
        }
    }

    private fun refreshMenuItems() {
        val isDefaultFolder = !config.defaultFolder.isEmpty() && File(config.defaultFolder).compareTo(File(mPath)) == 0

        media_toolbar.menu.apply {
            findItem(R.id.group).isVisible = !config.scrollHorizontally

            findItem(R.id.empty_recycle_bin).isVisible = mPath == RECYCLE_BIN
            findItem(R.id.empty_disable_recycle_bin).isVisible = mPath == RECYCLE_BIN
            findItem(R.id.restore_all_files).isVisible = mPath == RECYCLE_BIN

            findItem(R.id.folder_view).isVisible = mShowAll
            findItem(R.id.open_camera).isVisible = mShowAll
            findItem(R.id.about).isVisible = mShowAll
            findItem(R.id.create_new_folder).isVisible = !mShowAll && mPath != RECYCLE_BIN && mPath != FAVORITES

            findItem(R.id.temporarily_show_hidden).isVisible = (!isRPlus() || isExternalStorageManager()) && !config.shouldShowHidden
            findItem(R.id.stop_showing_hidden).isVisible = (!isRPlus() || isExternalStorageManager()) && config.temporarilyShowHidden

            findItem(R.id.set_as_default_folder).isVisible = !isDefaultFolder
            findItem(R.id.unset_as_default_folder).isVisible = isDefaultFolder

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            findItem(R.id.increase_column_count).isVisible = viewType == VIEW_TYPE_GRID && config.mediaColumnCnt < MAX_COLUMN_COUNT
            findItem(R.id.reduce_column_count).isVisible = viewType == VIEW_TYPE_GRID && config.mediaColumnCnt > 1
            findItem(R.id.toggle_filename).isVisible = viewType == VIEW_TYPE_GRID

            // sắp xếp Tùy chỉnh: nhấn giữ dùng để kéo thả nên cần mục riêng để vào chế độ chọn nhiều
            val isCustomSorting = config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath) and SORT_BY_CUSTOM != 0
            findItem(R.id.select_items).isVisible = isCustomSorting && !(mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent)
        }
    }

    private fun setupOptionsMenu() {
        setupSearch(media_toolbar.menu)
        media_toolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.sort -> showSortingDialog()
                R.id.select_items -> getMediaAdapter()?.startSelectionMode()
                R.id.filter -> showFilterMediaDialog()
                R.id.empty_recycle_bin -> emptyRecycleBin()
                R.id.empty_disable_recycle_bin -> emptyAndDisableRecycleBin()
                R.id.restore_all_files -> restoreAllFiles()
                R.id.toggle_filename -> toggleFilenameVisibility()
                R.id.open_camera -> launchCamera()
                R.id.folder_view -> switchToFolderView()
                R.id.change_view_type -> changeViewType()
                R.id.group -> showGroupByDialog()
                R.id.create_new_folder -> createNewFolder()
                R.id.temporarily_show_hidden -> tryToggleTemporarilyShowHidden()
                R.id.stop_showing_hidden -> tryToggleTemporarilyShowHidden()
                R.id.increase_column_count -> increaseColumnCount()
                R.id.reduce_column_count -> reduceColumnCount()
                R.id.set_as_default_folder -> setAsDefaultFolder()
                R.id.unset_as_default_folder -> unsetAsDefaultFolder()
                R.id.slideshow -> startSlideshow()
                R.id.settings -> launchSettings()
                R.id.about -> launchAbout()
                else -> return@setOnMenuItemClickListener false
            }
            return@setOnMenuItemClickListener true
        }
    }

    private fun startSlideshow() {
        if (mMedia.isNotEmpty()) {
            hideKeyboard()
            Intent(this, ViewPagerActivity::class.java).apply {
                val item = mMedia.firstOrNull { it is Medium } as? Medium ?: return
                putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                putExtra(PATH, item.path)
                putExtra(SHOW_ALL, mShowAll)
                putExtra(SLIDESHOW_START_ON_ENTER, true)
                startActivity(this)
            }
        }
    }

    private fun storeStateVariables() {
        mStoredTextColor = getProperTextColor()
        mStoredPrimaryColor = getProperPrimaryColor()
        config.apply {
            mStoredAnimateGifs = animateGifs
            mStoredCropThumbnails = cropThumbnails
            mStoredScrollHorizontally = scrollHorizontally
            mStoredShowFileTypes = showThumbnailFileTypes
            mStoredMarkFavoriteItems = markFavoriteItems
            mStoredThumbnailSpacing = thumbnailSpacing
            mStoredRoundedCorners = fileRoundedCorners
            mShowAll = showAll
        }
    }

    private fun setupSearch(menu: Menu) {
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        mSearchMenuItem = menu.findItem(R.id.search)
        (mSearchMenuItem?.actionView as? SearchView)?.apply {
            setSearchableInfo(searchManager.getSearchableInfo(componentName))
            isSubmitButtonEnabled = false
            setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String) = false

                override fun onQueryTextChange(newText: String): Boolean {
                    if (mIsSearchOpen) {
                        mLastSearchedText = newText
                        searchQueryChanged(newText)
                    }
                    return true
                }
            })
        }

        MenuItemCompat.setOnActionExpandListener(mSearchMenuItem, object : MenuItemCompat.OnActionExpandListener {
            override fun onMenuItemActionExpand(item: MenuItem?): Boolean {
                mIsSearchOpen = true
                media_refresh_layout.isEnabled = false
                if (mCoverActive) media_cover_title.visibility = android.view.View.INVISIBLE
                return true
            }

            // this triggers on device rotation too, avoid doing anything
            override fun onMenuItemActionCollapse(item: MenuItem?): Boolean {
                if (mIsSearchOpen) {
                    mIsSearchOpen = false
                    mLastSearchedText = ""
                    if (mCoverActive) { media_cover_title.visibility = android.view.View.VISIBLE; applyCoverTitleTransform() }

                    media_refresh_layout.isEnabled = config.enablePullToRefresh
                    searchQueryChanged("")
                }
                return true
            }
        })
    }

    private fun searchQueryChanged(text: String) {
        ensureBackgroundThread {
            try {
                val filtered = mMedia.filter { it is Medium && it.name.contains(text, true) } as ArrayList
                filtered.sortBy { it is Medium && !it.name.startsWith(text, true) }
                val grouped = MediaFetcher(applicationContext).groupMedia(filtered as ArrayList<Medium>, mPath)
                runOnUiThread {
                    if (grouped.isEmpty()) {
                        media_empty_text_placeholder.text = getString(R.string.no_items_found)
                        media_empty_text_placeholder.beVisible()
                        media_fastscroller.beGone()
                    } else {
                        media_empty_text_placeholder.beGone()
                        media_fastscroller.beVisible()
                    }

                    handleGridSpacing(grouped)
                    getMediaAdapter()?.updateMedia(grouped)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun tryLoadGallery() {
        handlePermission(getPermissionToRequest()) {
            if (it) {
                val dirName = when {
                    mPath == FAVORITES -> getString(R.string.favorites)
                    mPath == RECYCLE_BIN -> getString(R.string.recycle_bin)
                    mPath == config.OTGPath -> getString(R.string.usb)
                    else -> getHumanizedFilename(mPath)
                }

                media_toolbar.title = if (mShowAll) resources.getString(R.string.all_folders) else dirName
                setupCoverHeader(if (mShowAll) resources.getString(R.string.all_folders) else dirName)
                getMedia()
                setupLayoutManager()
            } else {
                toast(R.string.no_storage_permissions)
                finish()
            }
        }
    }


    // ===== Header ảnh bìa: mở rộng xuống + làm mờ 20%, cuộn thì co lại, co hết thì về layout mặc định (không còn ảnh bìa) =====
    private fun findAlbumCover(): String? {
        if (mShowAll || mPath.isEmpty() || mPath == FAVORITES || mPath == RECYCLE_BIN) return null
        val otgPath = config.OTGPath
        return config.parseAlbumCovers().firstOrNull { it.path == mPath && getDoesFilePathExist(it.tmb, otgPath) }?.tmb
    }

    private fun setupCoverHeader(dirName: String, force: Boolean = false) {
        mCoverDirName = dirName
        val cover = findAlbumCover()
        // Quay về từ trình phát video: onResume gọi lại hàm này. Nếu ảnh bìa + tên thư mục không đổi thì giữ nguyên
        // header (đang co hay giãn thế nào giữ thế đó), không setExpanded(true) làm nhảy về đầu.
        if (!force && mCoverSetupDone && cover == mAppliedCover) {
            if (mCoverActive) {
                media_cover_title.text = dirName
                applyCoverToolbarStyle()
            }
            return
        }
        mCoverSetupDone = true
        mAppliedCover = cover
        val lp = media_collapsing.layoutParams as AppBarLayout.LayoutParams
        media_app_bar_layout.removeOnOffsetChangedListener(mCoverOffsetListener)

        if (cover == null) {
            // layout mặc định: chỉ có toolbar, không cuộn, không ảnh bìa
            mCoverActive = false
            mCoverFraction = 0f
            lp.scrollFlags = 0
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            media_collapsing.layoutParams = lp
            media_cover_holder.beGone()
            media_cover_texts.beGone()
            media_app_bar_layout.setExpanded(true, false)
            media_toolbar.setBackgroundColor(getProperStatusBarColor())
            media_toolbar.setTitleTextColor(getProperStatusBarColor().getContrastColor())
            window.statusBarColor = getSystemStatusBarColor()
            setStatusOnToolbar(false)
            media_cover_title.beGone()
            media_toolbar.title = dirName
            media_toolbar.titleMarginStart = 0
            media_collapsing.setScrimsShown(false, false)
            applyCoverInsets()
            window.decorView.requestApplyInsets()
            return
        }

        mCoverActive = true
        lp.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL or AppBarLayout.LayoutParams.SCROLL_FLAG_EXIT_UNTIL_COLLAPSED
        lp.height = (COVER_EXPANDED_DP * resources.displayMetrics.density).toInt() + mStatusInset
        media_collapsing.layoutParams = lp

        media_cover_dim.alpha = 0f
        media_cover_title.text = dirName
        media_cover_title.visibility = if (mIsSearchOpen) android.view.View.INVISIBLE else android.view.View.VISIBLE
        applyCoverTitleStyle()
        media_cover_subtitle.text = ""
        media_cover_holder.beVisible()
        media_cover_texts.beVisible()
        Glide.with(applicationContext).load(cover)
            .transform(com.bumptech.glide.load.resource.bitmap.CenterCrop(), BlurTransformation(COVER_BLUR))
            .into(media_cover_image)

        media_app_bar_layout.setExpanded(true, false)
        media_app_bar_layout.addOnOffsetChangedListener(mCoverOffsetListener)
        mCoverFraction = 0f
        applyCoverInsets()
        window.decorView.requestApplyInsets()
        applyCoverToolbarStyle()
    }

    // ảnh bìa tràn lên dưới thanh trạng thái: toolbar giữ NGUYÊN chiều cao mặc định, chỉ đẩy xuống bằng margin
    // (không đệm padding nữa => icon/tiêu đề luôn căn giữa đúng như toolbar ở màn hình chính)
    private fun applyCoverInsets() {
        val barH = resources.getDimensionPixelSize(R.dimen.gallery_toolbar_height)
        val inset = if (mCoverActive) mStatusInset else 0
        media_toolbar.setPadding(0, 0, 0, 0)
        (media_toolbar.layoutParams as ViewGroup.MarginLayoutParams).let {
            it.height = barH
            it.topMargin = inset
            media_toolbar.layoutParams = it
        }
        // co hết cỡ = đúng bằng (thanh trạng thái + toolbar mặc định)
        media_collapsing.minimumHeight = barH + inset
        media_collapsing.scrimVisibleHeightTrigger = barH + inset + (16 * resources.displayMetrics.density).toInt()
        media_collapsing.scrimAnimationDuration = 150L
        if (mCoverActive) {
            val lp = media_collapsing.layoutParams
            lp.height = (COVER_EXPANDED_DP * resources.displayMetrics.density).toInt() + inset
            media_collapsing.layoutParams = lp
        }
    }

    // toolbar trong suốt khi đang mở rộng; setupToolbar() của commons luôn tô lại màu nên gọi lại sau mỗi lần setup
    private fun applyCoverToolbarStyle() {
        if (!mCoverActive) return
        applyCoverTitleStyle()
        applyCoverFraction()
    }

    // Tên thư mục: nằm dưới ảnh bìa (to) khi mở rộng; vuốt lên thì KHÔNG mờ đi mà nhỏ dần và đi xéo
    // (dịch đồng thời cả 2 trục) đến đúng vị trí tiêu đề mặc định của toolbar rồi dừng ở đó.
    private fun applyCoverTitleStyle() {
        if (!mCoverActive) return
        val d = resources.displayMetrics.density
        media_toolbar.title = ""   // tiêu đề toolbar để trống: chỉ còn 1 tiêu đề duy nhất là media_cover_title
        media_cover_title.text = mCoverDirName
        // cỡ chữ lúc mở rộng: 26sp, tên dài thì thu vừa 1 dòng (tối thiểu 14sp) chứ không cắt chữ
        val availW = resources.displayMetrics.widthPixels - 16 * d
        var sizePx = 26f * resources.displayMetrics.scaledDensity
        val paint = android.text.TextPaint(media_cover_title.paint)
        paint.textSize = sizePx
        val w = paint.measureText(mCoverDirName)
        if (w > availW) sizePx = (sizePx * availW / w).coerceAtLeast(14f * resources.displayMetrics.scaledDensity)
        media_cover_title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sizePx)
        media_cover_title.pivotX = 0f
        media_cover_title.pivotY = 0f
        if (!mTitleLayoutListenerAdded) {
            mTitleLayoutListenerAdded = true
            media_cover_title.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyCoverTitleTransform() }
        }
        applyCoverTitleTransform()
    }

    private fun applyCoverTitleTransform() {
        if (!mCoverActive) return
        val tv = media_cover_title
        val h = tv.height
        if (h <= 0) return
        val d = resources.displayMetrics.density
        val f = mCoverFraction.coerceIn(0f, 1f)
        val range = media_app_bar_layout.totalScrollRange
        val barH = resources.getDimensionPixelSize(R.dimen.gallery_toolbar_height)

        // tỉ lệ thu nhỏ cuối cùng: về cỡ chữ tiêu đề toolbar (21sp), nhưng không to hơn cỡ đang có và không đè lên các nút bên phải
        val expandedPx = tv.textSize
        var collapsedPx = minOf(expandedPx, 21f * resources.displayMetrics.scaledDensity)
        // vị trí tiêu đề mặc định của toolbar: ngay sau nút back (đọc đúng vị trí thật của nút, dự phòng 56dp); không có nút back thì lề 16dp
        var xTarget = (if (mShowAll) 16 else 56) * d
        if (!mShowAll) {
            for (i in 0 until media_toolbar.childCount) {
                val c = media_toolbar.getChildAt(i)
                if (c is android.widget.ImageButton && c.width > 0) xTarget = c.right.toFloat()
            }
        }
        var menuW = 0
        for (i in 0 until media_toolbar.childCount) {
            val c = media_toolbar.getChildAt(i)
            if (c is androidx.appcompat.widget.ActionMenuView) menuW = c.width
        }
        if (menuW == 0) menuW = (144 * d).toInt()
        val textW = tv.paint.measureText(mCoverDirName)
        val collapsedAvail = resources.displayMetrics.widthPixels - xTarget - menuW
        if (textW > 0f && textW * (collapsedPx / expandedPx) > collapsedAvail) {
            collapsedPx = (expandedPx * collapsedAvail / textW).coerceAtLeast(expandedPx * 0.5f)
        }
        val sC = collapsedPx / expandedPx
        val scale = 1f + f * (sC - 1f)

        // đích: căn giữa dọc trong toolbar (nằm dưới thanh trạng thái)
        val yTarget = mStatusInset + (barH - h * sC) / 2f
        val layoutTop = tv.top.toFloat()
        val layoutLeft = tv.left.toFloat()
        val yNow = layoutTop + f * (yTarget - layoutTop)
        // header cuộn lên theo offset = -f * range, nên bù lại để vị trí thật trên màn hình nội suy tuyến tính theo f
        tv.translationY = yNow - layoutTop + f * range
        tv.translationX = f * (xTarget - layoutLeft)
        tv.scaleX = scale
        tv.scaleY = scale
        tv.setTextColor(Color.WHITE.let { if (f >= 0.7f) getProperStatusBarColor().getContrastColor() else it })
    }

    private fun applyCoverFraction() {
        if (!mCoverActive) return
        val f = mCoverFraction.coerceIn(0f, 1f)
        // dòng thống kê (dải dưới toolbar) mờ dần khi cuộn
        val textAlpha = (1f - f * 2f).coerceIn(0f, 1f)
        media_cover_texts.alpha = textAlpha
        media_cover_texts.beVisibleIf(textAlpha > 0f)
        // co hết cỡ => ảnh bìa biến mất hoàn toàn, về layout mặc định
        media_cover_holder.beVisibleIf(f < 0.999f)
        val primary = getProperStatusBarColor()
        // toolbar luôn trong suốt; khi cuộn, CollapsingToolbarLayout tự phủ màu chính lên TOÀN BỘ header
        // (gồm cả vùng thanh trạng thái) => toolbar chiếm luôn màu thanh trạng thái
        media_toolbar.setBackgroundColor(Color.TRANSPARENT)
        media_collapsing.setContentScrimColor(primary)
        window.statusBarColor = Color.TRANSPARENT
        setStatusOnToolbar(f >= 0.7f)
        applyCoverTitleTransform()
    }

    // đổi icon thanh trạng thái (sáng/tối) cho hợp với nền: màu toolbar khi đã cuộn, ảnh bìa khi còn mở rộng
    @Suppress("DEPRECATION")
    private fun setStatusOnToolbar(onToolbar: Boolean) {
        if (onToolbar == mStatusOnToolbar) return
        mStatusOnToolbar = onToolbar
        val flag = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val vis = window.decorView.systemUiVisibility
        val light = if (onToolbar) {
            mStatusLightBackup = (vis and flag) != 0
            getProperStatusBarColor().getContrastColor() == 0xFF333333.toInt()
        } else {
            mStatusLightBackup
        }
        window.decorView.systemUiVisibility = if (light) vis or flag else vis and flag.inv()
    }

    private fun updateCoverSubtitle(media: ArrayList<ThumbnailItem>) {
        if (!mCoverActive) return
        var photos = 0
        var videos = 0
        var others = 0
        media.forEach {
            if (it is Medium) {
                when {
                    it.isImage() -> photos++
                    it.isVideo() -> videos++
                    else -> others++
                }
            }
        }
        media_cover_subtitle.text = getString(R.string.media_summary, photos, videos, others)
    }

    private fun getMediaAdapter() = media_grid.adapter as? MediaAdapter

    private fun setupAdapter() {
        if (!mShowAll && isDirEmpty()) {
            return
        }

        val currAdapter = media_grid.adapter
        if (currAdapter == null) {
            initZoomListener()
            MediaAdapter(
                this, mMedia.clone() as ArrayList<ThumbnailItem>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mPath, media_grid
            ) {
                if (it is Medium && !isFinishing) {
                    itemClicked(it.path)
                }
            }.apply {
                setupZoomListener(mZoomListener)
                media_grid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST && areSystemAnimationsEnabled && mSavedScrollPos < 0) {
                media_grid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
            restoreScrollPosition()
        } else if (mLastSearchedText.isEmpty()) {
            // vừa quay lại từ trình phát thì ưu tiên mốc đã lưu lúc rời đi, không thì lấy vị trí đang xem
            val hasSavedAnchor = mSavedScrollPos >= 0
            val anchor = if (hasSavedAnchor) {
                Triple(mSavedScrollPos, mSavedScrollOffset, mSavedAtEnd)
            } else if (media_grid.scrollState == RecyclerView.SCROLL_STATE_IDLE) {
                captureScrollAnchor()   // đang vuốt/fling thì không ép lại vị trí, tránh giật
            } else {
                null
            }
            (currAdapter as MediaAdapter).updateMedia(mMedia)
            handleGridSpacing()
            if (anchor != null && applyScrollAnchor(anchor.first, anchor.second, anchor.third)) {
                if (hasSavedAnchor) {
                    startRestoreGuard()
                    guardPos = anchor.first
                    guardOffset = anchor.second
                    guardAtEnd = anchor.third
                }
                mSavedScrollPos = -1
            }
        } else {
            searchQueryChanged(mLastSearchedText)
        }

        setupScrollDirection()
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val scrollHorizontally = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        media_fastscroller.setScrollVertically(!scrollHorizontally)
    }

    private fun checkLastMediaChanged() {
        if (isDestroyed || config.getFolderSorting(mPath) and SORT_BY_RANDOM != 0) {
            return
        }

        mLastMediaHandler.removeCallbacksAndMessages(null)
        mLastMediaHandler.postDelayed({
            ensureBackgroundThread {
                val mediaId = getLatestMediaId()
                val mediaDateId = getLatestMediaByDateId()
                if (mLatestMediaId != mediaId || mLatestMediaDateId != mediaDateId) {
                    mLatestMediaId = mediaId
                    mLatestMediaDateId = mediaDateId
                    runOnUiThread {
                        getMedia()
                    }
                } else {
                    checkLastMediaChanged()
                }
            }
        }, LAST_MEDIA_CHECK_PERIOD)
    }

    private fun showSortingDialog() {
        ChangeSortingDialog(this, false, true, mPath) {
            seedCustomOrderIfNeeded()
            mLoadedInitialPhotos = false
            media_grid.adapter = null
            getMedia()
        }
    }

    // lần đầu chuyển sang "Tùy chỉnh" thì giữ nguyên thứ tự đang thấy trên màn hình làm điểm xuất phát
    private fun seedCustomOrderIfNeeded() {
        val orderKey = if (mShowAll) SHOW_ALL else mPath
        if (config.getFolderSorting(orderKey) and SORT_BY_CUSTOM == 0 || config.hasCustomMediaOrder(orderKey)) {
            return
        }

        val currentOrder = mMedia.filterIsInstance<Medium>().map { it.path }
        if (currentOrder.isNotEmpty()) {
            config.saveCustomMediaOrder(orderKey, currentOrder)
        }
    }

    private fun showFilterMediaDialog() {
        FilterMediaDialog(this) {
            mLoadedInitialPhotos = false
            media_refresh_layout.isRefreshing = true
            media_grid.adapter = null
            getMedia()
        }
    }

    private fun emptyRecycleBin() {
        showRecycleBinEmptyingDialog {
            emptyTheRecycleBin {
                finish()
            }
        }
    }

    private fun emptyAndDisableRecycleBin() {
        showRecycleBinEmptyingDialog {
            emptyAndDisableTheRecycleBin {
                finish()
            }
        }
    }

    private fun restoreAllFiles() {
        val paths = mMedia.filter { it is Medium }.map { (it as Medium).path } as ArrayList<String>
        restoreRecycleBinPaths(paths) {
            ensureBackgroundThread {
                directoryDB.deleteDirPath(RECYCLE_BIN)
            }
            finish()
        }
    }

    private fun toggleFilenameVisibility() {
        config.displayFileNames = !config.displayFileNames
        getMediaAdapter()?.updateDisplayFilenames(config.displayFileNames)
    }

    private fun switchToFolderView() {
        hideKeyboard()
        config.showAll = false
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun changeViewType() {
        ChangeViewTypeDialog(this, false, mPath) {
            refreshMenuItems()
            setupLayoutManager()
            media_grid.adapter = null
            setupAdapter()
        }
    }

    private fun showGroupByDialog() {
        ChangeGroupingDialog(this, mPath) {
            mLoadedInitialPhotos = false
            media_grid.adapter = null
            getMedia()
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                    }
                }
            }
        }
    }

    private fun getMedia() {
        if (mIsGettingMedia) {
            return
        }

        mIsGettingMedia = true
        if (mLoadedInitialPhotos) {
            startAsyncTask()
        } else {
            getCachedMedia(mPath, mIsGetVideoIntent, mIsGetImageIntent) {
                if (it.isEmpty()) {
                    runOnUiThread {
                        media_refresh_layout.isRefreshing = true
                    }
                } else {
                    gotMedia(it, true)
                }
                startAsyncTask()
            }
        }

        mLoadedInitialPhotos = true
    }

    private fun startAsyncTask() {
        mCurrAsyncTask?.stopFetching()
        mCurrAsyncTask = GetMediaAsynctask(applicationContext, mPath, mIsGetImageIntent, mIsGetVideoIntent, mShowAll) {
            ensureBackgroundThread {
                val oldMedia = mMedia.clone() as ArrayList<ThumbnailItem>
                val newMedia = it
                try {
                    gotMedia(newMedia, false)

                    // remove cached files that are no longer valid for whatever reason
                    val newPaths = newMedia.mapNotNull { it as? Medium }.map { it.path }.toHashSet()
                    oldMedia.mapNotNull { it as? Medium }.filter { !newPaths.contains(it.path) }.forEach {
                        if (mPath == FAVORITES && getDoesFilePathExist(it.path)) {
                            favoritesDB.deleteFavoritePath(it.path)
                            mediaDB.updateFavorite(it.path, false)
                        } else {
                            mediaDB.deleteMediumPath(it.path)
                        }
                    }
                } catch (e: Exception) {
                }
            }
        }

        mCurrAsyncTask!!.execute()
    }

    private fun isDirEmpty(): Boolean {
        return if (mMedia.size <= 0 && config.filterMedia > 0) {
            if (mPath != FAVORITES && mPath != RECYCLE_BIN) {
                deleteDirectoryIfEmpty()
                deleteDBDirectory()
            }

            if (mPath == FAVORITES) {
                ensureBackgroundThread {
                    directoryDB.deleteDirPath(FAVORITES)
                }
            }

            finish()
            true
        } else {
            false
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                directoryDB.deleteDirPath(mPath)
            } catch (ignored: Exception) {
            }
        }
    }

    private fun createNewFolder() {
        CreateNewFolderDialog(this, mPath) {
            config.tempFolderPath = it
        }
    }

    private fun tryToggleTemporarilyShowHidden() {
        if (config.temporarilyShowHidden) {
            toggleTemporarilyShowHidden(false)
        } else {
            handleHiddenFolderPasswordProtection {
                toggleTemporarilyShowHidden(true)
            }
        }
    }

    private fun toggleTemporarilyShowHidden(show: Boolean) {
        mLoadedInitialPhotos = false
        config.temporarilyShowHidden = show
        getMedia()
        refreshMenuItems()
    }

    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
            setRefreshLayoutSize(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
            setRefreshLayoutSize(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        layoutManager.spanCount = config.mediaColumnCnt
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupListLayoutManager() {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL
        setRefreshLayoutSize(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        mZoomListener = null
    }

    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            // ItemTouchHelper (kéo thả sắp xếp tùy chỉnh) cũng là một ItemDecoration nên không được giả định GridSpacing nằm ở index 0
            val currentGridDecoration = findGridSpacingDecoration()
            currentGridDecoration?.items = media

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, config.scrollHorizontally, config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    media_grid.removeItemDecoration(currentGridDecoration)
                }
                media_grid.addItemDecoration(newGridDecoration)
            }
        }
    }

    private fun initZoomListener() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val layoutManager = media_grid.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 1) {
                        reduceColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    private fun increaseColumnCount() {
        config.mediaColumnCnt = ++(media_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun reduceColumnCount() {
        config.mediaColumnCnt = --(media_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun columnCountChanged() {
        handleGridSpacing()
        refreshMenuItems()
        getMediaAdapter()?.apply {
            notifyItemRangeChanged(0, media.size)
        }
    }

    private fun isSetWallpaperIntent() = intent.getBooleanExtra(SET_WALLPAPER_INTENT, false)

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        if (requestCode == REQUEST_EDIT_IMAGE) {
            if (resultCode == Activity.RESULT_OK && resultData != null) {
                mMedia.clear()
                refreshItems()
            }
        }
        super.onActivityResult(requestCode, resultCode, resultData)
    }

    private fun itemClicked(path: String) {
        hideKeyboard()
        if (isSetWallpaperIntent()) {
            toast(R.string.setting_wallpaper)

            val wantedWidth = wallpaperDesiredMinimumWidth
            val wantedHeight = wallpaperDesiredMinimumHeight
            val ratio = wantedWidth.toFloat() / wantedHeight

            val options = RequestOptions()
                .override((wantedWidth * ratio).toInt(), wantedHeight)
                .fitCenter()

            Glide.with(this)
                .asBitmap()
                .load(File(path))
                .apply(options)
                .into(object : SimpleTarget<Bitmap>() {
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                        try {
                            WallpaperManager.getInstance(applicationContext).setBitmap(resource)
                            setResult(Activity.RESULT_OK)
                        } catch (ignored: IOException) {
                        }

                        finish()
                    }
                })
        } else if (mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent) {
            Intent().apply {
                data = Uri.parse(path)
                setResult(Activity.RESULT_OK, this)
            }
            finish()
        } else {
            rememberScrollPosition()
            mWasFullscreenViewOpen = true
            val isVideo = path.isVideoFast()
            if (isVideo) {
                val extras = HashMap<String, Boolean>()
                extras[SHOW_FAVORITES] = mPath == FAVORITES
                if (path.startsWith(recycleBinPath)) {
                    extras[IS_IN_RECYCLE_BIN] = true
                }

                if (shouldSkipAuthentication()) {
                    extras[SKIP_AUTHENTICATION] = true
                }
                openPath(path, false, extras)
            } else {
                Intent(this, ViewPagerActivity::class.java).apply {
                    putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                    putExtra(PATH, path)
                    putExtra(SHOW_ALL, mShowAll)
                    putExtra(SHOW_FAVORITES, mPath == FAVORITES)
                    putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                    putExtra(IS_FROM_GALLERY, true)
                    startActivity(this)
                }
            }
        }
    }

    private fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false
        checkLastMediaChanged()
        mMedia = media

        runOnUiThread {
            media_refresh_layout.isRefreshing = false
            media_empty_text_placeholder.beVisibleIf(media.isEmpty() && !isFromCache)
            media_empty_text_placeholder_2.beVisibleIf(media.isEmpty() && !isFromCache)

            if (media_empty_text_placeholder.isVisible()) {
                media_empty_text_placeholder.text = getString(R.string.no_media_with_filters)
            }
            media_fastscroller.beVisibleIf(media_empty_text_placeholder.isGone())
            setupAdapter()
            updateCoverSubtitle(media)
        }

        mLatestMediaId = getLatestMediaId()
        mLatestMediaDateId = getLatestMediaByDateId()
        if (!isFromCache) {
            val mediaToInsert = (mMedia).filter { it is Medium && it.deletedTS == 0L }.map { it as Medium }
            Thread {
                try {
                    mediaDB.insertAll(mediaToInsert)
                } catch (e: Exception) {
                }
            }.start()
        }
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }

        // cập nhật cache thư mục ngay lập tức (không chờ xóa file xong / MediaStore)
        mLastOwnChangeTime = System.currentTimeMillis()
        refreshDirectoriesAfterChange(filtered.map { it.path })

        if (config.useRecycleBin && !filtered.first().path.startsWith(recycleBinPath)) {
            val movingItems = resources.getQuantityString(R.plurals.moving_items_into_bin, filtered.size, filtered.size)
            toast(movingItems)

            movePathsInRecycleBin(filtered.map { it.path } as ArrayList<String>) {
                if (it) {
                    deleteFilteredFiles(filtered)
                } else {
                    toast(R.string.unknown_error_occurred)
                }
            }
        } else {
            val deletingItems = resources.getQuantityString(R.plurals.deleting_items, filtered.size, filtered.size)
            toast(deletingItems)
            deleteFilteredFiles(filtered)
        }
    }

    private fun shouldSkipAuthentication() = intent.getBooleanExtra(SKIP_AUTHENTICATION, false)

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {
                val useRecycleBin = config.useRecycleBin
                filtered.forEach {
                    if (it.path.startsWith(recycleBinPath) || !useRecycleBin) {
                        deleteDBPath(it.path)
                    }
                }
            }

            if (mMedia.isEmpty()) {
                deleteDirectoryIfEmpty()
                deleteDBDirectory()
                finish()
            }
        }
    }

    override fun refreshItems() {
        getMedia()
    }

    override fun canSetAlbumCover() = !mShowAll && mPath.isNotEmpty() && mPath != FAVORITES && mPath != RECYCLE_BIN

    override fun setAlbumCover(path: String) {
        val covers = config.parseAlbumCovers().filterNot { it.path == mPath } as ArrayList
        covers.add(com.simplemobiletools.gallery.pro.models.AlbumCover(mPath, path))
        config.albumCovers = com.google.gson.Gson().toJson(covers)
        setupCoverHeader(mCoverDirName, true)
        toast(R.string.set_as_album_cover)
    }

    override fun mediaReordered(media: ArrayList<ThumbnailItem>) {
        mMedia = media.clone() as ArrayList<ThumbnailItem>
    }

    override fun selectedPaths(paths: ArrayList<String>) {
        Intent().apply {
            putExtra(PICKED_PATHS, paths)
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {
        var currentGridPosition = 0
        media.forEach {
            if (it is Medium) {
                it.gridPosition = currentGridPosition++
            } else if (it is ThumbnailSection) {
                currentGridPosition = 0
            }
        }

        findGridSpacingDecoration()?.items = media
    }

    private fun findGridSpacingDecoration(): GridSpacingItemDecoration? {
        for (i in 0 until media_grid.itemDecorationCount) {
            val decoration = media_grid.getItemDecorationAt(i)
            if (decoration is GridSpacingItemDecoration) {
                return decoration
            }
        }
        return null
    }

    private fun setAsDefaultFolder() {
        config.defaultFolder = mPath
        refreshMenuItems()
    }

    private fun unsetAsDefaultFolder() {
        config.defaultFolder = ""
        refreshMenuItems()
    }
}
