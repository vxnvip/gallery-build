package com.simplemobiletools.gallery.pro.helpers

import android.content.Context
import android.provider.MediaStore.Files
import android.provider.MediaStore.Images
import android.provider.MediaStore.MediaColumns
import com.simplemobiletools.commons.extensions.*
import com.simplemobiletools.commons.helpers.*
import com.simplemobiletools.gallery.pro.R
import com.simplemobiletools.gallery.pro.databases.GalleryDatabase
import com.simplemobiletools.gallery.pro.extensions.*
import com.simplemobiletools.gallery.pro.models.Directory
import com.simplemobiletools.gallery.pro.models.Medium
import java.io.File
import java.util.*

/**
 * Đồng bộ nhanh, port ý tưởng từ Aves (BSD-3-Clause, (c) 2020 Thibault Deckers):
 *
 *  1. MỘT truy vấn MediaStore cho toàn bộ media, thay vì File.listFiles() + file.length() từng thư mục
 *     (Aves: MediaStoreImageProvider.fetchAll)
 *  2. So khớp với DB theo (path, last_modified), chỉ ghi phần khác biệt
 *     (Aves: MediaStoreSource._loadNewEntries + checkObsoleteContentIds)
 *  3. Thư mục là dữ liệu suy ra từ media, chỉ dựng lại thư mục "bẩn", thư mục không đổi giữ nguyên cache
 *     (Aves: updateDirectories + invalidateAlbumFilterSummary(directories))
 *  4. Gọi UI cập nhật MỘT lần cho cả đợt, không gọi setupAdapter sau từng thư mục
 *
 * Không dùng được (trả null / để luồng cũ xử lý) khi: có OTG, bật lọc ảnh chân dung,
 * hoặc truy vấn MediaStore lỗi. Khi đó caller tự rơi về luồng quét cũ.
 */
class MediaStoreSync(private val context: Context) {
    @Volatile
    var shouldStop = false

    class Result(
        // thư mục có trong cache nhưng MediaStore không còn thấy media nào: để luồng cũ kiểm tra bằng file system
        // (có thể là thư mục .nomedia / thư mục ẩn mà MediaStore không index)
        val legacyFolders: Set<String>,
        // thư mục người dùng thêm thủ công (includedFolders) chưa có trong danh sách: luồng cũ quét
        val extraFolders: List<String>
    )

    fun canUseFastPath(): Boolean {
        val config = context.config
        return config.OTGPath.isEmpty() && config.filterMedia and TYPE_PORTRAITS == 0
    }

    /**
     * Một truy vấn duy nhất. Trả map: parentPath.lowercase() -> danh sách Medium (CHƯA sắp xếp).
     * [directory] != null thì chỉ lấy file có đường dẫn nằm dưới thư mục đó (giống selection của Aves),
     * caller tự lọc đúng thư mục cha.
     * Trả null nếu truy vấn lỗi.
     */
    fun querySnapshot(
        directory: String?, isPickImage: Boolean, isPickVideo: Boolean, favoritePaths: Set<String>
    ): HashMap<String, ArrayList<Medium>>? {
        val config = context.config
        val filterMedia = config.filterMedia
        val result = HashMap<String, ArrayList<Medium>>()
        if (filterMedia == 0) {
            return result
        }

        val showHidden = config.shouldShowHidden
        val withDuration = isQPlus()
        val projection = if (withDuration) {
            arrayOf(Files.FileColumns._ID, MediaColumns.DATA, MediaColumns.DATE_MODIFIED, Images.Media.DATE_TAKEN, MediaColumns.SIZE, MediaColumns.DURATION)
        } else {
            arrayOf(Files.FileColumns._ID, MediaColumns.DATA, MediaColumns.DATE_MODIFIED, Images.Media.DATE_TAKEN, MediaColumns.SIZE)
        }

        var selection = "${MediaColumns.SIZE} > 0"
        var selectionArgs: Array<String>? = null
        if (directory != null) {
            val escaped = directory.trimEnd('/').replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            selection += " AND ${MediaColumns.DATA} LIKE ? ESCAPE '\\'"
            selectionArgs = arrayOf("$escaped/%")
        }

        // EXIF date taken đã sửa được lưu ở bảng riêng, ưu tiên hơn giá trị của MediaStore (giống MediaFetcher.getDateTakens)
        val dateTakens = HashMap<String, Long>()
        try {
            context.dateTakensDB.getAllDateTakens().forEach { dateTakens[it.fullPath] = it.taken }
        } catch (ignored: Exception) {
        }

        try {
            val cursor = context.contentResolver.query(Files.getContentUri("external"), projection, selection, selectionArgs, null) ?: return null
            cursor.use {
                val idCol = it.getColumnIndexOrThrow(Files.FileColumns._ID)
                val pathCol = it.getColumnIndexOrThrow(MediaColumns.DATA)
                val modCol = it.getColumnIndexOrThrow(MediaColumns.DATE_MODIFIED)
                val takenCol = it.getColumnIndexOrThrow(Images.Media.DATE_TAKEN)
                val sizeCol = it.getColumnIndexOrThrow(MediaColumns.SIZE)
                val durCol = if (withDuration) it.getColumnIndexOrThrow(MediaColumns.DURATION) else -1

                var row = 0
                while (it.moveToNext()) {
                    if ((++row and 511) == 0 && shouldStop) {
                        return null
                    }

                    val path = it.getString(pathCol) ?: continue
                    val type = typeOf(path)
                    if (type == 0 || !isTypeWanted(type, filterMedia, isPickImage, isPickVideo)) {
                        continue
                    }

                    val filename = path.getFilenameFromPath()
                    if (!showHidden && filename.startsWith('.')) {
                        continue
                    }

                    val lastModified = it.getLong(modCol) * 1000
                    var dateTaken = dateTakens[path] ?: it.getLong(takenCol)
                    if (dateTaken == 0L) {
                        dateTaken = lastModified
                    }

                    val duration = if (type == TYPE_VIDEOS && durCol != -1) Math.round(it.getLong(durCol) / 1000.0).toInt() else 0
                    val parent = path.getParentPath()
                    val medium = Medium(
                        null, filename, path, parent, lastModified, dateTaken, it.getLong(sizeCol),
                        type, duration, favoritePaths.contains(path), 0L, it.getLong(idCol)
                    )

                    val key = parent.lowercase(Locale.getDefault())
                    var list = result[key]
                    if (list == null) {
                        list = ArrayList()
                        result[key] = list
                    }
                    list.add(medium)
                }
            }
        } catch (e: Exception) {
            return null
        }

        return result
    }

    /**
     * Đồng bộ danh sách thư mục: diff với DB, chỉ dựng lại thư mục bẩn, ghi DB một transaction.
     * Trả null nếu không dùng được đường nhanh (caller rơi về luồng cũ).
     */
    fun syncDirectories(
        dirs: ArrayList<Directory>, isPickImage: Boolean, isPickVideo: Boolean,
        favoritePaths: Set<String>, onChanged: () -> Unit
    ): Result? {
        if (!canUseFastPath()) {
            return null
        }

        val t0 = System.currentTimeMillis()
        val config = context.config
        val snapshot = querySnapshot(null, isPickImage, isPickVideo, favoritePaths) ?: return null
        android.util.Log.d("MediaStoreSync", "query: ${System.currentTimeMillis() - t0}ms")
        if (shouldStop) {
            return null
        }

        val knownRows = try {
            context.mediaDB.getSyncRows()
        } catch (e: Exception) {
            return null
        }

        // MediaStore trả rỗng trong khi DB có dữ liệu thường là mất quyền / lỗi tạm thời: tuyệt đối không xóa cache
        if (snapshot.isEmpty() && knownRows.isNotEmpty() && config.filterMedia != 0) {
            return null
        }

        // ---- 1. diff theo (path, last_modified) ----
        val knownModified = HashMap<String, Long>(knownRows.size * 2)
        knownRows.forEach { knownModified[it.path.lowercase(Locale.getDefault())] = it.modified }

        val dirtyParents = HashSet<String>()
        val toUpsert = ArrayList<Medium>()
        val seenPaths = HashSet<String>(knownRows.size * 2)
        for ((parent, list) in snapshot) {
            for (medium in list) {
                val key = medium.path.lowercase(Locale.getDefault())
                seenPaths.add(key)
                val known = knownModified[key]
                // DB cũ lưu file.lastModified() (ms), MediaStore chỉ có giây: so theo giây, nếu không MỌI file đều bị coi là đổi
                if (known == null || known / 1000 != medium.modified / 1000) {
                    toUpsert.add(medium)
                    dirtyParents.add(parent)
                }
            }
        }

        // DB có nhưng MediaStore không thấy: chỉ coi là đã xóa khi file thật sự không còn
        // (tránh xóa nhầm file ở thư mục .nomedia / chưa được index)
        val obsoletePaths = ArrayList<String>()
        for (row in knownRows) {
            if (seenPaths.contains(row.path.lowercase(Locale.getDefault()))) {
                continue
            }
            if (File(row.path).exists()) {
                continue
            }
            obsoletePaths.add(row.path)
            dirtyParents.add(row.parentPath.lowercase(Locale.getDefault()))
        }

        if (shouldStop) {
            return null
        }

        // ---- 3. dựng lại thư mục bẩn ----
        val excluded = if (config.temporarilyShowExcluded) HashSet() else config.excludedFolders
        val included = config.includedFolders
        val showHidden = config.shouldShowHidden
        val noMediaFolders = context.getNoMediaFoldersSync()
        val noMediaStatuses = HashMap<String, Boolean>()
        noMediaFolders.forEach { noMediaStatuses["$it/$NOMEDIA"] = true }

        val dirByKey = HashMap<String, Directory>(dirs.size * 2)
        dirs.forEach { dirByKey[it.path.lowercase(Locale.getDefault())] = it }

        // thư mục mới trong MediaStore: chỉ nhận nếu hiển thị được (không bị loại trừ / ẩn / .nomedia)
        for (parent in snapshot.keys) {
            if (dirByKey.containsKey(parent)) {
                continue
            }
            val realPath = snapshot[parent]!!.first().parentPath
            val visible = realPath.shouldFolderBeVisible(excluded, included, showHidden, noMediaStatuses) { path, hasNoMedia ->
                noMediaStatuses[path] = hasNoMedia
            }
            if (visible) {
                dirtyParents.add(parent)
            }
        }

        val fetcher = MediaFetcher(context)
        val albumCovers = config.parseAlbumCovers()
        val hiddenString = context.getString(R.string.hidden)
        val getProperFileSize = config.directorySorting and SORT_BY_SIZE != 0
        val legacyFolders = HashSet<String>()
        var changed = false

        for (parent in dirtyParents) {
            if (shouldStop) {
                return null
            }

            val existing = dirByKey[parent]
            if (existing != null && (existing.isRecycleBin() || existing.areFavorites())) {
                continue
            }

            val media = snapshot[parent]
            if (media.isNullOrEmpty()) {
                // không còn gì trong MediaStore: để luồng cũ xác nhận bằng file system rồi mới xóa thư mục
                if (existing != null) {
                    legacyFolders.add(existing.path)
                }
                continue
            }

            val path = media.first().parentPath
            fetcher.sortMedia(media, config.getFolderSorting(path), path)
            val newDir = context.createDirectoryFromMedia(path, media, albumCovers, hiddenString, included, getProperFileSize, noMediaFolders)

            if (existing == null) {
                dirs.add(newDir)
                dirByKey[parent] = newDir
                changed = true
                Thread {
                    try {
                        context.directoryDB.insert(newDir)
                    } catch (ignored: Exception) {
                    }
                }.start()
            } else if (existing.copy(subfoldersCount = 0, subfoldersMediaCount = 0) != newDir) {
                existing.apply {
                    tmb = newDir.tmb
                    name = newDir.name
                    mediaCnt = newDir.mediaCnt
                    modified = newDir.modified
                    taken = newDir.taken
                    this.size = newDir.size
                    types = newDir.types
                    sortValue = newDir.sortValue
                }
                context.updateDBDirectory(existing)
                changed = true
            }
        }

        // thư mục đang hiển thị mà MediaStore không có chút media nào và chưa bị "bẩn" ở trên (DB đã rỗng sẵn)
        dirs.forEach {
            val key = it.path.lowercase(Locale.getDefault())
            if (!it.isRecycleBin() && !it.areFavorites() && !snapshot.containsKey(key)) {
                legacyFolders.add(it.path)
            }
        }

        android.util.Log.d("MediaStoreSync", "done: ${System.currentTimeMillis() - t0}ms, upsert=${toUpsert.size}, obsolete=${obsoletePaths.size}, dirty=${dirtyParents.size}, legacy=${legacyFolders.size}")
        // ---- 4. cập nhật UI đúng một lần ----
        if (changed) {
            onChanged()
        }

        // ---- 5. ghi DB ở luồng nền, SAU khi UI đã có thư mục (Aves cũng hiện album trước, lưu DB sau) ----
        // nếu app bị tắt giữa chừng cũng không sao: lần mở sau diff lại sẽ tự bù phần thiếu
        if (toUpsert.isNotEmpty() || obsoletePaths.isNotEmpty()) {
            val appContext = context.applicationContext
            Thread {
                try {
                    GalleryDatabase.getInstance(appContext).runInTransaction {
                        toUpsert.chunked(500).forEach { appContext.mediaDB.insertAll(it) }
                        obsoletePaths.chunked(500).forEach { appContext.mediaDB.deleteByPaths(it) }
                    }
                } catch (ignored: Exception) {
                }
            }.start()
        }

        val extra = included.filter { !dirByKey.containsKey(it.lowercase(Locale.getDefault())) && !snapshot.containsKey(it.lowercase(Locale.getDefault())) }
        return Result(legacyFolders, extra)
    }

    /**
     * Nạp media của một thư mục (hoặc tất cả thư mục khi [directory] == null) bằng một truy vấn,
     * thay cho File.listFiles() + file.length() + MediaMetadataRetriever từng file.
     * Trả null nếu không dùng được hoặc thư mục không có gì trong MediaStore (để luồng cũ kiểm tra file system).
     */
    fun loadFolderMedia(directory: String?, isPickImage: Boolean, isPickVideo: Boolean, favoritePaths: Set<String>): ArrayList<Medium>? {
        if (!canUseFastPath()) {
            return null
        }

        val snapshot = querySnapshot(directory, isPickImage, isPickVideo, favoritePaths) ?: return null
        if (directory != null) {
            val list = snapshot[directory.trimEnd('/').lowercase(Locale.getDefault())]
            return if (list.isNullOrEmpty()) null else list
        }

        val config = context.config
        val excluded = if (config.temporarilyShowExcluded) HashSet() else config.excludedFolders
        val noMediaStatuses = HashMap<String, Boolean>()
        context.getNoMediaFoldersSync().forEach { noMediaStatuses["$it/$NOMEDIA"] = true }

        val all = ArrayList<Medium>()
        for ((_, list) in snapshot) {
            val folder = list.first().parentPath
            if (config.isFolderProtected(folder)) {
                continue
            }
            val visible = folder.shouldFolderBeVisible(excluded, config.includedFolders, config.shouldShowHidden, noMediaStatuses) { path, hasNoMedia ->
                noMediaStatuses[path] = hasNoMedia
            }
            if (visible) {
                all.addAll(list)
            }
        }
        return if (all.isEmpty()) null else all
    }

    private fun typeOf(path: String) = when {
        path.isImageFast() -> TYPE_IMAGES
        path.isVideoFast() -> TYPE_VIDEOS
        path.isGif() -> TYPE_GIFS
        path.isRawFast() -> TYPE_RAWS
        path.isSvg() -> TYPE_SVGS
        else -> 0
    }

    private fun isTypeWanted(type: Int, filterMedia: Int, isPickImage: Boolean, isPickVideo: Boolean) = when (type) {
        TYPE_VIDEOS -> !isPickImage && filterMedia and TYPE_VIDEOS != 0
        TYPE_IMAGES -> !isPickVideo && filterMedia and TYPE_IMAGES != 0
        TYPE_GIFS -> filterMedia and TYPE_GIFS != 0
        TYPE_RAWS -> filterMedia and TYPE_RAWS != 0
        TYPE_SVGS -> filterMedia and TYPE_SVGS != 0
        else -> false
    }
}
