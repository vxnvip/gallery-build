package com.simplemobiletools.gallery.pro.models

import androidx.room.ColumnInfo

// projection nhẹ dùng cho đồng bộ nhanh: không kéo cả bản ghi Medium
data class MediaSyncRow(
    @ColumnInfo(name = "full_path") val path: String,
    @ColumnInfo(name = "parent_path") val parentPath: String,
    @ColumnInfo(name = "last_modified") val modified: Long
)
