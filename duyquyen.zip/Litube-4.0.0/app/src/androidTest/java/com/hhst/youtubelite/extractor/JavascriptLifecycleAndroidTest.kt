package com.hhst.youtubelite.extractor

import com.google.common.util.concurrent.SettableFuture
import org.junit.Rule
import androidx.test.ext.junit.rules.ActivityScenarioRule
import android.app.ActivityManager
import android.os.Process
import android.os.Build
import android.webkit.CookieManager
import android.webkit.WebView
import com.hhst.youtubelite.core.WebViewTimerOccupancy
import com.hhst.youtubelite.core.WebViewTimerOwner
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.serialization.json.JsonObject
import org.junit.Assert.*
import org.junit.Assume.assumeNotNull
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File
import java.io.IOException
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicBoolean

/** Real non-terminating JS, host death and heap exhaustion; no network or credential export. */
class JavascriptLifecycleAndroidTest {
    @get:Rule val activity = ActivityScenarioRule(ExtractionTestActivity::class.java)
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val app = instrumentation.targetContext

    private fun context(current: AtomicBoolean = AtomicBoolean(true)): ExtractionContext = ExtractionContext(
        YoutubeWebSession("lifecycle", WebAccount.ANONYMOUS, 0, null, null, null,
            null, "fixture", 0, null, "offline", JsonObject(emptyMap()), { "" }),
        object : ExtractionTransport {
            override fun get(context: ExtractionContext, url: String, headers: Map<String, List<String>>) = throw IOException("LIFECYCLE_HAS_NO_NETWORK")
            override fun post(context: ExtractionContext, url: String, headers: Map<String, List<String>>, body: ByteArray) = throw IOException("LIFECYCLE_HAS_NO_NETWORK")
        }, false, false, true, "", System.nanoTime() + TimeUnit.SECONDS.toNanos(20), { current.get() },
        object : EngineDiagnostics { override fun event(stage: String, profile: String, detail: String, elapsedMillis: Long, httpStatus: Int) {} })

    private fun hostPid(): Int = app.getSystemService(ActivityManager::class.java).runningAppProcesses
        .first { it.processName == app.packageName + ":youtube_ejs" }.pid

    private fun assertStopped(pid: Int) {
        val end = System.nanoTime() + TimeUnit.SECONDS.toNanos(3)
        while (File("/proc/$pid").exists() && System.nanoTime() < end) Thread.sleep(20)
        assertFalse("EJS process remained alive after termination", File("/proc/$pid").exists())
    }

    @Test fun legacyWebViewRuntimeReturnsValuesAndSafeErrorsWithoutChangingCookies() {
        assumeTrue(Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
        val cookies = CookieManager.getInstance().getCookie(YoutubeSessionProvider.ORIGIN)
        HiddenJavascriptRuntime(app, WebViewTimerOccupancy.NOOP, WebViewTimerOwner.EJS, "fixture").use { runtime ->
            assertEquals("42", runtime.evaluate("String(6*7)", 5_000, context()))
            try {
                runtime.evaluate("throw new TypeError('private-body')", 5_000, context())
                fail("JavaScript error was lost")
            } catch (failure: IOException) {
                assertEquals("JS_EVALUATION_TypeError", failure.message)
                assertFalse(failure.toString().contains("private-body"))
            }
        }
        assertEquals(cookies, CookieManager.getInstance().getCookie(YoutubeSessionProvider.ORIGIN))
    }

    @Test fun remoteTimeoutCancellationAndCrashPreserveAccountWebView() {
        assumeTrue(EjsRuntimeProcess.canIsolate(app))
        lateinit var browser: WebView
        var cookieSnapshot: String? = null
        instrumentation.runOnMainSync {
            cookieSnapshot = CookieManager.getInstance().getCookie(YoutubeSessionProvider.ORIGIN)
            browser = WebView(app).apply {
                settings.javaScriptEnabled = true
                settings.blockNetworkLoads = true
                loadData("<title>lifecycle</title>", "text/html", "UTF-8")
            }
        }
        val timer = Executors.newSingleThreadScheduledExecutor()
        try {
            for (failureMode in listOf("timeout", "cancel", "crash")) {
                val runtime = RemoteEjsRuntime(app, "fixture")
                try {
                    assertEquals("ready", runtime.evaluate("'ready'", 5_000, context()))
                    val pid = hostPid()
                    val current = AtomicBoolean(true)
                    if (failureMode == "cancel") timer.schedule({ current.set(false) }, 250, TimeUnit.MILLISECONDS)
                    if (failureMode == "crash") timer.schedule({ Process.killProcess(pid) }, 250, TimeUnit.MILLISECONDS)
                    val started = System.nanoTime()
                    try {
                        runtime.evaluate("while(true){}", if (failureMode == "timeout") 300 else 5_000, context(current))
                        fail("Infinite JS returned successfully")
                    } catch (failure: IOException) {
                        assertTrue("Termination exceeded its bound", System.nanoTime() - started < TimeUnit.SECONDS.toNanos(3))
                    }
                    runtime.close()
                    assertStopped(pid)
                    // Only this isolated EJS process was stopped; the user's browser remains usable.
                    val heartbeat = SettableFuture.create<String>()
                    instrumentation.runOnMainSync {
                        browser.evaluateJavascript("'alive'", heartbeat::set)
                        assertTrue("Account cookies changed", cookieSnapshot ==
                            CookieManager.getInstance().getCookie(YoutubeSessionProvider.ORIGIN))
                    }
                    assertEquals("\"alive\"", heartbeat.get(3, TimeUnit.SECONDS))
                } finally { runtime.close() }
            }
            RemoteEjsRuntime(app, "fixture").use { reopened ->
                assertEquals("42", reopened.evaluate("String(6*7)", 5_000, context()))
            }
        } finally {
            timer.shutdownNow()
            instrumentation.runOnMainSync { browser.destroy() }
        }
    }

    @Test fun sandboxHeapLimitAndTimeoutAllowFreshRuntime() {
        assumeTrue(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        val runtime = SandboxRuntime.create(app, context())
        assumeNotNull(runtime)
        runtime!! .use {
            assertEquals("ready", it.evaluate("'ready'", 1_000, context()))
            try {
                it.evaluate("globalThis.held=[];while(true)held.push(new Array(1000000).fill(42));", 10_000, context())
                fail("Heap budget did not terminate the isolate")
            } catch (failure: IOException) {
                assertEquals("JS_HEAP_LIMIT", failure.message)
            }
        }
        // A close/termination must not leave an isolate consuming CPU indefinitely.
        SandboxRuntime.create(app, context()).use { fresh ->
            assertNotNull(fresh)
            assertEquals("42", fresh!!.evaluate("String(6*7)", 5_000, context()))
            try {
                fresh.evaluate("while(true){}", 300, context())
                fail("Sandbox timeout did not stop the isolate")
            } catch (failure: IOException) {
                assertEquals("JS_TIMEOUT", failure.message)
            }
        }
    }
}
