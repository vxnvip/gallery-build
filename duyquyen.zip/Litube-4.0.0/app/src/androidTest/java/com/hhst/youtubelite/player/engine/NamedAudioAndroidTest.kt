@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
package com.hhst.youtubelite.player.engine

import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.platform.app.InstrumentationRegistry
import com.hhst.youtubelite.watch.WatchActivity
import com.hhst.youtubelite.core.DeviceEvidence
import com.hhst.youtubelite.core.JsonCache
import com.hhst.youtubelite.extension.ExtensionManager
import com.hhst.youtubelite.extractor.*
import com.hhst.youtubelite.player.PlayerViewModel
import com.hhst.youtubelite.player.datasource.AudioTrackIdentity
import com.hhst.youtubelite.player.datasource.MediaSourceResolver
import com.hhst.youtubelite.player.datasource.PlayerDataSource
import com.hhst.youtubelite.player.sponsor.SponsorBlockManager
import fi.iki.elonen.NanoHTTPD
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Rule
import org.junit.Test
import org.koin.core.context.GlobalContext

class NamedAudioAndroidTest {
    @get:Rule val activity = ActivityScenarioRule(ComponentActivity::class.java)

    @Test fun realMultilingualVideoExposesOriginalAndSwitchesDub() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val args = InstrumentationRegistry.getArguments()
        assumeTrue(args.getString("network") == "1")
        val id = args.getString("videoId") ?: "zIN0foYC6_Y"
        val app = instrumentation.targetContext
        val engine = GlobalContext.get().get<PlaybackApi>() as PlaybackEngine
        val scenario = ActivityScenario.launch<WatchActivity>(
            com.hhst.youtubelite.watch.WatchActivity.intent(app, id))
        val player = engine.javaClass.getDeclaredField("player").apply { isAccessible = true }.get(engine) as ExoPlayer
        try {
            instrumentation.runOnMainSync {
                GlobalContext.get().get<PlayerViewModel>().openVideo(id)
            }
            var ready = false
            var menuOpened = false
            val deadline = SystemClock.elapsedRealtime() + 60_000
            while (!ready && SystemClock.elapsedRealtime() < deadline) {
                instrumentation.runOnMainSync {
                    if (!menuOpened && engine.snapshot.value.videoId == id && player.isPlaying) {
                        engine.onAudioMenuOpened()
                        menuOpened = true
                    }
                    ready = engine.snapshot.value.videoId == id && player.isPlaying && engine.snapshot.value.audioTracks.size > 1
                }
                if (!ready) Thread.sleep(100)
            }
            var sourceEvidence: Map<String, Any?> = emptyMap()
            var audioFormats: List<Format> = emptyList()
            instrumentation.runOnMainSync {
                val stream = engine.javaClass.getDeclaredField("currentStream").apply { isAccessible = true }.get(engine) as? Stream
                val supplement = engine.javaClass.getDeclaredField("audioSupplement").apply { isAccessible = true }.get(engine) as? Pair<*, *>
                audioFormats = stream?.formats.orEmpty() + (supplement?.second as? Stream)?.formats.orEmpty()
                val manifest = player.currentManifest as? androidx.media3.exoplayer.hls.HlsManifest
                sourceEvidence = mapOf(
                    "hlsClient" to stream?.hlsRequestPlan?.client?.name,
                    "formats" to stream?.formats?.map { mapOf("itag" to it.itag, "audioOnly" to it.audioOnly,
                        "trackId" to it.audioTrackId, "label" to it.audioTrackName, "language" to it.audioLocale,
                        "original" to it.audioTrackOriginal) },
                    "renditions" to manifest?.multivariantPlaylist?.audios?.map {
                        mapOf("label" to it.format.label, "language" to it.format.language, "codecs" to it.format.codecs)
                    },
                    "trackGroups" to player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }.map { group ->
                        (0 until group.length).map { index -> group.getTrackFormat(index).let { format ->
                            mapOf("label" to format.label, "language" to format.language, "supported" to group.isTrackSupported(index),
                                "selected" to group.isTrackSelected(index), "codecs" to format.codecs)
                        } }
                    },
                )
            }
            DeviceEvidence.writeJson("named-audio-source.json", com.hhst.youtubelite.core.TestJson.any(mapOf(
                "videoId" to id, "ready" to ready, "tracks" to engine.snapshot.value.audioTracks,
                "selected" to engine.snapshot.value.audioTrackKey, "error" to engine.snapshot.value.error,
                "source" to sourceEvidence)))
            assertTrue("Real multilingual video did not become playable: ${engine.snapshot.value}", ready)
            val original = engine.snapshot.value.audioTrackKey ?: audioFormats.firstOrNull(AudioTrackIdentity::isOriginal)
                ?.let(AudioTrackIdentity::key)
            assertNotNull("Original identity must be known", original)
            val originalChoice = engine.snapshot.value.audioTracks.single { it.key == original }
            assertTrue("Expected original audio: $originalChoice",
                audioFormats.any { AudioTrackIdentity.key(it) == original && AudioTrackIdentity.isOriginal(it) } ||
                    originalChoice.label.contains("original", ignoreCase = true))
            val dub = engine.snapshot.value.audioTracks.first { it.key != original }
            instrumentation.runOnMainSync { engine.setAudioTrack(dub.key) }
            val switchDeadline = SystemClock.elapsedRealtime() + 20_000
            var switched = false
            while (!switched && SystemClock.elapsedRealtime() < switchDeadline) {
                instrumentation.runOnMainSync {
                    player.audioDecoderCounters?.ensureUpdated()
                    val selected = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                        .flatMap { group -> (0 until group.length).filter(group::isTrackSelected).map { group.getTrackFormat(it) } }
                    switched = engine.snapshot.value.audioTrackKey == dub.key && player.isPlaying &&
                        (!dub.key.startsWith("hls:") || selected.any {
                            AudioTrackIdentity.renditionKey(it.language, it.label) == dub.key }) &&
                        (player.audioDecoderCounters?.renderedOutputBufferCount ?: 0) > 0
                }
                if (!switched) Thread.sleep(100)
            }
            assertTrue("Live dub failed", switched)
            instrumentation.runOnMainSync {
                val activeStream = engine.javaClass.getDeclaredField("currentStream").apply { isAccessible = true }.get(engine) as Stream
                assertTrue("Selected dub must remain in the active catalog", AudioTrackIdentity.matchingFormats(activeStream.formats, dub.key).isNotEmpty())
            }
            instrumentation.runOnMainSync { engine.setAudioTrack(null) }
            var returned = false
            val returnDeadline = SystemClock.elapsedRealtime() + 20_000
            while (!returned && SystemClock.elapsedRealtime() < returnDeadline) {
                instrumentation.runOnMainSync {
                    val selected = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                        .flatMap { group -> (0 until group.length).filter(group::isTrackSelected).map { group.getTrackFormat(it) } }
                    returned = engine.snapshot.value.audioTrackKey == original && player.isPlaying &&
                        (!original!!.startsWith("hls:") || selected.any {
                            AudioTrackIdentity.renditionKey(it.language, it.label) == original })
                }
                if (!returned) Thread.sleep(100)
            }
            assertTrue("Returning to original audio failed", returned)
            DeviceEvidence.writeJson("issue-337-live-switch.json", com.hhst.youtubelite.core.TestJson.any(mapOf("videoId" to id,
                "tracks" to engine.snapshot.value.audioTracks.size, "original" to original, "dub" to dub.key,
                "switched" to switched, "returned" to returned)))
        } finally {
            instrumentation.runOnMainSync { GlobalContext.get().get<PlayerViewModel>().onMiniClose(); engine.stop() }
            scenario.close()
        }
    }

    @Test fun namedAudioSurvivesQualityChanges() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val app = instrumentation.targetContext
        val audio = instrumentation.context.assets.open("player/audio-original/audio.ts").use { it.readBytes() }
        val requests = CopyOnWriteArrayList<String>()
        val server = object : NanoHTTPD("127.0.0.1", 0) {
            override fun serve(session: IHTTPSession): Response {
                requests += session.uri
                return newFixedLengthResponse(Response.Status.OK, "video/mp2t", audio.inputStream(), audio.size.toLong())
            }
        }
        server.start()
        val stream = Stream().apply {
            formats = listOf(
                Format(url = "http://127.0.0.1:${server.listeningPort}/english.ts", audioOnly = true,
                    codec = "mp4a.40.2", audioTrackName = "English", audioTrackOriginal = true),
                Format(url = "http://127.0.0.1:${server.listeningPort}/spanish.ts?pot=fixture", audioOnly = true,
                    codec = "mp4a.40.2", audioTrackName = "Spanish", bitrate = 200000))
        }
        val fixtureCache = streamCache(stream, title = "Named audio")
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        lateinit var engine: PlaybackEngine
        lateinit var player: ExoPlayer
        val timelineChanges = AtomicInteger()
        fun awaitTrack(key: String, path: String, minimumChanges: Int = 0) {
            var ready = false
            val deadline = SystemClock.elapsedRealtime() + 15_000
            while (!ready && SystemClock.elapsedRealtime() < deadline) {
                instrumentation.runOnMainSync {
                    player.audioDecoderCounters?.ensureUpdated()
                    ready = engine.snapshot.value.videoId == "namedAud001" && engine.snapshot.value.prepared &&
                        !engine.snapshot.value.isBuffering && timelineChanges.get() >= minimumChanges &&
                        engine.snapshot.value.audioTrackKey == key && player.isPlaying && requests.contains(path) &&
                        (player.audioDecoderCounters?.renderedOutputBufferCount ?: 0) > 0
                }
                if (!ready) Thread.sleep(50)
            }
            assertTrue("Track did not decode: ${engine.snapshot.value}", ready)
        }
        try {
            instrumentation.runOnMainSync {
                val prefs = GlobalContext.get().get<ExtensionManager>()
                val http = OkHttpClient()
                engine = PlaybackEngine(app, Extractor(fixtureCache, scope),
                    MediaSourceResolver(PlayerDataSource.create(app, http)), GlobalContext.get().get<JsonCache>(), prefs,
                    SponsorBlockManager(http, prefs, scope))
                player = engine.javaClass.getDeclaredField("player").apply { isAccessible = true }.get(engine) as ExoPlayer
                player.addListener(object : Player.Listener {
                    override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                        if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) timelineChanges.incrementAndGet()
                    }
                })
                engine.play("namedAud001")
            }
            awaitTrack("name:English", "/english.ts")
            assertEquals(listOf("name:English", "name:Spanish"), engine.snapshot.value.audioTracks.map { it.key })
            instrumentation.runOnMainSync { engine.setAudioTrack("name:Spanish") }
            awaitTrack("name:Spanish", "/spanish.ts")
            val changes = timelineChanges.get()
            instrumentation.runOnMainSync { engine.setQuality("720p") }
            awaitTrack("name:Spanish", "/spanish.ts", minimumChanges = changes + 1)
            instrumentation.runOnMainSync { engine.setAudioTrack(null) }
            awaitTrack("name:English", "/english.ts")
        } finally {
            instrumentation.runOnMainSync { engine.stop(); player.release() }
            scope.cancel(); server.stop()
        }
    }
}
