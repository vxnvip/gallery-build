# Nokia C5 skin integration

This source tree is based on J2ME Loader 1.8.2. The existing MIDP engine is retained.

## What changed
- Added `NokiaC5SkinView`, based on the supplied Canvas shell drawing.
- Added `NokiaC5CanvasHost`, which places the existing `CanvasView`/`GlesView` surface in the phone's screen opening.
- Connected Nokia C5 D-pad, OK, soft keys, digits, `*`, `#`, call/end and clear to MIDP Canvas key events in `Canvas.java`.
- Added `.github/workflows/build-nokia-c5.yml` to build a debug APK with GitHub Actions.

## Build
Run `./gradlew :app:assembleDebug` with Android SDK platform 34, build-tools 34.0.0, NDK 22.1.7171670 and JDK 17. The workflow prepares the `keystore.properties` file required by the upstream Gradle configuration. If the repository has the `DEBUG_KEYSTORE_B64` secret, it uses that keystore; otherwise Android's normal debug keystore is used.

## Notes
This is a source integration, not a verified build: this environment did not complete an Android Gradle build. Test with a MIDP Canvas game, especially touch input and games that use OpenGL. The Nokia C5 shell is applied to Canvas displayables; non-Canvas displayables retain the original J2ME Loader view.
