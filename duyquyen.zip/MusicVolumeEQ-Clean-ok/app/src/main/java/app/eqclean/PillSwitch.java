package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Rounded switch. With a label (e.g. "10 EQ") the text sits opposite the thumb. */
public class PillSwitch extends View {
    public interface Listener { void onToggle(boolean checked); }
    private boolean checked;
    private final boolean studio = true;
    private final String label;
    private Listener listener;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d, wDp, hDp;

    public PillSwitch(Context c, float wDp, float hDp, String label) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        this.wDp = wDp; this.hDp = hDp; this.label = label;
        setBackgroundResource(R.drawable.off_studio);
        setOnClickListener(v -> { checked = !checked; refreshBackground(); invalidate(); if (listener != null) listener.onToggle(checked); });
    }
    public void setListener(Listener l) { listener = l; }
    public void setChecked(boolean c) { checked = c; refreshBackground(); invalidate(); }
    public boolean isChecked() { return checked; }

    private void refreshBackground() {
        if (studio) setBackgroundResource(checked ? R.drawable.on_studio : R.drawable.off_studio);
    }

    @Override protected void onMeasure(int ws, int hs) { setMeasuredDimension((int) (wDp * d), (int) (hDp * d)); }

    @Override protected void onDraw(Canvas c) {
        if (studio) return;
        float w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(checked ? 0xFF3E5A40 : 0xFF3A3A3D);
        rf.set(0, h * 0.12f, w, h * 0.88f);
        c.drawRoundRect(rf, h, h, p);
        float tr = h * 0.42f;
        float tx = checked ? w - tr - h * 0.02f : tr + h * 0.02f;
        if (label != null) {
            p.setColor(checked ? 0xFFA5D6A7 : 0xFF8E8E93);
            p.setTextSize(h * 0.42f); p.setFakeBoldText(true); p.setTextAlign(Paint.Align.CENTER);
            float cx = checked ? (w - 2 * tr) / 2f : w - (w - 2 * tr) / 2f;
            c.drawText(label, cx, h / 2f + h * 0.15f, p);
            p.setFakeBoldText(false);
        }
        p.setColor(checked ? 0xFFA5D6A7 : 0xFF6E6E73);
        c.drawCircle(tx, h / 2f, tr, p);
    }
}
