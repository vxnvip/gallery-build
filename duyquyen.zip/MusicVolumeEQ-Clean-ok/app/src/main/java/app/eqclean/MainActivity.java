package app.eqclean;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * UI laid out like the reference screenshot:
 * header (back / title / speaker) -> EQUALIZER card (on/off switch, title, 10-band curve with knobs) ->
 * PRESET card (preset pill, BASS BOOST + VIRTUALIZER knobs with switches, VU button).
 * Speaker icon opens volume + lock + Preamp/Balance/Limiter. All audio goes through EqService.
 */
public class MainActivity extends Activity {
    private static final int GREEN = StudioTheme.ACCENT, BG = StudioTheme.BACKGROUND, CARD = StudioTheme.PANEL;
    private static final String[] N10 = {"32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K"};
    private static final String[][] BUILTIN_NAMES = {{"Flat"}, {"Rock"}, {"Pop"}, {"Bass"}, {"Treble"}, {"Vocal"}};
    /** dB per 10 bands (32..16k). */
    private static final float[][] BUILTIN = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {5, 4, 3, 1, -1, -1, 1, 3, 4, 5},
            {-1, 1, 3, 4, 3, 0, -1, -1, -1, -1},
            {7, 6, 5, 3, 1, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 1, 3, 5, 6, 7},
            {-2, -3, -3, 1, 3, 3, 3, 1, 0, -1}};
    private EqService svc;
    private SharedPreferences pos, onPrefs, presets;
    private EqView eqView;
    private PillSwitch swEq, swBass, swVirt;
    private KnobView knobBass, knobVirt;
    private TextView presetName;
    private AudioManager am;
    private float d;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable save10 = () -> {
        StringBuilder sb = new StringBuilder();
        for (float f : Cfg.bands10) sb.append(f).append(",");
        getSharedPreferences("eq10_save_prefs", 0).edit().putString("eq10_save_prefs", sb.toString()).apply();
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = ((EqService.LocalBinder) b).get(); }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        if (s == null && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        pos = getSharedPreferences("prefsEQPos", 0);
        onPrefs = getSharedPreferences("prefsEQOn", 0);
        presets = getSharedPreferences("prefsPresets", 0);
        d = getResources().getDisplayMetrics().density;
        Cfg.tenBand = true;
        load10();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(StudioTheme.background(this));
        root.setPadding(dp(8), dp(4), dp(8), dp(8));

        root.addView(header());
        root.addView(eqCard(), lp(-1, 0, 1, 0, 8));
        root.addView(presetCard(), lp(-1, -2, 0, 0, 8));
        setContentView(root);

        showEq();
        EqService.start(this);
        bindService(new Intent(this, EqService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        try { unbindService(conn); } catch (Exception ignored) {}
    }

    // ---------------------------------------------------------------- layout
    private int dp(float v) { return (int) (v * d + 0.5f); }
    private LinearLayout.LayoutParams lp(int w, int h, float weight, int mx, int my) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(mx), dp(my), dp(mx), dp(my));
        return p;
    }
    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp));
        return g;
    }
    private TextView label(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private View header() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        IconView back = new IconView(this, IconView.BACK);
        back.setOnClickListener(v -> finish());
        android.widget.ImageView title = new android.widget.ImageView(this);
        title.setImageResource(R.drawable.logo_toolbar_studio);
        title.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        IconView spk = new IconView(this, IconView.SPEAKER);
        spk.setOnClickListener(v -> volumeDialog());
        h.addView(back, new LinearLayout.LayoutParams(dp(42), dp(48)));
        h.addView(title, new LinearLayout.LayoutParams(0, dp(30), 1));
        h.addView(spk, new LinearLayout.LayoutParams(dp(42), dp(48)));
        return h;
    }

    private View eqCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(CARD, 5));
        card.setPadding(dp(5), dp(6), dp(5), dp(5));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        swEq = new PillSwitch(this, 74, 30, null);
        swEq.setChecked(onPrefs.getBoolean("prefsEQOn1", true));
        swEq.setListener(on -> {
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_EQ_TOGGLE));
            eqView.setAlpha(on ? 1f : 0.4f);
        });
        top.addView(swEq);
        top.addView(label("EQUALIZER", 18, Color.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(new View(this), new LinearLayout.LayoutParams(dp(74), 1));   // balances the switch
        card.addView(top, new LinearLayout.LayoutParams(-1, dp(40)));

        eqView = new EqView(this);
        eqView.setBackgroundColor(StudioTheme.BACKGROUND);
        card.addView(eqView, new LinearLayout.LayoutParams(-1, 0, 1));
        return card;
    }

    private View presetCard() {
        LinearLayout card = new LinearLayout(this);
        card.setBackground(rounded(CARD, 5));
        card.setPadding(dp(8), dp(8), dp(8), dp(8));

        // left: BASS BOOST
        swBass = new PillSwitch(this, 74, 30, null);
        swBass.setChecked(onPrefs.getBoolean("prefsBASSOn1", false));
        knobBass = new KnobView(this);
        knobBass.setup(1000, pos.getInt("BassLevel", 0), v -> { pos.edit().putInt("BassLevel", v).apply(); if (svc != null) svc.setBass(v); });
        knobBass.setActive(swBass.isChecked());
        swBass.setListener(on -> {
            knobBass.setActive(on);
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_BASS_TOGGLE));
        });
        // right: VIRTUALIZER
        swVirt = new PillSwitch(this, 74, 30, null);
        swVirt.setChecked(onPrefs.getBoolean("prefsVIRTOn1", false));
        knobVirt = new KnobView(this);
        knobVirt.setup(1000, pos.getInt("VirtLevel", 0), v -> { pos.edit().putInt("VirtLevel", v).apply(); if (svc != null) svc.setVirt(v); });
        knobVirt.setActive(swVirt.isChecked());
        swVirt.setListener(on -> {
            knobVirt.setActive(on);
            startService(new Intent(this, EqService.class).setAction(EqService.ACTION_VIRT_TOGGLE));
        });

        card.addView(side(swBass, knobBass, "BASS BOOST"), new LinearLayout.LayoutParams(0, -2, 1));

        // center: PRESET + pill + VU
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        mid.addView(label("PRESET", 21, Color.WHITE, true), new LinearLayout.LayoutParams(-2, dp(40)));
        presetName = label(pos.getString("PresetName", "Custom"), 20, GREEN, true);
        presetName.setBackground(rounded(0xFF000000, 3));
        presetName.setPadding(dp(18), dp(10), dp(18), dp(10));
        presetName.setSingleLine(true);
        presetName.setOnClickListener(v -> presetDialog());
        mid.addView(presetName, new LinearLayout.LayoutParams(-2, -2));
        View spacer = new View(this);
        mid.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));
        TextView vu = label("", 34, Color.WHITE, true);
        vu.setContentDescription("VU meter");
        vu.setBackgroundResource(R.drawable.botunvu_full_studio);
        vu.setOnClickListener(v -> vuDialog());
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(dp(84), dp(78));
        vp.topMargin = dp(10);
        mid.addView(vu, vp);
        card.addView(mid, new LinearLayout.LayoutParams(dp(124), -1));

        card.addView(side(swVirt, knobVirt, "VIRTUALIZER"), new LinearLayout.LayoutParams(0, -2, 1));
        return card;
    }

    private View side(PillSwitch sw, KnobView knob, String name) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.leftMargin = dp(4);
        c.addView(sw, sp);
        c.addView(knob, new LinearLayout.LayoutParams(-1, -2));
        TextView t = label(name, 13, Color.WHITE, true);
        t.setGravity(Gravity.START);
        t.setSingleLine(true);
        c.addView(t, new LinearLayout.LayoutParams(-2, -2));
        return c;
    }

    // ---------------------------------------------------------------- EQ modes
    private void load10() {
        String saved = getSharedPreferences("eq10_save_prefs", 0).getString("eq10_save_prefs", "");
        if (!saved.isEmpty()) {
            String[] sp = saved.split(",");
            for (int i = 0; i < 10 && i < sp.length; i++) try { Cfg.bands10[i] = Float.parseFloat(sp[i]); } catch (Exception ignored) {}
        }
    }

    private void showEq() {
        swEq.setChecked(onPrefs.getBoolean("prefsEQOn1", true));
        eqView.setAlpha(swEq.isChecked() ? 1f : 0.4f);
        int[] v = new int[10];
        for (int i = 0; i < 10; i++) v[i] = Math.max(0, Math.min(300, Math.round(Cfg.bands10[i] * 10f) + 150));
        eqView.configure(N10, 300, v, (i, p) -> dbText(Math.round((p - 150) / 10f)), this::on10);
    }

    private static String dbText(int v) { return v > 0 ? "+" + v : String.valueOf(v); }

    private void on10(int i, int p) {
        Cfg.bands10[i] = (p - 150) / 10f;
        if (svc != null && swEq.isChecked()) svc.dpEqApply(Cfg.bands10);
        ui.removeCallbacks(save10);
        ui.postDelayed(save10, 300);
        markCustom();
    }

    // ---------------------------------------------------------------- presets
    private void markCustom() {
        if (!"Custom".equals(presetName.getText().toString())) setPresetName("Custom");
    }
    private void setPresetName(String n) {
        presetName.setText(n);
        pos.edit().putString("PresetName", n).apply();
    }

    /** Set all bands (progress values for the current mode) and push them to the service. */
    private void applyValues(int[] vals) {
        for (int i = 0; i < vals.length && i < eqView.count(); i++) {
            eqView.setValue(i, vals[i]);
            on10(i, eqView.getValue(i));
        }
    }

    private int[] builtinValues(float[] db10) {
        int[] v = new int[10];
        for (int i = 0; i < 10; i++) v[i] = Math.max(0, Math.min(300, Math.round((db10[i] + 15f) * 10f)));
        return v;
    }

    private String userPrefix() { return "u10_"; }

    private void presetDialog() {
        final List<String> names = new ArrayList<>();
        final List<int[]> vals = new ArrayList<>();
        final List<String> keys = new ArrayList<>();          // non-null for user presets (deletable)
        for (int i = 0; i < BUILTIN.length; i++) { names.add(BUILTIN_NAMES[i][0]); vals.add(builtinValues(BUILTIN[i])); keys.add(null); }
        for (Map.Entry<String, ?> e : presets.getAll().entrySet()) {
            if (!e.getKey().startsWith(userPrefix())) continue;
            try {
                String[] sp = String.valueOf(e.getValue()).split(",");
                int[] v = new int[sp.length];
                for (int i = 0; i < sp.length; i++) v[i] = Integer.parseInt(sp[i].trim());
                names.add(e.getKey().substring(userPrefix().length())); vals.add(v); keys.add(e.getKey());
            } catch (Exception ignored) {}
        }
        names.add("+ Save current...");
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Preset")
                .setItems(names.toArray(new String[0]), (dd, which) -> {
                    if (which == names.size() - 1) { saveDialog(); return; }
                    applyValues(vals.get(which));
                    setPresetName(names.get(which));
                }).create();
        dlg.show();
        dlg.getListView().setOnItemLongClickListener((p, v, which, id) -> {
            if (which < keys.size() && keys.get(which) != null) {
                presets.edit().remove(keys.get(which)).apply();
                Toast.makeText(this, "Deleted " + names.get(which), Toast.LENGTH_SHORT).show();
                dlg.dismiss();
                return true;
            }
            return false;
        });
    }

    private void saveDialog() {
        final EditText in = new EditText(this);
        in.setSingleLine(true); in.setHint("Preset name");
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Save preset").setView(in)
                .setPositiveButton("Save", (dd, w) -> {
                    String n = in.getText().toString().trim().replace(",", " ");
                    if (n.isEmpty()) return;
                    StringBuilder sb = new StringBuilder();
                    for (int v : eqView.getValues()) sb.append(v).append(",");
                    presets.edit().putString(userPrefix() + n, sb.toString()).apply();
                    setPresetName(n);
                })
                .setNegativeButton("Cancel", null).show();
    }

    // ---------------------------------------------------------------- volume / effects dialog (speaker icon)
    private void volumeDialog() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(20), dp(12), dp(20), dp(4));
        TextView t = label("", 18, Color.WHITE, true);
        SeekBar bar = new SeekBar(this);
        bar.setMax(am.getStreamMaxVolume(3));
        bar.setProgress(am.getStreamVolume(3));
        t.setText(String.format("VOLUME %02d", bar.getProgress()));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                am.setStreamVolume(3, p, 0);
                t.setText(String.format("VOLUME %02d", p));
                if (EqService.volumeLock) EqService.lockedVolume = p;
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        CheckBox lock = new CheckBox(this);
        lock.setText("Lock volume"); lock.setTextColor(Color.WHITE);
        lock.setChecked(EqService.volumeLock);
        lock.setOnCheckedChangeListener((b, on) -> { if (svc != null) svc.setVolumeLock(on); });
        c.addView(t); c.addView(bar); c.addView(lock);
        Dialogs.Svc g = () -> svc;
        c.addView(menuButton("Preamp & Loudness", () -> Dialogs.preampLoudness(this, g)));
        c.addView(menuButton("Balance", () -> Dialogs.balance(this, g)));
        c.addView(menuButton("Limiter", () -> Dialogs.limiter(this, g)));
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setView(c).setPositiveButton("OK", null).show();
    }

    private Button menuButton(String text, Runnable r) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(GREEN); b.setBackground(rounded(0xFF2A2A2C, 12));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
        p.topMargin = dp(8);
        b.setLayoutParams(p);
        return b;
    }

    // ---------------------------------------------------------------- VU meter (Visualizer peak/RMS on the output mix)
    private void vuDialog() {
        final VuView vu = new VuView(this);
        vu.setPadding(dp(20), dp(8), dp(20), dp(8));
        Visualizer vis = null;
        try {
            vis = new Visualizer(Cfg.session);
            vis.setMeasurementMode(Visualizer.MEASUREMENT_MODE_PEAK_RMS);
            vis.setEnabled(true);
        } catch (Throwable e) {
            Toast.makeText(this, "VU needs the microphone permission (RECORD_AUDIO)", Toast.LENGTH_LONG).show();
            if (vis != null) try { vis.release(); } catch (Exception ignored) {}
            return;
        }
        final Visualizer v = vis;
        final Visualizer.MeasurementPeakRms m = new Visualizer.MeasurementPeakRms();
        final Runnable poll = new Runnable() {
            @Override public void run() {
                try {
                    v.getMeasurementPeakRms(m);
                    vu.set(clamp01((m.mPeak + 6000f) / 6000f), clamp01((m.mRms + 6000f) / 6000f));
                } catch (Exception ignored) {}
                ui.postDelayed(this, 50);
            }
        };
        ui.post(poll);
        AlertDialog dlg = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle("VU").setView(vu)
                .setPositiveButton("Close", null).create();
        dlg.setOnDismissListener(x -> { ui.removeCallbacks(poll); try { v.setEnabled(false); v.release(); } catch (Exception ignored) {} });
        dlg.show();
    }
    private static float clamp01(float f) { return Math.max(0f, Math.min(1f, f)); }
}
