package app.eqclean;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.View;

/** Equalizer curve: N vertical tracks with green knobs, smooth curve and dotted fill (like the reference layout). */
public class EqView extends View {
    public interface Listener { void onChange(int index, int value); }
    public interface Labeler { String label(int index, int value); }

    private String[] names = new String[0];
    private int[] values = new int[0];
    private int max = 100;
    private Labeler labeler;
    private Listener listener;
    private final SparseIntArray pointers = new SparseIntArray();
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valueText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint active = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint curve = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private float yTop, yBot, padX, colW;

    public EqView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        text.setColor(StudioTheme.TEXT); text.setTextAlign(Paint.Align.CENTER); text.setTextSize(15 * d);
        valueText.setColor(StudioTheme.ACCENT); valueText.setTextAlign(Paint.Align.CENTER);
        track.setColor(0xFF565A5A); track.setStrokeWidth(2.5f * d); track.setStrokeCap(Paint.Cap.ROUND);
        active.setColor(StudioTheme.ACCENT); active.setStrokeWidth(2.5f * d); active.setStrokeCap(Paint.Cap.ROUND);
        curve.setColor(StudioTheme.ACCENT); curve.setStyle(Paint.Style.STROKE); curve.setStrokeWidth(2 * d); curve.setStrokeJoin(Paint.Join.ROUND);
        fill.setColor(0x203AB7D0); fill.setStyle(Paint.Style.FILL);
        dot.setColor(0x6659C7DE);
        knob.setColor(StudioTheme.ACCENT);
        halo.setColor(0x226DE5FF);
    }

    public void configure(String[] names, int max, int[] values, Labeler labeler, Listener listener) {
        this.names = names; this.max = max; this.values = values.clone();
        this.labeler = labeler; this.listener = listener;
        text.setTextSize((names.length > 6 ? 14 : 16) * d);
        valueText.setTextSize((names.length > 6 ? 13 : 15) * d);
        invalidate();
    }
    public void setValue(int i, int v) { if (i >= 0 && i < values.length) { values[i] = Math.max(0, Math.min(max, v)); invalidate(); } }
    public int getValue(int i) { return values[i]; }
    public int[] getValues() { return values.clone(); }
    public int count() { return values.length; }

    private float px(int i) { return padX + colW * (i + 0.5f); }
    private float py(int v) { return yBot - (float) v / max * (yBot - yTop); }

    @Override protected void onDraw(Canvas c) {
        int n = values.length;
        if (n == 0) return;
        float w = getWidth(), h = getHeight();
        float r = 11 * d;
        padX = 6 * d; colW = (w - 2 * padX) / n;
        float areaTop = 38 * d, areaBot = h - 44 * d;
        yTop = areaTop + r; yBot = areaBot - r;

        for (int i = 0; i < n; i++) {
            float x = px(i);
            c.drawText(names[i], x, 24 * d, text);
            c.drawText(labeler != null ? labeler.label(i, values[i]) : String.valueOf(values[i]), x, h - 12 * d, valueText);
        }
        for (int i = 0; i < n; i++) c.drawLine(px(i), areaTop, px(i), areaBot, track);

        float[] xs = new float[n], ys = new float[n];
        for (int i = 0; i < n; i++) { xs[i] = px(i); ys[i] = py(values[i]); }
        Path line = new Path();
        line.moveTo(xs[0], ys[0]);
        for (int i = 0; i < n - 1; i++) {
            int p0 = Math.max(0, i - 1), p3 = Math.min(n - 1, i + 2);
            float c1x = xs[i] + (xs[i + 1] - xs[p0]) / 6f, c1y = ys[i] + (ys[i + 1] - ys[p0]) / 6f;
            float c2x = xs[i + 1] - (xs[p3] - xs[i]) / 6f, c2y = ys[i + 1] - (ys[p3] - ys[i]) / 6f;
            c1y = Math.max(yTop, Math.min(yBot, c1y)); c2y = Math.max(yTop, Math.min(yBot, c2y));
            line.cubicTo(c1x, c1y, c2x, c2y, xs[i + 1], ys[i + 1]);
        }
        Path area = new Path(line);
        area.lineTo(xs[n - 1], areaBot); area.lineTo(xs[0], areaBot); area.close();
        c.save();
        c.clipPath(area);
        c.drawRect(0, 0, w, h, fill);
        float step = 12 * d;
        for (float gy = areaBot - step / 2; gy > areaTop; gy -= step)
            for (float gx = padX + step / 2; gx < w; gx += step) c.drawCircle(gx, gy, 1.4f * d, dot);
        c.restore();

        for (int i = 0; i < n; i++) c.drawLine(xs[i], ys[i], xs[i], areaBot, active);
        c.drawPath(line, curve);
        for (int i = 0; i < n; i++) { c.drawCircle(xs[i], ys[i], r + 3 * d, halo); c.drawCircle(xs[i], ys[i], r, knob); }
    }

    private void update(int col, float y) {
        if (col < 0 || col >= values.length) return;
        int v = Math.round((yBot - y) / (yBot - yTop) * max);
        v = Math.max(0, Math.min(max, v));
        if (v != values[col]) {
            values[col] = v;
            invalidate();
            if (listener != null) listener.onChange(col, v);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (values.length == 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int k = e.getActionIndex();
                int col = (int) ((e.getX(k) - padX) / colW);
                col = Math.max(0, Math.min(values.length - 1, col));
                pointers.put(e.getPointerId(k), col);
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                update(col, e.getY(k));
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                for (int k = 0; k < e.getPointerCount(); k++) update(pointers.get(e.getPointerId(k), -1), e.getY(k));
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                pointers.delete(e.getPointerId(e.getActionIndex()));
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pointers.clear();
                return true;
        }
        return super.onTouchEvent(e);
    }
}
