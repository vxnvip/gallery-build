package app.eqclean;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.Shader;

/** Java-only reconstruction of the original Studio theme palette and surface. */
final class StudioTheme {
    static final int BACKGROUND = 0xFF000000;
    static final int PANEL = 0xFF191C1B;
    static final int ACCENT = 0xFF6DE5FF;
    static final int TEXT = 0xFFFFFFFF;
    static final int MUTED = 0xFF8A8A8A;

    private StudioTheme() {}

    static Drawable background(Context context) {
        BitmapDrawable drawable = new BitmapDrawable(context.getResources(),
                BitmapFactory.decodeResource(context.getResources(), R.drawable.bg_studio));
        drawable.setTileModeX(Shader.TileMode.REPEAT);
        drawable.setTileModeY(Shader.TileMode.REPEAT);
        return drawable;
    }
}
