// Port 1:1 of "User-Agent Switcher and Manager" 0.7.2 -> data/inject/override.js
// (phần JS-layer: ghi đè accessor trên Navigator.prototype giống hệt CRX).
// Placeholder PREFS = object do agent.js (Agent.parse) của CRX sinh ra cho UA đang dùng.
{
  const prefs = __PREFS__;

  // escape y hệt CRX (network.js -> regexFilter)
  const protectedRegex = list => {
    const regex = (list || [])
      .filter(c => typeof c === 'string' && c !== '')
      .map(c => c.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&'))
      .join('|');
    return regex ? new RegExp(regex) : null;
  };

  // accessor có name / arity / toString() giống native
  const nativeGetter = (key, get) => {
    const getter = {
      [key]: function() {
        return get(this);
      }
    }[key];
    Object.defineProperty(getter, 'name', {
      value: 'get ' + key,
      configurable: true
    });
    getter.toString = () => `function get ${key}() { [native code] }`;
    return getter;
  };

  // define trên prototype của navigator (không để own property)
  const define = (nav, key, get) => {
    const getter = nativeGetter(key, get);
    const proto = Object.getPrototypeOf(nav);
    try {
      proto.__defineGetter__(key, getter);
    }
    catch (e) {
      nav.__defineGetter__(key, getter);
    }
  };

  const override = nav => {
    // URL protected -> giữ navigator thật (khớp với header thật)
    const regex = protectedRegex(prefs.protected);
    if (regex) {
      let hrefs = [location.href];
      try {
        hrefs.push(window.top.location.href);
      }
      catch (e) {}
      if (hrefs.some(h => regex.test(h))) {
        return;
      }
    }
    try {
      for (const key of Object.keys(prefs)) {
        if (key === 'type' || key === 'protected') {
          continue;
        }
        if (prefs[key] === '[delete]') {
          delete Object.getPrototypeOf(nav)[key];
        }
        else {
          define(nav, key, () => {
            if (prefs[key] === 'empty') {
              return '';
            }
            return prefs[key];
          });
        }
      }
    }
    catch (e) {
      console.error('UA_SET_FAILED', e);
    }
  };

  override(navigator);
}
