package com.example.golikemulti;

import android.app.Activity;
import android.text.TextUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Arrays;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.webkit.ProfileStore;
import androidx.webkit.ProxyConfig;
import androidx.webkit.UserAgentMetadata;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;

/* compiled from: WebActivity.kt */
/* loaded from: classes3.dex */
public final class WebActivity extends Activity {
    public static final String UA = "Mozilla/5.0 (Linux; iPhone; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36";
    private CookieManager cm;
    private boolean destroyed;
    private boolean isNew;
    private String profile;
    private boolean saved;
    private WebView web;

    @Override // android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (WebViewFeature.isFeatureSupported("MULTI_PROFILE")) {
            this.isNew = getIntent().getBooleanExtra("new", false);
            String stringExtra = getIntent().getStringExtra("profile");
            if (stringExtra == null) {
                String uuid = UUID.randomUUID().toString();
                Intrinsics.checkNotNullExpressionValue(uuid, "toString(...)");
                stringExtra = "acc_" + uuid.replace("-", "");
            }
            this.profile = stringExtra;
            ProfileStore profileStore = ProfileStore.getInstance();
            String str = this.profile;
            if (str == null) {
                Intrinsics.throwUninitializedPropertyAccessException("profile");
                str = null;
            }
            CookieManager cookieManager = profileStore.getOrCreateProfile(str).getCookieManager();
            Intrinsics.checkNotNullExpressionValue(cookieManager, "getCookieManager(...)");
            this.cm = cookieManager;
            this.web = new WebView(this);
            WebView webView = this.web;
            if (webView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView = null;
            }
            String str2 = this.profile;
            if (str2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("profile");
                str2 = null;
            }
            WebViewCompat.setProfile(webView, str2);
            WebView webView2 = this.web;
            if (webView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView2 = null;
            }
            webView2.getSettings().setJavaScriptEnabled(true);
            WebView webView3 = this.web;
            if (webView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView3 = null;
            }
            webView3.getSettings().setDomStorageEnabled(true);
            WebView webView4 = this.web;
            if (webView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView4 = null;
            }
            webView4.getSettings().setUserAgentString(UA);
            if (WebViewFeature.isFeatureSupported("USER_AGENT_METADATA")) {
                try {
                    UserAgentMetadata md = new UserAgentMetadata.Builder().setBrandVersionList(Arrays.asList(new UserAgentMetadata.BrandVersion[]{onCreate$bv("Android WebView", "153"), onCreate$bv("Not_A Brand", "8"), onCreate$bv("Chromium", "153")})).setFullVersion("153.0.0.0").setPlatform("iOS").setMobile(true).build();
                    Intrinsics.checkNotNullExpressionValue(md, "build(...)");
                    WebView webView5 = this.web;
                    if (webView5 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("web");
                        webView5 = null;
                    }
                    WebSettingsCompat.setUserAgentMetadata(webView5.getSettings(), md);
                } catch (Throwable e) {
                    Toast.makeText(this, "Không set được UA metadata: " + e.getMessage(), 1).show();
                }
            } else {
                Toast.makeText(this, "WebView không hỗ trợ USER_AGENT_METADATA", 1).show();
            }
            WebView webView6 = this.web;
            if (webView6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView6 = null;
            }
            webView6.setWebViewClient(new WebViewClient() { // from class: com.example.golikemulti.WebActivity$onCreate$1
                @Override // android.webkit.WebViewClient
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                    String url = req.getUrl().toString();
                    if (!"GET".equals(req.getMethod()) || !url.startsWith("http")) {
                        return null;
                    }
                    try {
                        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                        c.setRequestMethod("GET");
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(30000);
                        c.setInstanceFollowRedirects(!req.isForMainFrame());
                        for (Map.Entry<String, String> reqHeader : req.getRequestHeaders().entrySet()) {
                            String k = reqHeader.getKey();
                            String v = reqHeader.getValue();
                            if (StringsKt.equals(k, "sec-ch-ua-platform", true)) {
                                c.setRequestProperty(k, "\"iOS\"");
                            } else if (!StringsKt.equals(k, "Accept-Encoding", true) && !StringsKt.equals(k, "User-Agent", true) && !StringsKt.equals(k, "Cookie", true)) {
                                c.setRequestProperty(k, v);
                            }
                        }
                        c.setRequestProperty("User-Agent", WebActivity.UA);
                        String cookie = WebActivity.this.cm.getCookie(url);
                        if (cookie != null) {
                            c.setRequestProperty("Cookie", cookie);
                        }
                        int code = c.getResponseCode();
                        List<String> setCookies = c.getHeaderFields().get("Set-Cookie");
                        if (setCookies != null) {
                            for (String sc : setCookies) {
                                WebActivity.this.cm.setCookie(url, sc);
                            }
                        }
                        if (code >= 300 && code < 400) {
                            c.disconnect();
                            return null;
                        }
                        String ct = c.getContentType();
                        if (ct == null) {
                            ct = "text/html";
                        }
                        int semi = ct.indexOf(';');
                        String mime = (semi < 0 ? ct : ct.substring(0, semi)).trim();
                        Matcher m = Pattern.compile("charset=([^;]+)", Pattern.CASE_INSENSITIVE).matcher(ct);
                        String enc = m.find() ? m.group(1).trim() : null;
                        Map<String, String> hdr = new LinkedHashMap<>();
                        for (Map.Entry<String, List<String>> respHeader : c.getHeaderFields().entrySet()) {
                            String k2 = respHeader.getKey();
                            if (k2 != null && !StringsKt.equals(k2, "Set-Cookie", true) && !StringsKt.equals(k2, "Content-Encoding", true) && !StringsKt.equals(k2, "Content-Length", true) && !StringsKt.equals(k2, "Transfer-Encoding", true)) {
                                hdr.put(k2, TextUtils.join(",", respHeader.getValue()));
                            }
                        }
                        InputStream stream = code >= 400 ? c.getErrorStream() : c.getInputStream();
                        String msg = c.getResponseMessage();
                        if (msg == null || msg.isEmpty()) {
                            msg = "OK";
                        }
                        return new WebResourceResponse(mime, enc, code, msg, hdr, stream);
                    } catch (Exception e2) {
                        return null;
                    }
                }
            });
            Button $this$onCreate_u24lambda_u241 = new Button(this);
            $this$onCreate_u24lambda_u241.setText("←");
            $this$onCreate_u24lambda_u241.setOnClickListener(new View.OnClickListener() { // from class: com.example.golikemulti.WebActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    WebActivity.onCreate$lambda$1$lambda$0(WebActivity.this, view);
                }
            });
            final EditText $this$onCreate_u24lambda_u242 = new EditText(this);
            $this$onCreate_u24lambda_u242.setHint("Nhập URL...");
            $this$onCreate_u24lambda_u242.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1.0f));
            $this$onCreate_u24lambda_u242.setText("https://app.golike.net/home");
            Button $this$onCreate_u24lambda_u244 = new Button(this);
            $this$onCreate_u24lambda_u244.setText("Đi");
            $this$onCreate_u24lambda_u244.setOnClickListener(new View.OnClickListener() { // from class: com.example.golikemulti.WebActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    WebActivity.onCreate$lambda$4$lambda$3(WebActivity.this, $this$onCreate_u24lambda_u242, view);
                }
            });
            LinearLayout $this$onCreate_u24lambda_u247 = new LinearLayout(this);
            $this$onCreate_u24lambda_u247.setOrientation(0);
            $this$onCreate_u24lambda_u247.setPadding(8, 72, 8, 8);
            $this$onCreate_u24lambda_u247.addView($this$onCreate_u24lambda_u241);
            $this$onCreate_u24lambda_u247.addView($this$onCreate_u24lambda_u242);
            $this$onCreate_u24lambda_u247.addView($this$onCreate_u24lambda_u244);
            if (this.isNew) {
                Button $this$onCreate_u24lambda_u247_u24lambda_u246 = new Button(this);
                $this$onCreate_u24lambda_u247_u24lambda_u246.setText("LƯU");
                $this$onCreate_u24lambda_u247_u24lambda_u246.setOnClickListener(new View.OnClickListener() { // from class: com.example.golikemulti.WebActivity$$ExternalSyntheticLambda2
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        WebActivity.onCreate$lambda$7$lambda$6$lambda$5(WebActivity.this, view);
                    }
                });
                $this$onCreate_u24lambda_u247.addView($this$onCreate_u24lambda_u247_u24lambda_u246);
            }
            LinearLayout $this$onCreate_u24lambda_u248 = new LinearLayout(this);
            $this$onCreate_u24lambda_u248.setOrientation(1);
            $this$onCreate_u24lambda_u248.addView($this$onCreate_u24lambda_u247, new LinearLayout.LayoutParams(-1, -2));
            WebView webView7 = this.web;
            if (webView7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView7 = null;
            }
            $this$onCreate_u24lambda_u248.addView(webView7, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            setContentView($this$onCreate_u24lambda_u248);
            WebView webView8 = this.web;
            if (webView8 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView8 = null;
            }
            webView8.loadUrl("https://app.golike.net/home");
            return;
        }
        Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", 1).show();
        finish();
    }

    private static final UserAgentMetadata.BrandVersion onCreate$bv(String b, String v) {
        UserAgentMetadata.BrandVersion build = new UserAgentMetadata.BrandVersion.Builder().setBrand(b).setMajorVersion(v).setFullVersion(v + ".0.0.0").build();
        Intrinsics.checkNotNullExpressionValue(build, "build(...)");
        return build;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$1$lambda$0(WebActivity this$0, View it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.onBackPressed();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$4$lambda$3(WebActivity this$0, EditText urlInput, View it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(urlInput, "$urlInput");
        WebView webView = this$0.web;
        if (webView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("web");
            webView = null;
        }
        webView.loadUrl(urlInput.getText().toString());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$7$lambda$6$lambda$5(WebActivity this$0, View it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.showSaveDialog();
    }

    private final void showSaveDialog() {
        final EditText $this$showSaveDialog_u24lambda_u249 = new EditText(this);
        $this$showSaveDialog_u24lambda_u249.setHint("Nhập user Golike");
        new AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView($this$showSaveDialog_u24lambda_u249).setPositiveButton("Lưu", new DialogInterface.OnClickListener() { // from class: com.example.golikemulti.WebActivity$$ExternalSyntheticLambda4
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                WebActivity.showSaveDialog$lambda$11($this$showSaveDialog_u24lambda_u249, WebActivity.this, dialogInterface, i);
            }
        }).setNegativeButton("Hủy", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showSaveDialog$lambda$11(EditText input, WebActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(input, "$input");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String name = StringsKt.trim((CharSequence) input.getText().toString()).toString();
        List list = Store.INSTANCE.all(this$0);
        boolean z = false;
        if (!(name.length() == 0)) {
            List $this$any$iv = list;
            if (!($this$any$iv instanceof Collection) || !$this$any$iv.isEmpty()) {
                Iterator it = $this$any$iv.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    Object element$iv = it.next();
                    Account it2 = (Account) element$iv;
                    if (Intrinsics.areEqual(it2.getName(), name)) {
                        z = true;
                        break;
                    }
                }
            }
            if (!z) {
                String str = this$0.profile;
                if (str == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("profile");
                    str = null;
                }
                list.add(new Account(str, name));
                Store.INSTANCE.save(this$0, list);
                this$0.saved = true;
                this$0.finish();
                return;
            }
            this$0.toast("User này đã có");
            return;
        }
        this$0.toast("Chưa nhập user");
    }

    private final void toast(String s) {
        Toast.makeText(this, s, 0).show();
    }

    private final void discard() {
        destroyWeb();
        try {
            ProfileStore profileStore = ProfileStore.getInstance();
            String str = this.profile;
            if (str == null) {
                Intrinsics.throwUninitializedPropertyAccessException("profile");
                str = null;
            }
            profileStore.deleteProfile(str);
        } catch (Exception e) {
        }
        finish();
    }

    private final void destroyWeb() {
        if (this.destroyed) {
            return;
        }
        this.destroyed = true;
        WebView webView = this.web;
        WebView webView2 = null;
        if (webView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("web");
            webView = null;
        }
        ViewParent parent = webView.getParent();
        ViewGroup viewGroup = parent instanceof ViewGroup ? (ViewGroup) parent : null;
        if (viewGroup != null) {
            WebView webView3 = this.web;
            if (webView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("web");
                webView3 = null;
            }
            viewGroup.removeView(webView3);
        }
        WebView webView4 = this.web;
        if (webView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("web");
        } else {
            webView2 = webView4;
        }
        webView2.destroy();
    }

    @Override // android.app.Activity
    @Deprecated
    public void onBackPressed() {
        if (this.web == null) {
            finish();
            return;
        }
        WebView webView = this.web;
        WebView webView2 = null;
        if (webView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("web");
            webView = null;
        }
        if (!webView.canGoBack()) {
            if (this.isNew && !this.saved) {
                new AlertDialog.Builder(this).setTitle("Bỏ tài khoản này?").setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.").setPositiveButton("Bỏ", new DialogInterface.OnClickListener() { // from class: com.example.golikemulti.WebActivity$$ExternalSyntheticLambda3
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i) {
                        WebActivity.onBackPressed$lambda$12(WebActivity.this, dialogInterface, i);
                    }
                }).setNegativeButton("Ở lại", (DialogInterface.OnClickListener) null).show();
                return;
            } else {
                finish();
                return;
            }
        }
        WebView webView3 = this.web;
        if (webView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("web");
        } else {
            webView2 = webView3;
        }
        webView2.goBack();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBackPressed$lambda$12(WebActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.discard();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (this.web != null) {
            destroyWeb();
        }
        super.onDestroy();
    }
}
