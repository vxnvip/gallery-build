package com.example.golikemulti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewFeature;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* compiled from: MainActivity.kt */
/* loaded from: classes3.dex */
public final class MainActivity extends Activity {
    private List<Account> accs = new ArrayList();
    private ListView list;

    @Override // android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(32, 96, 32, 32);
        this.list = new ListView(this);
        Button $this$onCreate_u24lambda_u242 = new Button(this);
        $this$onCreate_u24lambda_u242.setText("+ Thêm tài khoản");
        $this$onCreate_u24lambda_u242.setOnClickListener(new View.OnClickListener() { // from class: com.example.golikemulti.MainActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.onCreate$lambda$2$lambda$1(MainActivity.this, view);
            }
        });
        ListView listView = this.list;
        ListView listView2 = null;
        if (listView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("list");
            listView = null;
        }
        root.addView(listView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        root.addView($this$onCreate_u24lambda_u242, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        ListView listView3 = this.list;
        if (listView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("list");
            listView3 = null;
        }
        listView3.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.example.golikemulti.MainActivity$$ExternalSyntheticLambda2
            @Override // android.widget.AdapterView.OnItemClickListener
            public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                MainActivity.onCreate$lambda$3(MainActivity.this, adapterView, view, i, j);
            }
        });
        ListView listView4 = this.list;
        if (listView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("list");
        } else {
            listView2 = listView4;
        }
        listView2.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // from class: com.example.golikemulti.MainActivity$$ExternalSyntheticLambda3
            @Override // android.widget.AdapterView.OnItemLongClickListener
            public final boolean onItemLongClick(AdapterView adapterView, View view, int i, long j) {
                boolean onCreate$lambda$4;
                onCreate$lambda$4 = MainActivity.onCreate$lambda$4(MainActivity.this, adapterView, view, i, j);
                return onCreate$lambda$4;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$2$lambda$1(MainActivity this$0, View it) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.startActivity(new Intent(this$0, WebActivity.class).putExtra("new", true));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$3(MainActivity this$0, AdapterView adapterView, View view, int i, long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.startActivity(new Intent(this$0, WebActivity.class).putExtra("profile", this$0.accs.get(i).getProfileId()).putExtra("title", this$0.accs.get(i).getName()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean onCreate$lambda$4(MainActivity this$0, AdapterView adapterView, View view, int i, long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.menu(i);
        return true;
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        this.accs = Store.INSTANCE.all(this);
        ListView listView = this.list;
        if (listView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("list");
            listView = null;
        }
        MainActivity mainActivity = this;
        Iterable $this$map$iv = this.accs;
        Collection destination$iv$iv = new ArrayList();
        for (Object item$iv$iv : $this$map$iv) {
            Account it = (Account) item$iv$iv;
            destination$iv$iv.add(it.getName());
        }
        listView.setAdapter((ListAdapter) new ArrayAdapter(mainActivity, 17367043, (List) destination$iv$iv));
    }

    private final void menu(final int i) {
        new AlertDialog.Builder(this).setItems(new String[]{"Đổi tên", "Xóa"}, new DialogInterface.OnClickListener() { // from class: com.example.golikemulti.MainActivity$$ExternalSyntheticLambda5
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                MainActivity.menu$lambda$6(MainActivity.this, i, dialogInterface, i2);
            }
        }).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void menu$lambda$6(MainActivity this$0, int $i, DialogInterface dialogInterface, int w) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (w == 0) {
            this$0.rename($i);
        } else {
            this$0.delete($i);
        }
    }

    private final void rename(final int i) {
        final EditText $this$rename_u24lambda_u247 = new EditText(this);
        $this$rename_u24lambda_u247.setText(this.accs.get(i).getName());
        new AlertDialog.Builder(this).setTitle("Đổi tên").setView($this$rename_u24lambda_u247).setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.example.golikemulti.MainActivity$$ExternalSyntheticLambda4
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                MainActivity.rename$lambda$9($this$rename_u24lambda_u247, MainActivity.this, i, dialogInterface, i2);
            }
        }).setNegativeButton("Hủy", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void rename$lambda$9(EditText input, MainActivity this$0, int $i, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(input, "$input");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String n = StringsKt.trim((CharSequence) input.getText().toString()).toString();
        boolean z = false;
        if (!(n.length() > 0)) {
            return;
        }
        Iterable $this$none$iv = this$0.accs;
        if (!($this$none$iv instanceof Collection) || !((Collection) $this$none$iv).isEmpty()) {
            Iterator it = $this$none$iv.iterator();
            while (true) {
                if (it.hasNext()) {
                    Object element$iv = it.next();
                    Account it2 = (Account) element$iv;
                    if (Intrinsics.areEqual(it2.getName(), n)) {
                        break;
                    }
                } else {
                    z = true;
                    break;
                }
            }
        } else {
            z = true;
        }
        if (z) {
            this$0.accs.get($i).setName(n);
            Store.INSTANCE.save(this$0, this$0.accs);
            this$0.onResume();
        }
    }

    private final void delete(final int i) {
        new AlertDialog.Builder(this).setTitle("Xóa " + this.accs.get(i).getName() + "?").setMessage("Dữ liệu đăng nhập của tài khoản này cũng bị xóa.").setPositiveButton("Xóa", new DialogInterface.OnClickListener() { // from class: com.example.golikemulti.MainActivity$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                MainActivity.delete$lambda$10(MainActivity.this, i, dialogInterface, i2);
            }
        }).setNegativeButton("Hủy", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void delete$lambda$10(MainActivity this$0, int $i, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (WebViewFeature.isFeatureSupported("MULTI_PROFILE")) {
            try {
                ProfileStore.getInstance().deleteProfile(this$0.accs.get($i).getProfileId());
            } catch (Exception e) {
            }
        }
        this$0.accs.remove($i);
        Store.INSTANCE.save(this$0, this$0.accs);
        this$0.onResume();
    }
}
