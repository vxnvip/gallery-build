package com.example.golikemulti

import android.content.Context
import android.webkit.WebView
import androidx.webkit.ProfileStore
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/** Cấu hình chung cho mọi WebView (cả WebActivity lẫn tab điều khiển từ Termux). */
object WebConfig {
    /** Lấy major version Chrome thật của WebView trên máy để UA và client-hints khớp nhau. */
    fun major(ctx: Context): String {
        val v = try { WebViewCompat.getCurrentWebViewPackage(ctx)?.versionName } catch (_: Throwable) { null }
        val m = v?.substringBefore('.') ?: ""
        return if (m.isNotEmpty() && m.all { it.isDigit() }) m else "138"
    }

    fun ua(ctx: Context) =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/${major(ctx)}.0.0.0 Safari/537.36"

    /** Gọi ngay sau khi tạo WebView, TRƯỚC mọi lệnh khác (setProfile yêu cầu vậy). */
    fun apply(web: WebView, profile: String) {
        val ctx = web.context
        ProfileStore.getInstance().getOrCreateProfile(profile)
        WebViewCompat.setProfile(web, profile)

        val m = major(ctx)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = ua(ctx)
            useWideViewPort = true          // render như trang desktop
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }

        // sec-ch-ua-* cho MỌI request (kể cả POST) -> khớp UA Windows desktop
        if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
            try {
                fun bv(b: String, v: String) = UserAgentMetadata.BrandVersion.Builder()
                    .setBrand(b).setMajorVersion(v).setFullVersion("$v.0.0.0").build()
                val md = UserAgentMetadata.Builder()
                    .setBrandVersionList(listOf(bv("Chromium", m), bv("Google Chrome", m), bv("Not_A Brand", "8")))
                    .setFullVersion("$m.0.0.0")
                    .setPlatform("Windows")
                    .setPlatformVersion("15.0.0")
                    .setArchitecture("x86")
                    .setBitness(64)
                    .setModel("")
                    .setMobile(false)
                    .build()
                WebSettingsCompat.setUserAgentMetadata(web.settings, md)
            } catch (_: Throwable) { }
        }
    }
}
