package com.example.golikemulti;

import kotlin.jvm.internal.Intrinsics;

/* compiled from: Store.kt */
/* loaded from: classes3.dex */
public final class Account {
    private String name;
    private final String profileId;

    public static /* synthetic */ Account copy$default(Account account, String str, String str2, int i, Object obj) {
        if ((i & 1) != 0) {
            str = account.profileId;
        }
        if ((i & 2) != 0) {
            str2 = account.name;
        }
        return account.copy(str, str2);
    }

    public final String component1() {
        return this.profileId;
    }

    public final String component2() {
        return this.name;
    }

    public final Account copy(String profileId, String name) {
        Intrinsics.checkNotNullParameter(profileId, "profileId");
        Intrinsics.checkNotNullParameter(name, "name");
        return new Account(profileId, name);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Account) {
            Account account = (Account) obj;
            return Intrinsics.areEqual(this.profileId, account.profileId) && Intrinsics.areEqual(this.name, account.name);
        }
        return false;
    }

    public int hashCode() {
        return (this.profileId.hashCode() * 31) + this.name.hashCode();
    }

    public String toString() {
        return "Account(profileId=" + this.profileId + ", name=" + this.name + ")";
    }

    public Account(String profileId, String name) {
        Intrinsics.checkNotNullParameter(profileId, "profileId");
        Intrinsics.checkNotNullParameter(name, "name");
        this.profileId = profileId;
        this.name = name;
    }

    public final String getName() {
        return this.name;
    }

    public final String getProfileId() {
        return this.profileId;
    }

    public final void setName(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.name = str;
    }
}
