package com.example.golikemulti

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

class ApiServerActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val input = EditText(this).apply {
            hint = "https://example.com:8080"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            setText(Store.apiServer(this@ApiServerActivity))
        }
        val save = Button(this).apply {
            text = "Lưu"
            setOnClickListener {
                val v = input.text.toString().trim().trimEnd('/')
                if (v.isNotEmpty() && !v.startsWith("http://") && !v.startsWith("https://")) {
                    Toast.makeText(this@ApiServerActivity, "URL phải bắt đầu bằng http:// hoặc https://", Toast.LENGTH_SHORT).show()
                } else {
                    Store.setApiServer(this@ApiServerActivity, v)
                    Toast.makeText(this@ApiServerActivity, "Đã lưu", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 32)
            addView(input, LinearLayout.LayoutParams(-1, -2))
            addView(save, LinearLayout.LayoutParams(-1, -2))
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("←", "API server") { finish() }, LinearLayout.LayoutParams(-1, -2))
        root.addView(body, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }
}
