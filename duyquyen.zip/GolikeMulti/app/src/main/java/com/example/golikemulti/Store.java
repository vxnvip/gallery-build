package com.example.golikemulti;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: Store.kt */
/* loaded from: classes3.dex */
public final class Store {
    public static final Store INSTANCE = new Store();

    private Store() {
    }

    private final SharedPreferences sp(Context c) {
        return c.getSharedPreferences("accs", 0);
    }

    public final List<Account> all(Context c) {
        Intrinsics.checkNotNullParameter(c, "c");
        JSONArray arr = new JSONArray(sp(c).getString("list", "[]"));
        int length = arr.length();
        ArrayList arrayList = new ArrayList(length);
        for (int i = 0; i < length; i++) {
            int it = i;
            JSONObject o = arr.getJSONObject(it);
            String string = o.getString("p");
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String string2 = o.getString("n");
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            arrayList.add(new Account(string, string2));
        }
        return arrayList;
    }

    public final void save(Context c, List<Account> list) {
        Intrinsics.checkNotNullParameter(c, "c");
        Intrinsics.checkNotNullParameter(list, "list");
        JSONArray arr = new JSONArray();
        List<Account> $this$forEach$iv = list;
        for (Object element$iv : $this$forEach$iv) {
            Account it = (Account) element$iv;
            arr.put(new JSONObject().put("p", it.getProfileId()).put("n", it.getName()));
        }
        sp(c).edit().putString("list", arr.toString()).apply();
    }
}
