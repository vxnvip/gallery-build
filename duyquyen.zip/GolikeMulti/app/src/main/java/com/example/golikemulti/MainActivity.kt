package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {
    companion object {
        const val JOBS_URL = "https://app.golike.net/jobs/facebook?tab=job"
    }
    private lateinit var list: ListView
    private lateinit var taskBtn: Button
    private lateinit var scrim: View
    private lateinit var drawer: LinearLayout
    private var drawerW = 0
    private var drawerOpen = false
    private var accs = mutableListOf<Account>()
    private var exitArmed = false
    private var exitToast: Toast? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        drawerW = (resources.displayMetrics.widthPixels * 0.7f).toInt()

        list = ListView(this)
        taskBtn = Button(this).apply {
            text = "Nhiệm vụ"
            setOnClickListener { runTask() }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 0, 32, 32)
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(taskBtn, LinearLayout.LayoutParams(-1, -2))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(topBar("☰", "Golike Multi") { setDrawer(true) }, LinearLayout.LayoutParams(-1, -2))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        scrim = View(this).apply {
            setBackgroundColor(0x66000000)
            alpha = 0f
            visibility = View.GONE
            setOnClickListener { setDrawer(false) }
        }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(0, 96, 0, 0)
            translationX = -drawerW.toFloat()
            elevation = 16f
            addView(drawerItem("＋  Thêm tài khoản") {
                startActivity(Intent(this@MainActivity, WebActivity::class.java).putExtra("new", true))
            }, LinearLayout.LayoutParams(-1, -2))
            addView(drawerItem("⚙  Setting") {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }, LinearLayout.LayoutParams(-1, -2))
        }

        val root = FrameLayout(this).apply {
            addView(page, FrameLayout.LayoutParams(-1, -1))
            addView(scrim, FrameLayout.LayoutParams(-1, -1))
            addView(drawer, FrameLayout.LayoutParams(drawerW, -1))
        }
        setContentView(root)

        list.setOnItemClickListener { _, _, i, _ -> openAccount(accs[i]) }
        list.setOnItemLongClickListener { _, _, i, _ -> menu(i); true }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun drawerItem(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 18f
        setPadding(48, 36, 48, 36)
        pressable(this)
        setOnClickListener { setDrawer(false); onClick() }
    }

    private fun openAccount(a: Account) = startActivity(
        Intent(this, WebActivity::class.java)
            .putExtra("profile", a.profileId)
            .putExtra("title", a.name)
            .putExtra("url", JOBS_URL)
    )

    private fun runTask() {
        val api = Store.apiServer(this)
        if (api.isEmpty()) { toast("Chưa cài API server (Menu → Setting)"); return }
        taskBtn.isEnabled = false
        taskBtn.text = "Đang kiểm tra..."
        Thread {
            var user = ""
            var err: String? = null
            try {
                val c = URL(api).openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 10000
                try {
                    val body = c.inputStream.bufferedReader().use { it.readText() }
                    val o = JSONObject(body)
                    user = if (o.isNull("username")) "" else o.optString("username", "").trim()
                } finally { c.disconnect() }
            } catch (e: Exception) { err = e.message ?: e.javaClass.simpleName }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                taskBtn.isEnabled = true
                taskBtn.text = "Nhiệm vụ"
                val acc = accs.firstOrNull { it.name.equals(user, true) }
                when {
                    err != null -> toast("Lỗi API: $err")
                    user.isEmpty() -> toast("Không có nhiệm vụ")
                    acc == null -> toast("Chưa lưu tài khoản $user")
                    else -> openAccount(acc)
                }
            }
        }.start()
    }

    private fun setDrawer(open: Boolean) {
        drawerOpen = open
        if (open) scrim.visibility = View.VISIBLE
        scrim.animate().alpha(if (open) 1f else 0f).setDuration(200).start()
        drawer.animate().translationX(if (open) 0f else -drawerW.toFloat()).setDuration(200)
            .withEndAction { if (!drawerOpen) scrim.visibility = View.GONE }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            drawerOpen -> setDrawer(false)
            exitArmed -> { exitToast?.cancel(); super.onBackPressed() }
            else -> {
                exitArmed = true
                exitToast?.cancel()
                exitToast = Toast.makeText(this, "Bấm lần nữa để thoát", Toast.LENGTH_LONG)
                exitToast?.show()
                handler.postDelayed({ exitArmed = false; exitToast?.cancel() }, 3000)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        exitArmed = false
        accs = Store.all(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, accs.map { it.name })
    }

    private fun menu(i: Int) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Đổi tên", "Xóa")) { _, w -> if (w == 0) rename(i) else delete(i) }
            .show()
    }

    private fun rename(i: Int) {
        val input = EditText(this).apply { setText(accs[i].name) }
        AlertDialog.Builder(this).setTitle("Đổi tên").setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && accs.none { it.name == n }) {
                    accs[i].name = n
                    Store.save(this, accs)
                    onResume()
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun delete(i: Int) {
        AlertDialog.Builder(this).setTitle("Xóa ${accs[i].name}?")
            .setMessage("Dữ liệu đăng nhập của tài khoản này cũng bị xóa.")
            .setPositiveButton("Xóa") { _, _ ->
                if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                    try { ProfileStore.getInstance().deleteProfile(accs[i].profileId) } catch (_: Exception) {}
                }
                accs.removeAt(i)
                Store.save(this, accs)
                onResume()
            }.setNegativeButton("Hủy", null).show()
    }
}
