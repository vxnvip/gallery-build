package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {
    private lateinit var list: ListView
    private var accs = mutableListOf<Account>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
        }
        list = ListView(this)
        val add = Button(this).apply {
            text = "+ Thêm tài khoản"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, WebActivity::class.java).putExtra("new", true))
            }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(add, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        list.setOnItemClickListener { _, _, i, _ ->
            startActivity(
                Intent(this, WebActivity::class.java)
                    .putExtra("profile", accs[i].profileId)
                    .putExtra("title", accs[i].name)
            )
        }
        list.setOnItemLongClickListener { _, _, i, _ -> menu(i); true }
    }

    override fun onResume() {
        super.onResume()
        accs = Store.all(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, accs.map { it.name })
    }

    private fun menu(i: Int) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Đổi tên", "Xóa")) { _, w -> if (w == 0) rename(i) else delete(i) }
            .show()
    }

    private fun rename(i: Int) {
        val input = EditText(this).apply { setText(accs[i].name) }
        AlertDialog.Builder(this).setTitle("Đổi tên").setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && accs.none { it.name == n }) {
                    accs[i].name = n
                    Store.save(this, accs)
                    onResume()
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun delete(i: Int) {
        AlertDialog.Builder(this).setTitle("Xóa ${accs[i].name}?")
            .setMessage("Dữ liệu đăng nhập của tài khoản này cũng bị xóa.")
            .setPositiveButton("Xóa") { _, _ ->
                if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                    try { ProfileStore.getInstance().deleteProfile(accs[i].profileId) } catch (_: Exception) {}
                }
                accs.removeAt(i)
                Store.save(this, accs)
                onResume()
            }.setNegativeButton("Hủy", null).show()
    }
}
