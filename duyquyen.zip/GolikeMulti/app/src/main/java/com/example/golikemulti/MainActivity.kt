package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {
    private lateinit var list: ListView
    private lateinit var scrim: View
    private lateinit var drawer: LinearLayout
    private var drawerW = 0
    private var drawerOpen = false
    private var accs = mutableListOf<Account>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        drawerW = (resources.displayMetrics.widthPixels * 0.7f).toInt()

        list = ListView(this)
        val add = Button(this).apply {
            text = "+ Thêm tài khoản"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, WebActivity::class.java).putExtra("new", true))
            }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 0, 32, 32)
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(add, LinearLayout.LayoutParams(-1, -2))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(topBar("☰", "Golike Multi") { setDrawer(true) }, LinearLayout.LayoutParams(-1, -2))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        scrim = View(this).apply {
            setBackgroundColor(0x66000000)
            alpha = 0f
            visibility = View.GONE
            setOnClickListener { setDrawer(false) }
        }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(0, 96, 0, 0)
            translationX = -drawerW.toFloat()
            elevation = 16f
            addView(TextView(this@MainActivity).apply {
                text = "⚙  Setting"
                textSize = 18f
                setPadding(48, 36, 48, 36)
                pressable(this)
                setOnClickListener {
                    setDrawer(false)
                    startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        val root = FrameLayout(this).apply {
            addView(page, FrameLayout.LayoutParams(-1, -1))
            addView(scrim, FrameLayout.LayoutParams(-1, -1))
            addView(drawer, FrameLayout.LayoutParams(drawerW, -1))
        }
        setContentView(root)

        list.setOnItemClickListener { _, _, i, _ ->
            startActivity(
                Intent(this, WebActivity::class.java)
                    .putExtra("profile", accs[i].profileId)
                    .putExtra("title", accs[i].name)
            )
        }
        list.setOnItemLongClickListener { _, _, i, _ -> menu(i); true }
    }

    private fun setDrawer(open: Boolean) {
        drawerOpen = open
        if (open) scrim.visibility = View.VISIBLE
        scrim.animate().alpha(if (open) 1f else 0f).setDuration(200).start()
        drawer.animate().translationX(if (open) 0f else -drawerW.toFloat()).setDuration(200)
            .withEndAction { if (!drawerOpen) scrim.visibility = View.GONE }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) setDrawer(false) else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        accs = Store.all(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, accs.map { it.name })
    }

    private fun menu(i: Int) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Đổi tên", "Xóa")) { _, w -> if (w == 0) rename(i) else delete(i) }
            .show()
    }

    private fun rename(i: Int) {
        val input = EditText(this).apply { setText(accs[i].name) }
        AlertDialog.Builder(this).setTitle("Đổi tên").setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && accs.none { it.name == n }) {
                    accs[i].name = n
                    Store.save(this, accs)
                    onResume()
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun delete(i: Int) {
        AlertDialog.Builder(this).setTitle("Xóa ${accs[i].name}?")
            .setMessage("Dữ liệu đăng nhập của tài khoản này cũng bị xóa.")
            .setPositiveButton("Xóa") { _, _ ->
                if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                    try { ProfileStore.getInstance().deleteProfile(accs[i].profileId) } catch (_: Exception) {}
                }
                accs.removeAt(i)
                Store.save(this, accs)
                onResume()
            }.setNegativeButton("Hủy", null).show()
    }
}
