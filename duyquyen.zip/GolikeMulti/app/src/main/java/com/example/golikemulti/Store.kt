package com.example.golikemulti

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

data class Account(val profileId: String, var name: String)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("accs", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Account> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Account(o.getString("p"), o.getString("n"))
        }
    }

    fun save(c: Context, list: List<Account>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("p", it.profileId).put("n", it.name)) }
        sp(c).edit().putString("list", arr.toString()).apply()
    }

    fun apiServer(c: Context): String = sp(c).getString("api_server", "") ?: ""

    fun setApiServer(c: Context, v: String) {
        sp(c).edit().putString("api_server", v).apply()
    }

    /** Token cho API local (Termux gửi kèm header X-Token). Tự sinh lần đầu. */
    fun token(c: Context): String {
        sp(c).getString("token", null)?.let { return it }
        val b = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val t = b.joinToString("") { "%02x".format(it) }
        sp(c).edit().putString("token", t).apply()
        return t
    }
}
