package com.example.golikemulti

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Account(val profileId: String, var name: String)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("accs", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Account> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Account(o.getString("p"), o.getString("n"))
        }
    }

    fun save(c: Context, list: List<Account>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("p", it.profileId).put("n", it.name)) }
        sp(c).edit().putString("list", arr.toString()).apply()
    }
}
