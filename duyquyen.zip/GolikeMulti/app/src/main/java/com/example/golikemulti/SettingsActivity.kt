package com.example.golikemulti

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : Activity() {
    private lateinit var sub: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("←", "Setting") { finish() }, LinearLayout.LayoutParams(-1, -2))

        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 32)
            pressable(this)
            setOnClickListener {
                startActivity(Intent(this@SettingsActivity, ApiServerActivity::class.java))
            }
        }
        item.addView(TextView(this).apply { text = "API server"; textSize = 18f })
        sub = TextView(this).apply { textSize = 14f; setTextColor(Color.GRAY) }
        item.addView(sub)
        root.addView(item, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        sub.text = Store.apiServer(this).ifEmpty { "Chưa cài đặt" }
    }
}
