package com.example.golikemulti

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var sub: TextView
    private lateinit var apiSub: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(topBar("←", "Setting") { finish() }, LinearLayout.LayoutParams(-1, -2))

        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 32)
            pressable(this)
            setOnClickListener {
                startActivity(Intent(this@SettingsActivity, ApiServerActivity::class.java))
            }
        }
        item.addView(TextView(this).apply { text = "API server"; textSize = 18f })
        sub = TextView(this).apply { textSize = 14f; setTextColor(Color.GRAY) }
        item.addView(sub)
        root.addView(item, LinearLayout.LayoutParams(-1, -2))

        val local = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 32)
            pressable(this)
            setOnClickListener {
                val t = Store.token(this@SettingsActivity)
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("token", t))
                Toast.makeText(this@SettingsActivity, "Đã copy token", Toast.LENGTH_SHORT).show()
            }
        }
        local.addView(TextView(this).apply { text = "API local (Termux)"; textSize = 18f })
        apiSub = TextView(this).apply { textSize = 14f; setTextColor(Color.GRAY) }
        local.addView(apiSub)
        root.addView(local, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        sub.text = Store.apiServer(this).ifEmpty { "Chưa cài đặt" }
        apiSub.text = "http://127.0.0.1:${ApiService.PORT}\nToken: ${Store.token(this)}\n(chạm để copy token)"
    }
}
