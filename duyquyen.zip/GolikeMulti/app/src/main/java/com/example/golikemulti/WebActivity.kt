package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        // Same UA entered in the CRX test field.
        const val UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1"

        // UA-related JS port: parse the supplied UA, then expose the same
        // navigator-style values to page JavaScript as far as WebView allows.
        const val UA_OVERRIDE_JS = """
            (() => {
              'use strict';
              const ua = %UA_JSON%;

              const has = (s) => ua.indexOf(s) !== -1;
              const iosMatch = ua.match(/iPhone OS ([0-9_]+)/i);
              const androidMatch = ua.match(/Android ([0-9.]+)/i);
              const criosMatch = ua.match(/CriOS\/([0-9.]+)/i);
              const chromeMatch = ua.match(/Chrome\/([0-9.]+)/i);
              const safariMatch = ua.match(/Version\/([0-9.]+).*Safari\//i);

              const isIPhone = /iPhone/i.test(ua);
              const isIPad = /iPad/i.test(ua);
              const isIOS = isIPhone || isIPad || /CPU (?:iPhone )?OS /i.test(ua);
              const isAndroid = /Android/i.test(ua);
              const isMobile = /Mobile/i.test(ua) || isIPhone || isAndroid;

              let platform = 'Linux aarch64';
              let platformVersion = '';
              let model = '';
              let vendor = '';
              let architecture = '';
              let bitness = '';
              let browserName = '';
              let browserVersion = '';

              if (isIPhone) {
                platform = 'iPhone';
                platformVersion = iosMatch ? iosMatch[1].replace(/_/g, '.') : '';
                model = 'iPhone';
                vendor = 'Apple Computer, Inc.';
                browserName = 'Chrome';
                browserVersion = criosMatch ? criosMatch[1] : '';
              } else if (isIPad) {
                platform = 'iPad';
                platformVersion = iosMatch ? iosMatch[1].replace(/_/g, '.') : '';
                model = 'iPad';
                vendor = 'Apple Computer, Inc.';
                browserName = 'Chrome';
                browserVersion = criosMatch ? criosMatch[1] : '';
              } else if (isAndroid) {
                platform = 'Android';
                platformVersion = androidMatch ? androidMatch[1] : '';
                model = '';
                vendor = 'Google Inc.';
                browserName = 'Chrome';
                browserVersion = chromeMatch ? chromeMatch[1] : '';
                architecture = /arm64|aarch64/i.test(ua) ? 'arm' : '';
                bitness = architecture ? '64' : '';
              } else if (/Windows/i.test(ua)) {
                platform = 'Win32';
                vendor = '';
                browserName = 'Chrome';
                browserVersion = chromeMatch ? chromeMatch[1] : '';
              } else if (/Mac OS X/i.test(ua)) {
                platform = 'MacIntel';
                vendor = 'Google Inc.';
                browserName = 'Chrome';
                browserVersion = chromeMatch ? chromeMatch[1] : '';
              } else if (/Linux/i.test(ua)) {
                platform = 'Linux x86_64';
                vendor = 'Google Inc.';
                browserName = 'Chrome';
                browserVersion = chromeMatch ? chromeMatch[1] : '';
              }

              if (!browserVersion && safariMatch) browserVersion = safariMatch[1];
              if (!browserName) browserName = has('Safari/') ? 'Safari' : '';

              const appVersion = ua.replace(/^Mozilla\//, '');
              const product = 'Gecko';
              const productSub = '20030107';
              const userAgentDataSupportedByUA = /(?:Chrome|CriOS)\//i.test(ua);

              const brands = browserName === 'Chrome' && browserVersion
                ? [
                    { brand: 'Not_A Brand', version: '99' },
                    { brand: 'Chromium', version: browserVersion.split('.')[0] },
                    { brand: 'Google Chrome', version: browserVersion }
                  ]
                : [];

              const fullVersionList = brands.slice();
              const uaData = {
                get brands() { return brands.slice(); },
                get mobile() { return !!isMobile; },
                get platform() { return platform; },
                get platformVersion() { return platformVersion; },
                get architecture() { return architecture; },
                get bitness() { return bitness; },
                get model() { return model; },
                get uaFullVersion() { return browserVersion; },
                get fullVersionList() { return fullVersionList.slice(); },
                toJSON() {
                  return {
                    brands: brands.slice(), mobile: !!isMobile, platform,
                    platformVersion, architecture, bitness, model,
                    uaFullVersion: browserVersion, fullVersionList: fullVersionList.slice()
                  };
                },
                getHighEntropyValues(hints) {
                  return Promise.resolve((hints || []).reduce((out, hint) => {
                    switch (hint) {
                      case 'architecture': out.architecture = architecture; break;
                      case 'bitness': out.bitness = bitness; break;
                      case 'model': out.model = model; break;
                      case 'platform': out.platform = platform; break;
                      case 'platformVersion': out.platformVersion = platformVersion; break;
                      case 'uaFullVersion': out.uaFullVersion = browserVersion; break;
                      case 'fullVersionList': out.fullVersionList = fullVersionList.slice(); break;
                    }
                    return out;
                  }, { brands: brands.slice(), mobile: !!isMobile, platform }));
                }
              };

              const define = (obj, name, getter) => {
                try { Object.defineProperty(obj, name, { configurable: true, get: getter }); } catch (_) {}
              };

              // Mirror the CRX's Navigator-level override rather than waiting for onPageFinished.
              const navProto = Navigator.prototype;
              define(navProto, 'userAgent', () => ua);
              define(navProto, 'appVersion', () => appVersion);
              define(navProto, 'platform', () => platform);
              define(navProto, 'vendor', () => vendor);
              define(navProto, 'product', () => product);
              define(navProto, 'productSub', () => productSub);
              define(navProto, 'oscpu', () => iosMatch ? ('CPU iPhone OS ' + iosMatch[1]) : '');
              define(navProto, 'buildID', () => '');
              define(navProto, 'userAgentData', () => userAgentDataSupportedByUA ? uaData : undefined);
            })();
        """
    }

    private lateinit var web: WebView
    private lateinit var profile: String
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        ProfileStore.getInstance().getOrCreateProfile(profile)

        web = WebView(this)
        WebViewCompat.setProfile(web, profile)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            val js = UA_OVERRIDE_JS.replace("%UA_JSON%", org.json.JSONObject.quote(UA))
            WebViewCompat.addDocumentStartJavaScript(web, js, setOf("*"))
        }

        web.webViewClient = object : WebViewClient() {}

        val back = Button(this).apply { text = "←"; setOnClickListener { onBackPressed() } }
        val urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setSingleLine(true)
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener {
                val url = urlInput.text.toString().trim()
                if (url.isNotEmpty()) web.loadUrl(url)
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        when {
            web.canGoBack() -> web.goBack()
            isNew && !saved -> AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discard() }
                .setNegativeButton("Ở lại", null).show()
            else -> finish()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
