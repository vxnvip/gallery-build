package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        const val UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1"
    }
    private lateinit var web: WebView
    private lateinit var profile: String
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        ProfileStore.getInstance().getOrCreateProfile(profile)

        web = WebView(this)
        WebViewCompat.setProfile(web, profile) // phải gọi trước loadUrl
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA
        web.webViewClient = WebViewClient()

        val back = Button(this).apply { text = "←"; setOnClickListener { onBackPressed() } }
        val title = TextView(this).apply {
            text = if (isNew) "Thêm tài khoản" else intent.getStringExtra("title") ?: ""
            textSize = 18f
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(title, LinearLayout.LayoutParams(0, -1, 1f))
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.loadUrl("https://app.golike.net/home")
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        when {
            web.canGoBack() -> web.goBack()
            isNew && !saved -> AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discard() }
                .setNegativeButton("Ở lại", null).show()
            else -> finish()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
