package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONObject
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        const val UA = "Mozilla/5.0 (Linux; iPhone; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36"
    }
    private lateinit var web: WebView
    private lateinit var profile: String
    private lateinit var cm: CookieManager
    private var logUri: android.net.Uri? = null
    private var logFile: File? = null
    private val logLock = Any()


    // Hook fetch / XHR / sendBeacon (non-GET): đẩy qua native để không dính Sec-CH-UA*
    private val HOOK = """
(function(){
  if (window.__nbInstalled) return; window.__nbInstalled = true;
  var pend = {}, seq = 0;
  window.__nb_cb = function(id, r){ var f = pend[id]; delete pend[id]; if (f) f(r); };
  function b64ToBytes(b){ var s = atob(b || ''), u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
  function call(method, url, headers, body, cred){
    return new Promise(function(res){
      var id = 'r' + (++seq); pend[id] = res;
      var abs = new URL(url, location.href).href;
      NB.send(id, JSON.stringify({method: method, url: abs, headers: headers, body: body, cred: cred, origin: location.origin, referer: location.href}));
    });
  }
  function ok(m, u){
    m = (m || 'GET').toUpperCase(); if (m === 'GET' || m === 'HEAD') return false;
    try { var p = new URL(u, location.href).protocol; return p === 'http:' || p === 'https:'; } catch(e) { return false; }
  }
  var of = window.fetch;
  window.fetch = function(input, init){
    try {
      var isReq = (typeof input !== 'string') && !(input instanceof URL);
      var url = String(input);
      var method = (init && init.method) || 'GET';
      var body = init ? init.body : null;
      if (!isReq && ok(method, url) && (body == null || typeof body === 'string')) {
        var h = {}; new Headers((init && init.headers) || {}).forEach(function(v, k){ h[k] = v; });
        var c = init && init.credentials;
        var cred = c === 'include' || (c !== 'omit' && new URL(url, location.href).origin === location.origin);
        return call(method.toUpperCase(), url, h, body == null ? null : body, cred).then(function(r){
          if (r.err) return Promise.reject(new TypeError('Failed to fetch'));
          var nb = r.status === 204 || r.status === 205 || r.status === 304;
          var resp = new Response(nb ? null : b64ToBytes(r.body), {status: r.status, statusText: r.statusText || '', headers: r.headers});
          try { Object.defineProperty(resp, 'url', {value: r.url}); } catch(e) {}
          return resp;
        });
      }
    } catch(e) {}
    return of.apply(this, arguments);
  };
  var X = XMLHttpRequest.prototype, oOpen = X.open, oSet = X.setRequestHeader, oSend = X.send;
  X.open = function(m, u){ this.__m = m; this.__u = String(u); this.__h = {}; this.__async = (arguments.length < 3 || arguments[2] !== false); return oOpen.apply(this, arguments); };
  X.setRequestHeader = function(k, v){ if (this.__h) this.__h[k] = v; return oSet.apply(this, arguments); };
  X.send = function(body){
    var self = this;
    var rt = self.responseType;
    if (ok(self.__m, self.__u) && self.__async && (body == null || typeof body === 'string') && (!rt || rt === 'text' || rt === 'json')) {
      var cred = self.withCredentials || new URL(self.__u, location.href).origin === location.origin;
      call(String(self.__m).toUpperCase(), self.__u, self.__h, body == null ? null : body, cred).then(function(r){
        function fire(n){ try { self.dispatchEvent(new Event(n)); } catch(e) {} }
        var text = '';
        if (!r.err) { try { text = new TextDecoder('utf-8').decode(b64ToBytes(r.body)); } catch(e) {} }
        var resp = text;
        if (rt === 'json') { try { resp = JSON.parse(text); } catch(e) { resp = null; } }
        var hs = r.headers || {};
        var lower = {}; Object.keys(hs).forEach(function(k){ lower[k.toLowerCase()] = hs[k]; });
        Object.defineProperties(self, {
          readyState: {value: 4, configurable: true},
          status: {value: r.err ? 0 : r.status, configurable: true},
          statusText: {value: r.statusText || '', configurable: true},
          responseText: {value: text, configurable: true},
          response: {value: resp, configurable: true},
          responseURL: {value: r.url || self.__u, configurable: true},
          getResponseHeader: {value: function(k){ var v = lower[String(k).toLowerCase()]; return v === undefined ? null : v; }, configurable: true},
          getAllResponseHeaders: {value: function(){ return Object.keys(hs).map(function(k){ return k + ': ' + hs[k]; }).join('\r\n'); }, configurable: true}
        });
        fire('readystatechange');
        fire(r.err ? 'error' : 'load');
        fire('loadend');
      });
      return;
    }
    return oSend.apply(this, arguments);
  };
  var ob = navigator.sendBeacon ? navigator.sendBeacon.bind(navigator) : null;
  navigator.sendBeacon = function(u, d){
    if (ok('POST', u) && (d == null || typeof d === 'string')) { call('POST', u, {'content-type': 'text/plain;charset=UTF-8'}, d == null ? null : d, true); return true; }
    return ob ? ob(u, d) : false;
  };
})();
"""

    inner class Bridge {
        @JavascriptInterface
        fun send(id: String, json: String) {
            Thread {
                val res = JSONObject()
                try {
                    val o = JSONObject(json)
                    val url = o.getString("url")
                    val cred = o.optBoolean("cred", false)
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = o.getString("method")
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = true
                    val hs = o.getJSONObject("headers")
                    hs.keys().forEach { k ->
                        if (!k.startsWith("sec-ch-ua", true) &&
                            !k.equals("user-agent", true) &&
                            !k.equals("cookie", true) &&
                            !k.equals("accept-encoding", true) &&
                            !k.equals("origin", true) &&
                            !k.equals("referer", true)) c.setRequestProperty(k, hs.getString(k))
                    }
                    c.setRequestProperty("User-Agent", UA)
                    c.setRequestProperty("Origin", o.getString("origin"))
                    c.setRequestProperty("Referer", o.getString("referer"))
                    if (cred) cm.getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                    if (!o.isNull("body")) {
                        c.doOutput = true
                        c.outputStream.use { it.write(o.getString("body").toByteArray(Charsets.UTF_8)) }
                    }
                    log("BRIDGE ${o.getString("method")} $url\n    Header app gửi đi:\n${fmt(c.requestProperties)}")
                    val code = c.responseCode
                    if (cred) c.headerFields["Set-Cookie"]?.forEach { cm.setCookie(url, it) }
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
                    val rh = JSONObject()
                    c.headerFields.forEach { (k, v) ->
                        if (k != null && !k.equals("Set-Cookie", true) &&
                            !k.equals("Content-Encoding", true) &&
                            !k.equals("Content-Length", true) &&
                            !k.equals("Transfer-Encoding", true)) rh.put(k, v.joinToString(", "))
                    }
                    res.put("status", code)
                    res.put("statusText", c.responseMessage ?: "")
                    res.put("url", c.url.toString())
                    res.put("headers", rh)
                    res.put("body", Base64.encodeToString(bytes, Base64.NO_WRAP))
                    log("    => bridge status $code")
                } catch (e: Exception) {
                    res.put("err", true)
                    log("    => LỖI bridge: $e")
                }
                runOnUiThread {
                    if (!destroyed) web.evaluateJavascript("window.__nb_cb(\"$id\", $res)", null)
                }
            }.start()
        }
    }

    private fun openLog() {
        val name = "golike_requests_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                logUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                logFile = File(dir, name)
            }
            Toast.makeText(this, "Log: Download/$name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Không tạo được file log: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun log(msg: String) {
        val line = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date()) + " " + msg + "\n"
        synchronized(logLock) {
            try {
                logUri?.let { u -> contentResolver.openOutputStream(u, "wa")?.use { it.write(line.toByteArray()) } }
                logFile?.appendText(line)
            } catch (_: Exception) {}
        }
    }

    private fun fmt(h: Map<String, Any?>) = h.entries.joinToString("\n") { "      ${it.key}: ${it.value}" }
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        openLog()
        cm = ProfileStore.getInstance().getOrCreateProfile(profile).cookieManager

        web = WebView(this)
        WebViewCompat.setProfile(web, profile) 
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA
        web.addJavascriptInterface(Bridge(), "NB")
        val hookNative = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (hookNative) WebViewCompat.addDocumentStartJavaScript(web, HOOK, setOf("*"))
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (!hookNative) view?.evaluateJavascript(HOOK, null)
            }
            // Tự gửi request để loại bỏ hoàn toàn header Sec-CH-UA*
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val url = req.url.toString()
                log("${req.method} ${if (req.isForMainFrame) "[MAIN] " else ""}$url\n    WebView headers:\n${fmt(req.requestHeaders)}")
                if (req.method != "GET" || !url.startsWith("http")) {
                    log("    => KHÔNG proxy (không phải GET) - WebView tự gửi, header thực tế có thể khác")
                    return null
                }
                return try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "GET"
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = !req.isForMainFrame
                    req.requestHeaders.forEach { (k, v) ->
                        if (!k.startsWith("Sec-CH-UA", true) &&
                            !k.equals("Accept-Encoding", true) &&
                            !k.equals("User-Agent", true) &&
                            !k.equals("Cookie", true)) c.setRequestProperty(k, v)
                    }
                    c.setRequestProperty("User-Agent", UA)
                    cm.getCookie(url)?.let { c.setRequestProperty("Cookie", it) }

                    log("    Header app gửi đi:\n${fmt(c.requestProperties)}")
                    val code = c.responseCode
                    log("    => proxy, status $code")
                    c.headerFields["Set-Cookie"]?.forEach { cm.setCookie(url, it) }
                    // redirect trang chính: để WebView tự xử lý để URL đổi đúng
                    if (code in 300..399) { log("    => redirect, trả cho WebView tự xử lý"); c.disconnect(); return null }

                    val ct = c.contentType ?: "text/html"
                    val mime = ct.substringBefore(';').trim()
                    val enc = Regex("charset=([^;]+)", RegexOption.IGNORE_CASE)
                        .find(ct)?.groupValues?.get(1)?.trim()
                    val hdr = mutableMapOf<String, String>()
                    c.headerFields.forEach { (k, v) ->
                        if (k != null && !k.equals("Set-Cookie", true) &&
                            !k.equals("Content-Encoding", true) &&
                            !k.equals("Content-Length", true) &&
                            !k.equals("Transfer-Encoding", true)) hdr[k] = v.joinToString(",")
                    }
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    WebResourceResponse(mime, enc, code,
                        c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK", hdr, stream)
                } catch (e: Exception) { log("    => LỖI proxy: $e"); null }
            }
        }

        val back = Button(this).apply { text = "←"; setOnClickListener { onBackPressed() } }
        val urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setText("https://app.golike.net/home")
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener { web.loadUrl(urlInput.text.toString()) }
        }
        
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.loadUrl("https://app.golike.net/home")
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        when {
            web.canGoBack() -> web.goBack()
            isNew && !saved -> AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discard() }
                .setNegativeButton("Ở lại", null).show()
            else -> finish()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
