package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        const val UA = "Mozilla/5.0 (Linux; iPhone; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36"
    }
    private lateinit var web: WebView
    private lateinit var profile: String
    private lateinit var cm: CookieManager
    private var logUri: android.net.Uri? = null
    private var logFile: File? = null
    private val logLock = Any()

    private fun openLog() {
        val name = "golike_requests_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                logUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                logFile = File(dir, name)
            }
            Toast.makeText(this, "Log: Download/$name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Không tạo được file log: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun log(msg: String) {
        val line = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date()) + " " + msg + "\n"
        synchronized(logLock) {
            try {
                logUri?.let { u -> contentResolver.openOutputStream(u, "wa")?.use { it.write(line.toByteArray()) } }
                logFile?.appendText(line)
            } catch (_: Exception) {}
        }
    }

    private fun fmt(h: Map<String, Any?>) = h.entries.joinToString("\n") { "      ${it.key}: ${it.value}" }
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        openLog()
        cm = ProfileStore.getInstance().getOrCreateProfile(profile).cookieManager

        web = WebView(this)
        WebViewCompat.setProfile(web, profile) 
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA
        web.webViewClient = object : WebViewClient() {
            // Tự gửi request để loại bỏ hoàn toàn header Sec-CH-UA*
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val url = req.url.toString()
                log("${req.method} ${if (req.isForMainFrame) "[MAIN] " else ""}$url\n    WebView headers:\n${fmt(req.requestHeaders)}")
                if (req.method != "GET" || !url.startsWith("http")) {
                    log("    => KHÔNG proxy (không phải GET) - WebView tự gửi, header thực tế có thể khác")
                    return null
                }
                return try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "GET"
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = !req.isForMainFrame
                    req.requestHeaders.forEach { (k, v) ->
                        if (k.equals("sec-ch-ua-platform", true)) {
                            c.setRequestProperty(k, "\"iOS\"")
                        } else if (
                            !k.equals("Accept-Encoding", true) &&
                            !k.equals("User-Agent", true) &&
                            !k.equals("Cookie", true)) c.setRequestProperty(k, v)
                    }
                    c.setRequestProperty("User-Agent", UA)
                    cm.getCookie(url)?.let { c.setRequestProperty("Cookie", it) }

                    log("    Header app gửi đi:\n${fmt(c.requestProperties)}")
                    val code = c.responseCode
                    log("    => proxy, status $code")
                    c.headerFields["Set-Cookie"]?.forEach { cm.setCookie(url, it) }
                    // redirect trang chính: để WebView tự xử lý để URL đổi đúng
                    if (code in 300..399) { log("    => redirect, trả cho WebView tự xử lý"); c.disconnect(); return null }

                    val ct = c.contentType ?: "text/html"
                    val mime = ct.substringBefore(';').trim()
                    val enc = Regex("charset=([^;]+)", RegexOption.IGNORE_CASE)
                        .find(ct)?.groupValues?.get(1)?.trim()
                    val hdr = mutableMapOf<String, String>()
                    c.headerFields.forEach { (k, v) ->
                        if (k != null && !k.equals("Set-Cookie", true) &&
                            !k.equals("Content-Encoding", true) &&
                            !k.equals("Content-Length", true) &&
                            !k.equals("Transfer-Encoding", true)) hdr[k] = v.joinToString(",")
                    }
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    WebResourceResponse(mime, enc, code,
                        c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK", hdr, stream)
                } catch (e: Exception) { log("    => LỖI proxy: $e"); null }
            }
        }

        val back = Button(this).apply { text = "←"; setOnClickListener { onBackPressed() } }
        val urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setText("https://app.golike.net/home")
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener { web.loadUrl(urlInput.text.toString()) }
        }
        
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.loadUrl("https://app.golike.net/home")
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        when {
            web.canGoBack() -> web.goBack()
            isNew && !saved -> AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discard() }
                .setNegativeButton("Ở lại", null).show()
            else -> finish()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
