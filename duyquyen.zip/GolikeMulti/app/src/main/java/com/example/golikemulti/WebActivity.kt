package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        // Same UA input the test profile is based on.
        const val UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1"
    }

    private lateinit var web: WebView
    private lateinit var profile: String
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }

        isNew = intent.getBooleanExtra("new", false)
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        ProfileStore.getInstance().getOrCreateProfile(profile)

        web = WebView(this)
        WebViewCompat.setProfile(web, profile)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true

        // CRX's network layer changes the actual WebView UA through the
        // browser UA setting. JS values are handled separately below.
        web.settings.userAgentString = UA

        installCrxStyleNavigatorOverride(web, UA)

        web.webViewClient = object : WebViewClient() {
            // Deliberately do not try to mutate request.requestHeaders here.
            // Android exposes a copy; changing it does not resend the request.
            // The real HTTP UA is supplied by WebSettings.userAgentString.
        }

        val back = Button(this).apply {
            text = "←"
            setOnClickListener { onBackPressed() }
        }
        val urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setText("")
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener {
                val url = urlInput.text.toString().trim()
                if (url.isNotEmpty()) web.loadUrl(url)
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    /**
     * Equivalent Android-WebView implementation of the CRX's UA -> navigator
     * mapping. It intentionally follows the CRX's important decisions:
     * - appVersion is UA with the leading Mozilla/ removed
     * - iOS maps navigator.platform to the device model (iPhone/iPad/iPod)
     * - Safari (including CriOS strings that also contain Safari) is treated as
     *   Apple/Safari by the CRX's /Chrome/ test
     * - Safari/Firefox gets no Chromium userAgentData object
     * - accessors are installed on Navigator.prototype at document start
     * - values that the CRX marks [delete] are removed where WebView permits
     *
     * This is an implementation of the CRX behavior, not a copy of its source.
     */
    private fun installCrxStyleNavigatorOverride(view: WebView, ua: String) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return

        val jsUa = org.json.JSONObject.quote(ua)
        val script = """
            (() => {
                'use strict';
                try {
                    const s = $jsUa;
                    const isFF = /Firefox/.test(s);
                    const isCH = /Chrome/.test(s);
                    const isSF = /Safari/.test(s) && !isCH;

                    // Minimal UA parsing equivalent for the fields Agent.parse()
                    // uses for the supplied UA families.
                    let osName = '';
                    let osVersion = '';
                    let deviceModel = '';
                    let deviceVendor = '';
                    let engineName = '';

                    let m = s.match(/OS (\d+(?:[._]\d+)*) like Mac OS X/i);
                    if (m) {
                        osName = 'iOS';
                        osVersion = m[1].replace(/_/g, '.');
                        if (/iPad/i.test(s)) deviceModel = 'iPad';
                        else if (/iPod/i.test(s)) deviceModel = 'iPod';
                        else deviceModel = 'iPhone';
                        deviceVendor = 'Apple';
                    } else if (m = s.match(/Android (\d+(?:\.\d+)*)/i)) {
                        osName = 'Android';
                        osVersion = m[1];
                        const d = s.match(/Android[^;)]*;\s*([^;)]+)/i);
                        deviceModel = d ? d[1].replace(/\s+Build\b.*/i, '').trim() : '';
                    } else if (/Windows/i.test(s)) {
                        osName = 'Windows';
                    } else if (/Mac OS X|Macintosh/i.test(s)) {
                        osName = 'Mac OS';
                    } else if (/Linux/i.test(s)) {
                        osName = 'Linux';
                    }

                    if (/AppleWebKit/i.test(s)) engineName = 'WebKit';
                    else if (/Gecko/i.test(s)) engineName = 'Gecko';

                    const platform =
                        osName === 'Mac OS' ? 'MacIntel' :
                        osName === 'Windows' ? 'Win32' :
                        osName === 'Linux' ? (s.match(/(aarch64|armv\d+|x86_64|x86)/i)?.[1] ? 'Linux ' + s.match(/(aarch64|armv\d+|x86_64|x86)/i)[1] : '') :
                        osName === 'Android' ? 'Linux armv81' :
                        osName === 'iOS' ? deviceModel :
                        osName;

                    const vendor = isSF ? 'Apple Computer, Inc.' : (isFF ? deviceVendor : 'Google Inc.');
                    const appVersion = s.replace(/^Mozilla\//, '').replace(/^Opera\//, '');
                    const product = s.indexOf('Gecko') !== -1 ? 'Gecko' : engineName;
                    const productSub = isFF ? '20100101' : '20030107';
                    const oscpu = isFF ? (osName + ' ' + osVersion).trim() : null;
                    const buildID = isFF ? '20181001000000' : null;

                    const nativeGetter = (key, get) => {
                        const obj = {};
                        obj[key] = function() { return get(this); };
                        const getter = obj[key];
                        try { Object.defineProperty(getter, 'name', {value: 'get ' + key, configurable: true}); } catch(e) {}
                        getter.toString = () => 'function get ' + key + '() { [native code] }';
                        return getter;
                    };
                    const define = (nav, key, get) => {
                        const getter = nativeGetter(key, get);
                        const proto = Object.getPrototypeOf(nav);
                        try { proto.__defineGetter__(key, getter); }
                        catch(e) { try { nav.__defineGetter__(key, getter); } catch(e2) {} }
                    };

                    const nav = navigator;
                    define(nav, 'userAgent', () => s);
                    define(nav, 'appVersion', () => appVersion);
                    define(nav, 'platform', () => platform);
                    define(nav, 'vendor', () => vendor);
                    define(nav, 'product', () => product);
                    define(nav, 'productSub', () => productSub);

                    // CRX sets these to [delete] for non-Firefox UAs.
                    if (!isFF) {
                        try { delete Object.getPrototypeOf(nav).oscpu; } catch(e) {}
                        try { delete Object.getPrototypeOf(nav).buildID; } catch(e) {}
                    } else {
                        define(nav, 'oscpu', () => oscpu);
                        define(nav, 'buildID', () => buildID);
                    }

                    // Agent.parse() only builds userAgentData for UAs containing
                    // the literal Chrome/<major> token. CriOS does not match that
                    // test, so the supplied iPhone CriOS UA intentionally has no
                    // spoofed userAgentData, matching the CRX.
                    if (!(/Chrome\/\d+/.test(s))) {
                        try { delete Object.getPrototypeOf(nav).userAgentData; } catch(e) {}
                    }
                } catch (e) {
                    console.error('UA_SET_FAILED', e);
                }
            })();
        """.trimIndent()

        WebViewCompat.addDocumentStartJavaScript(view, script, setOf("*"))
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        when {
            web.canGoBack() -> web.goBack()
            isNew && !saved -> AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discard() }
                .setNegativeButton("Ở lại", null).show()
            else -> finish()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
