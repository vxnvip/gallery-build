package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        const val UA = "Mozilla/5.0 (Linux; iPhone; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36"
    }
    private lateinit var web: WebView
    private lateinit var profile: String
    private lateinit var cm: CookieManager
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        cm = ProfileStore.getInstance().getOrCreateProfile(profile).cookieManager

        web = WebView(this)
        WebViewCompat.setProfile(web, profile) 
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA
        // Đặt chung với UA: sec-ch-ua-platform = "iOS" cho MỌI request (kể cả POST)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
            try {
                fun bv(b: String, v: String) = UserAgentMetadata.BrandVersion.Builder()
                    .setBrand(b).setMajorVersion(v).setFullVersion("$v.0.0.0").build()
                val md = UserAgentMetadata.Builder()
                    .setBrandVersionList(listOf(bv("Android WebView", "153"), bv("Not_A Brand", "8"), bv("Chromium", "153")))
                    .setFullVersion("153.0.0.0")
                    .setPlatform("iOS")
                    .setMobile(true)
                    .build()
                WebSettingsCompat.setUserAgentMetadata(web.settings, md)
            } catch (e: Throwable) {
                Toast.makeText(this, "Không set được UA metadata: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "WebView không hỗ trợ USER_AGENT_METADATA", Toast.LENGTH_LONG).show()
        }
        web.webViewClient = object : WebViewClient() {
            // Tự gửi request GET để đổi sec-ch-ua-platform thành "iOS"
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val url = req.url.toString()
                if (req.method != "GET" || !url.startsWith("http")) return null
                return try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "GET"
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = !req.isForMainFrame
                    req.requestHeaders.forEach { (k, v) ->
                        if (k.equals("sec-ch-ua-platform", true)) {
                            c.setRequestProperty(k, "\"iOS\"")
                        } else if (
                            !k.equals("Accept-Encoding", true) &&
                            !k.equals("User-Agent", true) &&
                            !k.equals("Cookie", true)) c.setRequestProperty(k, v)
                    }
                    c.setRequestProperty("User-Agent", UA)
                    cm.getCookie(url)?.let { c.setRequestProperty("Cookie", it) }

                    val code = c.responseCode
                    c.headerFields["Set-Cookie"]?.forEach { cm.setCookie(url, it) }
                    // redirect trang chính: để WebView tự xử lý để URL đổi đúng
                    if (code in 300..399) { c.disconnect(); return null }

                    val ct = c.contentType ?: "text/html"
                    val mime = ct.substringBefore(';').trim()
                    val enc = Regex("charset=([^;]+)", RegexOption.IGNORE_CASE)
                        .find(ct)?.groupValues?.get(1)?.trim()
                    val hdr = mutableMapOf<String, String>()
                    c.headerFields.forEach { (k, v) ->
                        if (k != null && !k.equals("Set-Cookie", true) &&
                            !k.equals("Content-Encoding", true) &&
                            !k.equals("Content-Length", true) &&
                            !k.equals("Transfer-Encoding", true)) hdr[k] = v.joinToString(",")
                    }
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    WebResourceResponse(mime, enc, code,
                        c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK", hdr, stream)
                } catch (e: Exception) { null }
            }
        }

        val back = Button(this).apply { text = "←"; setOnClickListener { onBackPressed() } }
        val urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setText("https://app.golike.net/home")
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener { web.loadUrl(urlInput.text.toString()) }
        }
        
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.loadUrl("https://app.golike.net/home")
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        when {
            web.canGoBack() -> web.goBack()
            isNew && !saved -> AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discard() }
                .setNegativeButton("Ở lại", null).show()
            else -> finish()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
