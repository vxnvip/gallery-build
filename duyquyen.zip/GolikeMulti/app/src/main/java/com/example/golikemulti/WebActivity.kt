package com.example.golikemulti

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        // UA nhập trong ô test của CRX.
        const val UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1"

        // Danh sách "protected" mặc định của CRX: URL khớp thì giữ UA/navigator thật.
        val PROTECTED = listOf(
            "google.com/recaptcha",
            "gstatic.com/recaptcha",
            "accounts.google.com",
            "accounts.youtube.com",
            "gitlab.com/users/sign_in"
        )

        /**
         * Kết quả đúng của Agent.parse(UA) trong CRX (agent.js, đã chạy thật bằng
         * ua-parser của CRX). UA là CriOS (iOS) -> không khớp /Chrome\/\d+/ nên
         * KHÔNG có userAgentDataBuilder: userAgentData bị xóa khỏi Navigator.prototype,
         * không giả brands. Thứ tự key giữ nguyên như CRX.
         */
        fun uaPrefs(): JSONObject = JSONObject().apply {
            put("userAgent", UA)
            put("appVersion", UA.removePrefix("Mozilla/"))   // "5.0 (iPhone; ..."
            put("platform", "iPhone")                        // p.device.model
            put("vendor", "Apple Computer, Inc.")            // isSF
            put("product", "Gecko")                          // UA có "Gecko"
            put("userAgentData", "[delete]")
            put("oscpu", "[delete]")
            put("buildID", "[delete]")
            put("productSub", "20030107")
            put("protected", JSONArray(PROTECTED))
        }

        private val PROTECTED_REGEX = Regex(PROTECTED.joinToString("|") { Regex.escape(it) })
        fun isProtected(url: String?) = url != null && PROTECTED_REGEX.containsMatchIn(url)
    }

    private lateinit var web: WebView
    private lateinit var profile: String
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        ProfileStore.getInstance().getOrCreateProfile(profile)

        web = WebView(this)
        WebViewCompat.setProfile(web, profile)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            val js = assets.open("ua_override.js").bufferedReader().use { it.readText() }
                .replace("__PREFS__", uaPrefs().toString())
            WebViewCompat.addDocumentStartJavaScript(web, js, setOf("*"))
        }

        // Tầng network của CRX: URL protected -> giữ header thật, còn lại set UA.
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                applyUa(r.url.toString())
                return false
            }
        }

        val back = Button(this).apply { text = "←"; setOnClickListener { onBackPressed() } }
        val urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setSingleLine(true)
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener {
                val url = urlInput.text.toString().trim()
                if (url.isNotEmpty()) { applyUa(url); web.loadUrl(url) }
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun applyUa(url: String?) {
        // null = UA mặc định của WebView (header thật)
        web.settings.userAgentString = if (isProtected(url)) null else UA
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        when {
            web.canGoBack() -> web.goBack()
            isNew && !saved -> AlertDialog.Builder(this)
                .setTitle("Bỏ tài khoản này?")
                .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
                .setPositiveButton("Bỏ") { _, _ -> discard() }
                .setNegativeButton("Ở lại", null).show()
            else -> finish()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
