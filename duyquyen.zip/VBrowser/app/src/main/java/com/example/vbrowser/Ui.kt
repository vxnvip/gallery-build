package com.example.vbrowser

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.util.TypedValue
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

fun Activity.topBar(icon: String, title: String, onIcon: () -> Unit) = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
    setPadding(8, 72, 8, 8)
    addView(Button(this@topBar).apply {
        text = icon; textSize = 20f
        setOnClickListener { onIcon() }
    }, LinearLayout.LayoutParams(-2, -2))
    addView(TextView(this@topBar).apply {
        text = title; textSize = 20f
        setPadding(24, 0, 0, 0)
    }, LinearLayout.LayoutParams(0, -2, 1f))
}

fun pressable(v: View) {
    val tv = TypedValue()
    v.context.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
    v.setBackgroundResource(tv.resourceId)
    v.isClickable = true
}
