package com.example.vbrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Account(val profileId: String, var name: String)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("accs", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Account> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Account(o.getString("p"), o.getString("n"))
        }
    }

    fun save(c: Context, list: List<Account>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("p", it.profileId).put("n", it.name)) }
        sp(c).edit().putString("list", arr.toString()).apply()
    }

    fun apiServer(c: Context): String = sp(c).getString("api_server", "") ?: ""

    fun setApiServer(c: Context, v: String) {
        sp(c).edit().putString("api_server", v).apply()
    }

    fun setSession(c: Context, profile: String, title: String, url: String, isNew: Boolean) {
        sp(c).edit().putString("session", JSONObject()
            .put("p", profile).put("t", title).put("u", url).put("n", isNew).toString()).apply()
    }

    fun session(c: Context): JSONObject? =
        sp(c).getString("session", null)?.let { try { JSONObject(it) } catch (_: Exception) { null } }

    fun clearSession(c: Context) { sp(c).edit().remove("session").apply() }
}
