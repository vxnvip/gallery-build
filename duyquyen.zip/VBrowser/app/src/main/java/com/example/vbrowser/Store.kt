package com.example.vbrowser

import android.content.Context

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("accs", Context.MODE_PRIVATE)

    fun apiServer(c: Context): String = sp(c).getString("api_server", "") ?: ""

    fun setApiServer(c: Context, v: String) {
        sp(c).edit().putString("api_server", v).apply()
    }
}
