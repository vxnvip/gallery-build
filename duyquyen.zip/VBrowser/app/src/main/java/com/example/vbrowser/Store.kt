package com.example.vbrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Account(val profileId: String, var name: String)
data class Session(val profile: String, val title: String, val url: String, val isNew: Boolean)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("accs", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Account> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Account(o.getString("p"), o.getString("n"))
        }
    }

    fun save(c: Context, list: List<Account>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("p", it.profileId).put("n", it.name)) }
        sp(c).edit().putString("list", arr.toString()).apply()
    }

    fun apiServer(c: Context): String = sp(c).getString("api_server", "") ?: ""

    fun setApiServer(c: Context, v: String) {
        sp(c).edit().putString("api_server", v).apply()
    }

    // ---- Phiên đang mở (để mở lại app vẫn ở đúng trang) ----
    fun session(c: Context): Session? {
        val p = sp(c)
        val prof = p.getString("s_profile", null) ?: return null
        val url = p.getString("s_url", null) ?: return null
        return Session(prof, p.getString("s_title", "") ?: "", url, p.getBoolean("s_new", false))
    }

    fun saveSession(c: Context, profile: String, title: String, url: String, isNew: Boolean, sync: Boolean = false) {
        val e = sp(c).edit()
            .putString("s_profile", profile).putString("s_title", title)
            .putString("s_url", url).putBoolean("s_new", isNew)
        if (sync) e.commit() else e.apply()
    }

    fun clearSession(c: Context) {
        sp(c).edit().remove("s_profile").remove("s_title").remove("s_url").remove("s_new").commit()
    }
}
