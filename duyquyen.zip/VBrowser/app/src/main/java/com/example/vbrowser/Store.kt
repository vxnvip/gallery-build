package com.example.vbrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Account(val profileId: String, var name: String)

data class Session(val profile: String, val url: String, val title: String?, val isNew: Boolean)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("accs", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Account> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Account(o.getString("p"), o.getString("n"))
        }
    }

    fun save(c: Context, list: List<Account>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("p", it.profileId).put("n", it.name)) }
        sp(c).edit().putString("list", arr.toString()).apply()
    }

    fun apiServer(c: Context): String = sp(c).getString("api_server", "") ?: ""

    fun setApiServer(c: Context, v: String) {
        sp(c).edit().putString("api_server", v).apply()
    }

    // ---- Phiên đang mở: để mở lại app vẫn ở đúng trang (kể cả khi tắt đa nhiệm / buộc dừng)
    fun saveSession(c: Context, profile: String, url: String, title: String?, isNew: Boolean) {
        sp(c).edit()
            .putString("s_profile", profile)
            .putString("s_url", url)
            .putString("s_title", title)
            .putBoolean("s_new", isNew)
            .apply()
    }

    fun updateSessionUrl(c: Context, url: String) {
        if (sp(c).getString("s_profile", null) == null) return
        if (!url.startsWith("http")) return
        sp(c).edit().putString("s_url", url).apply()
    }

    fun session(c: Context): Session? {
        val p = sp(c).getString("s_profile", null) ?: return null
        val u = sp(c).getString("s_url", null) ?: return null
        return Session(p, u, sp(c).getString("s_title", null), sp(c).getBoolean("s_new", false))
    }

    fun clearSession(c: Context) {
        sp(c).edit().remove("s_profile").remove("s_url").remove("s_title").remove("s_new").apply()
    }
}
