package com.example.vbrowser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import java.util.UUID

class WebActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var profile: String
    private lateinit var cm: CookieManager
    private lateinit var urlInput: EditText
    private var isNew = false
    private var saved = false
    private var destroyed = false
    private var leaving = false      // true khi người dùng chủ động thoát (←, lưu, bỏ) -> không lưu phiên nữa
    private var title = ""
    private var currentUrl = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        title = intent.getStringExtra("title") ?: ""
        profile = intent.getStringExtra("profile") ?: b?.getString("profile")
            ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        val intentUrl = intent.getStringExtra("url") ?: "https://app.golike.net/home"
        // Khôi phục: mở lại app sau khi bị kill, hoặc hệ thống tạo lại activity -> dùng URL đã lưu
        val sess = Store.session(this)
        val restoring = b != null || intent.getBooleanExtra("restore", false)
        val startUrl = if (restoring && sess != null && sess.profile == profile) sess.url else intentUrl
        currentUrl = startUrl
        cm = ProfileStore.getInstance().getOrCreateProfile(profile).cookieManager

        web = WebView(this)
        WebViewCompat.setProfile(web, profile) 
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            // Link mà app khác hỗ trợ (fb://, intent://, zalo://, tel:, ... hoặc link https có app xử lý) -> mở app
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                val isWeb = url.startsWith("http://") || url.startsWith("https://")
                return if (isWeb) openInApp(url, req) else openScheme(view, url)
            }
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (url != null && !leaving) {
                    currentUrl = url
                    Store.saveSession(this@WebActivity, profile, title, url, isNew)
                }
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (url != null && ::urlInput.isInitialized && !urlInput.hasFocus()) urlInput.setText(url)
            }
        }

        val back = Button(this).apply { text = "←"; setOnClickListener { goHome() } }
        urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            setSingleLine()
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> web.loadUrl(normalizeUrl(text.toString())); clearFocus(); true }
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setText(startUrl)
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener { web.loadUrl(normalizeUrl(urlInput.text.toString())) }
        }
        
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.loadUrl(startUrl)
    }

    // Link https: chỉ mở app khi người dùng bấm vào link và có app (không phải trình duyệt) nhận link đó
    private fun openInApp(url: String, req: WebResourceRequest): Boolean {
        if (android.os.Build.VERSION.SDK_INT < 30) return false
        if (!req.isForMainFrame || !req.hasGesture()) return false
        val host = req.url.host ?: return false
        if (host == "golike.net" || host.endsWith(".golike.net")) return false
        return try {
            val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                .addCategory(android.content.Intent.CATEGORY_BROWSABLE)
                .addFlags(android.content.Intent.FLAG_ACTIVITY_REQUIRE_NON_BROWSER)
            startActivity(i)
            true
        } catch (e: Exception) { false }
    }

    // Link scheme khác (intent://, fb://, tel:, mailto:, market:, ...)
    private fun openScheme(view: WebView, url: String): Boolean {
        return try {
            val i = if (url.startsWith("intent:"))
                android.content.Intent.parseUri(url, android.content.Intent.URI_INTENT_SCHEME)
            else android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            i.addCategory(android.content.Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            try {
                startActivity(i)
            } catch (e: android.content.ActivityNotFoundException) {
                val fb = i.getStringExtra("browser_fallback_url")
                val pkg = i.`package`
                when {
                    fb != null -> view.loadUrl(fb)
                    pkg != null -> try {
                        startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("market://details?id=$pkg")))
                    } catch (_: Exception) { toast("Chưa cài app để mở link này") }
                    else -> toast("Chưa cài app để mở link này")
                }
            }
            true
        } catch (e: Exception) { toast("Không mở được link"); true }
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        leaving = true
                        Store.clearSession(this)
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        leaving = true
        Store.clearSession(this)
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        // Còn lịch sử thì lùi trang; ở trang đầu tiên thì chặn, không thoát (dùng nút ← để về home)
        if (web.canGoBack()) web.goBack()
    }

    // Nút ← góc trên trái: về thẳng màn hình chính, không back từng trang
    private fun goHome() {
        if (isNew && !saved) confirmDiscard()
        else { leaving = true; Store.clearSession(this); finish() }
    }

    private fun confirmDiscard() {
        AlertDialog.Builder(this)
            .setTitle("Bỏ tài khoản này?")
            .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
            .setPositiveButton("Bỏ") { _, _ -> discard() }
            .setNegativeButton("Ở lại", null).show()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        if (::profile.isInitialized) out.putString("profile", profile)
    }

    // Rời màn hình (đa nhiệm, mở app khác, bị kill...) -> lưu phiên + ghi cookie xuống đĩa
    override fun onPause() {
        super.onPause()
        if (!leaving && !isFinishing && ::cm.isInitialized) {
            Store.saveSession(this, profile, title, currentUrl, isNew, sync = true)
            cm.flush()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
