package com.example.vbrowser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class WebActivity : Activity() {
    companion object {
        const val UA = "Mozilla/5.0 (Linux; iPhone; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36"
    }
    private lateinit var web: WebView
    private lateinit var profile: String
    private lateinit var cm: CookieManager
    private lateinit var urlInput: EditText
    private var isNew = false
    private var saved = false
    private var destroyed = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Máy chưa hỗ trợ nhiều profile WebView. Hãy cập nhật Android System WebView.", Toast.LENGTH_LONG).show()
            finish(); return
        }
        isNew = intent.getBooleanExtra("new", false)
        val startUrl = intent.getStringExtra("url") ?: "https://app.golike.net/home"
        profile = intent.getStringExtra("profile") ?: ("acc_" + UUID.randomUUID().toString().replace("-", ""))
        cm = ProfileStore.getInstance().getOrCreateProfile(profile).cookieManager

        web = WebView(this)
        WebViewCompat.setProfile(web, profile) 
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = UA
        // Đặt chung với UA: sec-ch-ua-platform = "iOS" cho MỌI request (kể cả POST)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
            try {
                fun bv(b: String, v: String) = UserAgentMetadata.BrandVersion.Builder()
                    .setBrand(b).setMajorVersion(v).setFullVersion("$v.0.0.0").build()
                val md = UserAgentMetadata.Builder()
                    .setBrandVersionList(listOf(bv("Android WebView", "153"), bv("Not_A Brand", "8"), bv("Chromium", "153")))
                    .setFullVersion("153.0.0.0")
                    .setPlatform("iOS")
                    .setMobile(true)
                    .build()
                WebSettingsCompat.setUserAgentMetadata(web.settings, md)
            } catch (e: Throwable) {
                Toast.makeText(this, "Không set được UA metadata: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "WebView không hỗ trợ USER_AGENT_METADATA", Toast.LENGTH_LONG).show()
        }
        web.webViewClient = object : WebViewClient() {
            // Link mà app khác hỗ trợ (fb://, intent://, zalo://, tel:, ... hoặc link https có app xử lý) -> mở app
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                val isWeb = url.startsWith("http://") || url.startsWith("https://")
                return if (isWeb) openInApp(url, req) else openScheme(view, url)
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (url != null && ::urlInput.isInitialized && !urlInput.hasFocus()) urlInput.setText(url)
            }
            // Tự gửi request GET để đổi sec-ch-ua-platform thành "iOS"
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val url = req.url.toString()
                if (req.method != "GET" || !url.startsWith("http")) return null
                return try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "GET"
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = !req.isForMainFrame
                    req.requestHeaders.forEach { (k, v) ->
                        if (k.equals("sec-ch-ua-platform", true)) {
                            c.setRequestProperty(k, "\"iOS\"")
                        } else if (
                            !k.equals("Accept-Encoding", true) &&
                            !k.equals("User-Agent", true) &&
                            !k.equals("Cookie", true)) c.setRequestProperty(k, v)
                    }
                    c.setRequestProperty("User-Agent", UA)
                    cm.getCookie(url)?.let { c.setRequestProperty("Cookie", it) }

                    val code = c.responseCode
                    c.headerFields["Set-Cookie"]?.forEach { cm.setCookie(url, it) }
                    // redirect trang chính: để WebView tự xử lý để URL đổi đúng
                    if (code in 300..399) { c.disconnect(); return null }

                    val ct = c.contentType ?: "text/html"
                    val mime = ct.substringBefore(';').trim()
                    val enc = Regex("charset=([^;]+)", RegexOption.IGNORE_CASE)
                        .find(ct)?.groupValues?.get(1)?.trim()
                    val hdr = mutableMapOf<String, String>()
                    c.headerFields.forEach { (k, v) ->
                        if (k != null && !k.equals("Set-Cookie", true) &&
                            !k.equals("Content-Encoding", true) &&
                            !k.equals("Content-Length", true) &&
                            !k.equals("Transfer-Encoding", true)) hdr[k] = v.joinToString(",")
                    }
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    WebResourceResponse(mime, enc, code,
                        c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK", hdr, stream)
                } catch (e: Exception) { null }
            }
        }

        val back = Button(this).apply { text = "←"; setOnClickListener { goHome() } }
        urlInput = EditText(this).apply {
            hint = "Nhập URL..."
            setSingleLine()
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> web.loadUrl(normalizeUrl(text.toString())); clearFocus(); true }
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setText(startUrl)
        }
        val goBtn = Button(this).apply {
            text = "Đi"
            setOnClickListener { web.loadUrl(normalizeUrl(urlInput.text.toString())) }
        }
        
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 72, 8, 8)
            addView(back)
            addView(urlInput)
            addView(goBtn)
            if (isNew) addView(Button(this@WebActivity).apply {
                text = "LƯU"
                setOnClickListener { showSaveDialog() }
            })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.loadUrl(startUrl)
    }

    // Link https: chỉ mở app khi người dùng bấm vào link và có app (không phải trình duyệt) nhận link đó
    private fun openInApp(url: String, req: WebResourceRequest): Boolean {
        if (android.os.Build.VERSION.SDK_INT < 30) return false
        if (!req.isForMainFrame || !req.hasGesture()) return false
        val host = req.url.host ?: return false
        if (host == "golike.net" || host.endsWith(".golike.net")) return false
        return try {
            val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                .addCategory(android.content.Intent.CATEGORY_BROWSABLE)
                .addFlags(android.content.Intent.FLAG_ACTIVITY_REQUIRE_NON_BROWSER)
            startActivity(i)
            true
        } catch (e: Exception) { false }
    }

    // Link scheme khác (intent://, fb://, tel:, mailto:, market:, ...)
    private fun openScheme(view: WebView, url: String): Boolean {
        return try {
            val i = if (url.startsWith("intent:"))
                android.content.Intent.parseUri(url, android.content.Intent.URI_INTENT_SCHEME)
            else android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            i.addCategory(android.content.Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            try {
                startActivity(i)
            } catch (e: android.content.ActivityNotFoundException) {
                val fb = i.getStringExtra("browser_fallback_url")
                val pkg = i.`package`
                when {
                    fb != null -> view.loadUrl(fb)
                    pkg != null -> try {
                        startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("market://details?id=$pkg")))
                    } catch (_: Exception) { toast("Chưa cài app để mở link này") }
                    else -> toast("Chưa cài app để mở link này")
                }
            }
            true
        } catch (e: Exception) { toast("Không mở được link"); true }
    }

    private fun showSaveDialog() {
        val input = EditText(this).apply { hint = "Nhập user Golike" }
        AlertDialog.Builder(this).setTitle("Lưu tài khoản").setView(input)
            .setPositiveButton("Lưu") { _, _ ->
                val name = input.text.toString().trim()
                val list = Store.all(this)
                when {
                    name.isEmpty() -> toast("Chưa nhập user")
                    list.any { it.name == name } -> toast("User này đã có")
                    else -> {
                        list.add(Account(profile, name))
                        Store.save(this, list)
                        saved = true
                        finish()
                    }
                }
            }.setNegativeButton("Hủy", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun discard() {
        destroyWeb()
        try { ProfileStore.getInstance().deleteProfile(profile) } catch (_: Exception) {}
        finish()
    }

    private fun destroyWeb() {
        if (destroyed) return
        destroyed = true
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::web.isInitialized) { finish(); return }
        // Còn lịch sử thì lùi trang; ở trang đầu tiên thì chặn, không thoát (dùng nút ← để về home)
        if (web.canGoBack()) web.goBack()
    }

    // Nút ← góc trên trái: về thẳng màn hình chính, không back từng trang
    private fun goHome() {
        if (isNew && !saved) confirmDiscard() else finish()
    }

    private fun confirmDiscard() {
        AlertDialog.Builder(this)
            .setTitle("Bỏ tài khoản này?")
            .setMessage("Chưa lưu, dữ liệu đăng nhập sẽ bị xóa.")
            .setPositiveButton("Bỏ") { _, _ -> discard() }
            .setNegativeButton("Ở lại", null).show()
    }

    override fun onDestroy() {
        if (::web.isInitialized) destroyWeb()
        super.onDestroy()
    }
}
