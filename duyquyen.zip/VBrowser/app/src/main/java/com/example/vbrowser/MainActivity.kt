package com.example.vbrowser

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    companion object {
        const val SHOPEE_PACKAGE = "com.shopee.vn"
    }

    private lateinit var mainBtn: Button
    private lateinit var status: TextView
    private lateinit var scrim: View
    private lateinit var drawer: LinearLayout
    private var drawerW = 0
    private var drawerOpen = false
    private var currentUrl: String? = null
    private var loading = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        drawerW = (resources.displayMetrics.widthPixels * 0.7f).toInt()

        mainBtn = Button(this).apply {
            text = "Get link"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#2563EB"))
            setOnClickListener { onMainClick() }
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), dp(24))
        }
        val content = FrameLayout(this).apply {
            addView(mainBtn, FrameLayout.LayoutParams(dp(160), dp(56), Gravity.CENTER))
            addView(status, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F3F4F6"))
            addView(topBar("☰", "VBrowser") { setDrawer(true) }, LinearLayout.LayoutParams(-1, -2))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        scrim = View(this).apply {
            setBackgroundColor(0x66000000)
            alpha = 0f
            visibility = View.GONE
            setOnClickListener { setDrawer(false) }
        }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(0, 96, 0, 0)
            translationX = -drawerW.toFloat()
            elevation = 16f
            addView(drawerItem("⚙  Setting") {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }, LinearLayout.LayoutParams(-1, -2))
        }

        val root = FrameLayout(this).apply {
            addView(page, FrameLayout.LayoutParams(-1, -1))
            addView(scrim, FrameLayout.LayoutParams(-1, -1))
            addView(drawer, FrameLayout.LayoutParams(drawerW, -1))
        }
        setContentView(root)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun drawerItem(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 18f
        setPadding(48, 36, 48, 36)
        pressable(this)
        setOnClickListener { setDrawer(false); onClick() }
    }

    // Chỉ chấp nhận link http(s) của shopee.vn
    private fun checkShopeeUrl(raw: String): Uri {
        val uri = Uri.parse(raw.trim())
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https")
            throw IllegalArgumentException("Giao thức link không hợp lệ")
        val host = uri.host?.lowercase() ?: ""
        if (host != "shopee.vn" && !host.endsWith(".shopee.vn"))
            throw IllegalArgumentException("Link không thuộc Shopee Việt Nam")
        return uri
    }

    private fun onMainClick() {
        if (loading) return

        // Đã có link: bấm lần nữa để mở Shopee
        val url = currentUrl
        if (url != null) {
            currentUrl = null
            mainBtn.text = "Get link"
            status.text = "Đang mở Shopee..."
            try {
                val i = Intent(Intent.ACTION_VIEW, checkShopeeUrl(url))
                    .addCategory(Intent.CATEGORY_BROWSABLE)
                    .setPackage(SHOPEE_PACKAGE)
                startActivity(i)
            } catch (e: ActivityNotFoundException) {
                status.text = "Chưa cài app Shopee"
            } catch (e: Exception) {
                status.text = e.message ?: "Không mở được link"
            }
            return
        }

        getLink()
    }

    private fun getLink() {
        val api = Store.apiServer(this)
        if (api.isEmpty()) { toast("Chưa cài API server (Menu → Setting)"); return }

        loading = true
        mainBtn.isEnabled = false
        mainBtn.alpha = 0.6f
        mainBtn.text = "Đang lấy link..."
        status.text = ""

        Thread {
            var link: String? = null
            var err: String? = null
            try {
                val c = URL("$api/golike/getjob.php").openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.useCaches = false
                try {
                    if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
                    val body = c.inputStream.bufferedReader().use { it.readText() }
                    val o = JSONObject(body)
                    val u = o.optJSONObject("data")?.optString("url", "")
                    if (o.optBoolean("success", false) && !u.isNullOrEmpty()) {
                        checkShopeeUrl(u) // kiểm tra trước khi lưu
                        link = u
                    }
                } finally { c.disconnect() }
            } catch (e: IOException) {
                err = "Lỗi kết nối máy chủ"
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
            }

            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                loading = false
                mainBtn.isEnabled = true
                mainBtn.alpha = 1f
                when {
                    err != null -> { mainBtn.text = "Get link"; status.text = err }
                    link == null -> { mainBtn.text = "Get link"; status.text = "Không có link Shopee phù hợp" }
                    else -> {
                        currentUrl = link
                        mainBtn.text = "Mở"
                        status.text = "Đã lấy link Shopee thành công"
                    }
                }
            }
        }.start()
    }

    private fun setDrawer(open: Boolean) {
        drawerOpen = open
        if (open) scrim.visibility = View.VISIBLE
        scrim.animate().alpha(if (open) 1f else 0f).setDuration(200).start()
        drawer.animate().translationX(if (open) 0f else -drawerW.toFloat()).setDuration(200)
            .withEndAction { if (!drawerOpen) scrim.visibility = View.GONE }.start()
    }

    // Back không bao giờ thoát app: chỉ đóng drawer nếu đang mở
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) setDrawer(false)
    }

}
